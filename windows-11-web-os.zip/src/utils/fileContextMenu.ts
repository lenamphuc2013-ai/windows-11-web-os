import { ContextMenuItem, FileSystemItem } from '../types';

interface GenerateFileContextMenuOptions {
  item: FileSystemItem;
  onOpen: (item: FileSystemItem) => void;
  onOpenNewWindow?: (item: FileSystemItem) => void;
  onDelete: (item: FileSystemItem) => void;
  onRename?: (item: FileSystemItem) => void;
  onProperties: (item: FileSystemItem) => void;
  onDefenderScan: (item: FileSystemItem) => void;
  onPinQuickAccess?: (item: FileSystemItem) => void;
  onAddToArchive?: (item: FileSystemItem, format?: 'rar' | 'zip' | 'iso') => void;
  onCreateShortcut?: (item: FileSystemItem) => void;
  onSendToDesktop?: (item: FileSystemItem) => void;
  onSendToDocs?: (item: FileSystemItem) => void;
  onSendToZip?: (item: FileSystemItem) => void;
  onSendToMail?: (item: FileSystemItem) => void;
  onSendToBluetooth?: (item: FileSystemItem) => void;
  onIncludeInLibrary?: (item: FileSystemItem, lib: 'docs' | 'pics' | 'music' | 'vids') => void;
  onRestoreVersions?: (item: FileSystemItem) => void;
  onCopy?: (item: FileSystemItem) => void;
  onCut?: (item: FileSystemItem) => void;
  onSetAsWallpaper?: (item: FileSystemItem) => void;
  notify?: (title: string, message: string, type?: 'info' | 'system' | 'security') => void;
}

export const generateFileContextMenu = ({
  item,
  onOpen,
  onOpenNewWindow,
  onDelete,
  onRename,
  onProperties,
  onDefenderScan,
  onPinQuickAccess,
  onAddToArchive,
  onCreateShortcut,
  onSendToDesktop,
  onSendToDocs,
  onSendToZip,
  onSendToMail,
  onSendToBluetooth,
  onIncludeInLibrary,
  onRestoreVersions,
  onCopy,
  onCut,
  onSetAsWallpaper,
  notify,
}: GenerateFileContextMenuOptions): ContextMenuItem[] => {
  const baseName = item.name.replace(/\.[^/.]+$/, '');
  const rarName = `${item.isDirectory ? item.name : baseName}.rar`;
  const isImageFile = !item.isDirectory && (/\.(png|jpe?g|webp|svg|gif|bmp)$/i.test(item.name) || (item.content && item.content.startsWith('data:image')));

  return [
    {
      id: `open-${item.id}`,
      label: 'Mở',
      icon: 'FolderOpen',
      onClick: () => onOpen(item),
    },
    ...(isImageFile
      ? [
          {
            id: `set-wallpaper-${item.id}`,
            label: 'Đặt làm hình nền Desktop',
            icon: 'Image',
            onClick: () => {
              if (onSetAsWallpaper) onSetAsWallpaper(item);
              else if (notify) notify('Cá nhân hóa', `Đã đặt "${item.name}" làm hình nền Desktop`, 'system');
            },
          },
        ]
      : []),
    {
      id: `open-new-win-${item.id}`,
      label: 'Mở trong cửa sổ mới',
      icon: 'ExternalLink',
      onClick: () => (onOpenNewWindow ? onOpenNewWindow(item) : onOpen(item)),
    },
    {
      id: `pin-quick-${item.id}`,
      label: 'Ghim vào Truy cập nhanh',
      icon: 'Pin',
      onClick: () => {
        if (onPinQuickAccess) onPinQuickAccess(item);
        else if (notify) notify('Truy cập nhanh', `Đã ghim "${item.name}" vào danh sách Truy cập nhanh`, 'info');
      },
    },
    {
      id: `defender-scan-${item.id}`,
      label: 'Quét bằng Microsoft Defender...',
      icon: 'Shield',
      onClick: () => onDefenderScan(item),
    },
    { separator: true, id: `sep-sec-${item.id}`, label: '' },
    {
      id: `give-access-${item.id}`,
      label: 'Cho phép truy nhập vào',
      icon: 'Share2',
      submenu: [
        {
          id: `access-remove-${item.id}`,
          label: 'Xóa quyền truy cập',
          icon: 'Ban',
          onClick: () => {
            if (notify) notify('Chia sẻ tệp', `Đã đóng chia sẻ mạng nội bộ cho "${item.name}"`, 'security');
          },
        },
        {
          id: `access-specific-${item.id}`,
          label: 'Người dùng cụ thể...',
          icon: 'UserCheck',
          onClick: () => {
            onProperties(item);
          },
        },
      ],
    },
    {
      id: `restore-versions-${item.id}`,
      label: 'Khôi phục các phiên bản trước',
      icon: 'RotateCcw',
      onClick: () => {
        if (onRestoreVersions) onRestoreVersions(item);
        else onProperties(item);
      },
    },
    {
      id: `include-library-${item.id}`,
      label: 'Bao gồm trong thư viện',
      icon: 'FolderPlus',
      submenu: [
        {
          id: `lib-docs-${item.id}`,
          label: 'Tài liệu (Documents)',
          icon: 'FileText',
          onClick: () => {
            if (onIncludeInLibrary) onIncludeInLibrary(item, 'docs');
            else if (notify) notify('Thư viện', `Đã thêm "${item.name}" vào Thư viện Tài liệu`, 'info');
          },
        },
        {
          id: `lib-pics-${item.id}`,
          label: 'Hình ảnh (Pictures)',
          icon: 'Image',
          onClick: () => {
            if (onIncludeInLibrary) onIncludeInLibrary(item, 'pics');
            else if (notify) notify('Thư viện', `Đã thêm "${item.name}" vào Thư viện Hình ảnh`, 'info');
          },
        },
        {
          id: `lib-music-${item.id}`,
          label: 'Âm nhạc (Music)',
          icon: 'Music',
          onClick: () => {
            if (onIncludeInLibrary) onIncludeInLibrary(item, 'music');
            else if (notify) notify('Thư viện', `Đã thêm "${item.name}" vào Thư viện Âm nhạc`, 'info');
          },
        },
        {
          id: `lib-vids-${item.id}`,
          label: 'Video (Videos)',
          icon: 'Video',
          onClick: () => {
            if (onIncludeInLibrary) onIncludeInLibrary(item, 'vids');
            else if (notify) notify('Thư viện', `Đã thêm "${item.name}" vào Thư viện Video`, 'info');
          },
        },
      ],
    },
    { separator: true, id: `sep-winrar-${item.id}`, label: '' },
    {
      id: `winrar-add-${item.id}`,
      label: 'Thêm vào tập lưu trữ...',
      icon: 'Archive',
      onClick: () => {
        if (onAddToArchive) onAddToArchive(item, 'rar');
        else if (notify) notify('WinRAR', `Đã tạo tệp nén "${rarName}"`, 'info');
      },
    },
    {
      id: `winrar-add-named-${item.id}`,
      label: `Thêm vào "${rarName}"`,
      icon: 'Archive',
      onClick: () => {
        if (onAddToArchive) onAddToArchive(item, 'rar');
        else if (notify) notify('WinRAR', `Đã tạo tệp nén lưu trữ "${rarName}" thành công!`, 'info');
      },
    },
    {
      id: `winrar-compress-email-${item.id}`,
      label: 'Nén và gửi email...',
      icon: 'Mail',
      onClick: () => {
        if (onAddToArchive) onAddToArchive(item, 'rar');
        if (onSendToMail) onSendToMail(item);
        else if (notify) notify('Email', `Đã nén và chuẩn bị đính kèm "${rarName}" vào thư mới`, 'info');
      },
    },
    {
      id: `winrar-compress-named-email-${item.id}`,
      label: `Nén vào "${rarName}" và gửi email`,
      icon: 'Mail',
      onClick: () => {
        if (onAddToArchive) onAddToArchive(item, 'rar');
        if (onSendToMail) onSendToMail(item);
        else if (notify) notify('Email', `Đã đính kèm "${rarName}" vào thư mới`, 'info');
      },
    },
    {
      id: `poweriso-${item.id}`,
      label: 'PowerISO',
      icon: 'Disc',
      submenu: [
        {
          id: `piso-make-${item.id}`,
          label: 'Tạo tệp hình ảnh ISO...',
          icon: 'Disc',
          onClick: () => {
            if (onAddToArchive) onAddToArchive(item, 'iso');
            else if (notify) notify('PowerISO', `Đã tạo tệp hình ảnh ISO từ "${item.name}"`, 'info');
          },
        },
        {
          id: `piso-add-${item.id}`,
          label: 'Thêm vào hình ảnh...',
          icon: 'PlusCircle',
          onClick: () => {
            if (onAddToArchive) onAddToArchive(item, 'iso');
            else if (notify) notify('PowerISO', `Đã thêm "${item.name}" vào danh sách ảnh đĩa ISO`, 'info');
          },
        },
      ],
    },
    { separator: true, id: `sep-sendto-${item.id}`, label: '' },
    {
      id: `send-to-${item.id}`,
      label: 'Gửi tới (Send to)',
      icon: 'Send',
      submenu: [
        {
          id: `send-bt-${item.id}`,
          label: 'Thiết bị Bluetooth',
          icon: 'Bluetooth',
          onClick: () => {
            if (onSendToBluetooth) onSendToBluetooth(item);
            else if (notify) notify('Bluetooth', 'Đang quét tìm thiết bị nhận lân cận...', 'info');
          },
        },
        {
          id: `send-zip-${item.id}`,
          label: 'Thư mục nén (zipped)',
          icon: 'Archive',
          onClick: () => {
            if (onSendToZip) onSendToZip(item);
            else if (onAddToArchive) onAddToArchive(item, 'zip');
            else if (notify) notify('Nén tệp', `Đã tạo tệp "${baseName}.zip"`, 'info');
          },
        },
        {
          id: `send-desktop-${item.id}`,
          label: 'Màn hình nền (tạo lối tắt)',
          icon: 'Monitor',
          onClick: () => {
            if (onSendToDesktop) onSendToDesktop(item);
            else if (notify) notify('Lối tắt', `Đã tạo lối tắt cho "${item.name}" trên Desktop!`, 'info');
          },
        },
        {
          id: `send-mail-${item.id}`,
          label: 'Người nhận thư',
          icon: 'Mail',
          onClick: () => {
            if (onSendToMail) onSendToMail(item);
            else if (notify) notify('Mail', `Đã mở thư mới cho "${item.name}"`, 'info');
          },
        },
        {
          id: `send-docs-${item.id}`,
          label: 'Tài liệu (Documents)',
          icon: 'FileText',
          onClick: () => {
            if (onSendToDocs) onSendToDocs(item);
            else if (notify) notify('Tài liệu', `Đã gửi bản sao của "${item.name}" vào Documents`, 'info');
          },
        },
      ],
    },
    { separator: true, id: `sep-crud-${item.id}`, label: '' },
    {
      id: `cut-${item.id}`,
      label: 'Cắt (Cut)',
      icon: 'Scissors',
      shortcut: 'Ctrl+X',
      onClick: () => {
        if (onCut) onCut(item);
        else if (notify) notify('Clipboard', `Đã cắt "${item.name}"`, 'info');
      },
    },
    {
      id: `copy-${item.id}`,
      label: 'Sao chép (Copy)',
      icon: 'Copy',
      shortcut: 'Ctrl+C',
      onClick: () => {
        if (onCopy) onCopy(item);
        else if (notify) notify('Clipboard', `Đã sao chép "${item.name}"`, 'info');
      },
    },
    {
      id: `shortcut-${item.id}`,
      label: 'Tạo lối tắt (Create shortcut)',
      icon: 'CornerUpRight',
      onClick: () => {
        if (onCreateShortcut) onCreateShortcut(item);
        else if (notify) notify('Lối tắt', `Đã tạo lối tắt cho "${item.name}"`, 'info');
      },
    },
    {
      id: `delete-${item.id}`,
      label: 'Xóa (Delete)',
      icon: 'Trash2',
      shortcut: 'Del',
      danger: true,
      onClick: () => onDelete(item),
    },
    {
      id: `rename-${item.id}`,
      label: 'Đổi tên (Rename)',
      icon: 'Edit3',
      shortcut: 'F2',
      onClick: () => {
        if (onRename) onRename(item);
      },
    },
    { separator: true, id: `sep-prop-${item.id}`, label: '' },
    {
      id: `properties-${item.id}`,
      label: 'Thuộc tính (Properties)',
      icon: 'Info',
      shortcut: 'Alt+Enter',
      onClick: () => onProperties(item),
    },
  ];
};
