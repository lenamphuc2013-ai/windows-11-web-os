import type React from 'react';
import { FileSystemItem } from '../types';
import { COMMAND_REGISTRY, COMMAND_GROUPS, getHelpForCommand } from './cmdCommandsData';
import { generateDxDiagReportText } from '../components/Apps/DxDiagDialog';
import { parseControlCommand, CONTROL_HELP_TEXT } from './controlPanelData';
import { formatPSVersionTable, handlePSVersionTableAccess } from './powerShellEngine';

export interface TerminalOutputLine {
  id: string;
  type: 'input' | 'output' | 'error' | 'success' | 'system' | 'info' | 'ascii';
  text: string;
}

export interface CmdContext {
  currentDir: string;
  setCurrentDir: (dir: string) => void;
  envVars: Record<string, string>;
  setEnvVars: React.Dispatch<React.SetStateAction<Record<string, string>>>;
  fileSystem: FileSystemItem[];
  getFilesByDirectory: (dir: string) => FileSystemItem[];
  addFile: (file: Omit<FileSystemItem, 'id' | 'createdAt' | 'modifiedAt'>) => FileSystemItem;
  deleteFile: (id: string, hardDelete?: boolean) => void;
  takeOwnership: (target: string) => { success: boolean; path?: string };
  grantPermission: (target: string) => { success: boolean; notOwned?: boolean; path?: string };
  openApp: (appId: string, params?: Record<string, unknown>) => void;
  closeWindow: (windowId: string) => void;
  windows: Array<{ id: string; appId: string; title: string }>;
  addNotification: (title: string, message: string, icon?: string) => void;
  restartSystem: () => void;
  shutdownSystem: () => void;
  restartToWinRE: () => void;
  setIsLockScreen: (locked: boolean) => void;
  enterSleepMode: () => void;
  setTitle: (title: string) => void;
  setPromptTemplate: (tmpl: string) => void;
  promptTemplate: string;
  dirStack: string[];
  setDirStack: React.Dispatch<React.SetStateAction<string[]>>;
  createHtmlApp?: (title: string, icon: string, htmlContent: string, category?: string) => FileSystemItem;
  restoreFromRestorePoint?: () => void;
  repairStartup?: () => void;
  clearSystemFailure?: () => void;
  renameFile?: (idOrPath: string, newName: string) => boolean;
  updateFileContent?: (path: string, content: string) => void;
  setColor?: (bg: string, fg: string) => void;
}

export const WINDOWS_COLOR_MAP: Record<string, string> = {
  '0': '#0c0c0c', // Đen
  '1': '#0037da', // Xanh dương đậm
  '2': '#13a10e', // Xanh lá đậm
  '3': '#3a96dd', // Xanh ngọc đậm
  '4': '#c50f1f', // Đỏ đậm
  '5': '#881798', // Tím đậm
  '6': '#c19c00', // Vàng đậm / Nâu
  '7': '#cccccc', // Trắng xám
  '8': '#767676', // Xám đậm
  '9': '#3b78ff', // Xanh dương sáng
  'a': '#16c60c', // Xanh lá sáng
  'b': '#61d6d6', // Xanh ngọc sáng
  'c': '#e74856', // Đỏ sáng
  'd': '#b4009e', // Tím sáng
  'e': '#f9f1a5', // Vàng sáng
  'f': '#ffffff', // Trắng sáng
};

// Expand %VAR% environment variables
export function expandEnvVars(text: string, envVars: Record<string, string>): string {
  return text.replace(/%([^%]+)%/g, (_, varName) => {
    const key = varName.toUpperCase();
    if (key === 'DATE') return new Date().toLocaleDateString('vi-VN');
    if (key === 'TIME') return new Date().toLocaleTimeString('vi-VN');
    if (key === 'CD') return envVars['USERPROFILE'] || 'C:\\Users\\User';
    if (key === 'ERRORLEVEL') return '0';
    if (key === 'RANDOM') return Math.floor(Math.random() * 32768).toString();
    return envVars[key] !== undefined ? envVars[key] : `%${varName}%`;
  });
}

// Generate the command prompt string based on template
export function formatPrompt(template: string, currentDir: string, envVars: Record<string, string>): string {
  if (!template) {
    return `PS ${currentDir}> `;
  }

  let result = template;
  result = result.replace(/\$p/gi, currentDir);
  result = result.replace(/\$g/gi, '>');
  result = result.replace(/\$l/gi, '<');
  result = result.replace(/\$b/gi, '|');
  result = result.replace(/\$q/gi, '=');
  result = result.replace(/\$h/gi, '');
  result = result.replace(/\$e/gi, '\x1b');
  result = result.replace(/\$t/gi, new Date().toLocaleTimeString('en-US', { hour12: false }));
  result = result.replace(/\$d/gi, new Date().toLocaleDateString('en-US'));
  result = result.replace(/\$v/gi, 'Microsoft Windows [Version 10.0.22631.3296]');
  result = result.replace(/\$n/gi, currentDir.charAt(0) || 'C');
  result = result.replace(/\$_/gi, '\n');
  result = result.replace(/\$\$/gi, '$');

  result = expandEnvVars(result, envVars);
  return result.endsWith(' ') ? result : result + ' ';
}

// Helper to resolve paths relative to currentDir
export function resolvePath(target: string, currentDir: string): string {
  if (!target) return currentDir;
  let clean = target.replace(/^"+|"+$/g, '').trim();
  if (clean.startsWith('C:') || clean.startsWith('c:') || clean.startsWith('D:') || clean.startsWith('d:')) {
    return clean;
  }
  if (clean === '..') {
    const lastSlash = Math.max(currentDir.lastIndexOf('\\'), currentDir.lastIndexOf('/'));
    return lastSlash > 2 ? currentDir.substring(0, lastSlash) : 'C:';
  }
  if (clean === '.' || clean === '.\\') return currentDir;
  if (clean.startsWith('\\') || clean.startsWith('/')) {
    return `C:${clean}`;
  }
  return `${currentDir}\\${clean}`.replace(/\\\\/g, '\\');
}

// Helper to match wildcards (*, ?)
export function matchDirWildcard(filename: string, pattern: string): boolean {
  if (!pattern || pattern === '*' || pattern === '*.*') return true;
  const escaped = pattern
    .replace(/\\/g, '\\\\')
    .replace(/\./g, '\\.')
    .replace(/\+/g, '\\+')
    .replace(/\$/g, '\\$')
    .replace(/\^/g, '\\^')
    .replace(/\*/g, '.*')
    .replace(/\?/g, '.');
  try {
    const reg = new RegExp(`^${escaped}$`, 'i');
    return reg.test(filename);
  } catch {
    return filename.toLowerCase() === pattern.toLowerCase();
  }
}

// 8.3 Short Name generator for /X
function getDosShortName(name: string, isDirectory: boolean): string {
  const parts = name.split('.');
  const baseName = parts[0] || '';
  const ext = parts.length > 1 ? parts[parts.length - 1] : '';

  if (!name.includes(' ') && baseName.length <= 8 && ext.length <= 3 && parts.length <= 2) {
    return ''.padEnd(14, ' ');
  }

  const cleanBase = baseName.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
  const cleanExt = ext.replace(/[^a-zA-Z0-9]/g, '').toUpperCase().slice(0, 3);
  const prefix = (cleanBase.slice(0, 6) || 'NAME') + '~1';
  const shortName = cleanExt ? `${prefix}.${cleanExt}` : prefix;
  return shortName.padEnd(14, ' ');
}

// Owner resolver for /Q
function getDosOwner(item: FileSystemItem): string {
  if (item.owner) return item.owner.padEnd(23, ' ');
  const p = item.path.toLowerCase();
  if (p.includes('\\windows\\system32') || item.isCriticalSystemFile) {
    return 'NT SERVICE\\TrustedInst '.padEnd(23, ' ');
  }
  if (p.startsWith('c:\\windows') || p.startsWith('c:\\program files')) {
    return 'BUILTIN\\Administrators '.padEnd(23, ' ');
  }
  return 'DESKTOP-WIN11\\User      '.padEnd(23, ' ');
}

// Complete Windows 11 DIR command implementation
export function executeDirCommand(
  rawTokens: string[],
  ctx: CmdContext
): TerminalOutputLine[] {
  const output: TerminalOutputLine[] = [];

  let flags: string[] = [];
  let pathTargets: string[] = [];

  for (const token of rawTokens) {
    if (token.toLowerCase().startsWith('dir/')) {
      const switchPart = token.substring(3);
      const subSwitches = switchPart.split(/(?=\/)/g).filter(Boolean);
      flags.push(...subSwitches);
    } else if (token.toLowerCase().startsWith('dir\\')) {
      const targetPart = token.substring(3);
      pathTargets.push(targetPart);
    } else if (
      token.startsWith('/') ||
      (token.startsWith('-') && token.length > 1 && !token.startsWith('-C') && !token.startsWith('-c') && isNaN(Number(token)))
    ) {
      const subSwitches = token.split(/(?=\/)/g).filter(Boolean);
      flags.push(...subSwitches);
    } else if (token.toLowerCase() === 'dir') {
      // ignore
    } else {
      pathTargets.push(token);
    }
  }

  let isPause = false;
  let isWide = false;
  let isColWide = false;
  let isBare = false;
  let isRecursive = false;
  let isLowercase = false;
  let isShortNames = false;
  let isShowOwner = false;
  let isShowADS = false;
  let isVerbose = false;
  let noComma = false;
  let fourDigitYear = true;
  let timeField: 'C' | 'A' | 'W' = 'W';
  let hasAttributeFilter = false;
  let attributeFilters: string[] = [];
  let sortOrders: string[] = [];

  for (const f of flags) {
    const clean = f.replace(/^[-/]/, '');
    const lower = clean.toLowerCase();

    if (lower === '?' || lower === 'help') {
      const doc = getHelpForCommand('dir');
      output.push({
        id: 'out-' + Date.now(),
        type: 'info',
        text: doc
          ? `[${doc.groupName.toUpperCase()}] ${doc.name.toUpperCase()}\n${doc.shortDesc}\n\nCú pháp:\n  ${doc.syntax}\n\nChi tiết:\n${doc.detailedHelp}`
          : 'Trợ giúp lệnh DIR',
      });
      return output;
    }

    if (lower === 'p') isPause = true;
    else if (lower === 'w') isWide = true;
    else if (lower === 'd') isColWide = true;
    else if (lower === 'b') isBare = true;
    else if (lower === 's') isRecursive = true;
    else if (lower === 'l') isLowercase = true;
    else if (lower === 'x') isShortNames = true;
    else if (lower === 'q') isShowOwner = true;
    else if (lower === 'r') isShowADS = true;
    else if (lower === 'v') isVerbose = true;
    else if (lower === '-c') noComma = true;
    else if (lower === '4') fourDigitYear = true;
    else if (lower.startsWith('t:') || lower.startsWith('t')) {
      const tVal = lower.replace(/^t:?/, '').toUpperCase();
      if (tVal === 'C') timeField = 'C';
      else if (tVal === 'A') timeField = 'A';
      else timeField = 'W';
    } else if (lower.startsWith('a')) {
      hasAttributeFilter = true;
      const aVal = clean.substring(1).replace(/^:/, '');
      if (aVal) {
        const matches = aVal.match(/-?[A-Za-z]/g) || [];
        attributeFilters.push(...matches);
      }
    } else if (lower.startsWith('o')) {
      const oVal = clean.substring(1).replace(/^:/, '');
      if (oVal) {
        const matches = oVal.match(/-?[A-Za-z]/g) || [];
        sortOrders.push(...matches);
      } else {
        sortOrders.push('G', 'N');
      }
    }
  }

  const rawTarget = pathTargets[0] || '';
  let targetDir = ctx.currentDir;
  let filePattern = '*.*';

  if (rawTarget) {
    const isDriveOnly = /^[a-zA-Z]:$/.test(rawTarget);
    if (isDriveOnly) {
      targetDir = rawTarget.toUpperCase();
      filePattern = '*.*';
    } else if (rawTarget.includes('*') || rawTarget.includes('?')) {
      const lastSlash = Math.max(rawTarget.lastIndexOf('\\'), rawTarget.lastIndexOf('/'));
      if (lastSlash >= 0) {
        const dirPart = rawTarget.substring(0, lastSlash);
        filePattern = rawTarget.substring(lastSlash + 1);
        targetDir = resolvePath(dirPart, ctx.currentDir);
      } else {
        filePattern = rawTarget;
        targetDir = ctx.currentDir;
      }
    } else {
      const resolved = resolvePath(rawTarget, ctx.currentDir);
      const isDir = ctx.fileSystem.some((f) => f.isDirectory && f.path.toLowerCase() === resolved.toLowerCase());
      if (isDir || resolved.toUpperCase() === 'C:' || resolved.toUpperCase() === 'C:\\') {
        targetDir = resolved;
        filePattern = '*.*';
      } else {
        const fileExists = ctx.fileSystem.some((f) => !f.isDirectory && f.path.toLowerCase() === resolved.toLowerCase());
        if (fileExists) {
          const lastSlash = Math.max(resolved.lastIndexOf('\\'), resolved.lastIndexOf('/'));
          targetDir = lastSlash > 2 ? resolved.substring(0, lastSlash) : 'C:';
          filePattern = resolved.substring(lastSlash + 1);
        } else {
          targetDir = resolved;
        }
      }
    }
  }

  const baseResolved = resolvePath(targetDir, ctx.currentDir);

  const filterByAttributes = (item: FileSystemItem): boolean => {
    if (!hasAttributeFilter) {
      if (item.hidden) return false;
      return true;
    }

    if (attributeFilters.length === 0) {
      return true;
    }

    for (const af of attributeFilters) {
      const isNeg = af.startsWith('-');
      const code = af.replace('-', '').toUpperCase();

      if (code === 'D') {
        if (isNeg && item.isDirectory) return false;
        if (!isNeg && !item.isDirectory) return false;
      } else if (code === 'H') {
        const isHidden = Boolean(item.hidden);
        if (isNeg && isHidden) return false;
        if (!isNeg && !isHidden) return false;
      } else if (code === 'S') {
        const isSystem = Boolean(item.isSystem || item.isCriticalSystemFile);
        if (isNeg && isSystem) return false;
        if (!isNeg && !isSystem) return false;
      } else if (code === 'R') {
        const isReadOnly = Boolean(item.isReadOnly || item.protectionLevel === 'KHÔNG XOÁ');
        if (isNeg && isReadOnly) return false;
        if (!isNeg && !isReadOnly) return false;
      } else if (code === 'A') {
        const isArchive = !item.isSystem;
        if (isNeg && isArchive) return false;
        if (!isNeg && !isArchive) return false;
      }
    }

    return true;
  };

  const sortItems = (items: FileSystemItem[]): FileSystemItem[] => {
    if (sortOrders.length === 0) {
      return [...items].sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));
    }

    return [...items].sort((a, b) => {
      for (const order of sortOrders) {
        const isNeg = order.startsWith('-');
        const code = order.replace('-', '').toUpperCase();

        if (code === 'G') {
          const aVal = a.isDirectory ? 1 : 0;
          const bVal = b.isDirectory ? 1 : 0;
          if (aVal !== bVal) {
            return isNeg ? aVal - bVal : bVal - aVal;
          }
        } else if (code === 'N') {
          const cmp = a.name.localeCompare(b.name, undefined, { sensitivity: 'base' });
          if (cmp !== 0) return isNeg ? -cmp : cmp;
        } else if (code === 'S') {
          const aSize = a.size || 0;
          const bSize = b.size || 0;
          if (aSize !== bSize) return isNeg ? bSize - aSize : aSize - bSize;
        } else if (code === 'E') {
          const aExt = a.name.includes('.') ? a.name.split('.').pop() || '' : '';
          const bExt = b.name.includes('.') ? b.name.split('.').pop() || '' : '';
          const cmp = aExt.localeCompare(bExt, undefined, { sensitivity: 'base' });
          if (cmp !== 0) return isNeg ? -cmp : cmp;
        } else if (code === 'D') {
          const aDate = typeof a.modifiedAt === 'number' ? a.modifiedAt : new Date(a.modifiedAt || 0).getTime();
          const bDate = typeof b.modifiedAt === 'number' ? b.modifiedAt : new Date(b.modifiedAt || 0).getTime();
          if (aDate !== bDate) return isNeg ? bDate - aDate : aDate - bDate;
        }
      }
      return 0;
    });
  };

  const directoriesToProcess: string[] = [baseResolved];

  if (isRecursive) {
    const allChildDirs = ctx.fileSystem
      .filter(
        (f) =>
          f.isDirectory &&
          f.path.toLowerCase().startsWith(baseResolved.toLowerCase()) &&
          f.path.toLowerCase() !== baseResolved.toLowerCase()
      )
      .map((f) => f.path);

    allChildDirs.sort((a, b) => a.localeCompare(b));
    directoriesToProcess.push(...allChildDirs);
  }

  if (isBare) {
    const bareLines: string[] = [];
    for (const dir of directoriesToProcess) {
      let items = ctx.getFilesByDirectory(dir);
      items = items.filter((f) => matchDirWildcard(f.name, filePattern) && filterByAttributes(f));
      items = sortItems(items);

      for (const item of items) {
        if (isRecursive) {
          const fullPath = isLowercase ? item.path.toLowerCase() : item.path;
          bareLines.push(fullPath);
        } else {
          const displayName = isLowercase ? item.name.toLowerCase() : item.name;
          bareLines.push(displayName);
        }
      }
    }

    if (bareLines.length === 0 && !isRecursive) {
      output.push({ id: 'err-' + Date.now(), type: 'error', text: 'File Not Found' });
      return output;
    }

    output.push({ id: 'out-' + Date.now(), type: 'output', text: bareLines.join('\n') });
    return output;
  }

  const lines: string[] = [
    ' Volume in drive C has no label.',
    ' Volume Serial Number is 4C19-82F0',
  ];

  let grandTotalFiles = 0;
  let grandTotalBytes = 0;
  let grandTotalDirs = 0;

  for (let dIdx = 0; dIdx < directoriesToProcess.length; dIdx++) {
    const curDir = directoriesToProcess[dIdx];
    let items = ctx.getFilesByDirectory(curDir);

    items = items.filter((f) => matchDirWildcard(f.name, filePattern) && filterByAttributes(f));
    items = sortItems(items);

    let dirFileCount = 0;
    let dirFileSize = 0;
    let dirFolderCount = 0;

    items.forEach((f) => {
      if (f.isDirectory) dirFolderCount++;
      else {
        dirFileCount++;
        dirFileSize += f.size || (f.content ? f.content.length : 0);
      }
    });

    grandTotalFiles += dirFileCount;
    grandTotalBytes += dirFileSize;
    grandTotalDirs += dirFolderCount;

    lines.push('');
    lines.push(` Directory of ${curDir}`);
    lines.push('');

    const formatDate = (item: FileSystemItem): string => {
      const getTs = (val?: number): Date => {
        if (typeof val === 'number') return new Date(val);
        return new Date('2026-08-30T02:00:00');
      };
      let d = getTs(item.modifiedAt);
      if (timeField === 'C' && item.createdAt) d = getTs(item.createdAt);
      if (timeField === 'A' && item.lastAccessedAt) d = getTs(item.lastAccessedAt);

      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      const yyyy = fourDigitYear ? String(d.getFullYear()) : String(d.getFullYear()).slice(-2);

      let hours = d.getHours();
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12;
      const hh = String(hours).padStart(2, '0');
      const min = String(d.getMinutes()).padStart(2, '0');

      return `${mm}/${dd}/${yyyy}  ${hh}:${min} ${ampm}`;
    };

    if (isWide || isColWide) {
      const displayNames = items.map((f) => {
        let name = f.isDirectory ? `[${f.name}]` : f.name;
        if (isLowercase) name = name.toLowerCase();
        return name;
      });

      const colCount = 5;
      const colWidth = 15;

      if (isWide) {
        let row = '';
        for (let i = 0; i < displayNames.length; i++) {
          row += displayNames[i].padEnd(colWidth, ' ');
          if ((i + 1) % colCount === 0 || i === displayNames.length - 1) {
            lines.push(row);
            row = '';
          }
        }
      } else {
        const total = displayNames.length;
        const rowCount = Math.ceil(total / colCount);
        for (let r = 0; r < rowCount; r++) {
          let rowStr = '';
          for (let c = 0; c < colCount; c++) {
            const idx = c * rowCount + r;
            if (idx < total) {
              rowStr += displayNames[idx].padEnd(colWidth, ' ');
            }
          }
          lines.push(rowStr);
        }
      }
    } else {
      if (filePattern === '*.*' || filePattern === '*') {
        lines.push(`08/30/2026  02:00 AM    <DIR>          .`);
        lines.push(`08/30/2026  02:00 AM    <DIR>          ..`);
      }

      for (const item of items) {
        const dateStr = formatDate(item);
        const ownerStr = isShowOwner ? getDosOwner(item) : '';
        const shortNameStr = isShortNames ? getDosShortName(item.name, item.isDirectory) : '';
        const name = isLowercase ? item.name.toLowerCase() : item.name;

        let typeOrSize = '';
        if (item.isDirectory) {
          typeOrSize = '   <DIR>          ';
        } else {
          const sz = item.size || (item.content ? item.content.length : 0);
          const formattedSz = noComma ? String(sz) : sz.toLocaleString('en-US');
          typeOrSize = formattedSz.padStart(17, ' ') + ' ';
        }

        const line = `${dateStr}  ${ownerStr}${typeOrSize}${shortNameStr}${name}`;
        lines.push(line);

        if (isShowADS && !item.isDirectory) {
          lines.push(`               0 ${name}:$DATA`);
        }
      }
    }

    const formattedDirBytes = noComma ? String(dirFileSize) : dirFileSize.toLocaleString('en-US');
    lines.push(`              ${dirFileCount.toString().padStart(4, ' ')} File(s)     ${formattedDirBytes.padStart(14, ' ')} bytes`);
    lines.push(`              ${(dirFolderCount + (filePattern === '*.*' ? 2 : 0)).toString().padStart(4, ' ')} Dir(s)   245,782,109,696 bytes free`);
  }

  if (isRecursive && directoriesToProcess.length > 1) {
    lines.push('');
    lines.push('     Total Files Listed:');
    const formattedGrandBytes = noComma ? String(grandTotalBytes) : grandTotalBytes.toLocaleString('en-US');
    lines.push(`              ${grandTotalFiles.toString().padStart(4, ' ')} File(s)     ${formattedGrandBytes.padStart(14, ' ')} bytes`);
    lines.push(`              ${(grandTotalDirs + 2).toString().padStart(4, ' ')} Dir(s)   245,782,109,696 bytes free`);
  }

  if (isPause && lines.length > 24) {
    const paginated: string[] = [];
    for (let i = 0; i < lines.length; i++) {
      paginated.push(lines[i]);
      if ((i + 1) % 22 === 0 && i !== lines.length - 1) {
        paginated.push('Press any key to continue . . . (Nhấn phím bất kỳ để tiếp tục...)');
      }
    }
    output.push({ id: 'out-' + Date.now(), type: 'output', text: paginated.join('\n') });
    return output;
  }

  output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
  return output;
}
export function getAllHelpGroupsText(): string {
  const lines: string[] = [];
  lines.push('================================================================================');
  lines.push('              DANH SÁCH 245 LỆNH WINDOWS 11 — HỆ THỐNG DÒNG LỆNH CHUẨN            ');
  lines.push('================================================================================');
  lines.push("Gõ 'help [tên_lệnh]' hoặc '[tên_lệnh] /?' để xem cú pháp chi tiết từng lệnh.\n");

  for (const group of COMMAND_GROUPS) {
    lines.push(`▶ ${group.name}`);
    const cmdsInGroup = Object.values(COMMAND_REGISTRY).filter((c) => c.group === group.id);
    const cmdNames = cmdsInGroup.map((c) => c.name);

    // Format into columns
    let row = '  ';
    for (let i = 0; i < cmdNames.length; i++) {
      row += cmdNames[i].padEnd(16, ' ');
      if ((i + 1) % 4 === 0 || i === cmdNames.length - 1) {
        lines.push(row);
        row = '  ';
      }
    }
    lines.push('');
  }

  lines.push('Các tiện ích & phần mềm tích hợp:');
  lines.push('  calc            notepad         paint           explorer        settings');
  lines.push('  taskmgr         copilot         edge            curl            matrix');
  lines.push('================================================================================');
  return lines.join('\n');
}

// Execute a Batch Script (.bat or .cmd)
export function executeBatchScript(
  scriptContent: string,
  scriptArgs: string[],
  ctx: CmdContext
): TerminalOutputLine[] {
  const output: TerminalOutputLine[] = [];
  const lines = scriptContent.split(/\r?\n/);
  let echoOn = false;

  // Local environment for batch script execution
  const localEnv: Record<string, string> = {
    ...ctx.envVars,
    '0': 'script.bat',
    '1': scriptArgs[0] || '',
    '2': scriptArgs[1] || '',
    '3': scriptArgs[2] || '',
    '4': scriptArgs[3] || '',
    '5': scriptArgs[4] || '',
    '6': scriptArgs[5] || '',
    '7': scriptArgs[6] || '',
    '8': scriptArgs[7] || '',
    '9': scriptArgs[8] || '',
    '*': scriptArgs.join(' '),
    ERRORLEVEL: '0',
  };

  // Find all labels: :label
  const labels: Record<string, number> = {};
  for (let i = 0; i < lines.length; i++) {
    const trimmed = lines[i].trim();
    if (trimmed.startsWith(':') && !trimmed.startsWith('::')) {
      const labelName = trimmed.substring(1).trim().split(/\s+/)[0].toLowerCase();
      labels[labelName] = i;
    }
  }

  let lineIdx = 0;
  let executionCount = 0;
  const maxExecutions = 2000;

  while (lineIdx < lines.length && executionCount < maxExecutions) {
    executionCount++;
    const rawLine = lines[lineIdx];
    lineIdx++;

    let trimmed = rawLine.trim();
    if (!trimmed || trimmed.startsWith('::') || trimmed.startsWith('rem ') || trimmed === 'rem') {
      continue;
    }

    if (trimmed.startsWith(':')) {
      continue;
    }

    let isSilent = false;
    if (trimmed.startsWith('@')) {
      isSilent = true;
      trimmed = trimmed.substring(1).trim();
    }

    if (echoOn && !isSilent) {
      output.push({
        id: 'bat-echo-' + Date.now() + '-' + Math.random(),
        type: 'output',
        text: `${ctx.currentDir}> ${trimmed}`,
      });
    }

    // Handle 'echo on' / 'echo off'
    if (trimmed.toLowerCase() === 'echo on') {
      echoOn = true;
      continue;
    } else if (trimmed.toLowerCase() === 'echo off') {
      echoOn = false;
      continue;
    }

    // Handle GOTO :label or GOTO label
    if (trimmed.toLowerCase().startsWith('goto ') || trimmed.toLowerCase().startsWith('goto:')) {
      const targetLabel = trimmed.replace(/^goto\s*:?/i, '').trim().toLowerCase();
      if (targetLabel === ':eof' || targetLabel === 'eof') {
        break;
      }
      if (labels[targetLabel] !== undefined) {
        lineIdx = labels[targetLabel] + 1;
        continue;
      } else {
        output.push({
          id: 'bat-err-' + Date.now(),
          type: 'error',
          text: `Hệ thống không tìm thấy nhãn lô đã chỉ định - ${targetLabel}`,
        });
        localEnv['ERRORLEVEL'] = '1';
        break;
      }
    }

    // Handle SETLOCAL / ENDLOCAL
    if (trimmed.toLowerCase() === 'setlocal' || trimmed.toLowerCase() === 'endlocal') {
      continue;
    }

    // Execute the single line
    const expandedLine = expandEnvVars(trimmed, localEnv);
    const cmdResult = executeSingleCommand(expandedLine, {
      ...ctx,
      envVars: localEnv,
      setEnvVars: (updater) => {
        if (typeof updater === 'function') {
          const next = updater(localEnv);
          Object.assign(localEnv, next);
        } else {
          Object.assign(localEnv, updater);
        }
      },
    });

    output.push(...cmdResult);
  }

  return output;
}

// Execute a single line or command chain
export function executeSingleCommand(
  rawInput: string,
  ctx: CmdContext
): TerminalOutputLine[] {
  const output: TerminalOutputLine[] = [];
  const trimmed = rawInput.trim();

  if (!trimmed) {
    return output;
  }

  // Handle command chaining: 'cmd1 && cmd2' or 'cmd1 & cmd2'
  if (trimmed.includes('&&')) {
    const parts = trimmed.split('&&');
    for (const part of parts) {
      const subOut = executeSingleCommand(part.trim(), ctx);
      output.push(...subOut);
      const hasError = subOut.some((o) => o.type === 'error');
      if (hasError) break;
    }
    return output;
  }

  if (trimmed.includes(' & ') || (trimmed.includes('&') && !trimmed.includes('&&'))) {
    const parts = trimmed.split('&');
    for (const part of parts) {
      if (part.trim()) {
        const subOut = executeSingleCommand(part.trim(), ctx);
        output.push(...subOut);
      }
    }
    return output;
  }

  // Handle File Redirection: 'command > filename' or 'command >> filename'
  const redirAppendMatch = trimmed.match(/^(.*?)\s*>>\s*(.*?)$/);
  const redirOverwriteMatch = !redirAppendMatch ? trimmed.match(/^(.*?)\s*>\s*(.*?)$/) : null;

  if (redirAppendMatch || redirOverwriteMatch) {
    const isAppend = !!redirAppendMatch;
    const commandPart = (isAppend ? redirAppendMatch![1] : redirOverwriteMatch![1]).trim();
    const targetFilePart = (isAppend ? redirAppendMatch![2] : redirOverwriteMatch![2]).trim();

    if (!commandPart || !targetFilePart) {
      output.push({
        id: 'err-' + Date.now(),
        type: 'error',
        text: 'Cú pháp chuyển hướng không hợp lệ.',
      });
      return output;
    }

    const res = executeSingleCommand(commandPart, ctx);
    const contentToWrite = res.map((r) => r.text).join('\n');
    const resolved = resolvePath(targetFilePart, ctx.currentDir);

    const existing = ctx.fileSystem.find(
      (f) => !f.isDirectory && f.path.toLowerCase() === resolved.toLowerCase()
    );

    if (existing) {
      const newContent = isAppend ? (existing.content || '') + '\n' + contentToWrite : contentToWrite;
      if (ctx.updateFileContent) {
        ctx.updateFileContent(existing.path, newContent);
      } else {
        ctx.deleteFile(existing.id, true);
        ctx.addFile({
          name: existing.name,
          path: existing.path,
          isDirectory: false,
          size: newContent.length,
          content: newContent,
        });
      }
    } else {
      const fileName = targetFilePart.includes('\\')
        ? targetFilePart.substring(targetFilePart.lastIndexOf('\\') + 1)
        : targetFilePart;
      ctx.addFile({
        name: fileName,
        path: resolved,
        isDirectory: false,
        size: contentToWrite.length,
        content: contentToWrite,
      });
    }

    return output;
  }

  // Tokenize the command respecting quotes
  const tokens = trimmed.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || [];
  if (tokens.length === 0) return output;

  const rawFirst = tokens[0];
  const firstToken = rawFirst.toLowerCase();
  const args = tokens.slice(1).map((a) => a.replace(/^["']|["']$/g, ''));
  const restText = trimmed.substring(rawFirst.length).trim();

  // Check if user is requesting help via 'help' or '/?'
  if (firstToken === 'help') {
    if (args.length === 0) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'info',
        text: getAllHelpGroupsText(),
      });
      return output;
    } else {
      const targetCmd = args[0].toLowerCase();
      const doc = getHelpForCommand(targetCmd);
      if (doc) {
        output.push({
          id: 'out-' + Date.now(),
          type: 'info',
          text: `[${doc.groupName.toUpperCase()}] ${doc.name.toUpperCase()}\n${doc.shortDesc}\n\nCú pháp:\n  ${doc.syntax}\n\nChi tiết:\n${doc.detailedHelp}`,
        });
      } else {
        output.push({
          id: 'err-' + Date.now(),
          type: 'error',
          text: `Lệnh '${targetCmd}' không tồn tại trong danh sách trợ giúp. Gõ 'help' để xem danh sách 7 nhóm lệnh.`,
        });
      }
      return output;
    }
  }

  // Check if command ends with /?
  if (args.includes('/?') || trimmed.endsWith('/?')) {
    const doc = getHelpForCommand(firstToken);
    if (doc) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'info',
        text: `[${doc.groupName.toUpperCase()}] ${doc.name.toUpperCase()}\n${doc.shortDesc}\n\nCú pháp:\n  ${doc.syntax}\n\nChi tiết:\n${doc.detailedHelp}`,
      });
      return output;
    }
  }

  // ==========================================
  // DISPATCH COMMANDS
  // ==========================================

  // --- NHÓM 1: LỆNH CƠ BẢN ---

  if (firstToken === 'dir' || firstToken.startsWith('dir/') || firstToken.startsWith('dir\\')) {
    return executeDirCommand(tokens, ctx);
  }

  if (firstToken === 'cd' || firstToken === 'chdir') {
    if (args.length === 0) {
      output.push({ id: 'out-' + Date.now(), type: 'output', text: ctx.currentDir });
      return output;
    }
    const target = args[0] === '/d' ? args[1] : args[0];
    if (!target) {
      output.push({ id: 'out-' + Date.now(), type: 'output', text: ctx.currentDir });
      return output;
    }

    if (target === '\\' || target === '/') {
      ctx.setCurrentDir('C:');
      return output;
    }
    if (target === '..') {
      const lastSlash = Math.max(ctx.currentDir.lastIndexOf('\\'), ctx.currentDir.lastIndexOf('/'));
      const newDir = lastSlash > 2 ? ctx.currentDir.substring(0, lastSlash) : 'C:';
      ctx.setCurrentDir(newDir);
      return output;
    }

    const resolved = resolvePath(target, ctx.currentDir);
    const found = ctx.fileSystem.find(
      (f) => f.isDirectory && f.path.toLowerCase() === resolved.toLowerCase()
    );

    if (found || resolved.toUpperCase() === 'C:' || resolved.toUpperCase() === 'C:\\') {
      ctx.setCurrentDir(resolved);
    } else {
      output.push({
        id: 'err-' + Date.now(),
        type: 'error',
        text: `Hệ thống không thể tìm thấy đường dẫn đã chỉ định: ${target}`,
      });
    }
    return output;
  }

  if (firstToken === 'echo') {
    if (!restText) {
      output.push({ id: 'out-' + Date.now(), type: 'output', text: 'ECHO đang bật.' });
      return output;
    }
    if (restText.toLowerCase() === 'on' || restText.toLowerCase() === 'off') {
      output.push({ id: 'out-' + Date.now(), type: 'output', text: `ECHO is ${restText.toUpperCase()}` });
      return output;
    }
    output.push({ id: 'out-' + Date.now(), type: 'output', text: restText });
    return output;
  }

  if (firstToken === 'echo.') {
    output.push({ id: 'out-' + Date.now(), type: 'output', text: '' });
    return output;
  }

  if (firstToken === 'pause') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'output',
      text: 'Press any key to continue . . . (Nhấn phím bất kỳ để tiếp tục...)',
    });
    return output;
  }

  if (firstToken === 'rem' || firstToken === '::') {
    // Comment line - silent
    return output;
  }

  if (firstToken === 'ver') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'output',
      text: 'Microsoft Windows [Version 10.0.22631.3296]',
    });
    return output;
  }

  if (firstToken === 'winver' || firstToken === 'winver.exe') {
    ctx.openApp('winver');
    return output;
  }

  if (firstToken === 'vol') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'output',
      text: ' Volume in drive C has no label.\n Volume Serial Number is 4C19-82F0',
    });
    return output;
  }

  if (firstToken === 'time') {
    const now = new Date();
    if (args.includes('/t') || args.includes('/T')) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: now.toLocaleTimeString('vi-VN'),
      });
    } else {
      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: `Giờ hiện tại là: ${now.toLocaleTimeString('vi-VN')},${now.getMilliseconds()}\nNhập giờ mới: (Giờ hệ thống được bảo vệ bởi Windows Time Service)`,
      });
    }
    return output;
  }

  if (firstToken === 'date') {
    const now = new Date();
    if (args.includes('/t') || args.includes('/T')) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: now.toLocaleDateString('vi-VN'),
      });
    } else {
      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: `Ngày hiện tại là: ${now.toLocaleDateString('vi-VN')}\nNhập ngày mới (dd-mm-yy): (Ngày hệ thống được đồng bộ hóa qua NTP)`,
      });
    }
    return output;
  }

  if (firstToken === 'title') {
    if (!restText) {
      const doc = getHelpForCommand('title');
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Cú pháp không đầy đủ.\n${doc?.syntax || 'TITLE [tiêu_đề]'}` });
      return output;
    }
    ctx.setTitle(restText);
    output.push({ id: 'out-' + Date.now(), type: 'success', text: `Đã đặt tiêu đề Terminal thành: "${restText}"` });
    return output;
  }

  if (firstToken === 'prompt') {
    if (!restText) {
      ctx.setPromptTemplate('PS $p$g');
    } else {
      ctx.setPromptTemplate(restText);
    }
    output.push({ id: 'out-' + Date.now(), type: 'info', text: 'Dấu nhắc lệnh đã được cập nhật.' });
    return output;
  }

  if (firstToken === 'color') {
    if (args.includes('/?') || args.includes('-?') || args.includes('/help') || args.includes('-help')) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: `Thiết lập màu nền và màu chữ mặc định của bảng điều khiển.

COLOR [attr]

  attr        Chỉ định thuộc tính màu của đầu ra bảng điều khiển

Các thuộc tính màu được chỉ định bởi HAI chữ số thập lục phân -- chữ số
đầu tiên tương ứng với nền; chữ số thứ hai tương ứng với chữ.
Mỗi chữ số có thể là bất kỳ giá trị nào sau đây:

    0 = Đen                 8 = Xám đậm
    1 = Xanh dương đậm      9 = Xanh dương sáng
    2 = Xanh lá đậm         A = Xanh lá sáng
    3 = Xanh ngọc đậm       B = Xanh ngọc sáng
    4 = Đỏ đậm              C = Đỏ sáng
    5 = Tím đậm             D = Tím sáng
    6 = Vàng đậm / Nâu      E = Vàng sáng
    7 = Trắng xám           F = Trắng sáng

Cú pháp:
  COLOR           → Trở về màu mặc định của hệ thống
  COLOR /?        → Hiển thị trợ giúp + bảng mã màu
  COLOR X         → Chỉ đổi màu chữ (X = mã chữ từ 0-F)
  COLOR XY        → X = mã màu nền, Y = mã màu chữ (viết liền không dấu cách)

Tất cả 16 × 16 = 256 cách kết hợp (COLOR 00 đến COLOR FF) đều hợp lệ!
Ví dụ: "COLOR 0A" (chữ xanh lá sáng trên nền đen), "COLOR 1F" (chữ trắng sáng trên nền xanh dương).`,
      });
      return output;
    }

    if (args.length === 0) {
      // Reset to default
      ctx.setColor?.('#0c0c0c', '#cccccc');
      return output;
    }

    if (args.length > 1) {
      output.push({
        id: 'err-' + Date.now(),
        type: 'error',
        text: 'Cú pháp lệnh COLOR không hợp lệ. Viết liền 2 mã màu không có dấu cách (ví dụ: COLOR 02, COLOR 0A). Gõ "COLOR /?" để xem hướng dẫn.',
      });
      return output;
    }

    const code = args[0].toLowerCase();
    if (code.length === 1 && WINDOWS_COLOR_MAP[code]) {
      // Single hex character: changes text color only
      ctx.setColor?.('#0c0c0c', WINDOWS_COLOR_MAP[code]);
      return output;
    }

    if (code.length === 2 && WINDOWS_COLOR_MAP[code[0]] && WINDOWS_COLOR_MAP[code[1]]) {
      // Two hex characters: bg and fg
      ctx.setColor?.(WINDOWS_COLOR_MAP[code[0]], WINDOWS_COLOR_MAP[code[1]]);
      return output;
    }

    output.push({
      id: 'err-' + Date.now(),
      type: 'error',
      text: 'Mã màu không hợp lệ. Vui lòng nhập từ 0-9 hoặc A-F (ví dụ: COLOR 0A, COLOR 1F). Gõ "COLOR /?" để xem bảng mã.',
    });
    return output;
  }

  if (firstToken === 'hostname') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'output',
      text: ctx.envVars['COMPUTERNAME'] || 'DESKTOP-WIN11-OS',
    });
    return output;
  }

  if (firstToken === 'whoami') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'output',
      text: `${ctx.envVars['COMPUTERNAME'] || 'DESKTOP-WIN11'}\\${ctx.envVars['USERNAME'] || 'User'}`,
    });
    return output;
  }

  if (firstToken === 'exit') {
    const termWin = ctx.windows?.find((w) => w.appId === 'terminal');
    if (termWin && ctx.closeWindow) {
      ctx.closeWindow(termWin.id);
    }
    return output;
  }

  // --- NHÓM 2: QUẢN LÝ TỆP & THƯ MỤC ---

  if (firstToken === 'copy' || firstToken === 'cp') {
    const cleanArgs = args.filter((a) => !a.startsWith('/'));
    if (cleanArgs.length < 2) {
      const doc = getHelpForCommand('copy');
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Cú pháp lệnh không chính xác.\n${doc?.syntax || 'COPY [nguồn] [đích]'}` });
      return output;
    }
    const srcPath = resolvePath(cleanArgs[0], ctx.currentDir);
    const destPath = resolvePath(cleanArgs[1], ctx.currentDir);

    const srcFile = ctx.fileSystem.find(
      (f) => !f.isDirectory && f.path.toLowerCase() === srcPath.toLowerCase()
    );

    if (!srcFile) {
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Hệ thống không tìm thấy tệp đã chỉ định: ${cleanArgs[0]}` });
      return output;
    }

    const destIsDir = ctx.fileSystem.some(
      (f) => f.isDirectory && f.path.toLowerCase() === destPath.toLowerCase()
    );
    const finalPath = destIsDir ? `${destPath}\\${srcFile.name}` : destPath;
    const finalName = finalPath.substring(finalPath.lastIndexOf('\\') + 1);

    ctx.addFile({
      name: finalName,
      path: finalPath,
      isDirectory: false,
      size: srcFile.size,
      content: srcFile.content,
    });

    output.push({ id: 'out-' + Date.now(), type: 'success', text: `        1 tệp đã được sao chép.` });
    return output;
  }

  if (firstToken === 'xcopy' || firstToken === 'robocopy') {
    const cleanArgs = args.filter((a) => !a.startsWith('/'));
    if (cleanArgs.length < 2) {
      const doc = getHelpForCommand('xcopy');
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Cú pháp lệnh không chính xác.\n${doc?.syntax || 'XCOPY [nguồn] [đích]'}` });
      return output;
    }
    output.push({
      id: 'out-' + Date.now(),
      type: 'success',
      text: `Sao chép cây thư mục thành công: ${cleanArgs[0]} -> ${cleanArgs[1]}\n        Đã xử lý tất cả tệp và thư mục con.`,
    });
    return output;
  }

  if (firstToken === 'move' || firstToken === 'mv') {
    const cleanArgs = args.filter((a) => !a.startsWith('/'));
    if (cleanArgs.length < 2) {
      const doc = getHelpForCommand('move');
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Cú pháp lệnh không chính xác.\n${doc?.syntax || 'MOVE [nguồn] [đích]'}` });
      return output;
    }
    const srcPath = resolvePath(cleanArgs[0], ctx.currentDir);
    const destPath = resolvePath(cleanArgs[1], ctx.currentDir);

    const srcFile = ctx.fileSystem.find(
      (f) => f.path.toLowerCase() === srcPath.toLowerCase()
    );

    if (!srcFile) {
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Hệ thống không tìm thấy tệp hoặc thư mục đã chỉ định: ${cleanArgs[0]}` });
      return output;
    }

    ctx.deleteFile(srcFile.id, true);
    ctx.addFile({
      name: destPath.substring(destPath.lastIndexOf('\\') + 1),
      path: destPath,
      isDirectory: srcFile.isDirectory,
      size: srcFile.size,
      content: srcFile.content,
    });

    output.push({ id: 'out-' + Date.now(), type: 'success', text: `        1 tệp/thư mục đã được di chuyển.` });
    return output;
  }

  if (firstToken === 'del' || firstToken === 'erase' || firstToken === 'rm') {
    const cleanArgs = args.filter((a) => !a.startsWith('/'));
    if (cleanArgs.length === 0) {
      const doc = getHelpForCommand('del');
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Cú pháp lệnh không chính xác.\n${doc?.syntax || 'DEL [tên_tệp]'}` });
      return output;
    }

    const target = cleanArgs[0];
    const resolved = resolvePath(target, ctx.currentDir);
    const targetFile = ctx.fileSystem.find(
      (f) => !f.isDirectory && f.path.toLowerCase() === resolved.toLowerCase()
    );

    if (!targetFile) {
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Không tìm thấy ${resolved}` });
      return output;
    }

    if ((targetFile.isCriticalSystemFile || targetFile.isSystem) && targetFile.owner !== 'Administrators' && targetFile.owner !== 'User') {
      output.push({
        id: 'err-' + Date.now(),
        type: 'error',
        text: `Truy cập bị từ chối: Tệp ${targetFile.name} thuộc sở hữu của ${targetFile.owner || 'TrustedInstaller'}.\n(Dùng lệnh 'takeown /f ${targetFile.name}' để chiếm quyền sở hữu trước).`,
      });
      return output;
    }

    ctx.deleteFile(targetFile.id, true);
    output.push({ id: 'out-' + Date.now(), type: 'success', text: `Đã xóa tệp: ${targetFile.name}` });
    return output;
  }

  if (firstToken === 'ren' || firstToken === 'rename') {
    if (args.length < 2) {
      const doc = getHelpForCommand('ren');
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Cú pháp lệnh không chính xác.\n${doc?.syntax || 'REN [tên_cũ] [tên_mới]'}` });
      return output;
    }
    const oldPath = resolvePath(args[0], ctx.currentDir);
    const newName = args[1].replace(/^["']|["']$/g, '');

    const file = ctx.fileSystem.find((f) => f.path.toLowerCase() === oldPath.toLowerCase());
    if (!file) {
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Hệ thống không tìm thấy tệp đã chỉ định: ${args[0]}` });
      return output;
    }

    if (ctx.renameFile) {
      ctx.renameFile(file.id, newName);
    }
    output.push({ id: 'out-' + Date.now(), type: 'success', text: `Đã đổi tên thành: ${newName}` });
    return output;
  }

  if (firstToken === 'md' || firstToken === 'mkdir') {
    if (args.length === 0) {
      const doc = getHelpForCommand('md');
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Cú pháp lệnh không chính xác.\n${doc?.syntax || 'MD [tên_thư_mục]'}` });
      return output;
    }
    const dirName = args[0];
    const newPath = resolvePath(dirName, ctx.currentDir);

    ctx.addFile({
      name: dirName.includes('\\') ? dirName.substring(dirName.lastIndexOf('\\') + 1) : dirName,
      path: newPath,
      isDirectory: true,
      size: 0,
    });

    output.push({ id: 'out-' + Date.now(), type: 'success', text: `Đã tạo thư mục: ${newPath}` });
    return output;
  }

  if (firstToken === 'rd' || firstToken === 'rmdir') {
    const cleanArgs = args.filter((a) => !a.startsWith('/'));
    if (cleanArgs.length === 0) {
      const doc = getHelpForCommand('rd');
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Cú pháp lệnh không chính xác.\n${doc?.syntax || 'RD [/s] [/q] [tên_thư_mục]'}` });
      return output;
    }
    const target = cleanArgs[0];
    const resolved = resolvePath(target, ctx.currentDir);
    const dirItem = ctx.fileSystem.find(
      (f) => f.isDirectory && f.path.toLowerCase() === resolved.toLowerCase()
    );

    if (!dirItem) {
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Hệ thống không tìm thấy thư mục: ${target}` });
      return output;
    }

    ctx.deleteFile(dirItem.id, true);
    output.push({ id: 'out-' + Date.now(), type: 'success', text: `Đã xóa thư mục: ${dirItem.name}` });
    return output;
  }

  if (firstToken === 'attrib') {
    if (args.length === 0) {
      const files = ctx.getFilesByDirectory(ctx.currentDir);
      const lines = files.map((f) => {
        const attrStr = `A   ${f.isSystem || f.hidden ? 'S H' : '   '}      ${f.path}`;
        return attrStr;
      });
      output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
      return output;
    }
    output.push({ id: 'out-' + Date.now(), type: 'success', text: `Đã cập nhật thuộc tính cho: ${args.join(' ')}` });
    return output;
  }

  if (firstToken === 'tree') {
    const showFiles = args.includes('/f') || args.includes('/F');
    const files = ctx.fileSystem.filter((f) => f.path.toLowerCase().startsWith(ctx.currentDir.toLowerCase()));

    const lines = [`Folder PATH listing for volume Windows11`, `Volume serial number is 4C19-82F0`, ctx.currentDir];
    files.forEach((f) => {
      if (f.path === ctx.currentDir) return;
      const rel = f.path.substring(ctx.currentDir.length).replace(/^\\/, '');
      if (f.isDirectory) {
        lines.push(`├───📁 ${rel}`);
      } else if (showFiles) {
        lines.push(`│   ├── 📄 ${rel}`);
      }
    });
    output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
    return output;
  }

  if (firstToken === 'type' || firstToken === 'cat' || firstToken === 'more') {
    if (args.length === 0) {
      const doc = getHelpForCommand('type');
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Cú pháp lệnh không chính xác.\n${doc?.syntax || 'TYPE [tên_tệp]'}` });
      return output;
    }
    const resolved = resolvePath(args[0], ctx.currentDir);
    const file = ctx.fileSystem.find(
      (f) => !f.isDirectory && f.path.toLowerCase() === resolved.toLowerCase()
    );

    if (!file) {
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Hệ thống không thể tìm thấy tệp: ${args[0]}` });
      return output;
    }

    output.push({ id: 'out-' + Date.now(), type: 'output', text: file.content || '(Tệp rỗng)' });
    return output;
  }

  if (firstToken === 'replace' || firstToken === 'mklink' || firstToken === 'expand') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'success',
      text: `Thực thi lệnh '${firstToken}' thành công. Đã hoàn tất xử lý liên kết và tệp hệ thống.`,
    });
    return output;
  }

  // --- NHÓM 3: QUẢN LÝ HỆ THỐNG ---

  if (firstToken === 'systeminfo') {
    const sysInfo = `
Host Name:                 ${ctx.envVars['COMPUTERNAME'] || 'DESKTOP-WIN11-OS'}
OS Name:                   Microsoft Windows 11 Pro
OS Version:                10.0.22631 N/A Build 22631.3296 (23H2)
OS Manufacturer:           Microsoft Corporation
OS Configuration:          Standalone Workstation
OS Build Type:             Multiprocessor Free
Registered Owner:          ${ctx.envVars['USERNAME'] || 'User'}
System Manufacturer:       Advanced Virtual Platform
System Model:              Cloud Edition x64
System Type:               x64-based PC
Processor(s):              1 Processor(s) Installed.
                           [01]: AMD Ryzen 9 7950X 16-Core Processor ~4.50GHz
BIOS Version:              American Megatrends Inc. 2.10, 08/30/2026
Windows Directory:         C:\\Windows
System Directory:          C:\\Windows\\system32
Boot Device:               \\Device\\HarddiskVolume1
System Locale:             vi-VN;Vietnamese
Input Locale:              en-US;English (United States)
Time Zone:                 (UTC+07:00) Bangkok, Hanoi, Jakarta
Total Physical Memory:     32,768 MB
Available Physical Memory: 24,192 MB
Virtual Memory: Max Size:  37,632 MB
Virtual Memory: Available: 28,450 MB
Hotfix(s):                 4 Hotfix(s) Installed.
                           [01]: KB5034765
                           [02]: KB5034441
                           [03]: KB5034123
                           [04]: KB5033453
Network Card(s):           1 NIC(s) Installed.
                           [01]: Intel(R) Wi-Fi 6E AX211 160MHz
                                 Status:      Media connected
                                 DHCP Server: 192.168.1.1
                                 IP address:  192.168.1.105/24
Hyper-V Requirements:      VM Monitor Mode Extensions: Yes
                           Virtualization Enabled In Firmware: Yes
`;
    output.push({ id: 'out-' + Date.now(), type: 'output', text: sysInfo.trim() });
    return output;
  }

  if (firstToken === 'tasklist') {
    const isVerbose = args.includes('/v') || args.includes('/V');
    const isSvc = args.includes('/svc') || args.includes('/SVC');

    const lines = [
      `Image Name                     PID Session Name        Session#    Mem Usage`,
      `========================= ======== ================ =========== ============`,
      `System Idle Process              0 Services                   0          8 K`,
      `System                           4 Services                   0        240 K`,
      `smss.exe                       388 Services                   0      1,120 K`,
      `csrss.exe                      544 Services                   0      5,240 K`,
      `wininit.exe                    620 Services                   0      4,180 K`,
      `services.exe                   680 Services                   0      9,850 K`,
      `lsass.exe                      712 Services                   0     18,400 K`,
      `svchost.exe                    892 Services                   0     24,560 K`,
      `dwm.exe                       1024 Console                    1     68,320 K`,
      `explorer.exe                  2180 Console                    1    142,500 K`,
      `ShellExperienceHost.exe       3450 Console                    1     45,200 K`,
      `StartMenuExperienceHost.exe   4120 Console                    1     38,400 K`,
      `WindowsTerminal.exe           5890 Console                    1     56,700 K`,
    ];

    ctx.windows.forEach((w, idx) => {
      const pid = 6000 + idx * 120;
      const name = `${w.appId}.exe`.padEnd(25, ' ');
      lines.push(`${name}     ${pid} Console                    1     48,200 K`);
    });

    if (isVerbose) {
      lines.push('\n[Trạng thái: Đang chạy mượt mà | CPU: 3.2% | RAM khả dụng: 74%]');
    }
    if (isSvc) {
      lines.push('\n[Dịch vụ liên quan: DcomLaunch, RpcSs, EventLog, TermService, Winmgmt, LanmanWorkstation]');
    }

    output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
    return output;
  }

  if (firstToken === 'taskkill' || firstToken === 'tskill') {
    if (args.length === 0) {
      const doc = getHelpForCommand('taskkill');
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Cú pháp lệnh không chính xác.\n${doc?.syntax || 'TASKKILL [/PID số] [/IM tên] [/F]'}` });
      return output;
    }

    const pidIdx = args.indexOf('/PID') !== -1 ? args.indexOf('/PID') : args.indexOf('/pid');
    const imIdx = args.indexOf('/IM') !== -1 ? args.indexOf('/IM') : args.indexOf('/im');

    let targetName = 'app';
    if (pidIdx !== -1 && args[pidIdx + 1]) {
      targetName = `PID ${args[pidIdx + 1]}`;
    } else if (imIdx !== -1 && args[imIdx + 1]) {
      targetName = args[imIdx + 1];
    } else if (args[0]) {
      targetName = args[0];
    }

    // Try closing window matching target
    const win = ctx.windows.find(
      (w) => w.appId.toLowerCase() === targetName.toLowerCase().replace('.exe', '')
    );
    if (win) {
      ctx.closeWindow(win.id);
    }

    output.push({
      id: 'out-' + Date.now(),
      type: 'success',
      text: `THÀNH CÔNG: Tiến trình "${targetName}" đã được kết thúc thành công.`,
    });
    return output;
  }

  if (firstToken === 'shutdown') {
    if (args.includes('/a') || args.includes('/A')) {
      output.push({ id: 'out-' + Date.now(), type: 'success', text: 'Đã hủy lệnh tắt/khởi động lại hệ thống đang chờ.' });
      return output;
    }
    if (args.includes('/r') || args.includes('/R')) {
      output.push({ id: 'out-' + Date.now(), type: 'info', text: 'Đang khởi động lại Windows 11...' });
      setTimeout(() => ctx.restartSystem(), 1200);
      return output;
    }
    if (args.includes('/s') || args.includes('/S') || args.includes('/p')) {
      output.push({ id: 'out-' + Date.now(), type: 'info', text: 'Đang tắt máy tính...' });
      setTimeout(() => ctx.shutdownSystem(), 1200);
      return output;
    }
    if (args.includes('/o') || args.includes('/O')) {
      output.push({ id: 'out-' + Date.now(), type: 'info', text: 'Đang khởi động vào Môi trường Phục hồi WinRE...' });
      setTimeout(() => ctx.restartToWinRE(), 1200);
      return output;
    }
    if (args.includes('/l') || args.includes('/L')) {
      ctx.setIsLockScreen(true);
      output.push({ id: 'out-' + Date.now(), type: 'info', text: 'Đã đăng xuất người dùng.' });
      return output;
    }

    const doc = getHelpForCommand('shutdown');
    output.push({ id: 'out-' + Date.now(), type: 'info', text: `Cú pháp:\n${doc?.syntax || 'SHUTDOWN [/s | /r | /l | /a | /o]'}` });
    return output;
  }

  if (firstToken === 'logoff') {
    ctx.setIsLockScreen(true);
    output.push({ id: 'out-' + Date.now(), type: 'info', text: 'Đang đăng xuất khỏi phiên làm việc hiện tại...' });
    return output;
  }

  if (firstToken === 'netstat' || firstToken === 'nbtstat') {
    const lines = [
      `Active Connections`,
      ``,
      `  Proto  Local Address          Foreign Address        State           PID`,
      `  TCP    0.0.0.0:135            0.0.0.0:0              LISTENING       892`,
      `  TCP    0.0.0.0:445            0.0.0.0:0              LISTENING       4`,
      `  TCP    0.0.0.0:5040           0.0.0.0:0              LISTENING       680`,
      `  TCP    127.0.0.1:3000         0.0.0.0:0              LISTENING       5890`,
      `  TCP    192.168.1.105:54320    20.189.173.1:443       ESTABLISHED     2180`,
      `  TCP    192.168.1.105:54322    52.178.17.2:443        ESTABLISHED     3450`,
      `  TCP    192.168.1.105:54330    142.250.190.46:443     ESTABLISHED     5890`,
      `  UDP    0.0.0.0:5353           *:*                                    2180`,
    ];
    output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
    return output;
  }

  if (firstToken === 'net') {
    const subCmd = args[0]?.toLowerCase();
    if (subCmd === 'user') {
      if (args.length > 1) {
        output.push({ id: 'out-' + Date.now(), type: 'success', text: `Lệnh đã hoàn thành thành công cho người dùng: ${args[1]}` });
      } else {
        const lines = [
          `User accounts for \\\\${ctx.envVars['COMPUTERNAME'] || 'DESKTOP-WIN11'}`,
          `-------------------------------------------------------------------------------`,
          `Administrator            DefaultAccount           Guest`,
          `User                     WDAGUtilityAccount`,
          `The command completed successfully.`,
        ];
        output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
      }
      return output;
    }
    if (subCmd === 'localgroup') {
      const lines = [
        `Aliases for \\\\${ctx.envVars['COMPUTERNAME'] || 'DESKTOP-WIN11'}`,
        `-------------------------------------------------------------------------------`,
        `*Administrators`,
        `*Users`,
        `*Backup Operators`,
        `*Remote Desktop Users`,
        `The command completed successfully.`,
      ];
      output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
      return output;
    }
    if (subCmd === 'start' || subCmd === 'stop') {
      const sName = args.slice(1).join(' ') || 'Windows Service';
      output.push({
        id: 'out-' + Date.now(),
        type: 'success',
        text: `Dịch vụ ${sName} đã được ${subCmd === 'start' ? 'khởi động' : 'dừng'} thành công.`,
      });
      return output;
    }
    if (subCmd === 'share' || subCmd === 'use' || subCmd === 'view' || subCmd === 'accounts' || subCmd === 'config') {
      output.push({
        id: 'out-' + Date.now(),
        type: 'success',
        text: `NET ${subCmd.toUpperCase()}: Cấu hình dịch vụ mạng hoàn tất thành công.`,
      });
      return output;
    }

    output.push({
      id: 'out-' + Date.now(),
      type: 'info',
      text: 'Cú pháp lệnh NET:\n  NET [ ACCOUNTS | CONFIG | LOCALGROUP | SHARE | START | STOP | USE | USER | VIEW ]',
    });
    return output;
  }

  if (firstToken === 'wmic') {
    const rawQuery = restText.trim();
    const query = rawQuery.toLowerCase();

    // 1. WMIC logicaldisk get [caption, volumename, size, freespace, description, filesystem, etc.]
    if (query.startsWith('logicaldisk')) {
      const getIdx = query.indexOf('get');
      let requestedFields: string[] = ['caption', 'volumename', 'size', 'freespace'];
      if (getIdx !== -1) {
        const fieldsStr = query.substring(getIdx + 3).trim();
        if (fieldsStr) {
          requestedFields = fieldsStr
            .split(/[,\s]+/)
            .map((f) => f.trim().toLowerCase())
            .filter(Boolean);
        }
      }

      // Calculate disk usage based on fileSystem
      const totalUsedBytes = ctx.fileSystem.reduce((acc, f) => acc + (f.size || (f.isDirectory ? 4096 : (f.content?.length || 0) * 2)), 0);
      const cTotalBytes = 256 * 1024 * 1024 * 1024; // 256 GB
      const cFreeBytes = Math.max(1024 * 1024 * 1024, cTotalBytes - totalUsedBytes * 1000 - 45 * 1024 * 1024 * 1024);
      const dTotalBytes = 512 * 1024 * 1024 * 1024; // 512 GB Data
      const dFreeBytes = 468 * 1024 * 1024 * 1024;

      const disks = [
        {
          caption: 'C:',
          description: 'Local Fixed Disk',
          deviceid: 'C:',
          drivetype: '3',
          filesystem: 'NTFS',
          freespace: String(cFreeBytes),
          size: String(cTotalBytes),
          volumename: 'Windows11',
          volumeserialnumber: '8A32-9F1C',
        },
        {
          caption: 'D:',
          description: 'Local Fixed Disk',
          deviceid: 'D:',
          drivetype: '3',
          filesystem: 'NTFS',
          freespace: String(dFreeBytes),
          size: String(dTotalBytes),
          volumename: 'Data',
          volumeserialnumber: '4C91-6E3A',
        },
      ];

      // Format table according to requested fields or default standard
      if (requestedFields.length === 0) {
        requestedFields = ['caption', 'volumename', 'size', 'freespace'];
      }

      // Compute field headers matching original case capitalization in Windows WMIC
      const headerMap: Record<string, string> = {
        caption: 'Caption',
        volumename: 'VolumeName',
        size: 'Size',
        freespace: 'FreeSpace',
        description: 'Description',
        deviceid: 'DeviceID',
        drivetype: 'DriveType',
        filesystem: 'FileSystem',
        volumeserialnumber: 'VolumeSerialNumber',
        name: 'Name',
      };

      const columns = requestedFields.map((f) => headerMap[f] || f.toUpperCase());
      const colWidths = columns.map((col, i) => {
        const fieldKey = requestedFields[i];
        let maxW = col.length;
        disks.forEach((d) => {
          const val = (d as Record<string, string>)[fieldKey] || '';
          if (val.length > maxW) maxW = val.length;
        });
        return Math.max(maxW + 2, 12);
      });

      const headerLine = columns.map((col, i) => col.padEnd(colWidths[i])).join('').trimEnd();
      const rows = disks.map((d) => {
        return requestedFields
          .map((f, i) => {
            const val = (d as Record<string, string>)[f] || '';
            return val.padEnd(colWidths[i]);
          })
          .join('')
          .trimEnd();
      });

      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: [headerLine, ...rows].join('\n'),
      });
      return output;
    }

    // 2. WMIC diskdrive get [model, size, status, mediatype, etc.]
    if (query.startsWith('diskdrive')) {
      const isGet = query.includes('get');
      if (isGet) {
        const lines = [
          'DeviceID            Model                           MediaType              Size              Status',
          '\\\\.\\PHYSICALDRIVE0  NVMe Samsung SSD 990 PRO 2TB    Fixed hard disk media  2000396321280     OK',
        ];
        output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
      } else {
        output.push({
          id: 'out-' + Date.now(),
          type: 'output',
          text: 'Model                           Size\nNVMe Samsung SSD 990 PRO 2TB    2000396321280',
        });
      }
      return output;
    }

    // 3. WMIC cpu get [name, numberofcores, maxclockspeed, etc.]
    if (query.startsWith('cpu')) {
      if (query.includes('get')) {
        output.push({
          id: 'out-' + Date.now(),
          type: 'output',
          text: 'Caption                               DeviceID  MaxClockSpeed  Name                                  NumberOfCores  NumberOfLogicalProcessors\nAMD64 Family 25 Model 97 Stepping 2   CPU0      4500           AMD Ryzen 9 7950X 16-Core Processor   16             32',
        });
      } else {
        output.push({ id: 'out-' + Date.now(), type: 'output', text: 'Name\nAMD Ryzen 9 7950X 16-Core Processor' });
      }
      return output;
    }

    // 4. WMIC os get [caption, version, osarchitecture, buildnumber, etc.]
    if (query.startsWith('os')) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: 'BuildNumber  Caption                   OSArchitecture  Version\n22631        Microsoft Windows 11 Pro  64-bit          10.0.22631',
      });
      return output;
    }

    // 5. WMIC bios get [serialnumber, version, manufacturer, smbiosbiosversion]
    if (query.startsWith('bios')) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: 'Manufacturer          Name              SerialNumber        SMBIOSBIOSVersion  Version\nAmerican Megatrends   BIOS Date: 03/20  Default string      F21a               ALASKA - 1072009',
      });
      return output;
    }

    // 6. WMIC baseboard / memorychip / process / nic / useraccount / product
    if (query.startsWith('baseboard')) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: 'Manufacturer  Product               SerialNumber  Version\nASUSTeK       ROG STRIX X670E-E     2308194810    Rev 1.xx',
      });
      return output;
    }

    if (query.startsWith('memorychip')) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: 'BankLabel  Capacity     DeviceLocator  Manufacturer  Speed\nBANK 0     17179869184  DIMM 1         Corsair       6000\nBANK 2     17179869184  DIMM 3         Corsair       6000',
      });
      return output;
    }

    if (query.startsWith('process')) {
      const procLines = [
        'Caption                       CommandLine                                 Handle  ProcessId',
        'System                                                                    4       4',
        'smss.exe                                                                  280     280',
        'csrss.exe                     C:\\Windows\\system32\\csrss.exe                460     460',
        'wininit.exe                   C:\\Windows\\system32\\wininit.exe              520     520',
        'services.exe                  C:\\Windows\\system32\\services.exe             680     680',
        'lsass.exe                     C:\\Windows\\system32\\lsass.exe                710     710',
        'explorer.exe                  C:\\Windows\\explorer.exe                    2180    2180',
        'WindowsTerminal.exe           C:\\Windows\\WindowsTerminal.exe             5890    5890',
      ];
      output.push({ id: 'out-' + Date.now(), type: 'output', text: procLines.join('\n') });
      return output;
    }

    if (query.startsWith('useraccount')) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: 'AccountType  Caption                      Domain            Name           SID\n512          DESKTOP-WIN11\\Administrator  DESKTOP-WIN11    Administrator  S-1-5-21-3296-500\n512          DESKTOP-WIN11\\User           DESKTOP-WIN11    User           S-1-5-21-3296-1001',
      });
      return output;
    }

    if (query.startsWith('nic')) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: 'AdapterType          Description                         MACAddress         NetConnectionStatus\nEthernet 802.3       Intel(R) Wi-Fi 6E AX211 160MHz      F4:B3:81:22:9A:0D  2',
      });
      return output;
    }

    // Default WMIC interactive mode / help
    output.push({
      id: 'out-' + Date.now(),
      type: 'output',
      text: 'WMIC1.0 - Windows Management Instrumentation Command-line Utility\n[WMI Object Model Ready]\n\nCác alias hỗ trợ: LOGICALDISK, DISKDRIVE, CPU, OS, BIOS, BASEBOARD, MEMORYCHIP, PROCESS, USERACCOUNT, NIC',
    });
    return output;
  }

  if (firstToken === 'driverquery') {
    const isVerbose = args.includes('/v') || args.includes('/V');
    const lines = [
      `Module Name  Display Name           Driver Type   Link Date`,
      `============ ====================== ============= ======================`,
      `ACPI         ACPI Driver            Kernel        08/15/2026 09:20:11 AM`,
      `disk         Disk Driver            Kernel        08/15/2026 09:20:15 AM`,
      `nvlddmkm     NVIDIA Windows Kernel  Kernel        08/20/2026 04:12:00 PM`,
      `Netwtw12     Intel Wi-Fi Driver     Kernel        08/22/2026 11:34:22 AM`,
      `volume       Volume Driver          Kernel        08/15/2026 09:20:18 AM`,
    ];
    if (isVerbose) {
      lines.push('\n[Trạng thái: 5/5 driver hệ thống đang chạy ổn định]');
    }
    output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
    return output;
  }

  if (firstToken === 'sc') {
    const sub = args[0]?.toLowerCase();
    if (sub === 'query' || sub === 'queryex') {
      const lines = [
        `SERVICE_NAME: WinDefend`,
        `        TYPE               : 20  WIN32_SHARE_PROCESS`,
        `        STATE              : 4  RUNNING`,
        `                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)`,
        `        WIN32_EXIT_CODE    : 0  (0x0)`,
        `        SERVICE_EXIT_CODE  : 0  (0x0)`,
        `        CHECKPOINT         : 0x0`,
        `        WAIT_HINT          : 0x0`,
      ];
      output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
      return output;
    }
    output.push({
      id: 'out-' + Date.now(),
      type: 'success',
      text: `[SC] Thực thi lệnh Service Controller "${args.join(' ')}" thành công.`,
    });
    return output;
  }

  if (firstToken === 'sfc') {
    if (args.includes('/?') || args.includes('-?') || args.includes('/help')) {
      const doc = getHelpForCommand('sfc');
      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: `Microsoft (R) Windows (R) Resource Checker Version 6.0\n${doc?.syntax || 'SFC [/SCANNOW] [/VERIFYONLY] [/SCANFILE=<file>] [/VERIFYFILE=<file>]'}\n\n${doc?.detailedHelp || ''}`,
      });
      return output;
    }

    const sfcResult = [
      'Bắt đầu quá trình quét hệ thống...',
      '',
      'Đang xác minh giai đoạn 1/3...  10%',
      'Đang xác minh giai đoạn 1/3...  30%',
      'Đang xác minh giai đoạn 1/3...  50%',
      'Đang xác minh giai đoạn 1/3...  100%',
      '',
      'Đang xác minh giai đoạn 2/3...  100%',
      '',
      'Đang xác minh giai đoạn 3/3...  100%',
      '',
      '',
      'Kiểm tra 100% hoàn tất.',
      '',
      'Bảo vệ tài nguyên Windows không tìm thấy vi phạm tính toàn vẹn.',
      'Không thực hiện bất kỳ thao tác nào.',
    ].join('\n');

    output.push({
      id: 'out-' + Date.now(),
      type: 'output',
      text: sfcResult,
    });
    return output;
  }

  if (firstToken === 'dxdiag') {
    const reportText = generateDxDiagReportText();
    const tIdx = args.indexOf('/t') !== -1 ? args.indexOf('/t') : args.indexOf('/T');
    const xIdx = args.indexOf('/x') !== -1 ? args.indexOf('/x') : args.indexOf('/X');
    const fileArg = tIdx !== -1 ? args[tIdx + 1] : xIdx !== -1 ? args[xIdx + 1] : null;

    if (fileArg) {
      const fileName = fileArg.split('\\').pop() || 'DxDiag.txt';
      const filePath = fileArg.includes('\\') ? fileArg : `${ctx.currentDir}\\${fileName}`;
      ctx.addFile({
        name: fileName,
        path: filePath,
        isDirectory: false,
        content: reportText,
        size: reportText.length,
      });
      output.push({
        id: 'out-' + Date.now(),
        type: 'success',
        text: `DirectX Diagnostic Tool: Đã lưu thông tin chẩn đoán thành công vào "${filePath}".`,
      });
      return output;
    }

    // Launch GUI tool
    ctx.openApp('dxdiag');

    output.push({
      id: 'out-' + Date.now(),
      type: 'output',
      text: reportText.trim(),
    });
    return output;
  }

  // --- NHÓM 4: MẠNG & KẾT NỐI ---

  if (firstToken === 'ping') {
    if (args.length === 0) {
      const doc = getHelpForCommand('ping');
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Cú pháp lệnh không chính xác.\n${doc?.syntax || 'PING [địa_chỉ]'}` });
      return output;
    }
    const cleanArgs = args.filter((a) => !a.startsWith('-') && !a.startsWith('/'));
    const target = cleanArgs[0] || '127.0.0.1';
    const targetIp = target === 'localhost' || target === '127.0.0.1' ? '127.0.0.1' : '142.250.190.46';

    const lines = [
      `Pinging ${target} [${targetIp}] with 32 bytes of data:`,
      `Reply from ${targetIp}: bytes=32 time=8ms TTL=118`,
      `Reply from ${targetIp}: bytes=32 time=7ms TTL=118`,
      `Reply from ${targetIp}: bytes=32 time=9ms TTL=118`,
      `Reply from ${targetIp}: bytes=32 time=8ms TTL=118`,
      ``,
      `Ping statistics for ${targetIp}:`,
      `    Packets: Sent = 4, Received = 4, Lost = 0 (0% loss),`,
      `Approximate round trip times in milli-seconds:`,
      `    Minimum = 7ms, Maximum = 9ms, Average = 8ms`,
    ];
    output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
    return output;
  }

  if (firstToken === 'ipconfig') {
    const isAll = args.includes('/all') || args.includes('/ALL');
    const isFlush = args.includes('/flushdns') || args.includes('/FLUSHDNS');
    const isRelease = args.includes('/release');
    const isRenew = args.includes('/renew');

    if (isFlush) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'success',
        text: 'Windows IP Configuration\n\nSuccessfully flushed the DNS Resolver Cache. (Đã xóa bộ nhớ đệm phân giải DNS thành công).',
      });
      return output;
    }
    if (isRelease) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'info',
        text: 'Windows IP Configuration\n\nEthernet adapter Ethernet 1:\n   IP Address đã được giải phóng.',
      });
      return output;
    }
    if (isRenew) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'success',
        text: 'Windows IP Configuration\n\nEthernet adapter Ethernet 1:\n   IPv4 Address. . . . . . . . . . . : 192.168.1.105\n   Subnet Mask . . . . . . . . . . . : 255.255.255.0\n   Default Gateway . . . . . . . . . : 192.168.1.1',
      });
      return output;
    }

    const lines = [
      `Windows IP Configuration`,
      ``,
    ];
    if (isAll) {
      lines.push(`   Host Name . . . . . . . . . . . . : ${ctx.envVars['COMPUTERNAME'] || 'DESKTOP-WIN11'}`);
      lines.push(`   Primary Dns Suffix  . . . . . . . : `);
      lines.push(`   Node Type . . . . . . . . . . . . : Hybrid`);
      lines.push(`   IP Routing Enabled. . . . . . . . : No`);
      lines.push(`   WINS Proxy Enabled. . . . . . . . : No`);
      lines.push(``);
    }
    lines.push(`Wireless LAN adapter Wi-Fi:`);
    lines.push(`   Connection-specific DNS Suffix  . : lan`);
    if (isAll) {
      lines.push(`   Description . . . . . . . . . . . : Intel(R) Wi-Fi 6E AX211 160MHz`);
      lines.push(`   Physical Address. . . . . . . . . : F4-B3-81-22-9A-0D`);
      lines.push(`   DHCP Enabled. . . . . . . . . . . : Yes`);
      lines.push(`   Autoconfiguration Enabled . . . . : Yes`);
    }
    lines.push(`   IPv4 Address. . . . . . . . . . . : 192.168.1.105`);
    lines.push(`   Subnet Mask . . . . . . . . . . . : 255.255.255.0`);
    lines.push(`   Default Gateway . . . . . . . . . : 192.168.1.1`);
    if (isAll) {
      lines.push(`   DHCP Server . . . . . . . . . . . : 192.168.1.1`);
      lines.push(`   DNS Servers . . . . . . . . . . . : 8.8.8.8`);
      lines.push(`                                       1.1.1.1`);
    }

    output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
    return output;
  }

  if (firstToken === 'tracert' || firstToken === 'pathping') {
    const target = args.find((a) => !a.startsWith('-')) || 'google.com';
    const lines = [
      `Tracing route to ${target} [142.250.190.46] over a maximum of 30 hops:`,
      `  1     1 ms     1 ms     1 ms  192.168.1.1`,
      `  2     3 ms     2 ms     3 ms  10.0.0.1`,
      `  3     8 ms     7 ms     7 ms  142.250.190.46`,
      `Trace complete. (Lộ trình truy vết hoàn tất).`,
    ];
    output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
    return output;
  }

  if (firstToken === 'nslookup') {
    const domain = args.find((a) => !a.startsWith('-')) || 'google.com';
    const lines = [
      `Server:  dns.google`,
      `Address:  8.8.8.8`,
      ``,
      `Non-authoritative answer:`,
      `Name:    ${domain}`,
      `Addresses:  142.250.190.46`,
      `          2404:6800:4005:809::200e`,
    ];
    output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
    return output;
  }

  if (firstToken === 'arp') {
    if (args.includes('-d')) {
      output.push({ id: 'out-' + Date.now(), type: 'success', text: 'Bảng ARP đã được xóa sạch.' });
      return output;
    }
    const lines = [
      `Interface: 192.168.1.105 --- 0x3`,
      `  Internet Address      Physical Address      Type`,
      `  192.168.1.1           e4-aa-5d-31-89-22     dynamic`,
      `  192.168.1.255         ff-ff-ff-ff-ff-ff     static`,
      `  224.0.0.22            01-00-5e-00-00-16     static`,
    ];
    output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
    return output;
  }

  if (firstToken === 'route') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'output',
      text: `===========================================================================
Interface List
  3...f4 b3 81 22 9a 0d ......Intel(R) Wi-Fi 6E AX211 160MHz
===========================================================================
IPv4 Route Table
===========================================================================
Active Routes:
Network Destination        Netmask          Gateway       Interface  Metric
          0.0.0.0          0.0.0.0      192.168.1.1   192.168.1.105      25
        127.0.0.0        255.0.0.0         On-link        127.0.0.1     331
      192.168.1.0    255.255.255.0         On-link    192.168.1.105     281
    192.168.1.105  255.255.255.255         On-link    192.168.1.105     281
===========================================================================`,
    });
    return output;
  }

  if (firstToken === 'netsh') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'success',
      text: `[netsh] Thực thi cấu hình mạng hoàn tất:\nAll network interfaces and profiles are in active state.`,
    });
    return output;
  }

  if (firstToken === 'ftp' || firstToken === 'telnet' || firstToken === 'tftp' || firstToken === 'bitsadmin' || firstToken === 'certutil') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'output',
      text: `Công cụ [${firstToken.toUpperCase()}] đã xử lý yêu cầu thành công.`,
    });
    return output;
  }

  // --- NHÓM 5: LỆNH NỘI BỘ & BÍ MẬT ---

  if (firstToken === 'deltree' || firstToken === 'defltr') {
    if (args.length === 0) {
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Cú pháp lệnh không chính xác.\n${firstToken.toUpperCase()} [đường_dẫn_thư_mục]` });
      return output;
    }
    const resolved = resolvePath(args[0], ctx.currentDir);
    const item = ctx.fileSystem.find(
      (f) => f.isDirectory && f.path.toLowerCase() === resolved.toLowerCase()
    );
    if (!item) {
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Không tìm thấy thư mục: ${args[0]}` });
      return output;
    }
    ctx.deleteFile(item.id, true);
    output.push({ id: 'out-' + Date.now(), type: 'success', text: `Đã xóa toàn bộ thư mục và tệp con: ${item.name}` });
    return output;
  }

  if (firstToken === 'reagentc') {
    if (args.includes('/info')) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: `Windows Recovery Environment (Windows RE) and system reset configuration
Information:

    Windows RE status:         Enabled
    Windows RE location:       \\\\?\\GLOBALROOT\\device\\harddisk0\\partition4\\Recovery\\WindowsRE
    Boot Configuration Data (BCD) identifier: 42fa7971-d419-11ee-bb84-984827aa191b
    Custom image location:     
    Custom image index:        0
    Special recovery image:    
    Special recovery image index: 0

REAGENTC.EXE: Operation Successful.`,
      });
      return output;
    }
    if (args.includes('/boottore')) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'success',
        text: 'REAGENTC.EXE: Lần khởi động máy tính tiếp theo sẽ chuyển hướng trực tiếp vào WinRE.',
      });
      return output;
    }
    output.push({ id: 'out-' + Date.now(), type: 'success', text: 'REAGENTC.EXE: Operation Successful.' });
    return output;
  }

  if (firstToken === 'takeown') {
    const fIdx = args.indexOf('/f') !== -1 ? args.indexOf('/f') : args.indexOf('/F');
    const target = fIdx !== -1 && args[fIdx + 1] ? args[fIdx + 1] : args[0];
    if (!target) {
      const doc = getHelpForCommand('takeown');
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Cú pháp lệnh không chính xác.\n${doc?.syntax || 'TAKEOWN /F [tệp]'}` });
      return output;
    }

    const res = ctx.takeOwnership(target);
    if (res.success) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'success',
        text: `THÀNH CÔNG: Tệp (hoặc thư mục): "${res.path || target}" hiện thuộc sở hữu của người dùng hiện tại.`,
      });
    } else {
      output.push({
        id: 'err-' + Date.now(),
        type: 'error',
        text: `LỖI: Không thể chiếm quyền sở hữu cho "${target}".`,
      });
    }
    return output;
  }

  if (firstToken === 'icacls') {
    if (args.length === 0) {
      const doc = getHelpForCommand('icacls');
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Cú pháp lệnh không chính xác.\n${doc?.syntax || 'ICACLS [tệp] /grant [người]:[quyền]'}` });
      return output;
    }
    const target = args[0];
    const res = ctx.grantPermission(target);
    if (res.success) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'success',
        text: `xử lý tệp thành công: ${res.path || target}\nĐã xử trị thành công 1 tệp; Xử lý không thành công 0 tệp`,
      });
    } else {
      output.push({
        id: 'err-' + Date.now(),
        type: 'error',
        text: `Không thể cấp quyền cho ${target}. (Bạn cần chiếm quyền sở hữu tệp bằng 'takeown' trước).`,
      });
    }
    return output;
  }

  if (firstToken === 'reg') {
    const sub = args[0]?.toLowerCase();
    if (sub === 'query') {
      const keyArg = args[1]?.replace(/^["']|["']$/g, '') || 'HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion';
      const vIdx = args.findIndex((a) => a.toLowerCase() === '/v');
      const valName = vIdx !== -1 && args[vIdx + 1] ? args[vIdx + 1].replace(/^["']|["']$/g, '') : null;

      if (keyArg.toUpperCase().includes('WINDOWS NT\\CURRENTVERSION')) {
        if (valName && valName.toLowerCase() === 'displayversion') {
          output.push({
            id: 'out-' + Date.now(),
            type: 'output',
            text: `HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\n    DisplayVersion    REG_SZ    23H2`,
          });
          return output;
        }
        if (valName && valName.toLowerCase() === 'productname') {
          output.push({
            id: 'out-' + Date.now(),
            type: 'output',
            text: `HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\n    ProductName    REG_SZ    Windows 11 Pro`,
          });
          return output;
        }
        output.push({
          id: 'out-' + Date.now(),
          type: 'output',
          text: `HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\n    DisplayVersion        REG_SZ       23H2\n    ProductName           REG_SZ       Windows 11 Pro\n    CurrentBuild          REG_SZ       22631\n    CurrentBuildNumber    REG_SZ       22631\n    UBR                   REG_DWORD    0xce0\n    ReleaseId             REG_SZ       2009\n    EditionID             REG_SZ       Professional\n    RegisteredOwner       REG_SZ       User\n    SystemRoot            REG_SZ       C:\\Windows`,
        });
        return output;
      }

      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: `${keyArg}\n    (Default)    REG_SZ    (value not set)\n    Installed    REG_DWORD    0x1`,
      });
      return output;
    }

    if (sub === 'add' || sub === 'delete') {
      output.push({
        id: 'out-' + Date.now(),
        type: 'success',
        text: 'Thao tác Registry đã hoàn tất thành công.',
      });
      return output;
    }

    output.push({
      id: 'out-' + Date.now(),
      type: 'output',
      text: 'Cú pháp lệnh REG:\n  REG [ QUERY | ADD | DELETE | COPY | SAVE | RESTORE | LOAD | UNLOAD | COMPARE | EXPORT | IMPORT | FLAGS ]',
    });
    return output;
  }

  if (firstToken === 'bcdedit' || firstToken === 'fsutil' || firstToken === 'wevtutil' || firstToken === 'schtasks' || firstToken === 'pnputil') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'success',
      text: `[${firstToken.toUpperCase()}] Thao tác thành công. Dữ liệu cấu hình đã được áp dụng vào hệ thống.`,
    });
    return output;
  }

  // --- NHÓM 6: LỆNH NÂNG CAO & CHUYÊN GIA ---

  if (firstToken === 'chkdsk') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'output',
      text: `The type of the file system is NTFS.
Volume label is Windows11.

Stage 1: Examining basic file system structure ...
  24576 file records processed.
  File verification completed.
Stage 2: Examining file name linkage ...
  32400 index entries processed.
  Index verification completed.
Stage 3: Examining security descriptors ...
  Security descriptor verification completed.

Windows has scanned the file system and found no problems.
No further action is required.`,
    });
    return output;
  }

  if (firstToken === 'defrag') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'success',
      text: `Microsoft Drive Optimizer
Running (TRIM / Defragmentation) on Windows11 (C:)...
Post Defragmentation Report:
    Volume size                 = 228.45 GB
    Free space                  = 184.20 GB
    Total fragmented space      = 0 %
    Excess fragments            = 0
The operation completed successfully.`,
    });
    return output;
  }

  if (firstToken === 'diskpart' || firstToken === 'diskpart.exe') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'output',
      text: `Microsoft DiskPart version 10.0.22621.1\n\nCopyright (C) 1999-2024 Microsoft Corporation.\nOn computer: DESKTOP-WIN11-OS\n\nDiskPart environment activated in interactive Command Prompt session.`,
    });
    return output;
  }

  if (firstToken === 'compact' || firstToken === 'cipher' || firstToken === 'format' || firstToken === 'convert' || firstToken === 'label' || firstToken === 'mountvol' || firstToken === 'subst' || firstToken === 'ftype' || firstToken === 'assoc') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'success',
      text: `[${firstToken.toUpperCase()}] Lệnh chuyên gia đã thực thi thành công.`,
    });
    return output;
  }

  if (firstToken === 'set' || firstToken.startsWith('set/')) {
    // Check for arithmetic switch: set /a or set/a
    const isSetA =
      firstToken === 'set/a' ||
      firstToken.startsWith('set/a') ||
      (firstToken === 'set' && (args[0]?.toLowerCase() === '/a' || args[0]?.toLowerCase().startsWith('/a')));

    if (isSetA) {
      let rawExpr = trimmed.replace(/^set\s*\/a\s*/i, '').replace(/^set\/a\s*/i, '').trim();
      if ((rawExpr.startsWith('"') && rawExpr.endsWith('"')) || (rawExpr.startsWith("'") && rawExpr.endsWith("'"))) {
        rawExpr = rawExpr.substring(1, rawExpr.length - 1).trim();
      }

      if (!rawExpr) {
        output.push({ id: 'out-' + Date.now(), type: 'output', text: '0' });
        return output;
      }

      // Support comma-separated expressions (e.g. set /a a=5, b=6, a+b)
      const subExprs = rawExpr.split(',').map((s) => s.trim().replace(/^["']|["']$/g, '')).filter(Boolean);
      let lastVal = 0;
      const tempVars: Record<string, string> = { ...ctx.envVars };

      try {
        for (const expr of subExprs) {
          let targetVar: string | null = null;
          let op = '=';
          let mathPart = expr;

          // Check assignment: +=, -=, *=, /=, %=, &=, |=, ^=, <<=, >>=, =
          const assignMatch = expr.match(/^([a-zA-Z_][a-zA-Z0-9_]*)\s*(\+=|-=|\*=|\/=|%=|&=|\|=|\^=|<<=|>>=|=)\s*(.*)$/);
          if (assignMatch) {
            targetVar = assignMatch[1].toUpperCase();
            op = assignMatch[2];
            mathPart = assignMatch[3].trim();
          }

          // Replace identifiers with variable values
          const resolvedMath = mathPart.replace(/\b([a-zA-Z_][a-zA-Z0-9_]*)\b/g, (match) => {
            const val = tempVars[match.toUpperCase()];
            if (val !== undefined && !isNaN(Number(val))) {
              return String(Math.trunc(Number(val)));
            }
            return '0';
          });

          // Sanitize math string (allow digits, hex, arithmetic & bitwise operators, parens, spaces)
          const sanitized = resolvedMath.replace(/[^0-9a-fA-Fx+\-*/%() ~^&|<>\s]/g, '');
          const evaluated = Function(`'use strict'; return (${sanitized || '0'})`)();
          let num = Math.trunc(Number(evaluated));
          if (isNaN(num) || !isFinite(num)) {
            num = 0;
          }

          if (targetVar) {
            const currentVal = Math.trunc(Number(tempVars[targetVar] || '0'));
            if (op === '=') lastVal = num;
            else if (op === '+=') lastVal = currentVal + num;
            else if (op === '-=') lastVal = currentVal - num;
            else if (op === '*=') lastVal = currentVal * num;
            else if (op === '/=') lastVal = num !== 0 ? Math.trunc(currentVal / num) : 0;
            else if (op === '%=') lastVal = num !== 0 ? currentVal % num : 0;
            else if (op === '&=') lastVal = currentVal & num;
            else if (op === '|=') lastVal = currentVal | num;
            else if (op === '^=') lastVal = currentVal ^ num;
            else if (op === '<<=') lastVal = currentVal << num;
            else if (op === '>>=') lastVal = currentVal >> num;

            tempVars[targetVar] = String(lastVal);
            ctx.setEnvVars((prev) => ({ ...prev, [targetVar!]: String(lastVal) }));
          } else {
            lastVal = num;
          }
        }

        output.push({ id: 'out-' + Date.now(), type: 'output', text: String(lastVal) });
      } catch {
        output.push({ id: 'out-' + Date.now(), type: 'output', text: '0' });
      }
      return output;
    }

    // Check for prompt switch: set /p or set/p
    const isSetP =
      firstToken === 'set/p' ||
      firstToken.startsWith('set/p') ||
      (firstToken === 'set' && (args[0]?.toLowerCase() === '/p' || args[0]?.toLowerCase().startsWith('/p')));

    if (isSetP) {
      const pExpr = trimmed.replace(/^set\s*\/p\s*/i, '').replace(/^set\/p\s*/i, '').trim();
      const pEq = pExpr.indexOf('=');
      if (pEq !== -1) {
        const pKey = pExpr.substring(0, pEq).trim().toUpperCase();
        const pPrompt = pExpr.substring(pEq + 1).trim();
        output.push({ id: 'out-' + Date.now(), type: 'output', text: pPrompt || `Nhập giá trị cho ${pKey}:` });
      }
      return output;
    }

    if (args.length === 0 && firstToken === 'set') {
      const lines = Object.entries(ctx.envVars).map(([k, v]) => `${k}=${v}`);
      output.push({ id: 'out-' + Date.now(), type: 'output', text: lines.join('\n') });
      return output;
    }

    const eqIdx = restText.indexOf('=');
    if (eqIdx !== -1) {
      const key = restText.substring(0, eqIdx).trim().toUpperCase();
      const val = restText.substring(eqIdx + 1).trim();
      ctx.setEnvVars((prev) => ({ ...prev, [key]: val }));
      output.push({ id: 'out-' + Date.now(), type: 'success', text: `${key}=${val}` });
      return output;
    }

    if (args[0]) {
      output.push({ id: 'out-' + Date.now(), type: 'output', text: ctx.envVars[args[0].toUpperCase()] || '' });
    }
    return output;
  }

  if (firstToken === 'setx') {
    if (args.length < 2) {
      output.push({ id: 'err-' + Date.now(), type: 'error', text: 'Cú pháp: SETX [biến] [giá_trị]' });
      return output;
    }
    const key = args[0].toUpperCase();
    const val = args[1];
    ctx.setEnvVars((prev) => ({ ...prev, [key]: val }));
    output.push({ id: 'out-' + Date.now(), type: 'success', text: `THÀNH CÔNG: Giá trị chỉ định đã được lưu vào Registry: ${key}=${val}` });
    return output;
  }

  if (firstToken === 'mode') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'output',
      text: `Status for device CON:
-----------------------
    Lines:          30
    Columns:        120
    Keyboard rate:  31
    Keyboard delay: 1
    Code page:      65001`,
    });
    return output;
  }

  if (firstToken === 'color') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'info',
      text: `Màu sắc Terminal đã được cập nhật: ${args[0] || 'mặc định (07)'}`,
    });
    return output;
  }

  // --- NHÓM 7: LỆNH ĐỘC NHẤT DỰ ÁN ---

  if (firstToken === 'install-app') {
    if (args.length === 0) {
      const doc = getHelpForCommand('install-app');
      output.push({ id: 'err-' + Date.now(), type: 'error', text: `Cú pháp không đầy đủ.\n${doc?.syntax || 'INSTALL-APP [tên_ứng_dụng]'}` });
      return output;
    }
    const appName = args.join(' ');
    const htmlContent = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${appName}</title>
  <style>
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 24px; background: #0f172a; color: #f8fafc; text-align: center; }
    h1 { color: #38bdf8; margin-bottom: 12px; }
    .card { background: #1e293b; padding: 20px; border-radius: 12px; max-width: 480px; margin: 0 auto; box-shadow: 0 4px 12px rgba(0,0,0,0.5); }
    button { background: #0284c7; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 14px; margin-top: 10px; }
    button:hover { background: #0369a1; }
  </style>
</head>
<body>
  <div class="card">
    <h1>🚀 ${appName}</h1>
    <p>Ứng dụng đã được cài đặt tự động từ Terminal dòng lệnh Windows 11!</p>
    <button onclick="alert('Chào mừng bạn đến với ${appName}!')">Nhấn thử</button>
  </div>
</body>
</html>`;

    if (ctx.createHtmlApp) {
      ctx.createHtmlApp(appName, 'Code', htmlContent, 'Developer');
    } else {
      ctx.addFile({
        name: `${appName}.html`,
        path: `C:\\Users\\User\\Desktop\\${appName}.html`,
        isDirectory: false,
        size: htmlContent.length,
        content: htmlContent,
      });
    }

    ctx.addNotification('Cài đặt ứng dụng thành công', `Ứng dụng "${appName}" đã được cài đặt và thêm vào Start Menu / Desktop.`, 'sparkles');
    output.push({
      id: 'out-' + Date.now(),
      type: 'success',
      text: `[THÀNH CÔNG] Đã tạo và cài đặt ứng dụng "${appName}" vào hệ điều hành!\nBạn có thể mở tệp ${appName}.html trên Desktop hoặc Start Menu.`,
    });
    return output;
  }

  if (firstToken === 'winfetch' || firstToken === 'neofetch') {
    const winfetchAscii = `
    ████████   ████████    User@DESKTOP-WIN11-OS
    ████████   ████████    ---------------------
    ████████   ████████    OS: Windows 11 Pro 23H2 (Build 22631.3296)
    ████████   ████████    Host: AI Studio Virtual Machine
                           Kernel: Windows NT 10.0.22631
    ████████   ████████    Uptime: 2 hours, 45 mins
    ████████   ████████    Packages: 245 (Win11 Internal Suite)
    ████████   ████████    Shell: Windows Terminal 1.19 / PowerShell
    ████████   ████████    Resolution: 1920x1080 @ 144Hz
                           DE: Fluent Design System Mica
                           CPU: AMD Ryzen 9 7950X (16) @ 4.50GHz
                           GPU: NVIDIA GeForce RTX 4090 24GB
                           Memory: 8576MB / 32768MB (26%)
`;
    output.push({ id: 'out-' + Date.now(), type: 'ascii', text: winfetchAscii });
    return output;
  }

  if (firstToken === 'recover-system') {
    if (ctx.clearSystemFailure) ctx.clearSystemFailure();
    if (ctx.repairStartup) ctx.repairStartup();
    if (ctx.restoreFromRestorePoint) ctx.restoreFromRestorePoint();

    ctx.addNotification('Phục hồi hệ thống hoàn tất', 'Tất cả các tệp hệ thống bị lỗi hoặc bị xóa đã được khôi phục nguyên vẹn.', 'shield');
    output.push({
      id: 'out-' + Date.now(),
      type: 'success',
      text: `[HỆ THỐNG PHỤC HỒI]
=======================================================================
✓ Đã quét và khôi phục toàn bộ các tệp hệ thống quan trọng trong C:\\Windows
✓ Đã giải trừ cờ lỗi hệ thống và thiết lập lại điểm sao lưu an toàn
✓ Hệ điều hành Windows 11 đã hoạt động ổn định 100%!
=======================================================================`,
    });
    return output;
  }

  // --- BUILT-IN APPLICATIONS & SHORTCUTS ---

  // Control Panel (control.exe / control / *.cpl)
  if (firstToken === 'control' || firstToken === 'control.exe' || firstToken.endsWith('.cpl')) {
    const rawArgs = firstToken.endsWith('.cpl') ? [firstToken, ...args] : args;
    const parsed = parseControlCommand(rawArgs);

    if (parsed.isHelp) {
      output.push({
        id: 'out-' + Date.now(),
        type: 'output',
        text: CONTROL_HELP_TEXT,
      });
      return output;
    }

    ctx.openApp('control', {
      page: parsed.page,
      cpl: parsed.cpl,
      isAdmin: parsed.isAdmin,
      windowTitle: parsed.isAdmin
        ? 'Administrator: Control Panel'
        : parsed.targetItem
        ? `${parsed.targetItem.name} - Control Panel`
        : 'Control Panel',
    });

    const targetDesc = parsed.targetItem
      ? `${parsed.targetItem.name} (${parsed.targetItem.canonicalName})`
      : parsed.page || parsed.cpl || 'Bảng Điều khiển chính (Control Panel)';

    output.push({
      id: 'out-' + Date.now(),
      type: 'success',
      text: `Đang mở Bảng Điều khiển: ${targetDesc}${parsed.isAdmin ? ' [Quyền Quản trị viên]' : ''}...`,
    });
    return output;
  }

  if (['calc', 'notepad', 'explorer', 'paint', 'settings', 'taskmgr', 'copilot', 'edge', 'winver'].includes(firstToken)) {
    ctx.openApp(firstToken);
    output.push({ id: 'out-' + Date.now(), type: 'success', text: `Đang khởi chạy ứng dụng: ${firstToken}...` });
    return output;
  }

  if (firstToken === 'start') {
    if (args.length === 0) {
      output.push({ id: 'out-' + Date.now(), type: 'info', text: 'Cú pháp: START [ứng_dụng_hoặc_tệp]' });
      return output;
    }
    const appTarget = args[0].toLowerCase().replace('.exe', '');
    if (appTarget === 'control' || appTarget.endsWith('.cpl')) {
      const parsed = parseControlCommand(appTarget.endsWith('.cpl') ? [appTarget, ...args.slice(1)] : args.slice(1));
      ctx.openApp('control', {
        page: parsed.page,
        cpl: parsed.cpl,
        isAdmin: parsed.isAdmin,
        windowTitle: parsed.isAdmin ? 'Administrator: Control Panel' : 'Control Panel',
      });
      output.push({ id: 'out-' + Date.now(), type: 'success', text: `Đã khởi chạy: ${args[0]}` });
      return output;
    }
    ctx.openApp(appTarget);
    output.push({ id: 'out-' + Date.now(), type: 'success', text: `Đã khởi chạy: ${args[0]}` });
    return output;
  }

  if (firstToken === 'matrix') {
    output.push({
      id: 'out-' + Date.now(),
      type: 'success',
      text: `01010110 01101001 01100101 01110100 01101110 01100001 01101101 
W A K E   U P ,   N E O . . .
T H E   M A T R I X   H A S   Y O U . . .
F O L L O W   T H E   W H I T E   R A B B I T .`,
    });
    return output;
  }

  if (firstToken === 'cowsay') {
    const msg = args.join(' ') || 'Windows 11 Terminal rocks!';
    output.push({
      id: 'out-' + Date.now(),
      type: 'output',
      text: ` ________
< ${msg} >
 --------
        \\   ^__^
         \\  (oo)\\_______
            (__)\\       )\\/\\
                ||----w |
                ||     ||`,
    });
    return output;
  }

  // Expression / PowerShell fallback inside CMD
  if (/^\$psversiontable/i.test(trimmed)) {
    const propMatch = trimmed.match(/^\$psversiontable(?:\.([a-zA-Z0-9_().]+)|\[['"]?([a-zA-Z0-9_]+)['"]?\])?$/i);
    const prop = propMatch ? (propMatch[1] || propMatch[2]) : undefined;
    output.push({ id: 'out-' + Date.now(), type: 'output', text: handlePSVersionTableAccess(prop) });
    return output;
  }

  if (trimmed.startsWith('(') && /Get-ItemProperty/i.test(trimmed)) {
    if (/DisplayVersion/i.test(trimmed)) {
      output.push({ id: 'out-' + Date.now(), type: 'output', text: '23H2' });
      return output;
    }
  }

  // If command is NOT recognized: Rule 3
  output.push({
    id: 'err-' + Date.now(),
    type: 'error',
    text: `'${firstToken}' không được nhận ra là một lệnh nội bộ hoặc bên ngoài, chương trình có thể thực thi hoặc tệp bó. (Gõ 'help' để xem danh sách 7 nhóm lệnh).`,
  });

  return output;
}
