export type ControlPanelCategory =
  | 'system_security'
  | 'network'
  | 'hardware'
  | 'programs'
  | 'accounts'
  | 'appearance'
  | 'clock'
  | 'ease_of_access';

export interface ControlPanelItem {
  id: string;
  canonicalName: string;
  name: string;
  vietnameseName: string;
  category: ControlPanelCategory;
  icon: string;
  cpl?: string;
  description: string;
  vietnameseDescription: string;
  keywords: string[];
}

export interface CategoryInfo {
  id: ControlPanelCategory;
  name: string;
  vietnameseName: string;
  icon: string;
  color: string;
  description: string;
  tasks: {
    label: string;
    vietnameseLabel: string;
    targetItem: string;
  }[];
}

export const CONTROL_PANEL_CATEGORIES: CategoryInfo[] = [
  {
    id: 'system_security',
    name: 'System and Security',
    vietnameseName: 'Hệ thống và Bảo mật',
    icon: 'ShieldCheck',
    color: '#0078D4',
    description: "Review your computer's status, backup files, and configure system security",
    tasks: [
      { label: "Review your computer's status", vietnameseLabel: 'Kiểm tra trạng thái máy tính', targetItem: 'Microsoft.ActionCenter' },
      { label: 'Windows Defender Firewall', vietnameseLabel: 'Tường lửa Windows Defender', targetItem: 'Microsoft.Firewall' },
      { label: 'System', vietnameseLabel: 'Hệ thống (Thông tin máy)', targetItem: 'Microsoft.System' },
      { label: 'Power Options', vietnameseLabel: 'Tùy chọn Nguồn điện', targetItem: 'Microsoft.PowerOptions' },
      { label: 'BitLocker Drive Encryption', vietnameseLabel: 'Mã hóa ổ đĩa BitLocker', targetItem: 'Microsoft.BitLockerDriveEncryption' },
      { label: 'Storage Spaces', vietnameseLabel: 'Không gian lưu trữ Storage Spaces', targetItem: 'Microsoft.StorageSpaces' },
      { label: 'Device Manager', vietnameseLabel: 'Trình quản lý Thiết bị', targetItem: 'Microsoft.DeviceManager' },
    ],
  },
  {
    id: 'network',
    name: 'Network and Internet',
    vietnameseName: 'Mạng và Internet',
    icon: 'Globe',
    color: '#0078D4',
    description: 'View network status, connect to networks, and set internet preferences',
    tasks: [
      { label: 'View network status and tasks', vietnameseLabel: 'Xem trạng thái mạng và tác vụ', targetItem: 'Microsoft.NetworkAndSharingCenter' },
      { label: 'Internet Options', vietnameseLabel: 'Tùy chọn Internet', targetItem: 'Microsoft.InternetOptions' },
      { label: 'Network Connections', vietnameseLabel: 'Kết nối mạng (ncpa.cpl)', targetItem: 'ncpa.cpl' },
    ],
  },
  {
    id: 'hardware',
    name: 'Hardware and Sound',
    vietnameseName: 'Phần cứng và Âm thanh',
    icon: 'Speaker',
    color: '#0078D4',
    description: 'Configure devices, sound cards, printers, and power settings',
    tasks: [
      { label: 'Device Manager', vietnameseLabel: 'Trình quản lý Thiết bị', targetItem: 'Microsoft.DeviceManager' },
      { label: 'Sound', vietnameseLabel: 'Cài đặt Âm thanh (mmsys.cpl)', targetItem: 'Microsoft.Sound' },
      { label: 'Power Options', vietnameseLabel: 'Tùy chọn Nguồn điện (powercfg.cpl)', targetItem: 'Microsoft.PowerOptions' },
      { label: 'Mouse', vietnameseLabel: 'Thuộc tính Chuột (main.cpl)', targetItem: 'Microsoft.Mouse' },
      { label: 'Keyboard', vietnameseLabel: 'Cài đặt Bàn phím', targetItem: 'Microsoft.Keyboard' },
      { label: 'AutoPlay', vietnameseLabel: 'Tự động phát AutoPlay', targetItem: 'Microsoft.AutoPlay' },
      { label: 'Game Controllers', vietnameseLabel: 'Thiết bị trò chơi (joy.cpl)', targetItem: 'joy.cpl' },
    ],
  },
  {
    id: 'programs',
    name: 'Programs',
    vietnameseName: 'Chương trình',
    icon: 'Package',
    color: '#0078D4',
    description: 'Uninstall programs, manage Windows features, and configure defaults',
    tasks: [
      { label: 'Uninstall a program', vietnameseLabel: 'Gỡ cài đặt chương trình (appwiz.cpl)', targetItem: 'Microsoft.ProgramsAndFeatures' },
      { label: 'Default Programs', vietnameseLabel: 'Chương trình mặc định', targetItem: 'Microsoft.DefaultPrograms' },
    ],
  },
  {
    id: 'accounts',
    name: 'User Accounts',
    vietnameseName: 'Tài khoản người dùng',
    icon: 'UserCheck',
    color: '#0078D4',
    description: 'Manage user profiles, account types, and credential manager',
    tasks: [
      { label: 'Change account type', vietnameseLabel: 'Thay đổi loại tài khoản', targetItem: 'Microsoft.UserAccounts' },
      { label: 'User Accounts', vietnameseLabel: 'Quản lý tài khoản người dùng', targetItem: 'Microsoft.UserAccounts' },
    ],
  },
  {
    id: 'appearance',
    name: 'Appearance and Personalization',
    vietnameseName: 'Giao diện và Cá nhân hóa',
    icon: 'Palette',
    color: '#0078D4',
    description: 'Change desktop wallpaper, window colors, taskbar, and fonts',
    tasks: [
      { label: 'Personalization', vietnameseLabel: 'Cá nhân hóa giao diện', targetItem: 'Microsoft.Personalization' },
      { label: 'File Explorer Options', vietnameseLabel: 'Tùy chọn Thư mục File Explorer', targetItem: 'Microsoft.FolderOptions' },
      { label: 'Fonts', vietnameseLabel: 'Quản lý Phông chữ', targetItem: 'Microsoft.Fonts' },
      { label: 'Display', vietnameseLabel: 'Cài đặt Hiển thị', targetItem: 'Microsoft.Display' },
    ],
  },
  {
    id: 'clock',
    name: 'Clock and Region',
    vietnameseName: 'Đồng hồ và Vùng',
    icon: 'Clock',
    color: '#0078D4',
    description: 'Set date, time, time zone, formats, and regional language',
    tasks: [
      { label: 'Set the time and date', vietnameseLabel: 'Cài đặt Ngày và Giờ (timedate.cpl)', targetItem: 'Microsoft.DateAndTime' },
      { label: 'Region and Language', vietnameseLabel: 'Vùng và Định dạng số/ngày (intl.cpl)', targetItem: 'Microsoft.RegionAndLanguage' },
    ],
  },
  {
    id: 'ease_of_access',
    name: 'Ease of Access',
    vietnameseName: 'Hỗ trợ tiếp cận',
    icon: 'Eye',
    color: '#0078D4',
    description: 'Let Windows suggest settings, speech recognition, and visual aids',
    tasks: [
      { label: 'Speech Recognition / Text to Speech', vietnameseLabel: 'Nhận dạng giọng nói / Giọng đọc', targetItem: 'Microsoft.TextToSpeech' },
      { label: 'Troubleshooting', vietnameseLabel: 'Trợ giúp & Khắc phục sự cố', targetItem: 'Microsoft.Troubleshooting' },
    ],
  },
];

export const CONTROL_PANEL_ITEMS: ControlPanelItem[] = [
  {
    id: 'Microsoft.System',
    canonicalName: 'Microsoft.System',
    name: 'System',
    vietnameseName: 'Hệ thống (Thông tin máy)',
    category: 'system_security',
    icon: 'Cpu',
    cpl: 'sysdm.cpl',
    description: 'View basic information about your computer, processor, RAM, and system properties',
    vietnameseDescription: 'Xem thông tin cơ bản về cấu hình máy tính, vi xử lý, RAM và thuộc tính hệ thống',
    keywords: ['system', 'sysdm.cpl', 'specs', 'ram', 'cpu', 'processor', 'hardware', 'windows version', 'computer name'],
  },
  {
    id: 'Microsoft.DateAndTime',
    canonicalName: 'Microsoft.DateAndTime',
    name: 'Date and Time',
    vietnameseName: 'Ngày & Giờ',
    category: 'clock',
    icon: 'Clock',
    cpl: 'timedate.cpl',
    description: 'Set the date, time, time zone, and internet time synchronization',
    vietnameseDescription: 'Đặt ngày, giờ, múi giờ và đồng bộ hóa thời gian internet',
    keywords: ['time', 'date', 'timedate.cpl', 'clock', 'timezone', 'sync', 'internet time'],
  },
  {
    id: 'Microsoft.RegionAndLanguage',
    canonicalName: 'Microsoft.RegionAndLanguage',
    name: 'Region and Language',
    vietnameseName: 'Vùng & Ngôn ngữ',
    category: 'clock',
    icon: 'Languages',
    cpl: 'intl.cpl',
    description: 'Customize formats for dates, times, currency, and regional language',
    vietnameseDescription: 'Tùy chỉnh định dạng ngày tháng, thời gian, tiền tệ và vùng địa lý',
    keywords: ['region', 'language', 'intl.cpl', 'format', 'locale', 'vietnam', 'english'],
  },
  {
    id: 'Microsoft.UserAccounts',
    canonicalName: 'Microsoft.UserAccounts',
    name: 'User Accounts',
    vietnameseName: 'Tài khoản người dùng',
    category: 'accounts',
    icon: 'UserCheck',
    description: 'Change user account settings, passwords, account type, and UAC',
    vietnameseDescription: 'Thay đổi cài đặt tài khoản người dùng, mật khẩu, phân quyền quản trị và UAC',
    keywords: ['user', 'account', 'admin', 'password', 'uac', 'profile', 'security'],
  },
  {
    id: 'Microsoft.DeviceManager',
    canonicalName: 'Microsoft.DeviceManager',
    name: 'Device Manager',
    vietnameseName: 'Trình quản lý Thiết bị',
    category: 'hardware',
    icon: 'HardDrive',
    cpl: 'hdwwiz.cpl',
    description: 'View and update device drivers, hardware properties, and troubleshoot devices',
    vietnameseDescription: 'Xem và cập nhật trình điều khiển phần cứng, kiểm tra thông số và khắc phục sự cố thiết bị',
    keywords: ['device', 'driver', 'hardware', 'gpu', 'display', 'cpu', 'sound', 'network', 'hdwwiz.cpl', 'devmgmt.msc'],
  },
  {
    id: 'Microsoft.NetworkAndSharingCenter',
    canonicalName: 'Microsoft.NetworkAndSharingCenter',
    name: 'Network and Sharing Center',
    vietnameseName: 'Mạng & Trung tâm chia sẻ',
    category: 'network',
    icon: 'Globe',
    cpl: 'ncpa.cpl',
    description: 'Check network status, change adapter settings, and configure connections',
    vietnameseDescription: 'Kiểm tra trạng thái mạng, thay đổi thiết lập card mạng và cấu hình chia sẻ',
    keywords: ['network', 'wifi', 'ethernet', 'adapter', 'ncpa.cpl', 'ip', 'sharing', 'internet'],
  },
  {
    id: 'Microsoft.Sound',
    canonicalName: 'Microsoft.Sound',
    name: 'Sound',
    vietnameseName: 'Âm thanh',
    category: 'hardware',
    icon: 'Speaker',
    cpl: 'mmsys.cpl',
    description: 'Configure audio devices, speakers, microphones, and system sound schemes',
    vietnameseDescription: 'Cấu hình thiết bị phát âm thanh, loa, micrô và bộ âm thanh thông báo hệ thống',
    keywords: ['sound', 'audio', 'mmsys.cpl', 'speakers', 'microphone', 'volume', 'playback', 'recording'],
  },
  {
    id: 'Microsoft.PowerOptions',
    canonicalName: 'Microsoft.PowerOptions',
    name: 'Power Options',
    vietnameseName: 'Tùy chọn Nguồn',
    category: 'system_security',
    icon: 'BatteryCharging',
    cpl: 'powercfg.cpl',
    description: 'Choose or customize power plans, sleep modes, and display timeouts',
    vietnameseDescription: 'Chọn hoặc tùy chỉnh gói nguồn điện, chế độ ngủ và thời gian tắt màn hình',
    keywords: ['power', 'powercfg.cpl', 'battery', 'sleep', 'energy', 'plan', 'balanced', 'performance'],
  },
  {
    id: 'Microsoft.WindowsUpdate',
    canonicalName: 'Microsoft.WindowsUpdate',
    name: 'Windows Update',
    vietnameseName: 'Cập nhật Windows',
    category: 'system_security',
    icon: 'RotateCw',
    description: 'Check for Windows updates, driver patches, and review update history',
    vietnameseDescription: 'Kiểm tra các bản cập nhật Windows, vá lỗi bảo mật và xem lịch sử nâng cấp',
    keywords: ['update', 'windows update', 'patch', 'upgrade', 'kb', 'build'],
  },
  {
    id: 'Microsoft.Defender',
    canonicalName: 'Microsoft.Defender',
    name: 'Windows Security',
    vietnameseName: 'Bảo mật Windows (Defender)',
    category: 'system_security',
    icon: 'ShieldCheck',
    description: 'Manage Microsoft Defender antivirus, real-time protection, and threat scanning',
    vietnameseDescription: 'Quản lý tính năng diệt virus Microsoft Defender, bảo vệ thời gian thực và quét mối đe dọa',
    keywords: ['defender', 'antivirus', 'security', 'protection', 'scan', 'virus', 'firewall'],
  },
  {
    id: 'Microsoft.Display',
    canonicalName: 'Microsoft.Display',
    name: 'Display',
    vietnameseName: 'Hiển thị',
    category: 'appearance',
    icon: 'Monitor',
    cpl: 'desk.cpl',
    description: 'Change screen resolution, DPI scaling, orientation, and refresh rates',
    vietnameseDescription: 'Thay đổi độ phân giải màn hình, tỷ lệ thu phóng DPI, hướng hiển thị và tần số quét',
    keywords: ['display', 'screen', 'resolution', 'desk.cpl', 'scaling', 'monitor', '4k', 'hdr'],
  },
  {
    id: 'Microsoft.Personalization',
    canonicalName: 'Microsoft.Personalization',
    name: 'Personalization',
    vietnameseName: 'Cá nhân hóa',
    category: 'appearance',
    icon: 'Palette',
    description: 'Customize desktop background wallpaper, accent colors, and dark/light themes',
    vietnameseDescription: 'Tùy chỉnh hình nền máy tính, màu sắc điểm nhấn và chủ đề giao diện Sáng/Tối',
    keywords: ['personalization', 'theme', 'wallpaper', 'color', 'dark mode', 'accent', 'background'],
  },
  {
    id: 'Microsoft.DefaultPrograms',
    canonicalName: 'Microsoft.DefaultPrograms',
    name: 'Default Programs',
    vietnameseName: 'Chương trình mặc định',
    category: 'programs',
    icon: 'AppWindow',
    description: 'Set default programs for web browsing, media, email, and file associations',
    vietnameseDescription: 'Chọn chương trình mặc định để duyệt web, phát nhạc, xem video và mở loại tệp',
    keywords: ['default', 'programs', 'browser', 'assoc', 'media player', 'email'],
  },
  {
    id: 'Microsoft.ProgramsAndFeatures',
    canonicalName: 'Microsoft.ProgramsAndFeatures',
    name: 'Programs and Features',
    vietnameseName: 'Gỡ cài đặt chương trình (Programs and Features)',
    category: 'programs',
    icon: 'Package',
    cpl: 'appwiz.cpl',
    description: 'Uninstall, repair, or change installed applications and Windows features',
    vietnameseDescription: 'Gỡ cài đặt, sửa chữa hoặc thay đổi các ứng dụng đã cài đặt và tính năng Windows',
    keywords: ['uninstall', 'programs', 'features', 'appwiz.cpl', 'remove', 'software', 'install'],
  },
  {
    id: 'Microsoft.Firewall',
    canonicalName: 'Microsoft.Firewall',
    name: 'Windows Defender Firewall',
    vietnameseName: 'Tường lửa Windows (Firewall)',
    category: 'system_security',
    icon: 'Shield',
    cpl: 'firewall.cpl',
    description: 'Protect your computer against unauthorized access and configure network traffic rules',
    vietnameseDescription: 'Bảo vệ máy tính khỏi các truy cập trái phép và thiết lập quy tắc truyền tải mạng',
    keywords: ['firewall', 'firewall.cpl', 'defender', 'security', 'ports', 'inbound', 'outbound'],
  },
  {
    id: 'Microsoft.BitLockerDriveEncryption',
    canonicalName: 'Microsoft.BitLockerDriveEncryption',
    name: 'BitLocker Drive Encryption',
    vietnameseName: 'Mã hóa ổ đĩa BitLocker',
    category: 'system_security',
    icon: 'Lock',
    description: 'Protect files and folders from unauthorized access by encrypting drives',
    vietnameseDescription: 'Bảo vệ dữ liệu và thư mục khỏi truy cập trái phép bằng cách mã hóa toàn bộ ổ đĩa',
    keywords: ['bitlocker', 'encryption', 'drive', 'tpm', 'recovery key', 'security', 'disk'],
  },
  {
    id: 'Microsoft.StorageSpaces',
    canonicalName: 'Microsoft.StorageSpaces',
    name: 'Storage Spaces',
    vietnameseName: 'Không gian lưu trữ Storage Spaces',
    category: 'system_security',
    icon: 'HardDrive',
    description: 'Save files to two or more drives to help protect your data from drive failure',
    vietnameseDescription: 'Lưu trữ tệp trên nhiều ổ đĩa để bảo vệ dữ liệu khi ổ cứng gặp sự cố',
    keywords: ['storage', 'spaces', 'pool', 'disk', 'redundancy', 'mirror', 'parity'],
  },
  {
    id: 'Microsoft.Fonts',
    canonicalName: 'Microsoft.Fonts',
    name: 'Fonts',
    vietnameseName: 'Phông chữ Fonts',
    category: 'appearance',
    icon: 'Type',
    description: 'Preview, add, remove, and configure installed system typography and fonts',
    vietnameseDescription: 'Xem trước, thêm, xóa và thiết lập các bộ phông chữ hệ thống được cài đặt',
    keywords: ['fonts', 'font', 'typography', 'segoe', 'arial', 'times', 'preview'],
  },
  {
    id: 'Microsoft.TextToSpeech',
    canonicalName: 'Microsoft.TextToSpeech',
    name: 'Speech Recognition & Text to Speech',
    vietnameseName: 'Giọng nói & Đọc văn bản (Text to Speech)',
    category: 'ease_of_access',
    icon: 'Mic',
    description: 'Configure text-to-speech voice, reading speed, and speech recognition settings',
    vietnameseDescription: 'Cấu hình giọng đọc văn bản, tốc độ đọc và các thiết lập nhận dạng giọng nói',
    keywords: ['tts', 'speech', 'voice', 'text to speech', 'recognition', 'narration'],
  },
  {
    id: 'Microsoft.Keyboard',
    canonicalName: 'Microsoft.Keyboard',
    name: 'Keyboard',
    vietnameseName: 'Bàn phím',
    category: 'hardware',
    icon: 'Keyboard',
    description: 'Adjust keyboard character repeat rate, repeat delay, and cursor blink rate',
    vietnameseDescription: 'Điều chỉnh tốc độ lặp phím, độ trễ và tần số nhấp nháy của con trỏ chuột',
    keywords: ['keyboard', 'keys', 'repeat rate', 'delay', 'cursor blink'],
  },
  {
    id: 'Microsoft.Mouse',
    canonicalName: 'Microsoft.Mouse',
    name: 'Mouse',
    vietnameseName: 'Chuột (Mouse Properties)',
    category: 'hardware',
    icon: 'Mouse',
    cpl: 'main.cpl',
    description: 'Customize mouse buttons, double-click speed, pointer schemes, and scroll wheel',
    vietnameseDescription: 'Tùy chỉnh nút chuột trái/phải, tốc độ nhấp đúp, con trỏ và bánh xe lăn cuộn',
    keywords: ['mouse', 'mouse.cpl', 'main.cpl', 'pointer', 'double click', 'cursor', 'wheel', 'scroll'],
  },
  {
    id: 'Microsoft.PenAndTouch',
    canonicalName: 'Microsoft.PenAndTouch',
    name: 'Pen and Touch',
    vietnameseName: 'Bút & Cảm ứng',
    category: 'hardware',
    icon: 'Hand',
    description: 'Configure pen buttons, gestures, and multi-touch screen actions',
    vietnameseDescription: 'Cấu hình nút bấm trên bút stylus, cử chỉ vuốt và thao tác cảm ứng đa điểm',
    keywords: ['pen', 'touch', 'stylus', 'gestures', 'screen', 'tapping'],
  },
  {
    id: 'Microsoft.AutoPlay',
    canonicalName: 'Microsoft.AutoPlay',
    name: 'AutoPlay',
    vietnameseName: 'Tự động phát AutoPlay',
    category: 'hardware',
    icon: 'PlayCircle',
    description: 'Choose what happens when you insert removable drives, USB flash, or memory cards',
    vietnameseDescription: 'Chọn hành động tự động khi cắm ổ USB flash, thẻ nhớ hoặc thiết bị ngoài',
    keywords: ['autoplay', 'usb', 'flash drive', 'removable', 'media', 'memory card'],
  },
  {
    id: 'Microsoft.FolderOptions',
    canonicalName: 'Microsoft.FolderOptions',
    name: 'File Explorer Options',
    vietnameseName: 'Tùy chọn Thư mục (Folder Options)',
    category: 'appearance',
    icon: 'FolderTree',
    description: 'Configure folder browsing, show hidden files and folders, and search options',
    vietnameseDescription: 'Cấu hình cách duyệt thư mục, hiện tệp tin/thư mục ẩn và các tùy chọn tìm kiếm',
    keywords: ['folder', 'explorer', 'hidden files', 'options', 'view', 'extensions'],
  },
  {
    id: 'Microsoft.IndexingOptions',
    canonicalName: 'Microsoft.IndexingOptions',
    name: 'Indexing Options',
    vietnameseName: 'Tùy chọn Lập chỉ mục',
    category: 'system_security',
    icon: 'Search',
    description: 'Change how Windows indexes files to speed up searching in File Explorer',
    vietnameseDescription: 'Thay đổi cách Windows lập chỉ mục tệp tin để tăng tốc tìm kiếm tệp',
    keywords: ['indexing', 'search', 'index', 'speed', 'catalog', 'find'],
  },
  {
    id: 'Microsoft.InternetOptions',
    canonicalName: 'Microsoft.InternetOptions',
    name: 'Internet Options',
    vietnameseName: 'Tùy chọn Internet (Internet Properties)',
    category: 'network',
    icon: 'Globe2',
    cpl: 'inetcpl.cpl',
    description: 'Configure web browser security zones, privacy settings, cookies, and network connections',
    vietnameseDescription: 'Cấu hình vùng bảo mật duyệt web, quyền riêng tư, cookie và kết nối mạng',
    keywords: ['internet', 'inetcpl.cpl', 'security', 'privacy', 'proxy', 'tls', 'connections'],
  },
  {
    id: 'Microsoft.PhoneAndModem',
    canonicalName: 'Microsoft.PhoneAndModem',
    name: 'Phone and Modem',
    vietnameseName: 'Điện thoại & Điều giải (Phone and Modem)',
    category: 'hardware',
    icon: 'Phone',
    cpl: 'telephon.cpl',
    description: 'Configure phone dialing rules, country codes, and modem hardware settings',
    vietnameseDescription: 'Cấu hình quy tắc quay số điện thoại, mã vùng quốc gia và thiết bị modem',
    keywords: ['phone', 'modem', 'telephon.cpl', 'dialing', 'telephony'],
  },
  {
    id: 'Microsoft.RemoteAppAndDesktopConnections',
    canonicalName: 'Microsoft.RemoteAppAndDesktopConnections',
    name: 'RemoteApp and Desktop Connections',
    vietnameseName: 'Kết nối từ xa RemoteApp',
    category: 'system_security',
    icon: 'MonitorUp',
    description: 'Access work programs, remote desktop virtual sessions, and corporate workspaces',
    vietnameseDescription: 'Truy cập chương trình làm việc từ xa, phiên máy tính ảo và không gian doanh nghiệp',
    keywords: ['remote', 'remoteapp', 'rdp', 'desktop', 'workspace', 'virtual'],
  },
  {
    id: 'Microsoft.SecurityCenter',
    canonicalName: 'Microsoft.SecurityCenter',
    name: 'Security Center',
    vietnameseName: 'Trung tâm Bảo mật (Security Center)',
    category: 'system_security',
    icon: 'ShieldCheck',
    cpl: 'wscui.cpl',
    description: 'Review overall system security status: firewall, antivirus, and security policies',
    vietnameseDescription: 'Xem trạng thái an ninh tổng thể: tường lửa, diệt virus và chính sách bảo mật',
    keywords: ['security', 'center', 'wscui.cpl', 'firewall', 'antivirus', 'protection'],
  },
  {
    id: 'Microsoft.ActionCenter',
    canonicalName: 'Microsoft.ActionCenter',
    name: 'Security and Maintenance',
    vietnameseName: 'Trung tâm Hành động (Security & Maintenance)',
    category: 'system_security',
    icon: 'Activity',
    description: 'Review important alerts about your computer and resolve issues that need attention',
    vietnameseDescription: 'Xem các thông báo quan trọng về máy tính và xử lý các vấn đề cần chú ý',
    keywords: ['action center', 'maintenance', 'alerts', 'notifications', 'health'],
  },
  {
    id: 'Microsoft.Troubleshooting',
    canonicalName: 'Microsoft.Troubleshooting',
    name: 'Troubleshooting',
    vietnameseName: 'Trợ giúp & Khắc phục sự cố',
    category: 'system_security',
    icon: 'Wrench',
    description: 'Automatically find and fix problems with networks, hardware, audio, and Windows Update',
    vietnameseDescription: 'Tự động phát hiện và khắc phục sự cố về mạng, phần cứng, âm thanh và Windows Update',
    keywords: ['troubleshoot', 'fix', 'problem', 'repair', 'diagnostic', 'network fix'],
  },
  {
    id: 'Microsoft.WorkFolders',
    canonicalName: 'Microsoft.WorkFolders',
    name: 'Work Folders',
    vietnameseName: 'Thư mục làm việc (Work Folders)',
    category: 'system_security',
    icon: 'FolderSync',
    description: 'Access your work files on this PC even when you are working offline',
    vietnameseDescription: 'Truy cập tệp công việc trên máy tính này ngay cả khi ngoại tuyến',
    keywords: ['work folders', 'sync', 'offline', 'enterprise', 'files'],
  },
  // Direct CPL shortcuts
  {
    id: 'joy.cpl',
    canonicalName: 'joy.cpl',
    name: 'Game Controllers',
    vietnameseName: 'Thiết bị trò chơi (Game Controllers)',
    category: 'hardware',
    icon: 'Gamepad2',
    cpl: 'joy.cpl',
    description: 'Configure and calibrate USB gamepads, joysticks, and Xbox controllers',
    vietnameseDescription: 'Cấu hình và hiệu chỉnh tay cầm chơi game, joystick và tay cầm Xbox',
    keywords: ['joy.cpl', 'game', 'controller', 'gamepad', 'joystick', 'xbox'],
  },
  {
    id: 'ks.cpl',
    canonicalName: 'ks.cpl',
    name: 'Camera & Imaging Settings',
    vietnameseName: 'Cài đặt máy ảnh & Thiết bị hình ảnh',
    category: 'hardware',
    icon: 'Camera',
    cpl: 'ks.cpl',
    description: 'Manage webcam device settings, video capture preferences, and imaging filters',
    vietnameseDescription: 'Quản lý cài đặt webcam, quay video và quyền truy cập máy ảnh',
    keywords: ['ks.cpl', 'camera', 'webcam', 'video', 'imaging'],
  },
];

export interface ControlParsedResult {
  isHelp: boolean;
  page?: string;
  cpl?: string;
  isAdmin?: boolean;
  targetItem?: ControlPanelItem;
  viewMode?: 'category' | 'large_icons' | 'small_icons';
  message?: string;
}

export function parseControlCommand(args: string[]): ControlParsedResult {
  if (args.length === 0) {
    return { isHelp: false };
  }

  const first = args[0].toLowerCase();
  if (first === '/?' || first === '-?' || first === '/help' || first === '-help' || first === 'help') {
    return { isHelp: true };
  }

  let isAdmin = false;
  let page: string | undefined;
  let cpl: string | undefined;
  let targetItem: ControlPanelItem | undefined;

  for (let i = 0; i < args.length; i++) {
    const rawArg = args[i];
    const arg = rawArg.toLowerCase();

    if (arg === '/admin' || arg === '-admin') {
      isAdmin = true;
      continue;
    }

    if (arg === '/?' || arg === '-?' || arg === '/help' || arg === '-help') {
      return { isHelp: true };
    }

    if (arg === '/name' || arg === '-name') {
      const val = args[i + 1];
      if (val) {
        page = val;
        i++;
      }
      continue;
    }

    if (arg.startsWith('/name:') || arg.startsWith('-name:')) {
      page = rawArg.split(':')[1];
      continue;
    }

    if (arg === '/page' || arg === '-page' || arg === '/applet' || arg === '-applet') {
      const val = args[i + 1];
      if (val) {
        page = val;
        i++;
      }
      continue;
    }

    if (arg.endsWith('.cpl')) {
      cpl = arg;
      continue;
    }

    // Direct Microsoft.X token without /name
    if (arg.startsWith('microsoft.') || arg.startsWith('microsoft/')) {
      page = rawArg;
      continue;
    }
  }

  // Resolve targetItem
  if (page) {
    const cleanPage = page.toLowerCase().replace(/["']/g, '');
    targetItem = CONTROL_PANEL_ITEMS.find(
      (it) =>
        it.canonicalName.toLowerCase() === cleanPage ||
        it.id.toLowerCase() === cleanPage ||
        cleanPage.endsWith('.' + it.id.toLowerCase().replace('microsoft.', '')) ||
        it.name.toLowerCase() === cleanPage ||
        (it.cpl && it.cpl.toLowerCase() === cleanPage)
    );
  }

  if (!targetItem && cpl) {
    const cleanCpl = cpl.toLowerCase().replace(/["']/g, '');
    targetItem = CONTROL_PANEL_ITEMS.find((it) => it.cpl && it.cpl.toLowerCase() === cleanCpl);
    if (!targetItem) {
      if (cleanCpl === 'mouse.cpl') {
        targetItem = CONTROL_PANEL_ITEMS.find((it) => it.canonicalName === 'Microsoft.Mouse');
      }
    }
  }

  return {
    isHelp: false,
    isAdmin,
    page: page || (targetItem ? targetItem.canonicalName : undefined),
    cpl,
    targetItem,
  };
}

export const CONTROL_HELP_TEXT = `Controls the system settings and applets in Windows.

CONTROL [/NAME pageName] [/PAGE pageName] [/APPLET appletName] [/ADMIN] [applet.cpl] [/?]

  /NAME pageName     Opens the specified Control Panel item by its canonical name.
                     Examples:
                       Microsoft.System
                       Microsoft.DateAndTime
                       Microsoft.RegionAndLanguage
                       Microsoft.UserAccounts
                       Microsoft.DeviceManager
                       Microsoft.NetworkAndSharingCenter
                       Microsoft.Sound
                       Microsoft.PowerOptions
                       Microsoft.WindowsUpdate
                       Microsoft.Defender
                       Microsoft.Display
                       Microsoft.Personalization
                       Microsoft.DefaultPrograms
                       Microsoft.ProgramsAndFeatures
                       Microsoft.Firewall
                       Microsoft.BitLockerDriveEncryption
                       Microsoft.StorageSpaces
                       Microsoft.Fonts
                       Microsoft.TextToSpeech
                       Microsoft.Keyboard
                       Microsoft.Mouse
                       Microsoft.PenAndTouch
                       Microsoft.AutoPlay
                       Microsoft.FolderOptions
                       Microsoft.IndexingOptions
                       Microsoft.InternetOptions
                       Microsoft.PhoneAndModem
                       Microsoft.RemoteAppAndDesktopConnections
                       Microsoft.SecurityCenter
                       Microsoft.ActionCenter
                       Microsoft.Troubleshooting
                       Microsoft.WorkFolders

  /PAGE pageName     Navigates to the specified sub-page or tab.
  /ADMIN             Opens Control Panel with elevated Administrator privileges.
  applet.cpl         Directly opens a Control Panel (.cpl) applet file.
                     Examples:
                       appwiz.cpl   - Programs and Features
                       timedate.cpl - Date and Time
                       desk.cpl     - Display Settings
                       mouse.cpl    - Mouse Properties (main.cpl)
                       mmsys.cpl    - Sound Settings
                       powercfg.cpl - Power Options
                       ncpa.cpl     - Network Connections
                       firewall.cpl - Windows Defender Firewall
                       sysdm.cpl    - System Properties
                       inetcpl.cpl  - Internet Options
                       intl.cpl     - Region and Language
                       joy.cpl      - Game Controllers
                       ks.cpl       - Camera Settings
                       telephon.cpl - Phone and Modem

  /?                 Displays this help screen.`;
