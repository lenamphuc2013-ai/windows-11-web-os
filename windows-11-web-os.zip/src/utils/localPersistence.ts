// IndexedDB Local Storage Utility for Windows 11 Web
// Provides persistent client-side storage for files, GIFs, videos, wallpapers, and system state
// overcoming localStorage 5MB quota restrictions.

const DB_NAME = 'Win11LocalStore';
const DB_VERSION = 1;
const STORE_NAME = 'keyval';

let dbPromise: Promise<IDBDatabase> | null = null;

function getDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise<IDBDatabase>((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB is not supported in this environment'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };

    request.onsuccess = (event: Event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      resolve(db);
    };

    request.onerror = (event: Event) => {
      console.warn('IndexedDB open error:', (event.target as IDBOpenDBRequest).error);
      reject((event.target as IDBOpenDBRequest).error);
    };
  });

  return dbPromise;
}

/**
 * Save data to IndexedDB asynchronously
 */
export async function saveLocalData<T>(key: string, val: T): Promise<void> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(val, key);

      req.onsuccess = () => resolve();
      req.onerror = () => {
        console.warn(`IndexedDB put error for key "${key}":`, req.error);
        reject(req.error);
      };
    });
  } catch (err) {
    console.warn(`saveLocalData failed for key "${key}":`, err);
  }
}

/**
 * Load data from IndexedDB asynchronously
 */
export async function loadLocalData<T>(key: string): Promise<T | null> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(key);

      req.onsuccess = () => {
        resolve(req.result !== undefined ? (req.result as T) : null);
      };
      req.onerror = () => {
        console.warn(`IndexedDB get error for key "${key}":`, req.error);
        reject(req.error);
      };
    });
  } catch (err) {
    console.warn(`loadLocalData failed for key "${key}":`, err);
    return null;
  }
}

/**
 * Delete a specific key from IndexedDB
 */
export async function deleteLocalData(key: string): Promise<void> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.delete(key);

      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn(`deleteLocalData failed for key "${key}":`, err);
  }
}

/**
 * Clear all persistent data from IndexedDB
 */
export async function clearAllLocalData(): Promise<void> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.clear();

      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('clearAllLocalData failed:', err);
  }
}
