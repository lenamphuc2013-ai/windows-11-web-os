import { FileSystemItem } from '../types';
import { WINDOWS_SYSTEM_ITEMS } from './systemFileSystemData';

// Helper to reliably create SVG data URIs for wallpapers across all browsers & hosting platforms
const svgToDataUri = (svgStr: string) => `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svgStr.trim())}`;

export const DEFAULT_WALLPAPERS = [
  {
    id: 'bloom-dark',
    name: 'Windows 11 Bloom (Dark)',
    url: svgToDataUri(`
      <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1920 1080' width='100%' height='100%'>
        <defs>
          <radialGradient id='bg' cx='60%' cy='45%' r='85%'>
            <stop offset='0%' stop-color='#1b2845'/>
            <stop offset='35%' stop-color='#0f172a'/>
            <stop offset='70%' stop-color='#090d16'/>
            <stop offset='100%' stop-color='#030509'/>
          </radialGradient>
          <linearGradient id='petal1' x1='10%' y1='10%' x2='90%' y2='90%'>
            <stop offset='0%' stop-color='#0098ff' stop-opacity='0.95'/>
            <stop offset='45%' stop-color='#0078d4' stop-opacity='0.85'/>
            <stop offset='100%' stop-color='#00386b' stop-opacity='0.4'/>
          </linearGradient>
          <linearGradient id='petal2' x1='90%' y1='10%' x2='10%' y2='90%'>
            <stop offset='0%' stop-color='#38bdf8' stop-opacity='0.9'/>
            <stop offset='50%' stop-color='#0284c7' stop-opacity='0.8'/>
            <stop offset='100%' stop-color='#0369a1' stop-opacity='0.3'/>
          </linearGradient>
          <linearGradient id='petal3' x1='50%' y1='0%' x2='50%' y2='100%'>
            <stop offset='0%' stop-color='#60a5fa' stop-opacity='0.85'/>
            <stop offset='50%' stop-color='#2563eb' stop-opacity='0.75'/>
            <stop offset='100%' stop-color='#1e3a8a' stop-opacity='0.5'/>
          </linearGradient>
          <linearGradient id='petal4' x1='0%' y1='100%' x2='100%' y2='0%'>
            <stop offset='0%' stop-color='#818cf8' stop-opacity='0.8'/>
            <stop offset='100%' stop-color='#4338ca' stop-opacity='0.3'/>
          </linearGradient>
          <radialGradient id='bloomCore' cx='50%' cy='50%' r='50%'>
            <stop offset='0%' stop-color='#38bdf8' stop-opacity='0.7'/>
            <stop offset='50%' stop-color='#0284c7' stop-opacity='0.3'/>
            <stop offset='100%' stop-color='#0369a1' stop-opacity='0'/>
          </radialGradient>
          <filter id='bloomBlur' x='-40%' y='-40%' width='180%' height='180%'>
            <feGaussianBlur stdDeviation='35' result='blur'/>
            <feComposite in='SourceGraphic' in2='blur' operator='over'/>
          </filter>
        </defs>
        <rect width='1920' height='1080' fill='url(#bg)'/>
        <circle cx='1040' cy='520' r='380' fill='url(#bloomCore)' filter='url(#bloomBlur)'/>
        <g filter='url(#bloomBlur)' transform='translate(1020, 530)'>
          <!-- Layer 1 Back Petals -->
          <path d='M-240,-320 C-80,-460 220,-380 290,-180 C360,20 280,240 120,340 C-40,440 -260,360 -340,180 C-420,0 -400,-180 -240,-320 Z' fill='url(#petal4)' opacity='0.6'/>
          <!-- Layer 2 Middle Petals -->
          <path d='M-180,-260 C-30,-380 200,-300 260,-120 C320,60 210,260 60,280 C-90,300 -270,210 -280,30 C-290,-150 -330,-140 -180,-260 Z' fill='url(#petal3)'/>
          <!-- Layer 3 Dynamic Swirls -->
          <path d='M-120,-180 C30,-320 240,-190 280,-20 C320,150 160,270 20,240 C-120,210 -260,120 -230,-20 C-200,-160 -270,-40 -120,-180 Z' fill='url(#petal1)'/>
          <!-- Layer 4 Foreground Light Petal -->
          <path d='M0,-140 C140,-220 250,-80 220,90 C190,260 40,280 -80,210 C-200,140 -170,-40 -110,-130 C-50,-220 -140,-60 0,-140 Z' fill='url(#petal2)'/>
          <!-- Center Bright Accent -->
          <ellipse cx='20' cy='10' rx='140' ry='190' fill='#7dd3fc' opacity='0.35' transform='rotate(30 20 10)'/>
        </g>
      </svg>
    `),
    theme: 'dark' as const,
  },
  {
    id: 'bloom-light',
    name: 'Windows 11 Bloom (Light)',
    url: svgToDataUri(`
      <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1920 1080' width='100%' height='100%'>
        <defs>
          <radialGradient id='bg-l' cx='60%' cy='45%' r='85%'>
            <stop offset='0%' stop-color='#ffffff'/>
            <stop offset='30%' stop-color='#f0f6fc'/>
            <stop offset='65%' stop-color='#e2e8f0'/>
            <stop offset='100%' stop-color='#cbd5e1'/>
          </radialGradient>
          <linearGradient id='pet-l1' x1='0%' y1='0%' x2='100%' y2='100%'>
            <stop offset='0%' stop-color='#38bdf8' stop-opacity='0.95'/>
            <stop offset='100%' stop-color='#0284c7' stop-opacity='0.8'/>
          </linearGradient>
          <linearGradient id='pet-l2' x1='100%' y1='0%' x2='0%' y2='100%'>
            <stop offset='0%' stop-color='#818cf8' stop-opacity='0.95'/>
            <stop offset='100%' stop-color='#4f46e5' stop-opacity='0.75'/>
          </linearGradient>
          <linearGradient id='pet-l3' x1='0%' y1='100%' x2='100%' y2='0%'>
            <stop offset='0%' stop-color='#60a5fa' stop-opacity='0.9'/>
            <stop offset='100%' stop-color='#2563eb' stop-opacity='0.7'/>
          </linearGradient>
          <filter id='glow-l' x='-40%' y='-40%' width='180%' height='180%'>
            <feGaussianBlur stdDeviation='30' result='blur'/>
            <feComposite in='SourceGraphic' in2='blur' operator='over'/>
          </filter>
        </defs>
        <rect width='1920' height='1080' fill='url(#bg-l)'/>
        <g filter='url(#glow-l)' transform='translate(1020, 530)'>
          <path d='M-200,-280 C-60,-400 200,-330 250,-150 C300,30 210,230 80,290 C-50,350 -230,280 -280,130 C-330,-20 -320,-150 -200,-280 Z' fill='url(#pet-l2)' opacity='0.85'/>
          <path d='M-140,-220 C10,-320 220,-220 260,-60 C300,100 150,250 20,230 C-110,210 -250,130 -230,-10 C-210,-150 -260,-80 -140,-220 Z' fill='url(#pet-l3)'/>
          <path d='M-60,-150 C70,-240 230,-120 220,30 C210,180 60,250 -40,190 C-140,130 -200,-10 -150,-100 C-100,-190 -190,-60 -60,-150 Z' fill='url(#pet-l1)'/>
          <circle cx='20' cy='10' r='130' fill='#bae6fd' opacity='0.45'/>
        </g>
      </svg>
    `),
    theme: 'light' as const,
  },
  {
    id: 'flow-purple',
    name: 'Windows 11 Captured Motion',
    url: svgToDataUri(`
      <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1920 1080' width='100%' height='100%'>
        <defs>
          <radialGradient id='bg-p' cx='40%' cy='40%' r='80%'>
            <stop offset='0%' stop-color='#2e1065'/>
            <stop offset='50%' stop-color='#1e1b4b'/>
            <stop offset='100%' stop-color='#0f0f17'/>
          </radialGradient>
          <linearGradient id='wave1' x1='0%' y1='0%' x2='100%' y2='100%'>
            <stop offset='0%' stop-color='#c026d3'/>
            <stop offset='50%' stop-color='#9333ea'/>
            <stop offset='100%' stop-color='#4338ca'/>
          </linearGradient>
          <linearGradient id='wave2' x1='100%' y1='0%' x2='0%' y2='100%'>
            <stop offset='0%' stop-color='#f43f5e'/>
            <stop offset='100%' stop-color='#8b5cf6'/>
          </linearGradient>
        </defs>
        <rect width='1920' height='1080' fill='url(#bg-p)'/>
        <path d='M0,700 C400,500 800,900 1200,600 C1600,300 1800,500 1920,400 L1920,1080 L0,1080 Z' fill='url(#wave1)' opacity='0.7'/>
        <path d='M0,850 C500,650 900,1050 1400,750 C1700,550 1850,700 1920,600 L1920,1080 L0,1080 Z' fill='url(#wave2)' opacity='0.6'/>
      </svg>
    `),
    theme: 'dark' as const,
  },
  {
    id: 'sunrise-glow',
    name: 'Windows 11 Sunrise Glow',
    url: svgToDataUri(`
      <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1920 1080' width='100%' height='100%'>
        <defs>
          <linearGradient id='bg-s' x1='0%' y1='0%' x2='0%' y2='100%'>
            <stop offset='0%' stop-color='#fef3c7'/>
            <stop offset='40%' stop-color='#fed7aa'/>
            <stop offset='70%' stop-color='#fda4af'/>
            <stop offset='100%' stop-color='#e0e7ff'/>
          </linearGradient>
          <radialGradient id='sun' cx='50%' cy='50%' r='50%'>
            <stop offset='0%' stop-color='#fbbf24'/>
            <stop offset='70%' stop-color='#f97316' stop-opacity='0.8'/>
            <stop offset='100%' stop-color='#f43f5e' stop-opacity='0'/>
          </radialGradient>
        </defs>
        <rect width='1920' height='1080' fill='url(#bg-s)'/>
        <circle cx='960' cy='620' r='380' fill='url(#sun)'/>
        <path d='M0,720 C480,680 960,780 1440,710 C1680,670 1840,690 1920,700 L1920,1080 L0,1080 Z' fill='#6366f1' opacity='0.25'/>
        <path d='M0,820 C400,770 1000,880 1500,810 C1750,780 1850,800 1920,810 L1920,1080 L0,1080 Z' fill='#4338ca' opacity='0.3'/>
      </svg>
    `),
    theme: 'light' as const,
  },
  {
    id: 'cyber-neon',
    name: 'Cyberpunk Neon Horizon',
    url: svgToDataUri(`
      <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1920 1080' width='100%' height='100%'>
        <defs>
          <linearGradient id='cyber-bg' x1='0%' y1='0%' x2='0%' y2='100%'>
            <stop offset='0%' stop-color='#05050c'/>
            <stop offset='60%' stop-color='#110924'/>
            <stop offset='100%' stop-color='#2e0854'/>
          </linearGradient>
          <linearGradient id='grid-line' x1='0%' y1='0%' x2='100%' y2='0%'>
            <stop offset='0%' stop-color='#06b6d4' stop-opacity='0.1'/>
            <stop offset='50%' stop-color='#ec4899'/>
            <stop offset='100%' stop-color='#06b6d4' stop-opacity='0.1'/>
          </linearGradient>
        </defs>
        <rect width='1920' height='1080' fill='url(#cyber-bg)'/>
        <circle cx='960' cy='480' r='260' fill='none' stroke='#ec4899' stroke-width='4' opacity='0.7'/>
        <circle cx='960' cy='480' r='240' fill='#f43f5e' opacity='0.15'/>
        <line x1='0' y1='650' x2='1920' y2='650' stroke='url(#grid-line)' stroke-width='3'/>
        <g stroke='#06b6d4' stroke-width='1' opacity='0.4'>
          <line x1='960' y1='650' x2='200' y2='1080'/>
          <line x1='960' y1='650' x2='600' y2='1080'/>
          <line x1='960' y1='650' x2='960' y2='1080'/>
          <line x1='960' y1='650' x2='1320' y2='1080'/>
          <line x1='960' y1='650' x2='1720' y2='1080'/>
          <line x1='0' y1='720' x2='1920' y2='720'/>
          <line x1='0' y1='810' x2='1920' y2='810'/>
          <line x1='0' y1='930' x2='1920' y2='930'/>
        </g>
      </svg>
    `),
    theme: 'dark' as const,
  },
  {
    id: 'minimal-mountain',
    name: 'Minimal Alpine Dusk',
    url: svgToDataUri(`
      <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1920 1080' width='100%' height='100%'>
        <defs>
          <linearGradient id='dusk-sky' x1='0%' y1='0%' x2='0%' y2='100%'>
            <stop offset='0%' stop-color='#0f172a'/>
            <stop offset='45%' stop-color='#1e1b4b'/>
            <stop offset='75%' stop-color='#312e81'/>
            <stop offset='100%' stop-color='#fb7185'/>
          </linearGradient>
        </defs>
        <rect width='1920' height='1080' fill='url(#dusk-sky)'/>
        <circle cx='1400' cy='320' r='70' fill='#fef08a' opacity='0.85'/>
        <polygon points='100,1080 480,480 860,1080' fill='#1e1b4b' opacity='0.9'/>
        <polygon points='600,1080 1050,420 1500,1080' fill='#0f172a'/>
        <polygon points='1200,1080 1550,560 1900,1080' fill='#1e1b4b' opacity='0.85'/>
        <polygon points='-100,1080 250,620 600,1080' fill='#312e81' opacity='0.7'/>
      </svg>
    `),
    theme: 'dark' as const,
  },
];

// Pre-built interactive HTML apps ready to run inside C:\Apps
export const INDEX_HTML_PORTAL = `<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Windows 11 Live HTML App</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: radial-gradient(circle at 50% 30%, #1e293b, #0f172a, #020617);
      color: #f8fafc;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 24px;
      text-align: center;
    }
    .card {
      background: rgba(30, 41, 59, 0.75);
      backdrop-filter: blur(16px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 24px;
      padding: 36px 28px;
      max-width: 540px;
      width: 100%;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
      animation: pop 0.4s cubic-bezier(0.16, 1, 0.3, 1);
    }
    @keyframes pop {
      from { opacity: 0; transform: scale(0.92); }
      to { opacity: 1; transform: scale(1); }
    }
    .icon {
      width: 60px;
      height: 60px;
      margin: 0 auto 16px;
      background: linear-gradient(135deg, #0284c7, #38bdf8);
      border-radius: 18px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 28px;
      box-shadow: 0 10px 25px -5px rgba(56, 189, 248, 0.4);
    }
    h1 { font-size: 24px; font-weight: 700; margin-bottom: 8px; color: #ffffff; }
    p { color: #94a3b8; font-size: 14px; line-height: 1.6; margin-bottom: 20px; }
    .btn-group { display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; margin-bottom: 24px; }
    .btn {
      padding: 10px 20px;
      border-radius: 10px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      border: none;
      transition: all 0.2s;
    }
    .btn-primary { background: #0284c7; color: white; }
    .btn-primary:hover { background: #0369a1; transform: translateY(-2px); }
    .btn-success { background: #10b981; color: white; }
    .btn-success:hover { background: #059669; transform: translateY(-2px); }
    .counter-badge {
      display: inline-block;
      background: rgba(56, 189, 248, 0.15);
      color: #38bdf8;
      border: 1px solid rgba(56, 189, 248, 0.3);
      padding: 8px 16px;
      border-radius: 100px;
      font-weight: 700;
      font-size: 15px;
      margin-bottom: 16px;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">⚡</div>
    <h1>index.html đang chạy ngay!</h1>
    <p>File HTML tương tác trực tiếp với JavaScript, CSS & Máy chủ Express Node.js.</p>
    <div class="counter-badge">Số lần bấm: <span id="num">0</span></div>
    <div class="btn-group">
      <button class="btn btn-primary" onclick="countUp()">Tăng Điểm (+1)</button>
      <button class="btn btn-success" onclick="spawnParticles()">Hiệu Ứng Pháo Hoa</button>
    </div>
    <div style="font-size: 12px; color: #64748b;">
      Bạn có thể bấm "Edit Code" ở thanh tiêu đề để chỉnh sửa mã HTML này trực tiếp.
    </div>
  </div>
  <canvas id="c" style="position:fixed;top:0;left:0;width:100vw;height:100vh;pointer-events:none;z-index:99;"></canvas>
  <script>
    let c = 0;
    function countUp() {
      c++;
      document.getElementById('num').innerText = c;
      console.log('User interacted with index.html, click count:', c);
    }
    function spawnParticles() {
      countUp();
      const cv = document.getElementById('c');
      const ctx = cv.getContext('2d');
      cv.width = window.innerWidth; cv.height = window.innerHeight;
      let pts = [];
      for(let i=0; i<40; i++) {
        pts.push({
          x: cv.width/2, y: cv.height/2,
          vx: (Math.random()-0.5)*12, vy: (Math.random()-0.5)*12,
          r: Math.random()*5+2,
          color: 'hsl(' + Math.floor(Math.random()*360) + ', 100%, 60%)',
          alpha: 1
        });
      }
      function anim() {
        ctx.clearRect(0,0,cv.width,cv.height);
        let alive = false;
        pts.forEach(p => {
          p.x += p.vx; p.y += p.vy; p.alpha -= 0.02;
          if (p.alpha > 0) {
            alive = true;
            ctx.fillStyle = p.color;
            ctx.globalAlpha = p.alpha;
            ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI*2); ctx.fill();
          }
        });
        if(alive) requestAnimationFrame(anim);
      }
      anim();
    }
  </script>
</body>
</html>`;

export const FLAPPY_BIRD_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Flappy Bird Win11</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      background: #111827;
      color: #f3f4f6;
      font-family: system-ui, -apple-system, sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      overflow: hidden;
    }
    #game-container {
      position: relative;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 20px 40px rgba(0,0,0,0.6);
      border: 2px solid #374151;
    }
    canvas {
      display: block;
      background: #70c5ce;
    }
    .hud {
      position: absolute;
      top: 16px;
      left: 0;
      width: 100%;
      display: flex;
      justify-content: space-around;
      font-size: 20px;
      font-weight: 700;
      text-shadow: 2px 2px 4px rgba(0,0,0,0.8);
      pointer-events: none;
    }
    .overlay {
      position: absolute;
      inset: 0;
      background: rgba(0,0,0,0.65);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      backdrop-filter: blur(4px);
    }
    .overlay h1 { font-size: 32px; margin-bottom: 12px; color: #fbbf24; }
    .overlay p { font-size: 16px; margin-bottom: 20px; color: #e5e7eb; }
    .btn {
      padding: 10px 24px;
      background: #0078d4;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(0,120,212,0.4);
      transition: all 0.2s;
    }
    .btn:hover { background: #106ebe; transform: scale(1.05); }
  </style>
</head>
<body>
  <div id="game-container">
    <canvas id="gameCanvas" width="400" height="540"></canvas>
    <div class="hud">
      <div>Score: <span id="score">0</span></div>
      <div>High: <span id="highScore">0</span></div>
    </div>
    <div id="startScreen" class="overlay">
      <h1>🐦 Flappy Wings</h1>
      <p>Press Space or Click to Flap</p>
      <button class="btn" id="startBtn">Play Game</button>
    </div>
    <div id="gameOverScreen" class="overlay" style="display:none;">
      <h1 style="color:#ef4444;">Game Over!</h1>
      <p id="finalScoreText">Score: 0</p>
      <button class="btn" id="restartBtn">Play Again</button>
    </div>
  </div>

  <script>
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    const scoreEl = document.getElementById('score');
    const highScoreEl = document.getElementById('highScore');
    const startScreen = document.getElementById('startScreen');
    const gameOverScreen = document.getElementById('gameOverScreen');
    const finalScoreText = document.getElementById('finalScoreText');

    let state = 'START';
    let score = 0;
    let highScore = parseInt(localStorage.getItem('win11_flappy_high') || '0');
    highScoreEl.textContent = highScore;

    let bird = { x: 80, y: 240, vy: 0, gravity: 0.38, jump: -6.8, radius: 14, angle: 0 };
    let pipes = [];
    let pipeInterval = 95;
    let frame = 0;

    function resetGame() {
      bird.y = 240;
      bird.vy = 0;
      bird.angle = 0;
      pipes = [];
      score = 0;
      scoreEl.textContent = score;
      frame = 0;
    }

    function jump() {
      if (state === 'PLAYING') {
        bird.vy = bird.jump;
      }
    }

    window.addEventListener('keydown', (e) => {
      if (e.code === 'Space') {
        e.preventDefault();
        if (state === 'PLAYING') jump();
      }
    });

    canvas.addEventListener('mousedown', (e) => {
      e.preventDefault();
      if (state === 'PLAYING') jump();
    });

    document.getElementById('startBtn').addEventListener('click', () => {
      resetGame();
      state = 'PLAYING';
      startScreen.style.display = 'none';
    });

    document.getElementById('restartBtn').addEventListener('click', () => {
      resetGame();
      state = 'PLAYING';
      gameOverScreen.style.display = 'none';
    });

    function update() {
      if (state !== 'PLAYING') return;

      frame++;
      bird.vy += bird.gravity;
      bird.y += bird.vy;
      bird.angle = Math.min(Math.PI / 4, Math.max(-Math.PI / 4, bird.vy * 0.08));

      // Floor & ceiling collisions
      if (bird.y + bird.radius >= canvas.height - 40 || bird.y - bird.radius <= 0) {
        gameOver();
      }

      // Spawn pipes
      if (frame % pipeInterval === 0) {
        const gap = 130;
        const topHeight = Math.floor(Math.random() * (canvas.height - gap - 120)) + 40;
        pipes.push({
          x: canvas.width,
          top: topHeight,
          bottom: canvas.height - 40 - (topHeight + gap),
          passed: false
        });
      }

      // Move pipes
      for (let i = pipes.length - 1; i >= 0; i--) {
        const p = pipes[i];
        p.x -= 2.6;

        // Score update
        if (!p.passed && p.x + 48 < bird.x) {
          p.passed = true;
          score++;
          scoreEl.textContent = score;
          if (score > highScore) {
            highScore = score;
            highScoreEl.textContent = highScore;
            localStorage.setItem('win11_flappy_high', highScore);
          }
        }

        // Collision detection
        if (
          bird.x + bird.radius > p.x &&
          bird.x - bird.radius < p.x + 48 &&
          (bird.y - bird.radius < p.top || bird.y + bird.radius > canvas.height - 40 - p.bottom)
        ) {
          gameOver();
        }

        if (p.x < -60) pipes.splice(i, 1);
      }
    }

    function gameOver() {
      state = 'OVER';
      finalScoreText.textContent = 'Score: ' + score + ' (Best: ' + highScore + ')';
      gameOverScreen.style.display = 'flex';
    }

    function draw() {
      // Sky
      ctx.fillStyle = '#70c5ce';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Clouds
      ctx.fillStyle = 'rgba(255,255,255,0.7)';
      ctx.beginPath();
      ctx.arc(100, 80, 24, 0, Math.PI*2);
      ctx.arc(130, 80, 32, 0, Math.PI*2);
      ctx.arc(160, 80, 24, 0, Math.PI*2);
      ctx.fill();

      // Pipes
      for (const p of pipes) {
        ctx.fillStyle = '#22c55e';
        ctx.fillRect(p.x, 0, 48, p.top);
        ctx.fillRect(p.x, canvas.height - 40 - p.bottom, 48, p.bottom);

        // Pipe caps
        ctx.fillStyle = '#16a34a';
        ctx.fillRect(p.x - 4, p.top - 16, 56, 16);
        ctx.fillRect(p.x - 4, canvas.height - 40 - p.bottom, 56, 16);
      }

      // Ground
      ctx.fillStyle = '#ded895';
      ctx.fillRect(0, canvas.height - 40, canvas.width, 40);
      ctx.fillStyle = '#73bf2e';
      ctx.fillRect(0, canvas.height - 40, canvas.width, 8);

      // Bird
      ctx.save();
      ctx.translate(bird.x, bird.y);
      ctx.rotate(bird.angle);

      // Body
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(0, 0, bird.radius, 0, Math.PI*2);
      ctx.fill();
      ctx.strokeStyle = '#b45309';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Eye
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.arc(6, -4, 5, 0, Math.PI*2);
      ctx.fill();
      ctx.fillStyle = '#000';
      ctx.beginPath();
      ctx.arc(8, -4, 2, 0, Math.PI*2);
      ctx.fill();

      // Beak
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.moveTo(10, 0);
      ctx.lineTo(18, 4);
      ctx.lineTo(10, 8);
      ctx.fill();

      // Wing
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.ellipse(-6, 2, 7, 4, Math.PI / 4, 0, Math.PI*2);
      ctx.fill();

      ctx.restore();
    }

    function loop() {
      update();
      draw();
      requestAnimationFrame(loop);
    }
    loop();
  </script>
</body>
</html>`;

export const PUZZLE_2048_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>2048 Cyber Edition</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background: #0f172a;
      color: #f8fafc;
      font-family: system-ui, sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 16px;
    }
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 360px;
      margin-bottom: 16px;
    }
    h1 { font-size: 36px; font-weight: 800; color: #38bdf8; }
    .scores { display: flex; gap: 8px; }
    .score-box {
      background: #1e293b;
      padding: 6px 14px;
      border-radius: 8px;
      text-align: center;
      border: 1px solid #334155;
    }
    .score-title { font-size: 11px; text-transform: uppercase; color: #94a3b8; }
    .score-val { font-size: 18px; font-weight: 700; color: #38bdf8; }
    .board {
      width: 360px;
      height: 360px;
      background: #1e293b;
      border-radius: 12px;
      padding: 12px;
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      grid-template-rows: repeat(4, 1fr);
      gap: 10px;
      position: relative;
      border: 2px solid #334155;
    }
    .cell {
      background: #334155;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      font-weight: 700;
      transition: all 0.15s ease-in-out;
    }
    .cell[data-val="2"] { background: #e2e8f0; color: #0f172a; }
    .cell[data-val="4"] { background: #fed7aa; color: #0f172a; }
    .cell[data-val="8"] { background: #fdba74; color: #fff; }
    .cell[data-val="16"] { background: #fb923c; color: #fff; }
    .cell[data-val="32"] { background: #f97316; color: #fff; }
    .cell[data-val="64"] { background: #ea580c; color: #fff; }
    .cell[data-val="128"] { background: #eab308; color: #fff; font-size: 20px; box-shadow: 0 0 10px #eab308; }
    .cell[data-val="256"] { background: #ca8a04; color: #fff; font-size: 20px; box-shadow: 0 0 12px #ca8a04; }
    .cell[data-val="512"] { background: #a855f7; color: #fff; font-size: 20px; box-shadow: 0 0 14px #a855f7; }
    .cell[data-val="1024"] { background: #ec4899; color: #fff; font-size: 16px; box-shadow: 0 0 16px #ec4899; }
    .cell[data-val="2048"] { background: #06b6d4; color: #fff; font-size: 16px; box-shadow: 0 0 20px #06b6d4; }
    .controls {
      margin-top: 16px;
      display: flex;
      gap: 12px;
      width: 360px;
      justify-content: space-between;
    }
    button {
      background: #0284c7;
      color: white;
      border: none;
      padding: 8px 18px;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s;
    }
    button:hover { background: #0369a1; }
  </style>
</head>
<body>
  <div class="header">
    <h1>2048</h1>
    <div class="scores">
      <div class="score-box">
        <div class="score-title">Score</div>
        <div class="score-val" id="score">0</div>
      </div>
      <div class="score-box">
        <div class="score-title">Best</div>
        <div class="score-val" id="best">0</div>
      </div>
    </div>
  </div>
  <div class="board" id="board"></div>
  <div class="controls">
    <span style="font-size: 13px; color: #94a3b8; line-height: 2.2;">Use Arrow keys or WASD</span>
    <button onclick="initGame()">New Game</button>
  </div>

  <script>
    let grid = [];
    let score = 0;
    let best = parseInt(localStorage.getItem('win11_2048_best') || '0');
    document.getElementById('best').innerText = best;

    function initGame() {
      grid = [
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0]
      ];
      score = 0;
      updateScore(0);
      addRandomTile();
      addRandomTile();
      render();
    }

    function addRandomTile() {
      let empty = [];
      for (let r=0; r<4; r++) {
        for (let c=0; c<4; c++) {
          if (grid[r][c] === 0) empty.push({r, c});
        }
      }
      if (empty.length > 0) {
        let spot = empty[Math.floor(Math.random() * empty.length)];
        grid[spot.r][spot.c] = Math.random() < 0.9 ? 2 : 4;
      }
    }

    function render() {
      const board = document.getElementById('board');
      board.innerHTML = '';
      for (let r=0; r<4; r++) {
        for (let c=0; c<4; c++) {
          const val = grid[r][c];
          const cell = document.createElement('div');
          cell.className = 'cell';
          if (val > 0) {
            cell.innerText = val;
            cell.setAttribute('data-val', val);
          }
          board.appendChild(cell);
        }
      }
    }

    function updateScore(inc) {
      score += inc;
      document.getElementById('score').innerText = score;
      if (score > best) {
        best = score;
        document.getElementById('best').innerText = best;
        localStorage.setItem('win11_2048_best', best);
      }
    }

    function slide(row) {
      let arr = row.filter(val => val);
      for (let i = 0; i < arr.length - 1; i++) {
        if (arr[i] === arr[i + 1]) {
          arr[i] *= 2;
          updateScore(arr[i]);
          arr[i + 1] = 0;
        }
      }
      arr = arr.filter(val => val);
      while (arr.length < 4) arr.push(0);
      return arr;
    }

    function moveLeft() {
      let changed = false;
      for (let r=0; r<4; r++) {
        let old = [...grid[r]];
        grid[r] = slide(grid[r]);
        if (old.join(',') !== grid[r].join(',')) changed = true;
      }
      return changed;
    }

    function rotate() {
      let newGrid = [[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]];
      for (let r=0; r<4; r++) {
        for (let c=0; c<4; c++) {
          newGrid[c][3 - r] = grid[r][c];
        }
      }
      grid = newGrid;
    }

    function handleKey(dir) {
      let changed = false;
      if (dir === 'left') changed = moveLeft();
      if (dir === 'down') { rotate(); changed = moveLeft(); rotate(); rotate(); rotate(); }
      if (dir === 'right') { rotate(); rotate(); changed = moveLeft(); rotate(); rotate(); }
      if (dir === 'up') { rotate(); rotate(); rotate(); changed = moveLeft(); rotate(); }

      if (changed) {
        addRandomTile();
        render();
      }
    }

    window.addEventListener('keydown', e => {
      if (['ArrowLeft', 'KeyA'].includes(e.code)) { e.preventDefault(); handleKey('left'); }
      if (['ArrowRight', 'KeyD'].includes(e.code)) { e.preventDefault(); handleKey('right'); }
      if (['ArrowUp', 'KeyW'].includes(e.code)) { e.preventDefault(); handleKey('up'); }
      if (['ArrowDown', 'KeyS'].includes(e.code)) { e.preventDefault(); handleKey('down'); }
    });

    initGame();
  </script>
</body>
</html>`;

export const MATRIX_RAIN_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Cyber Matrix Canvas</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { background: #000; overflow: hidden; color: #00ff66; font-family: monospace; }
    canvas { display: block; }
    .overlay {
      position: absolute;
      top: 12px;
      left: 12px;
      background: rgba(0,20,10,0.85);
      border: 1px solid #00ff66;
      border-radius: 8px;
      padding: 10px 16px;
      font-size: 13px;
      pointer-events: none;
      backdrop-filter: blur(4px);
    }
  </style>
</head>
<body>
  <div class="overlay">
    <div>⚡ Windows 11 Matrix Core v2.4</div>
    <div style="color: #6ee7b7; margin-top: 4px;">Click anywhere to trigger energy shockwave</div>
  </div>
  <canvas id="c"></canvas>
  <script>
    const canvas = document.getElementById('c');
    const ctx = canvas.getContext('2d');
    
    function resize() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }
    window.addEventListener('resize', resize);
    resize();

    const chars = '01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲンABCDEF';
    const fontSize = 16;
    let cols = Math.floor(canvas.width / fontSize);
    let drops = Array(cols).fill(1);
    let particles = [];

    window.addEventListener('click', (e) => {
      for (let i = 0; i < 30; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * 6 + 2;
        particles.push({
          x: e.clientX,
          y: e.clientY,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          life: 1,
          char: chars[Math.floor(Math.random() * chars.length)]
        });
      }
    });

    function draw() {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = '#00ff66';
      ctx.font = fontSize + 'px monospace';

      if (cols !== Math.floor(canvas.width / fontSize)) {
        cols = Math.floor(canvas.width / fontSize);
        drops = Array(cols).fill(1);
      }

      for (let i = 0; i < drops.length; i++) {
        const text = chars[Math.floor(Math.random() * chars.length)];
        ctx.fillStyle = (Math.random() > 0.85) ? '#ffffff' : '#00ff66';
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);

        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }

      // Update Shockwave particles
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.02;
        ctx.fillStyle = 'rgba(56, 189, 248, ' + p.life + ')';
        ctx.fillText(p.char, p.x, p.y);
        if (p.life <= 0) particles.splice(i, 1);
      }

      requestAnimationFrame(draw);
    }
    draw();
  </script>
</body>
</html>`;

export const POMODORO_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Cyber Focus Pomodoro</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; font-family: system-ui, sans-serif; }
    body {
      background: #0f172a;
      color: #f8fafc;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 20px;
    }
    .card {
      background: #1e293b;
      border: 1px solid #334155;
      border-radius: 16px;
      padding: 32px;
      width: 360px;
      text-align: center;
      box-shadow: 0 20px 40px rgba(0,0,0,0.4);
    }
    .tabs { display: flex; gap: 8px; justify-content: center; margin-bottom: 24px; }
    .tab {
      background: transparent;
      border: none;
      color: #94a3b8;
      padding: 6px 14px;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
    }
    .tab.active { background: #0284c7; color: white; }
    .timer {
      font-size: 64px;
      font-weight: 800;
      font-variant-numeric: tabular-nums;
      margin: 16px 0;
      color: #38bdf8;
    }
    .controls { display: flex; gap: 12px; justify-content: center; }
    .btn {
      padding: 10px 24px;
      border-radius: 10px;
      font-size: 16px;
      font-weight: 700;
      border: none;
      cursor: pointer;
      transition: all 0.2s;
    }
    .btn-primary { background: #38bdf8; color: #0f172a; }
    .btn-secondary { background: #334155; color: #f8fafc; }
    .btn:hover { transform: scale(1.04); }
  </style>
</head>
<body>
  <div class="card">
    <div class="tabs">
      <button class="tab active" onclick="setMode(25, this)">Work (25m)</button>
      <button class="tab" onclick="setMode(5, this)">Short (5m)</button>
      <button class="tab" onclick="setMode(15, this)">Long (15m)</button>
    </div>
    <div class="timer" id="time">25:00</div>
    <div class="controls">
      <button class="btn btn-primary" id="toggleBtn" onclick="toggleTimer()">Start</button>
      <button class="btn btn-secondary" onclick="resetTimer()">Reset</button>
    </div>
  </div>
  <script>
    let totalSeconds = 25 * 60;
    let remaining = totalSeconds;
    let isRunning = false;
    let timerId = null;

    function renderTime() {
      const m = Math.floor(remaining / 60).toString().padStart(2, '0');
      const s = (remaining % 60).toString().padStart(2, '0');
      document.getElementById('time').innerText = m + ':' + s;
    }

    function setMode(mins, btn) {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      btn.classList.add('active');
      totalSeconds = mins * 60;
      resetTimer();
    }

    function toggleTimer() {
      if (isRunning) {
        clearInterval(timerId);
        isRunning = false;
        document.getElementById('toggleBtn').innerText = 'Start';
      } else {
        isRunning = true;
        document.getElementById('toggleBtn').innerText = 'Pause';
        timerId = setInterval(() => {
          if (remaining > 0) {
            remaining--;
            renderTime();
          } else {
            clearInterval(timerId);
            isRunning = false;
            document.getElementById('toggleBtn').innerText = 'Start';
            alert('Time is up!');
          }
        }, 1000);
      }
    }

    function resetTimer() {
      clearInterval(timerId);
      isRunning = false;
      remaining = totalSeconds;
      document.getElementById('toggleBtn').innerText = 'Start';
      renderTime();
    }
    renderTime();
  </script>
</body>
</html>`;

export const SPEED_TYPER_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Speed Typer Pro</title>
  <style>
    * { box-sizing: border-box; margin:0; padding:0; font-family: 'Segoe UI', system-ui, sans-serif; }
    body { background: #0f172a; color: #f8fafc; display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:100vh; padding:20px; }
    .card { background: #1e293b; border: 1px solid #334155; border-radius: 16px; padding: 28px; max-width: 580px; width: 100%; box-shadow: 0 20px 40px rgba(0,0,0,0.5); }
    h1 { color: #38bdf8; font-size: 24px; margin-bottom: 12px; }
    .stats { display: flex; gap: 12px; margin-bottom: 18px; }
    .stat { background: #0f172a; padding: 8px 16px; border-radius: 8px; border: 1px solid #334155; text-align: center; flex: 1; }
    .stat-val { font-size: 20px; font-weight: 800; color: #38bdf8; }
    .stat-lbl { font-size: 11px; text-transform: uppercase; color: #94a3b8; }
    .prompt { background: #0f172a; padding: 16px; border-radius: 10px; border: 1px solid #334155; font-size: 16px; line-height: 1.6; margin-bottom: 16px; min-height: 90px; }
    .prompt span.correct { color: #4ade80; }
    .prompt span.incorrect { color: #f87171; background: rgba(248,113,113,0.2); border-radius: 2px; }
    .prompt span.current { border-bottom: 2px solid #38bdf8; }
    input { width: 100%; padding: 12px 16px; background: #0f172a; border: 2px solid #38bdf8; border-radius: 8px; color: #fff; font-size: 16px; outline: none; }
    button { margin-top: 14px; padding: 8px 20px; background: #0284c7; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; }
  </style>
</head>
<body>
  <div class="card">
    <h1>⚡ Windows 11 Speed Typer</h1>
    <div class="stats">
      <div class="stat"><div class="stat-val" id="wpm">0</div><div class="stat-lbl">WPM</div></div>
      <div class="stat"><div class="stat-val" id="acc">100%</div><div class="stat-lbl">Accuracy</div></div>
      <div class="stat"><div class="stat-val" id="time">30s</div><div class="stat-lbl">Time Left</div></div>
    </div>
    <div class="prompt" id="promptBox"></div>
    <input type="text" id="typeInput" placeholder="Start typing here..." autofocus />
    <button onclick="resetTest()">New Quote</button>
  </div>
  <script>
    const quotes = [
      "Windows 11 brings you closer to what you love with fresh new experiences.",
      "The fast brown fox jumps over the lazy dog in high performance mode.",
      "TypeScript and modern web standards empower responsive applications.",
      "Virtual file systems provide seamless drag and drop file management."
    ];
    let quote = quotes[0];
    let startTime = null;
    let timer = null;
    let timeLeft = 30;
    const input = document.getElementById('typeInput');
    const promptBox = document.getElementById('promptBox');
    const wpmEl = document.getElementById('wpm');
    const accEl = document.getElementById('acc');
    const timeEl = document.getElementById('time');

    function renderPrompt() {
      const val = input.value;
      let html = '';
      for (let i = 0; i < quote.length; i++) {
        if (i < val.length) {
          if (val[i] === quote[i]) html += '<span class="correct">' + quote[i] + '</span>';
          else html += '<span class="incorrect">' + quote[i] + '</span>';
        } else if (i === val.length) {
          html += '<span class="current">' + quote[i] + '</span>';
        } else {
          html += '<span>' + quote[i] + '</span>';
        }
      }
      promptBox.innerHTML = html;
    }

    function resetTest() {
      clearInterval(timer);
      startTime = null;
      timeLeft = 30;
      timeEl.innerText = '30s';
      wpmEl.innerText = '0';
      accEl.innerText = '100%';
      quote = quotes[Math.floor(Math.random() * quotes.length)];
      input.value = '';
      input.disabled = false;
      renderPrompt();
      input.focus();
    }

    input.addEventListener('input', () => {
      if (!startTime) {
        startTime = Date.now();
        timer = setInterval(() => {
          timeLeft--;
          timeEl.innerText = timeLeft + 's';
          if (timeLeft <= 0) {
            clearInterval(timer);
            input.disabled = true;
          }
        }, 1000);
      }
      renderPrompt();
      const val = input.value;
      const elapsedMins = (Date.now() - startTime) / 60000;
      const words = val.length / 5;
      const wpm = elapsedMins > 0 ? Math.round(words / elapsedMins) : 0;
      wpmEl.innerText = wpm;

      let correct = 0;
      for (let i = 0; i < val.length; i++) {
        if (val[i] === quote[i]) correct++;
      }
      const acc = val.length > 0 ? Math.round((correct / val.length) * 100) : 100;
      accEl.innerText = acc + '%';

      if (val === quote) {
        clearInterval(timer);
        input.disabled = true;
        promptBox.innerHTML += '<div style="color:#4ade80;font-weight:bold;margin-top:8px;">🎉 Hoàn thành xuất sắc!</div>';
      }
    });

    resetTest();
  </script>
</body>
</html>`;

export const DISK_INFO = {
  driveLetter: 'C:',
  label: 'Local Disk (C:)',
  totalBytes: 1000204886016, // 1 TB = 1,000,204,886,016 bytes (931.5 GB in binary)
  freeBytes: 863104886016,   // ~863.1 GB free
  usedBytes: 137100000000,   // ~137.1 GB used
  fileSystem: 'NTFS',
  driveType: 'NVMe SSD',
  model: 'SAMSUNG MZVL21T0HCLR-00B00 1024.2 GB',
};

export const INITIAL_FILE_SYSTEM: FileSystemItem[] = [
  ...WINDOWS_SYSTEM_ITEMS,

  // =====================
  // C:\\Apps (User Apps & Installed HTML5 Apps)
  // =====================
  {
    id: "dir-apps",
    name: "Apps",
    path: "C:\\Apps",
    isDirectory: true,
    createdAt: Date.now() - 86400000 * 10,
    modifiedAt: Date.now(),
    icon: "LayoutGrid",
    protectionLevel: "CẨN THẬN",
    description: "Thư mục chứa ứng dụng người dùng và các tệp HTML5 cài đặt",
  },
  // Apps inside C:\\Apps
  {
    id: "app-index-main",
    name: "index.html",
    path: "C:\\Apps\\index.html",
    isDirectory: false,
    content: INDEX_HTML_PORTAL,
    size: INDEX_HTML_PORTAL.length,
    createdAt: Date.now() - 86400000 * 6,
    modifiedAt: Date.now() - 86400000 * 6,
    icon: "Code",
    isHtmlApp: true,
    protectionLevel: "AN TOÀN XOÁ",
    description: "Ứng dụng HTML5 mẫu tương tác",
    appMetadata: {
      title: "index.html App",
      icon: "Code",
      category: "productivity",
      description: "Interactive HTML5 index.html running directly on Windows 11",
    },
  },
  {
    id: "app-flappy",
    name: "FlappyBird.html",
    path: "C:\\Apps\\FlappyBird.html",
    isDirectory: false,
    content: FLAPPY_BIRD_HTML,
    size: FLAPPY_BIRD_HTML.length,
    createdAt: Date.now() - 86400000 * 5,
    modifiedAt: Date.now() - 86400000 * 5,
    icon: "Gamepad2",
    isHtmlApp: true,
    protectionLevel: "AN TOÀN XOÁ",
    description: "Game giải trí Flappy Bird",
    appMetadata: {
      title: "Flappy Bird",
      icon: "Gamepad2",
      category: "entertainment",
      description: "Arcade flapping adventure with scores and physics",
    },
  },
  {
    id: "app-2048",
    name: "2048.html",
    path: "C:\\Apps\\2048.html",
    isDirectory: false,
    content: PUZZLE_2048_HTML,
    size: PUZZLE_2048_HTML.length,
    createdAt: Date.now() - 86400000 * 4,
    modifiedAt: Date.now() - 86400000 * 4,
    icon: "Grid",
    isHtmlApp: true,
    protectionLevel: "AN TOÀN XOÁ",
    description: "Game giải đố số 2048 kinh điển",
    appMetadata: {
      title: "2048 Cyber",
      icon: "Grid",
      category: "entertainment",
      description: "Classic 2048 tile puzzle game",
    },
  },
  {
    id: "app-matrix",
    name: "MatrixRain.html",
    path: "C:\\Apps\\MatrixRain.html",
    isDirectory: false,
    content: MATRIX_RAIN_HTML,
    size: MATRIX_RAIN_HTML.length,
    createdAt: Date.now() - 86400000 * 3,
    modifiedAt: Date.now() - 86400000 * 3,
    icon: "Terminal",
    isHtmlApp: true,
    protectionLevel: "AN TOÀN XOÁ",
    description: "Mưa mã ma trận kỹ thuật số",
    appMetadata: {
      title: "Matrix Rain",
      icon: "Terminal",
      category: "utilities",
      description: "Interactive Matrix digital code rain canvas",
    },
  },
  {
    id: "app-pomodoro",
    name: "PomodoroFocus.html",
    path: "C:\\Apps\\PomodoroFocus.html",
    isDirectory: false,
    content: POMODORO_HTML,
    size: POMODORO_HTML.length,
    createdAt: Date.now() - 86400000 * 2,
    modifiedAt: Date.now() - 86400000 * 2,
    icon: "Clock",
    isHtmlApp: true,
    protectionLevel: "AN TOÀN XOÁ",
    description: "Đồng hồ tập trung công việc Pomodoro",
    appMetadata: {
      title: "Pomodoro Focus",
      icon: "Clock",
      category: "productivity",
      description: "Clean pomodoro work & study productivity timer",
    },
  },
  {
    id: "app-speedtyper",
    name: "SpeedTyper.html",
    path: "C:\\Apps\\SpeedTyper.html",
    isDirectory: false,
    content: SPEED_TYPER_HTML,
    size: SPEED_TYPER_HTML.length,
    createdAt: Date.now() - 86400000 * 1,
    modifiedAt: Date.now(),
    icon: "Keyboard",
    isHtmlApp: true,
    protectionLevel: "AN TOÀN XOÁ",
    description: "Kiểm tra tốc độ gõ phím WPM",
    appMetadata: {
      title: "Speed Typer Pro",
      icon: "Keyboard",
      category: "productivity",
      description: "WPM keyboard typing speed analyzer and accuracy test",
    },
  },

  // Desktop shortcuts to HTML apps
  {
    id: "desktop-index-app",
    name: "index.html",
    path: "C:\\Users\\User\\Desktop\\index.html",
    isDirectory: false,
    content: INDEX_HTML_PORTAL,
    size: INDEX_HTML_PORTAL.length,
    createdAt: Date.now() - 86400000 * 1,
    modifiedAt: Date.now(),
    icon: "Code",
    isHtmlApp: true,
    protectionLevel: "AN TOÀN XOÁ",
    description: "Chạy trực tiếp file index.html",
    appMetadata: {
      title: "index.html (Chạy ngay)",
      icon: "Code",
      category: "productivity",
      description: "Chạy trực tiếp file index.html",
    },
  },
  {
    id: "desktop-flappy-app",
    name: "FlappyBird.html",
    path: "C:\\Users\\User\\Desktop\\FlappyBird.html",
    isDirectory: false,
    content: FLAPPY_BIRD_HTML,
    size: FLAPPY_BIRD_HTML.length,
    createdAt: Date.now() - 86400000 * 1,
    modifiedAt: Date.now(),
    icon: "Gamepad2",
    isHtmlApp: true,
    protectionLevel: "AN TOÀN XOÁ",
    description: "Chạy game Flappy Bird",
    appMetadata: {
      title: "Flappy Bird Arcade",
      icon: "Gamepad2",
      category: "entertainment",
      description: "Chạy game Flappy Bird",
    },
  },

  // User Documents
  {
    id: "doc-welcome",
    name: "Welcome to Windows 11.txt",
    path: "C:\\Users\\User\\Documents\\Welcome to Windows 11.txt",
    isDirectory: false,
    content: `Chào mừng bạn đến với Windows 11 Web OS!

Tính năng nổi bật:
1. Cấu trúc thư mục & tệp hệ thống Windows 11 đầy đủ 100% (Windows, System32, SysWOW64, WinSxS, Drivers, v.v.).
2. Phân quyền bảo vệ 4 cấp độ: KHÔNG XOÁ, BẢO VỆ, CẨN THẬN, AN TOÀN XOÁ theo chuẩn Windows 11.
3. Ổ đĩa NVMe SSD 1 TB (1,000 GB) với kiểm tra phân quyền bảo mật TrustedInstaller & SYSTEM.
4. Chạy HTML trực tiếp: Bạn có thể thả (drag-and-drop) bất kỳ file .html nào vào thư mục C:\\Apps hoặc Desktop để chạy tức thì!
5. Microsoft Store: Kho ứng dụng phong phú, hỗ trợ tải lên file HTML từ máy tính để cài đặt.
6. Microsoft Edge: Trình duyệt web hiện đại, tìm kiếm trực tuyến và nhiều tab.
7. Bộ phím tắt Windows 11 phong phú (Win, Win+A, Win+I, Win+E, Win+R, Win+D, Win+L, Alt+Tab, v.v.).

Chúc bạn có trải nghiệm tuyệt vời!`,
    size: 920,
    createdAt: Date.now() - 86400000 * 7,
    modifiedAt: Date.now() - 86400000 * 7,
    icon: "FileText",
    protectionLevel: "AN TOÀN XOÁ",
    description: "Tài liệu hướng dẫn bắt đầu Windows 11",
  },
  {
    id: "doc-apps-guide",
    name: "Apps_Guide.txt",
    path: "C:\\Users\\User\\Documents\\Apps_Guide.txt",
    isDirectory: false,
    content: `HƯỚNG DẪN TẢI & CHẠY HTML TRÊN WINDOWS 11:

Cách 1: Mở Microsoft Store -> Chọn tab "Tải HTML lên / Upload HTML" -> Chọn hoặc thả tệp .html từ máy thật -> Bấm Cài đặt.
Cách 2: Kéo thả file .html từ máy tính thật vào màn hình Desktop hoặc cửa sổ File Explorer.
Cách 3: Mở File Explorer -> vào thư mục C:\\Apps -> bấm nút "+ Thêm App HTML".
Cách 4: Bấm chuột phải lên Desktop -> chọn "Tạo App HTML Mới".

Tất cả ứng dụng HTML sẽ tự động xuất hiện với biểu tượng trên Desktop, Start Menu và thư mục C:\\Apps!`,
    size: 640,
    createdAt: Date.now() - 86400000 * 3,
    modifiedAt: Date.now() - 86400000 * 3,
    icon: "FileText",
    protectionLevel: "AN TOÀN XOÁ",
    description: "Hướng dẫn cài đặt ứng dụng HTML",
  },
  {
    id: "bat-sample-demo",
    name: "demo.bat",
    path: "C:\\Users\\User\\demo.bat",
    isDirectory: false,
    content: `@echo off
rem ========================================
rem WINDOWS 11 BATCH SCRIPT DEMONSTRATION
rem ========================================
title Windows 11 Batch Demo
echo.
echo ===============================================
echo     CHAO MUNG DEN VOI WINDOWS 11 BATCH CLI
echo ===============================================
echo.
echo [1] Kiem tra he dieu hanh va bien moi truong:
if "%OS%"=="Windows_NT" (
  echo     He dieu hanh: Windows 11 Pro 64-bit (OK)
) else (
  echo     He dieu hanh khong xac dinh
)
echo     Nguoi dung: %USERNAME%
echo     Ngay gio: %DATE% - %TIME%
echo.
echo [2] Chay vong lap FOR /L dem tu 1 den 5:
for /l %%i in (1,1,5) do echo     * Buoc %%i / 5: He thong hoat dong on dinh
echo.
echo [3] Kiem tra su ton tai cua thu muc Documents:
if exist "C:\\Users\\User\\Documents" (
  echo     Thu muc Documents ton tai: [OK]
) else (
  echo     Khong tim thay thu muc Documents
)
echo.
echo [4] Hoan tat chuong trinh demo!
pause
`,
    size: 890,
    createdAt: Date.now() - 86400000 * 1,
    modifiedAt: Date.now(),
    icon: "FileCode",
    protectionLevel: "AN TOÀN XOÁ",
    description: "Tệp kịch bản Windows 11 Batch mẫu (.bat)",
  },
  {
    id: "video-nature-sample",
    name: "Wildlife_Bloom.mp4",
    path: "C:\\Users\\User\\Videos\\Wildlife_Bloom.mp4",
    isDirectory: false,
    content: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
    size: 1887436,
    createdAt: Date.now() - 86400000 * 2,
    modifiedAt: Date.now() - 86400000 * 2,
    icon: "Video",
    protectionLevel: "AN TOÀN XOÁ",
    description: "Tệp video mẫu thiên nhiên định dạng MP4 HD",
  },
  {
    id: "video-bunny-sample",
    name: "BigBuckBunny_1080p.mp4",
    path: "C:\\Users\\User\\Videos\\BigBuckBunny_1080p.mp4",
    isDirectory: false,
    content: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    size: 16568320,
    createdAt: Date.now() - 86400000 * 3,
    modifiedAt: Date.now() - 86400000 * 3,
    icon: "Video",
    protectionLevel: "AN TOÀN XOÁ",
    description: "Video hoạt hình mẫu chuẩn 1080p MP4",
  },
  {
    id: "video-garden-webm",
    name: "Botanical_Garden.webm",
    path: "C:\\Users\\User\\Videos\\Botanical_Garden.webm",
    isDirectory: false,
    content: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm",
    size: 1258291,
    createdAt: Date.now() - 86400000 * 4,
    modifiedAt: Date.now() - 86400000 * 4,
    icon: "Video",
    protectionLevel: "AN TOÀN XOÁ",
    description: "Tệp video mẫu chuẩn WebM (VP9 Codec)",
  },
  {
    id: "video-desktop-sample",
    name: "Sample_Video.mp4",
    path: "C:\\Users\\User\\Desktop\\Sample_Video.mp4",
    isDirectory: false,
    content: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
    size: 1887436,
    createdAt: Date.now() - 86400000 * 1,
    modifiedAt: Date.now() - 86400000 * 1,
    icon: "Video",
    protectionLevel: "AN TOÀN XOÁ",
    description: "Tệp video MP4 ngoài Desktop",
  },
  {
    id: "desktop-bat-demo",
    name: "demo.bat",
    path: "C:\\Users\\User\\Desktop\\demo.bat",
    isDirectory: false,
    content: `@echo off
title Windows 11 Batch Script Runner
echo =====================================
echo    WINDOWS 11 BATCH DEMO ON DESKTOP
echo =====================================
echo.
echo Nguoi dung: %USERNAME%
echo Ngay: %DATE%
echo.
for /l %%x in (1,1,3) do echo [+] Dang khoi chay tien trinh %%x...
echo.
echo Hoan tat! Chuc ban mot ngay tot lanh.
pause
`,
    size: 320,
    createdAt: Date.now() - 86400000 * 1,
    modifiedAt: Date.now(),
    icon: "FileCode",
    protectionLevel: "AN TOÀN XOÁ",
    description: "Kịch bản Batch mẫu ngoài màn hình nền",
  },
];
