/**
 * Windows CMD SET /A Arithmetic Evaluation Engine
 * Supports:
 * - Integer operations: +, -, *, /, %
 * - Assignment operators: =, +=, -=, *=, /=, %=
 * - Bitwise / Logic: &, |, ^, <<, >>
 * - Parentheses: ()
 * - Base formats: Decimal, Octal (052), Hexadecimal (0x2A)
 * - Environment variables resolution
 */

export interface SetAResult {
  success: boolean;
  varName?: string;
  result: number;
  output: string;
  newEnvVars?: Record<string, string>;
}

// Parse integer with support for 0x (hex), 0 (octal), and decimal
function parseCmdInt(token: string, env: Record<string, string>): number {
  const trimmed = token.trim();
  if (!trimmed) return 0;

  // If token is a variable name in environment
  if (env[trimmed.toUpperCase()] !== undefined) {
    return parseCmdInt(env[trimmed.toUpperCase()], env);
  }

  // Hexadecimal: 0x...
  if (/^0x[0-9a-f]+$/i.test(trimmed)) {
    return parseInt(trimmed, 16) | 0;
  }

  // Octal: starts with 0 and has other digits
  if (/^0[0-7]+$/.test(trimmed) && trimmed.length > 1) {
    return parseInt(trimmed, 8) | 0;
  }

  // Regular decimal integer
  const num = parseInt(trimmed, 10);
  return isNaN(num) ? 0 : (num | 0);
}

// Tokenize mathematical expression
function tokenize(expr: string): string[] {
  const tokens: string[] = [];
  let i = 0;
  while (i < expr.length) {
    const ch = expr[i];

    if (/\s/.test(ch)) {
      i++;
      continue;
    }

    // Two-character operators: <<, >>, +=, -=, *=, /=, %=, ==
    if (i + 1 < expr.length) {
      const two = expr.substring(i, i + 2);
      if (['<<', '>>', '+=', '-=', '*=', '/=', '%='].includes(two)) {
        tokens.push(two);
        i += 2;
        continue;
      }
    }

    // Single character operators
    if ('+-*/%()&=|^,~'.includes(ch)) {
      tokens.push(ch);
      i++;
      continue;
    }

    // Alphanumeric word / number (variables, decimals, hex)
    if (/[a-zA-Z0-9_]/.test(ch)) {
      let word = '';
      while (i < expr.length && /[a-zA-Z0-9_]/.test(expr[i])) {
        word += expr[i];
        i++;
      }
      tokens.push(word);
      continue;
    }

    // Skip unknown character
    i++;
  }
  return tokens;
}

/**
 * Shunting-yard algorithm to evaluate integer arithmetic expressions with proper operator precedence.
 */
export function evaluateMathExpression(expr: string, env: Record<string, string>): number {
  const tokens = tokenize(expr);
  if (tokens.length === 0) return 0;

  const prec: Record<string, number> = {
    '|': 1,
    '^': 2,
    '&': 3,
    '<<': 4,
    '>>': 4,
    '+': 5,
    '-': 5,
    '*': 6,
    '/': 6,
    '%': 6,
  };

  const values: number[] = [];
  const ops: string[] = [];

  const applyOp = () => {
    if (ops.length === 0 || values.length < 2) return;
    const op = ops.pop()!;
    const b = values.pop()!;
    const a = values.pop()!;

    let res = 0;
    switch (op) {
      case '+':
        res = (a + b) | 0;
        break;
      case '-':
        res = (a - b) | 0;
        break;
      case '*':
        res = (a * b) | 0;
        break;
      case '/':
        res = b !== 0 ? Math.trunc(a / b) | 0 : 0;
        break;
      case '%':
        res = b !== 0 ? (a % b) | 0 : 0;
        break;
      case '&':
        res = (a & b) | 0;
        break;
      case '|':
        res = (a | b) | 0;
        break;
      case '^':
        res = (a ^ b) | 0;
        break;
      case '<<':
        res = (a << b) | 0;
        break;
      case '>>':
        res = (a >> b) | 0;
        break;
      default:
        res = 0;
    }
    values.push(res);
  };

  let expectUnary = true;

  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];

    if (t === '(') {
      ops.push(t);
      expectUnary = true;
    } else if (t === ')') {
      while (ops.length > 0 && ops[ops.length - 1] !== '(') {
        applyOp();
      }
      if (ops.length > 0 && ops[ops.length - 1] === '(') {
        ops.pop();
      }
      expectUnary = false;
    } else if (['+', '-', '*', '/', '%', '&', '|', '^', '<<', '>>'].includes(t)) {
      if (expectUnary && (t === '+' || t === '-')) {
        // Handle unary plus or minus
        values.push(0);
      }
      while (
        ops.length > 0 &&
        ops[ops.length - 1] !== '(' &&
        prec[ops[ops.length - 1]] >= prec[t]
      ) {
        applyOp();
      }
      ops.push(t);
      expectUnary = true;
    } else {
      // Number or variable
      const val = parseCmdInt(t, env);
      values.push(val);
      expectUnary = false;
    }
  }

  while (ops.length > 0) {
    applyOp();
  }

  return values.length > 0 ? (values[values.length - 1] | 0) : 0;
}

/**
 * Main SET /A handler
 * Handles formats:
 * - set /a a=2+3
 * - set/a a=2+3
 * - set /a a+=5
 * - set /a a*=2
 * - set /a 10+5
 * - set /a "y=(1+2)*(3+4)"
 */
export function executeSetA(rawInput: string, currentEnv: Record<string, string>): SetAResult {
  // Strip "set /a" or "set/a" or "set  /a"
  let expr = rawInput.replace(/^set\s*\/a\s*/i, '').trim();
  // Remove wrapping quotes if present
  if (expr.startsWith('"') && expr.endsWith('"')) {
    expr = expr.substring(1, expr.length - 1).trim();
  }

  if (!expr) {
    return {
      success: false,
      result: 0,
      output: 'The syntax of the command is incorrect.',
    };
  }

  // Check for compound assignment or simple assignment
  // e.g. a=..., a+=..., a-=..., a*=..., a/=..., a%=...
  const assignMatch = expr.match(/^([a-zA-Z_][a-zA-Z0-9_]*)\s*(\+=|-=|\*=|\/=|%=|=)(.*)$/);

  if (assignMatch) {
    const varName = assignMatch[1].toUpperCase();
    const op = assignMatch[2];
    const rightExpr = assignMatch[3].trim();

    const rightVal = evaluateMathExpression(rightExpr, currentEnv);
    let finalVal = 0;
    const currentVal = parseCmdInt(varName, currentEnv);

    switch (op) {
      case '=':
        finalVal = rightVal;
        break;
      case '+=':
        finalVal = (currentVal + rightVal) | 0;
        break;
      case '-=':
        finalVal = (currentVal - rightVal) | 0;
        break;
      case '*=':
        finalVal = (currentVal * rightVal) | 0;
        break;
      case '/=':
        finalVal = rightVal !== 0 ? Math.trunc(currentVal / rightVal) | 0 : 0;
        break;
      case '%=':
        finalVal = rightVal !== 0 ? (currentVal % rightVal) | 0 : 0;
        break;
      default:
        finalVal = rightVal;
    }

    const updatedEnv = {
      ...currentEnv,
      [varName]: finalVal.toString(),
    };

    return {
      success: true,
      varName,
      result: finalVal,
      output: `${finalVal}`,
      newEnvVars: updatedEnv,
    };
  }

  // Pure arithmetic expression without assignment (e.g. set /a (2+3)*4)
  const result = evaluateMathExpression(expr, currentEnv);
  return {
    success: true,
    result,
    output: `${result}`,
  };
}
