// Microsoft DiskPart Engine for Windows 11 Simulation
// Authentic command line partition, disk, volume, and filesystem management

export interface DiskPartition {
  id: number;
  type: 'Primary' | 'System' | 'Reserved' | 'Recovery' | 'Extended' | 'Logical';
  sizeMB: number;
  offsetKB: number;
  isActive?: boolean;
  guid?: string;
  volumeId?: number;
}

export interface DiskVolume {
  id: number;
  letter: string; // e.g. "C", "D", ""
  label: string;
  fs: 'NTFS' | 'FAT32' | 'exFAT' | 'RAW' | 'ReFS';
  type: 'Partition' | 'Removable' | 'Simple' | 'Spanned' | 'Stripe' | 'Mirror' | 'RAID-5';
  sizeMB: number;
  freeMB: number;
  status: 'Healthy' | 'At Risk' | 'Failed' | 'Unknown';
  info: 'Boot' | 'System' | 'Hidden' | 'Pagefile' | 'Crashdump' | '';
  diskId: number;
  partitionId?: number;
  isReadOnly?: boolean;
  isHidden?: boolean;
  noDefaultDriveLetter?: boolean;
}

export interface PhysicalDisk {
  id: number;
  model: string;
  status: 'Online' | 'Offline';
  sizeGB: number;
  freeKB: number;
  isDynamic: boolean;
  isGpt: boolean;
  type: 'NVMe' | 'SATA' | 'USB' | 'SCSI';
  busType: string;
  diskIdGuid: string;
  isReadOnly: boolean;
  isBootDisk: boolean;
  isPagefileDisk: boolean;
  isCrashdumpDisk: boolean;
  partitions: DiskPartition[];
}

export interface DiskPartState {
  disks: PhysicalDisk[];
  volumes: DiskVolume[];
  selectedDiskId: number | null;
  selectedVolumeId: number | null;
  selectedPartitionId: number | null;
}

// Initial factory state for Windows 11 system
export function createInitialDiskPartState(): DiskPartState {
  const disk0: PhysicalDisk = {
    id: 0,
    model: 'Samsung SSD 990 PRO 1TB',
    status: 'Online',
    sizeGB: 512,
    freeKB: 1024,
    isDynamic: false,
    isGpt: true,
    type: 'NVMe',
    busType: 'NVMe',
    diskIdGuid: '{8F1C3E6B-5369-42E1-BA37-01D1A25B56F9}',
    isReadOnly: false,
    isBootDisk: true,
    isPagefileDisk: true,
    isCrashdumpDisk: true,
    partitions: [
      {
        id: 1,
        type: 'System',
        sizeMB: 100,
        offsetKB: 1024,
        isActive: false,
        guid: 'c12a7328-f81f-11d2-ba4b-00a0c93ec93b',
        volumeId: 1,
      },
      {
        id: 2,
        type: 'Reserved',
        sizeMB: 16,
        offsetKB: 103424,
        isActive: false,
        guid: 'e3c9e316-0b5c-4db8-817d-f92df00215ae',
      },
      {
        id: 3,
        type: 'Primary',
        sizeMB: 486400, // ~475 GB
        offsetKB: 119808,
        isActive: false,
        guid: 'ebd0a0a2-b9e5-4433-87c0-68b6b72699c7',
        volumeId: 0,
      },
      {
        id: 4,
        type: 'Recovery',
        sizeMB: 650,
        offsetKB: 498380800,
        isActive: false,
        guid: 'de94bba4-06d1-4d40-a16a-bfd50179d6ac',
        volumeId: 2,
      },
    ],
  };

  const disk1: PhysicalDisk = {
    id: 1,
    model: 'Crucial P3 Plus SSD 1TB',
    status: 'Online',
    sizeGB: 1000,
    freeKB: 2048,
    isDynamic: false,
    isGpt: true,
    type: 'NVMe',
    busType: 'NVMe',
    diskIdGuid: '{7D2B1A4C-4258-41D0-AA12-92C0B14A45E8}',
    isReadOnly: false,
    isBootDisk: false,
    isPagefileDisk: false,
    isCrashdumpDisk: false,
    partitions: [
      {
        id: 1,
        type: 'Primary',
        sizeMB: 1024000,
        offsetKB: 1024,
        isActive: false,
        guid: 'ebd0a0a2-b9e5-4433-87c0-68b6b72699c7',
        volumeId: 3,
      },
    ],
  };

  const disk2: PhysicalDisk = {
    id: 2,
    model: 'Kingston DataTraveler 3.0 USB Device',
    status: 'Online',
    sizeGB: 32,
    freeKB: 0,
    isDynamic: false,
    isGpt: false,
    type: 'USB',
    busType: 'USB',
    diskIdGuid: '{5B0C9D3E-3147-40CF-9811-81B0A03934D7}',
    isReadOnly: false,
    isBootDisk: false,
    isPagefileDisk: false,
    isCrashdumpDisk: false,
    partitions: [
      {
        id: 1,
        type: 'Primary',
        sizeMB: 32768,
        offsetKB: 1024,
        isActive: true,
        volumeId: 4,
      },
    ],
  };

  const volumes: DiskVolume[] = [
    {
      id: 0,
      letter: 'C',
      label: 'Windows11',
      fs: 'NTFS',
      type: 'Partition',
      sizeMB: 486400, // 475 GB
      freeMB: 327680, // 320 GB
      status: 'Healthy',
      info: 'Boot',
      diskId: 0,
      partitionId: 3,
    },
    {
      id: 1,
      letter: '',
      label: 'SYSTEM',
      fs: 'FAT32',
      type: 'Partition',
      sizeMB: 100,
      freeMB: 72,
      status: 'Healthy',
      info: 'System',
      diskId: 0,
      partitionId: 1,
      isHidden: true,
    },
    {
      id: 2,
      letter: '',
      label: 'Recovery',
      fs: 'NTFS',
      type: 'Partition',
      sizeMB: 650,
      freeMB: 120,
      status: 'Healthy',
      info: 'Hidden',
      diskId: 0,
      partitionId: 4,
      isHidden: true,
    },
    {
      id: 3,
      letter: 'D',
      label: 'Data',
      fs: 'NTFS',
      type: 'Partition',
      sizeMB: 1024000, // 1000 GB
      freeMB: 870400, // 850 GB
      status: 'Healthy',
      info: '',
      diskId: 1,
      partitionId: 1,
    },
    {
      id: 4,
      letter: 'E',
      label: 'USB_DRIVE',
      fs: 'FAT32',
      type: 'Removable',
      sizeMB: 32768, // 32 GB
      freeMB: 28672,
      status: 'Healthy',
      info: '',
      diskId: 2,
      partitionId: 1,
    },
  ];

  return {
    disks: [disk0, disk1, disk2],
    volumes,
    selectedDiskId: null,
    selectedVolumeId: null,
    selectedPartitionId: null,
  };
}

// Global persistent state across diskpart invocations in a session
let sharedDiskPartState: DiskPartState = createInitialDiskPartState();

export function getSharedDiskPartState(): DiskPartState {
  return sharedDiskPartState;
}

export function resetDiskPartState(): void {
  sharedDiskPartState = createInitialDiskPartState();
}

// Formatting helpers
function formatSizeMB(mb: number): string {
  if (mb >= 1024 * 1024) {
    return `${(mb / (1024 * 1024)).toFixed(1)} TB`;
  }
  if (mb >= 1024) {
    return `${Math.round(mb / 1024)} GB`;
  }
  return `${Math.round(mb)} MB`;
}

function formatOffsetKB(kb: number): string {
  if (kb >= 1024 * 1024) {
    return `${Math.round(kb / (1024 * 1024))} GB`;
  }
  if (kb >= 1024) {
    return `${Math.round(kb / 1024)} MB`;
  }
  return `${Math.round(kb)} KB`;
}

function padRight(str: string, length: number): string {
  return (str + ' '.repeat(Math.max(0, length - str.length))).slice(0, length);
}

function padLeft(str: string, length: number): string {
  return (' '.repeat(Math.max(0, length - str.length)) + str).slice(-length);
}

export interface DiskPartResult {
  output: string;
  isExit?: boolean;
  newState?: DiskPartState;
}

export const DISKPART_BANNER = `Microsoft DiskPart version 10.0.22621.1

Copyright (C) 1999-2024 Microsoft Corporation.
On computer: DESKTOP-WIN11-OS
`;

export function executeDiskPartCommand(
  rawCmd: string,
  state: DiskPartState = sharedDiskPartState
): DiskPartResult {
  const trimmed = rawCmd.trim();
  if (!trimmed) {
    return { output: '' };
  }

  // Tokens
  const parts = trimmed.split(/\s+/);
  const mainCmd = parts[0].toLowerCase();
  const subCmd = parts[1]?.toLowerCase() || '';
  const restArgs = parts.slice(2);

  // 1. EXIT / QUIT
  if (mainCmd === 'exit' || mainCmd === 'quit') {
    return {
      output: 'Leaving DiskPart...',
      isExit: true,
    };
  }

  // 2. HELP / ?
  if (mainCmd === 'help' || mainCmd === '?') {
    if (subCmd) {
      return { output: getSpecificHelp(subCmd) };
    }
    return { output: getMainHelp() };
  }

  // 3. LIST commands
  if (mainCmd === 'list') {
    if (subCmd === 'disk') {
      return listDisks(state);
    }
    if (subCmd === 'volume' || subCmd === 'vol') {
      return listVolumes(state);
    }
    if (subCmd === 'partition' || subCmd === 'part') {
      return listPartitions(state);
    }
    if (subCmd === 'vdisk') {
      return {
        output: 'There are no virtual disks to show.',
      };
    }
    return {
      output: `The arguments specified for this command are not valid.
For more information on the command type: HELP LIST`,
    };
  }

  // 4. SELECT commands
  if (mainCmd === 'select' || mainCmd === 'sel') {
    if (subCmd === 'disk') {
      const targetStr = restArgs[0];
      if (targetStr === undefined) {
        return { output: 'The arguments specified for this command are not valid.' };
      }
      const diskId = parseInt(targetStr, 10);
      const disk = state.disks.find((d) => d.id === diskId);
      if (!disk) {
        state.selectedDiskId = null;
        state.selectedPartitionId = null;
        return {
          output: 'The disk you specified is not valid.\nThere is no disk selected.',
          newState: { ...state },
        };
      }
      state.selectedDiskId = diskId;
      state.selectedPartitionId = null; // resetting partition focus when switching disk
      return {
        output: `Disk ${diskId} is now the selected disk.`,
        newState: { ...state },
      };
    }

    if (subCmd === 'volume' || subCmd === 'vol') {
      const targetStr = restArgs[0];
      if (targetStr === undefined) {
        return { output: 'The arguments specified for this command are not valid.' };
      }
      let targetVol: DiskVolume | undefined;
      const parsedNum = parseInt(targetStr, 10);
      if (!isNaN(parsedNum)) {
        targetVol = state.volumes.find((v) => v.id === parsedNum);
      } else {
        // By drive letter, e.g. "select volume C" or "select volume C:"
        const cleanLetter = targetStr.replace(/[:\\/]/g, '').toUpperCase();
        targetVol = state.volumes.find((v) => v.letter.toUpperCase() === cleanLetter);
      }

      if (!targetVol) {
        state.selectedVolumeId = null;
        return {
          output: 'The volume you specified is not valid.\nThere is no volume selected.',
          newState: { ...state },
        };
      }

      state.selectedVolumeId = targetVol.id;
      // Also sync disk & partition if applicable
      if (targetVol.diskId !== undefined) {
        state.selectedDiskId = targetVol.diskId;
      }
      if (targetVol.partitionId !== undefined) {
        state.selectedPartitionId = targetVol.partitionId;
      }

      return {
        output: `Volume ${targetVol.id} is now the selected volume.`,
        newState: { ...state },
      };
    }

    if (subCmd === 'partition' || subCmd === 'part') {
      if (state.selectedDiskId === null) {
        return {
          output: 'There is no disk selected.\nPlease select a disk and try again.',
        };
      }
      const disk = state.disks.find((d) => d.id === state.selectedDiskId);
      if (!disk) {
        return { output: 'The selected disk is not valid.' };
      }

      const targetStr = restArgs[0];
      if (targetStr === undefined) {
        return { output: 'The arguments specified for this command are not valid.' };
      }
      const partId = parseInt(targetStr, 10);
      const part = disk.partitions.find((p) => p.id === partId);
      if (!part) {
        state.selectedPartitionId = null;
        return {
          output: 'The partition you specified is not valid.\nThere is no partition selected.',
          newState: { ...state },
        };
      }

      state.selectedPartitionId = partId;
      // Sync selected volume if partition maps to one
      if (part.volumeId !== undefined) {
        state.selectedVolumeId = part.volumeId;
      }

      return {
        output: `Partition ${partId} is now the selected partition.`,
        newState: { ...state },
      };
    }

    return {
      output: `The arguments specified for this command are not valid.
For more information on the command type: HELP SELECT`,
    };
  }

  // 5. DETAIL commands
  if (mainCmd === 'detail' || mainCmd === 'det') {
    if (subCmd === 'disk') {
      return detailDisk(state);
    }
    if (subCmd === 'volume' || subCmd === 'vol') {
      return detailVolume(state);
    }
    if (subCmd === 'partition' || subCmd === 'part') {
      return detailPartition(state);
    }
    return {
      output: `The arguments specified for this command are not valid.
For more information on the command type: HELP DETAIL`,
    };
  }

  // 6. CREATE PARTITION commands
  if (mainCmd === 'create') {
    if (subCmd === 'partition' || subCmd === 'part') {
      return createPartition(restArgs, state);
    }
    if (subCmd === 'volume') {
      return {
        output: 'DiskPart succeeded in creating the volume.',
      };
    }
    return {
      output: `The arguments specified for this command are not valid.
For more information on the command type: HELP CREATE`,
    };
  }

  // 7. FORMAT command
  if (mainCmd === 'format') {
    return formatVolume(parts.slice(1), state);
  }

  // 8. ASSIGN command
  if (mainCmd === 'assign') {
    return assignLetter(parts.slice(1), state);
  }

  // 9. REMOVE command
  if (mainCmd === 'remove') {
    return removeLetter(parts.slice(1), state);
  }

  // 10. DELETE commands
  if (mainCmd === 'delete' || mainCmd === 'del') {
    if (subCmd === 'partition' || subCmd === 'part') {
      return deletePartition(restArgs, state);
    }
    if (subCmd === 'volume' || subCmd === 'vol') {
      return deleteVolume(restArgs, state);
    }
    if (subCmd === 'disk') {
      return deleteDisk(restArgs, state);
    }
    return {
      output: `The arguments specified for this command are not valid.
For more information on the command type: HELP DELETE`,
    };
  }

  // 11. CLEAN / CLEAN ALL
  if (mainCmd === 'clean') {
    return cleanDisk(subCmd === 'all', state);
  }

  // 12. ACTIVE / INACTIVE
  if (mainCmd === 'active') {
    return markActive(state);
  }
  if (mainCmd === 'inactive') {
    return markInactive(state);
  }

  // 13. CONVERT commands
  if (mainCmd === 'convert') {
    return convertDisk(subCmd, state);
  }

  // 14. ATTRIBUTES commands
  if (mainCmd === 'attributes' || mainCmd === 'attr') {
    return handleAttributes(subCmd, restArgs, state);
  }

  // 15. EXTEND command
  if (mainCmd === 'extend') {
    return extendVolume(parts.slice(1), state);
  }

  // 16. SHRINK command
  if (mainCmd === 'shrink') {
    return shrinkVolume(parts.slice(1), state);
  }

  // 17. ONLINE / OFFLINE commands
  if (mainCmd === 'online') {
    return onlineObject(subCmd, restArgs, state);
  }
  if (mainCmd === 'offline') {
    return offlineObject(subCmd, restArgs, state);
  }

  // 18. RESCAN command
  if (mainCmd === 'rescan') {
    return {
      output: `Please wait while DiskPart scans your configuration...

DiskPart has finished scanning your configuration.`,
    };
  }

  // 19. FILESYSTEMS command
  if (mainCmd === 'filesystems') {
    return getFilesystemsInfo(state);
  }

  // 20. AUTOMOUNT
  if (mainCmd === 'automount') {
    return {
      output: 'Automatic mounting of new volumes enabled.',
    };
  }

  // 21. SAN
  if (mainCmd === 'san') {
    return {
      output: 'SAN Policy : Online All',
    };
  }

  // Unknown command
  return {
    output: `Microsoft DiskPart version 10.0.22621.1

${mainCmd.toUpperCase()} is not recognized as an internal or external DiskPart command.
Type HELP for a list of available commands.`,
  };
}

// ================= Implementation Helpers =================

function listDisks(state: DiskPartState): DiskPartResult {
  const lines: string[] = [];
  lines.push('  Disk ###  Status         Size     Free     Dyn  Gpt');
  lines.push('  --------  -------------  -------  -------  ---  ---');

  state.disks.forEach((disk) => {
    const isSelected = disk.id === state.selectedDiskId;
    const prefix = isSelected ? '* ' : '  ';
    const diskNum = padRight(`Disk ${disk.id}`, 8);
    const status = padRight(disk.status, 13);
    const size = padLeft(`${disk.sizeGB} GB`, 7);
    const free = padLeft(disk.freeKB >= 1024 ? `${Math.round(disk.freeKB / 1024)} MB` : `${disk.freeKB} KB`, 7);
    const dyn = padRight(disk.isDynamic ? '*' : '', 3);
    const gpt = disk.isGpt ? '*' : '';

    lines.push(`${prefix}${diskNum}  ${status}  ${size}  ${free}  ${dyn}  ${gpt}`);
  });

  return { output: lines.join('\n') };
}

function listVolumes(state: DiskPartState): DiskPartResult {
  const lines: string[] = [];
  lines.push('  Volume ###  Ltr  Label        Fs     Type        Size     Status     Info');
  lines.push('  ----------  ---  -----------  -----  ----------  -------  ---------  --------');

  state.volumes.forEach((vol) => {
    const isSelected = vol.id === state.selectedVolumeId;
    const prefix = isSelected ? '* ' : '  ';
    const volNum = padRight(`Volume ${vol.id}`, 10);
    const ltr = padRight(vol.letter || ' ', 3);
    const label = padRight(vol.label || ' ', 11);
    const fs = padRight(vol.fs, 5);
    const type = padRight(vol.type, 10);
    const size = padLeft(formatSizeMB(vol.sizeMB), 7);
    const status = padRight(vol.status, 9);
    const info = vol.info || '';

    lines.push(`${prefix}${volNum}  ${ltr}  ${label}  ${fs}  ${type}  ${size}  ${status}  ${info}`);
  });

  return { output: lines.join('\n') };
}

function listPartitions(state: DiskPartState): DiskPartResult {
  if (state.selectedDiskId === null) {
    return {
      output: 'There is no disk selected.\nPlease select a disk and try again.',
    };
  }

  const disk = state.disks.find((d) => d.id === state.selectedDiskId);
  if (!disk) {
    return { output: 'The selected disk is not valid.' };
  }

  if (disk.partitions.length === 0) {
    return {
      output: 'There are no partitions on this disk to show.',
    };
  }

  const lines: string[] = [];
  lines.push('  Partition ###  Type              Size     Offset');
  lines.push('  -------------  ----------------  -------  -------');

  disk.partitions.forEach((part) => {
    const isSelected = part.id === state.selectedPartitionId;
    const prefix = isSelected ? '* ' : '  ';
    const partNum = padRight(`Partition ${part.id}`, 13);
    const type = padRight(part.type, 16);
    const size = padLeft(formatSizeMB(part.sizeMB), 7);
    const offset = padLeft(formatOffsetKB(part.offsetKB), 7);

    lines.push(`${prefix}${partNum}  ${type}  ${size}  ${offset}`);
  });

  return { output: lines.join('\n') };
}

function detailDisk(state: DiskPartState): DiskPartResult {
  if (state.selectedDiskId === null) {
    return {
      output: 'There is no disk selected.\nPlease select a disk and try again.',
    };
  }

  const disk = state.disks.find((d) => d.id === state.selectedDiskId);
  if (!disk) {
    return { output: 'The selected disk is not valid.' };
  }

  const lines: string[] = [
    disk.model,
    `Disk ID: ${disk.diskIdGuid}`,
    `Type   : ${disk.type}`,
    `Status : ${disk.status}`,
    `Path   : ${disk.id}`,
    `Target : 0`,
    `LUN ID : 0`,
    `Location Path : PCIROOT(0)#PCI(0101)#${disk.busType}(000${disk.id + 1})`,
    `Current Read-only State : ${disk.isReadOnly ? 'Yes' : 'No'}`,
    `Read-only : ${disk.isReadOnly ? 'Yes' : 'No'}`,
    `Boot Disk : ${disk.isBootDisk ? 'Yes' : 'No'}`,
    `Pagefile Disk : ${disk.isPagefileDisk ? 'Yes' : 'No'}`,
    `Hibernation File Disk : No`,
    `Crashdump Disk : ${disk.isCrashdumpDisk ? 'Yes' : 'No'}`,
    `Clustered Disk : No`,
    '',
    '  Volume ###  Ltr  Label        Fs     Type        Size     Status     Info',
    '  ----------  ---  -----------  -----  ----------  -------  ---------  --------',
  ];

  const diskVolumes = state.volumes.filter((v) => v.diskId === disk.id);
  if (diskVolumes.length === 0) {
    lines.push('  There are no volumes on this disk.');
  } else {
    diskVolumes.forEach((vol) => {
      const isSelected = vol.id === state.selectedVolumeId;
      const prefix = isSelected ? '* ' : '  ';
      const volNum = padRight(`Volume ${vol.id}`, 10);
      const ltr = padRight(vol.letter || ' ', 3);
      const label = padRight(vol.label || ' ', 11);
      const fs = padRight(vol.fs, 5);
      const type = padRight(vol.type, 10);
      const size = padLeft(formatSizeMB(vol.sizeMB), 7);
      const status = padRight(vol.status, 9);
      const info = vol.info || '';

      lines.push(`${prefix}${volNum}  ${ltr}  ${label}  ${fs}  ${type}  ${size}  ${status}  ${info}`);
    });
  }

  return { output: lines.join('\n') };
}

function detailVolume(state: DiskPartState): DiskPartResult {
  if (state.selectedVolumeId === null) {
    return {
      output: 'There is no volume selected.\nPlease select a volume and try again.',
    };
  }

  const vol = state.volumes.find((v) => v.id === state.selectedVolumeId);
  if (!vol) {
    return { output: 'The selected volume is not valid.' };
  }

  const disk = state.disks.find((d) => d.id === vol.diskId);

  const lines: string[] = [
    '  Disk ###  Status         Size     Free     Dyn  Gpt',
    '  --------  -------------  -------  -------  ---  ---',
  ];

  if (disk) {
    const isSelected = disk.id === state.selectedDiskId;
    const prefix = isSelected ? '* ' : '  ';
    const diskNum = padRight(`Disk ${disk.id}`, 8);
    const status = padRight(disk.status, 13);
    const size = padLeft(`${disk.sizeGB} GB`, 7);
    const free = padLeft(disk.freeKB >= 1024 ? `${Math.round(disk.freeKB / 1024)} MB` : `${disk.freeKB} KB`, 7);
    const dyn = padRight(disk.isDynamic ? '*' : '', 3);
    const gpt = disk.isGpt ? '*' : '';
    lines.push(`${prefix}${diskNum}  ${status}  ${size}  ${free}  ${dyn}  ${gpt}`);
  }

  lines.push('');
  lines.push(`Read-only              : ${vol.isReadOnly ? 'Yes' : 'No'}`);
  lines.push(`Hidden                 : ${vol.isHidden ? 'Yes' : 'No'}`);
  lines.push(`No Default Drive Letter: ${vol.noDefaultDriveLetter ? 'Yes' : 'No'}`);
  lines.push(`Shadow Copy            : No`);
  lines.push(`Offline                : No`);
  lines.push(`BitLocker Encrypted    : No`);
  lines.push(`Installable            : Yes`);
  lines.push('');
  lines.push(`Volume Capacity        : ${formatSizeMB(vol.sizeMB)}`);
  lines.push(`Volume Free Space      : ${formatSizeMB(vol.freeMB)}`);

  return { output: lines.join('\n') };
}

function detailPartition(state: DiskPartState): DiskPartResult {
  if (state.selectedDiskId === null) {
    return {
      output: 'There is no disk selected.\nPlease select a disk and try again.',
    };
  }
  const disk = state.disks.find((d) => d.id === state.selectedDiskId);
  if (!disk) {
    return { output: 'The selected disk is not valid.' };
  }

  if (state.selectedPartitionId === null) {
    return {
      output: 'There is no partition selected.\nPlease select a partition and try again.',
    };
  }

  const part = disk.partitions.find((p) => p.id === state.selectedPartitionId);
  if (!part) {
    return { output: 'The selected partition is not valid.' };
  }

  const typeGuid = part.guid || (part.type === 'Primary' ? 'ebd0a0a2-b9e5-4433-87c0-68b6b72699c7' : 'c12a7328-f81f-11d2-ba4b-00a0c93ec93b');

  const lines: string[] = [
    `Partition ${part.id}`,
    `Type    : ${typeGuid}`,
    `Hidden  : ${part.type === 'Recovery' || part.type === 'System' ? 'Yes' : 'No'}`,
    `Required: ${part.type === 'System' || part.type === 'Recovery' ? 'Yes' : 'No'}`,
    `Attrib  : 0000000000000000`,
    `Offset in Bytes: ${part.offsetKB * 1024}`,
  ];

  if (part.volumeId !== undefined) {
    const vol = state.volumes.find((v) => v.id === part.volumeId);
    if (vol) {
      lines.push('');
      lines.push('  Volume ###  Ltr  Label        Fs     Type        Size     Status     Info');
      lines.push('  ----------  ---  -----------  -----  ----------  -------  ---------  --------');
      const isSelected = vol.id === state.selectedVolumeId;
      const prefix = isSelected ? '* ' : '  ';
      const volNum = padRight(`Volume ${vol.id}`, 10);
      const ltr = padRight(vol.letter || ' ', 3);
      const label = padRight(vol.label || ' ', 11);
      const fs = padRight(vol.fs, 5);
      const type = padRight(vol.type, 10);
      const size = padLeft(formatSizeMB(vol.sizeMB), 7);
      const status = padRight(vol.status, 9);
      const info = vol.info || '';
      lines.push(`${prefix}${volNum}  ${ltr}  ${label}  ${fs}  ${type}  ${size}  ${status}  ${info}`);
    }
  }

  return { output: lines.join('\n') };
}

function createPartition(args: string[], state: DiskPartState): DiskPartResult {
  if (state.selectedDiskId === null) {
    return {
      output: 'There is no disk selected.\nPlease select a disk and try again.',
    };
  }

  const disk = state.disks.find((d) => d.id === state.selectedDiskId);
  if (!disk) {
    return { output: 'The selected disk is not valid.' };
  }

  const partTypeArg = args[0]?.toLowerCase() || 'primary';
  let sizeMB = 10240; // Default 10 GB

  // Parse size=N
  for (const arg of args.slice(1)) {
    if (arg.toLowerCase().startsWith('size=')) {
      const parsed = parseInt(arg.substring(5), 10);
      if (!isNaN(parsed) && parsed > 0) {
        sizeMB = parsed;
      }
    }
  }

  const nextPartId = (disk.partitions.reduce((max, p) => Math.max(max, p.id), 0) || 0) + 1;
  const lastPart = disk.partitions[disk.partitions.length - 1];
  const nextOffsetKB = lastPart ? lastPart.offsetKB + lastPart.sizeMB * 1024 : 1024;

  let finalType: DiskPartition['type'] = 'Primary';
  let guid = 'ebd0a0a2-b9e5-4433-87c0-68b6b72699c7';

  if (partTypeArg === 'efi') {
    finalType = 'System';
    guid = 'c12a7328-f81f-11d2-ba4b-00a0c93ec93b';
  } else if (partTypeArg === 'msr') {
    finalType = 'Reserved';
    guid = 'e3c9e316-0b5c-4db8-817d-f92df00215ae';
  } else if (partTypeArg === 'extended') {
    finalType = 'Extended';
  }

  // Create Volume if not MSR or Extended
  let newVolId: number | undefined;
  if (finalType === 'Primary' || finalType === 'System') {
    const nextVolId = (state.volumes.reduce((max, v) => Math.max(max, v.id), -1) || 0) + 1;
    newVolId = nextVolId;

    // Find next free drive letter
    const usedLetters = new Set(state.volumes.map((v) => v.letter.toUpperCase()).filter(Boolean));
    let assignedLetter = '';
    if (finalType === 'Primary') {
      for (const char of 'FGHIJKLMNOPQRSTUVWXYZ') {
        if (!usedLetters.has(char)) {
          assignedLetter = char;
          break;
        }
      }
    }

    state.volumes.push({
      id: nextVolId,
      letter: assignedLetter,
      label: finalType === 'System' ? 'SYSTEM' : 'New Volume',
      fs: finalType === 'System' ? 'FAT32' : 'RAW',
      type: 'Partition',
      sizeMB,
      freeMB: sizeMB,
      status: 'Healthy',
      info: finalType === 'System' ? 'System' : '',
      diskId: disk.id,
      partitionId: nextPartId,
    });
    state.selectedVolumeId = nextVolId;
  }

  const newPartition: DiskPartition = {
    id: nextPartId,
    type: finalType,
    sizeMB,
    offsetKB: nextOffsetKB,
    isActive: false,
    guid,
    volumeId: newVolId,
  };

  disk.partitions.push(newPartition);
  state.selectedPartitionId = nextPartId;

  return {
    output: 'DiskPart succeeded in creating the specified partition.',
    newState: { ...state },
  };
}

function formatVolume(args: string[], state: DiskPartState): DiskPartResult {
  let targetVol: DiskVolume | undefined;

  if (state.selectedVolumeId !== null) {
    targetVol = state.volumes.find((v) => v.id === state.selectedVolumeId);
  } else if (state.selectedDiskId !== null && state.selectedPartitionId !== null) {
    const disk = state.disks.find((d) => d.id === state.selectedDiskId);
    const part = disk?.partitions.find((p) => p.id === state.selectedPartitionId);
    if (part?.volumeId !== undefined) {
      targetVol = state.volumes.find((v) => v.id === part.volumeId);
    }
  }

  if (!targetVol) {
    return {
      output: 'There is no volume selected.\nPlease select a volume and try again.',
    };
  }

  let fsType: DiskVolume['fs'] = 'NTFS';
  let label = targetVol.label || 'New Volume';

  for (const arg of args) {
    const lower = arg.toLowerCase();
    if (lower.startsWith('fs=')) {
      const requestedFs = lower.substring(3).toUpperCase();
      if (requestedFs === 'FAT32') fsType = 'FAT32';
      else if (requestedFs === 'EXFAT') fsType = 'exFAT';
      else if (requestedFs === 'REFS') fsType = 'ReFS';
      else fsType = 'NTFS';
    } else if (lower.startsWith('label=')) {
      label = arg.substring(6).replace(/^["']|["']$/g, '');
    }
  }

  targetVol.fs = fsType;
  targetVol.label = label;
  targetVol.freeMB = Math.round(targetVol.sizeMB * 0.98); // fresh format

  return {
    output: `  100 percent completed

DiskPart successfully formatted the volume.`,
    newState: { ...state },
  };
}

function assignLetter(args: string[], state: DiskPartState): DiskPartResult {
  if (state.selectedVolumeId === null) {
    return {
      output: 'There is no volume selected.\nPlease select a volume and try again.',
    };
  }

  const vol = state.volumes.find((v) => v.id === state.selectedVolumeId);
  if (!vol) {
    return { output: 'The selected volume is not valid.' };
  }

  let desiredLetter = '';
  for (const arg of args) {
    if (arg.toLowerCase().startsWith('letter=')) {
      desiredLetter = arg.substring(7).replace(/[:\\/]/g, '').toUpperCase();
    }
  }

  if (!desiredLetter) {
    // Automatically find next available letter
    const usedLetters = new Set(state.volumes.map((v) => v.letter.toUpperCase()).filter(Boolean));
    for (const char of 'DEFGHIJKLMNOPQRSTUVWXYZ') {
      if (!usedLetters.has(char)) {
        desiredLetter = char;
        break;
      }
    }
  }

  if (desiredLetter) {
    const existing = state.volumes.find((v) => v.letter.toUpperCase() === desiredLetter && v.id !== vol.id);
    if (existing) {
      return {
        output: 'The specified drive letter is already in use.',
      };
    }
    vol.letter = desiredLetter;
  }

  return {
    output: 'DiskPart successfully assigned the drive letter or mount point.',
    newState: { ...state },
  };
}

function removeLetter(args: string[], state: DiskPartState): DiskPartResult {
  if (state.selectedVolumeId === null) {
    return {
      output: 'There is no volume selected.\nPlease select a volume and try again.',
    };
  }

  const vol = state.volumes.find((v) => v.id === state.selectedVolumeId);
  if (!vol) {
    return { output: 'The selected volume is not valid.' };
  }

  vol.letter = '';

  return {
    output: 'DiskPart successfully removed the drive letter or mount point.',
    newState: { ...state },
  };
}

function deletePartition(args: string[], state: DiskPartState): DiskPartResult {
  if (state.selectedDiskId === null) {
    return {
      output: 'There is no disk selected.\nPlease select a disk and try again.',
    };
  }

  const disk = state.disks.find((d) => d.id === state.selectedDiskId);
  if (!disk) {
    return { output: 'The selected disk is not valid.' };
  }

  if (state.selectedPartitionId === null) {
    return {
      output: 'There is no partition selected.\nPlease select a partition and try again.',
    };
  }

  const partIdx = disk.partitions.findIndex((p) => p.id === state.selectedPartitionId);
  if (partIdx === -1) {
    return { output: 'The selected partition is not valid.' };
  }

  const part = disk.partitions[partIdx];
  const isOverride = args.some((a) => a.toLowerCase() === 'override');

  if ((part.type === 'System' || part.type === 'Recovery') && !isOverride) {
    return {
      output: 'Cannot delete a protected partition without the force protected parameter set (override).',
    };
  }

  // Remove corresponding volume
  if (part.volumeId !== undefined) {
    state.volumes = state.volumes.filter((v) => v.id !== part.volumeId);
    if (state.selectedVolumeId === part.volumeId) {
      state.selectedVolumeId = null;
    }
  }

  disk.partitions.splice(partIdx, 1);
  state.selectedPartitionId = null;

  return {
    output: 'DiskPart successfully deleted the selected partition.',
    newState: { ...state },
  };
}

function deleteVolume(args: string[], state: DiskPartState): DiskPartResult {
  if (state.selectedVolumeId === null) {
    return {
      output: 'There is no volume selected.\nPlease select a volume and try again.',
    };
  }

  const volIdx = state.volumes.findIndex((v) => v.id === state.selectedVolumeId);
  if (volIdx === -1) {
    return { output: 'The selected volume is not valid.' };
  }

  const vol = state.volumes[volIdx];
  if (vol.info === 'Boot' || vol.info === 'System') {
    const isOverride = args.some((a) => a.toLowerCase() === 'override');
    if (!isOverride) {
      return {
        output: 'The volume you selected cannot be deleted because it is the current boot or system volume.',
      };
    }
  }

  // If tied to a partition, clear the link
  if (vol.diskId !== undefined && vol.partitionId !== undefined) {
    const disk = state.disks.find((d) => d.id === vol.diskId);
    const part = disk?.partitions.find((p) => p.id === vol.partitionId);
    if (part) {
      part.volumeId = undefined;
    }
  }

  state.volumes.splice(volIdx, 1);
  state.selectedVolumeId = null;

  return {
    output: 'DiskPart successfully deleted the volume.',
    newState: { ...state },
  };
}

function deleteDisk(args: string[], state: DiskPartState): DiskPartResult {
  return {
    output: 'DiskPart successfully deleted the disk.',
  };
}

function cleanDisk(all: boolean, state: DiskPartState): DiskPartResult {
  if (state.selectedDiskId === null) {
    return {
      output: 'There is no disk selected.\nPlease select a disk and try again.',
    };
  }

  const disk = state.disks.find((d) => d.id === state.selectedDiskId);
  if (!disk) {
    return { output: 'The selected disk is not valid.' };
  }

  // Remove all volumes on this disk
  state.volumes = state.volumes.filter((v) => v.diskId !== disk.id);

  // Clear all partitions
  disk.partitions = [];
  disk.freeKB = disk.sizeGB * 1024 * 1024;
  state.selectedPartitionId = null;
  state.selectedVolumeId = null;

  return {
    output: 'DiskPart succeeded in cleaning the disk.',
    newState: { ...state },
  };
}

function markActive(state: DiskPartState): DiskPartResult {
  if (state.selectedDiskId === null) {
    return {
      output: 'There is no disk selected.\nPlease select a disk and try again.',
    };
  }
  const disk = state.disks.find((d) => d.id === state.selectedDiskId);
  if (!disk) {
    return { output: 'The selected disk is not valid.' };
  }

  if (disk.isGpt) {
    return {
      output: `The selected disk is not a fixed MBR disk.
The ACTIVE command can only be used on fixed MBR disks.`,
    };
  }

  if (state.selectedPartitionId === null) {
    return {
      output: 'There is no partition selected.\nPlease select a partition and try again.',
    };
  }

  const part = disk.partitions.find((p) => p.id === state.selectedPartitionId);
  if (!part) {
    return { output: 'The selected partition is not valid.' };
  }

  // Clear active on others on same disk
  disk.partitions.forEach((p) => {
    p.isActive = false;
  });
  part.isActive = true;

  return {
    output: 'DiskPart marked the current partition as active.',
    newState: { ...state },
  };
}

function markInactive(state: DiskPartState): DiskPartResult {
  if (state.selectedDiskId === null || state.selectedPartitionId === null) {
    return {
      output: 'There is no partition selected.\nPlease select a partition and try again.',
    };
  }
  const disk = state.disks.find((d) => d.id === state.selectedDiskId);
  const part = disk?.partitions.find((p) => p.id === state.selectedPartitionId);
  if (part) {
    part.isActive = false;
  }
  return {
    output: 'DiskPart marked the current partition as inactive.',
    newState: { ...state },
  };
}

function convertDisk(targetFormat: string, state: DiskPartState): DiskPartResult {
  if (state.selectedDiskId === null) {
    return {
      output: 'There is no disk selected.\nPlease select a disk and try again.',
    };
  }

  const disk = state.disks.find((d) => d.id === state.selectedDiskId);
  if (!disk) {
    return { output: 'The selected disk is not valid.' };
  }

  const fmt = targetFormat.toLowerCase();
  if (fmt === 'mbr') {
    disk.isGpt = false;
    return {
      output: 'DiskPart successfully converted the selected disk to MBR format.',
      newState: { ...state },
    };
  }
  if (fmt === 'gpt') {
    disk.isGpt = true;
    return {
      output: 'DiskPart successfully converted the selected disk to GPT format.',
      newState: { ...state },
    };
  }
  if (fmt === 'basic') {
    disk.isDynamic = false;
    return {
      output: 'DiskPart successfully converted the selected disk to basic format.',
      newState: { ...state },
    };
  }
  if (fmt === 'dynamic') {
    disk.isDynamic = true;
    return {
      output: 'DiskPart successfully converted the selected disk to dynamic format.',
      newState: { ...state },
    };
  }

  return {
    output: `The arguments specified for this command are not valid.
For more information on the command type: HELP CONVERT`,
  };
}

function handleAttributes(target: string, args: string[], state: DiskPartState): DiskPartResult {
  const isDisk = target.toLowerCase() === 'disk';
  const isVol = target.toLowerCase() === 'volume' || target.toLowerCase() === 'vol';

  if (isDisk) {
    if (state.selectedDiskId === null) {
      return {
        output: 'There is no disk selected.\nPlease select a disk and try again.',
      };
    }
    const disk = state.disks.find((d) => d.id === state.selectedDiskId);
    if (!disk) return { output: 'The selected disk is not valid.' };

    const action = args[0]?.toLowerCase();
    const attr = args[1]?.toLowerCase();

    if (action === 'set' && attr === 'readonly') {
      disk.isReadOnly = true;
      return {
        output: 'Disk attributes set successfully.',
        newState: { ...state },
      };
    }
    if (action === 'clear' && attr === 'readonly') {
      disk.isReadOnly = false;
      return {
        output: 'Disk attributes cleared successfully.',
        newState: { ...state },
      };
    }

    return {
      output: `Current Read-only State : ${disk.isReadOnly ? 'Yes' : 'No'}
Read-only  : ${disk.isReadOnly ? 'Yes' : 'No'}
Boot Disk  : ${disk.isBootDisk ? 'Yes' : 'No'}
Pagefile Disk  : ${disk.isPagefileDisk ? 'Yes' : 'No'}
Hibernation File Disk  : No
Crashdump Disk  : ${disk.isCrashdumpDisk ? 'Yes' : 'No'}
Clustered Disk  : No`,
    };
  }

  if (isVol) {
    if (state.selectedVolumeId === null) {
      return {
        output: 'There is no volume selected.\nPlease select a volume and try again.',
      };
    }
    const vol = state.volumes.find((v) => v.id === state.selectedVolumeId);
    if (!vol) return { output: 'The selected volume is not valid.' };

    const action = args[0]?.toLowerCase();
    const attr = args[1]?.toLowerCase();

    if (action === 'set' && attr === 'readonly') {
      vol.isReadOnly = true;
      return {
        output: 'Volume attributes set successfully.',
        newState: { ...state },
      };
    }
    if (action === 'clear' && attr === 'readonly') {
      vol.isReadOnly = false;
      return {
        output: 'Volume attributes cleared successfully.',
        newState: { ...state },
      };
    }

    return {
      output: `Read-only              : ${vol.isReadOnly ? 'Yes' : 'No'}
Hidden                 : ${vol.isHidden ? 'Yes' : 'No'}
No Default Drive Letter: ${vol.noDefaultDriveLetter ? 'Yes' : 'No'}
Shadow Copy            : No`,
    };
  }

  return {
    output: `The arguments specified for this command are not valid.
For more information on the command type: HELP ATTRIBUTES`,
  };
}

function extendVolume(args: string[], state: DiskPartState): DiskPartResult {
  if (state.selectedVolumeId === null) {
    return {
      output: 'There is no volume selected.\nPlease select a volume and try again.',
    };
  }

  const vol = state.volumes.find((v) => v.id === state.selectedVolumeId);
  if (!vol) {
    return { output: 'The selected volume is not valid.' };
  }

  let sizeAddMB = 10240; // 10 GB
  for (const arg of args) {
    if (arg.toLowerCase().startsWith('size=')) {
      const parsed = parseInt(arg.substring(5), 10);
      if (!isNaN(parsed) && parsed > 0) {
        sizeAddMB = parsed;
      }
    }
  }

  vol.sizeMB += sizeAddMB;
  vol.freeMB += sizeAddMB;

  return {
    output: 'DiskPart successfully extended the volume.',
    newState: { ...state },
  };
}

function shrinkVolume(args: string[], state: DiskPartState): DiskPartResult {
  if (state.selectedVolumeId === null) {
    return {
      output: 'There is no volume selected.\nPlease select a volume and try again.',
    };
  }

  const vol = state.volumes.find((v) => v.id === state.selectedVolumeId);
  if (!vol) {
    return { output: 'The selected volume is not valid.' };
  }

  let shrinkMB = 1024;
  for (const arg of args) {
    if (arg.toLowerCase().startsWith('desired=')) {
      const parsed = parseInt(arg.substring(8), 10);
      if (!isNaN(parsed) && parsed > 0) {
        shrinkMB = parsed;
      }
    }
  }

  if (vol.sizeMB - shrinkMB < 100) {
    return {
      output: 'The specified shrink size is too big and will cause the volume to be smaller than the minimum volume size.',
    };
  }

  vol.sizeMB -= shrinkMB;
  vol.freeMB = Math.max(0, vol.freeMB - shrinkMB);

  return {
    output: `DiskPart successfully shrunk the volume by: ${shrinkMB} MB.`,
    newState: { ...state },
  };
}

function onlineObject(target: string, args: string[], state: DiskPartState): DiskPartResult {
  if (target.toLowerCase() === 'disk') {
    if (state.selectedDiskId === null) {
      return {
        output: 'There is no disk selected.\nPlease select a disk and try again.',
      };
    }
    const disk = state.disks.find((d) => d.id === state.selectedDiskId);
    if (disk) {
      disk.status = 'Online';
    }
    return {
      output: 'DiskPart successfully onlined the selected disk.',
      newState: { ...state },
    };
  }

  if (target.toLowerCase() === 'volume' || target.toLowerCase() === 'vol') {
    return {
      output: 'DiskPart successfully onlined the selected volume.',
    };
  }

  return {
    output: 'The arguments specified for this command are not valid.',
  };
}

function offlineObject(target: string, args: string[], state: DiskPartState): DiskPartResult {
  if (target.toLowerCase() === 'disk') {
    if (state.selectedDiskId === null) {
      return {
        output: 'There is no disk selected.\nPlease select a disk and try again.',
      };
    }
    const disk = state.disks.find((d) => d.id === state.selectedDiskId);
    if (disk) {
      disk.status = 'Offline';
    }
    return {
      output: 'DiskPart successfully offlined the selected disk.',
      newState: { ...state },
    };
  }

  if (target.toLowerCase() === 'volume' || target.toLowerCase() === 'vol') {
    return {
      output: 'DiskPart successfully offlined the selected volume.',
    };
  }

  return {
    output: 'The arguments specified for this command are not valid.',
  };
}

function getFilesystemsInfo(state: DiskPartState): DiskPartResult {
  if (state.selectedVolumeId === null) {
    return {
      output: 'There is no volume selected.\nPlease select a volume and try again.',
    };
  }

  const vol = state.volumes.find((v) => v.id === state.selectedVolumeId);
  const currentFs = vol ? vol.fs : 'NTFS';

  return {
    output: `Current File System
  Type                 : ${currentFs}
  Allocation Unit Size : 4096
  Flags : 00000000

File Systems Supported for Formatting
  Type                 : NTFS (Default)
  Allocation Unit Sizes: 512, 1024, 2048, 4096, 8192, 16K, 32K, 64K, 128K, 256K, 512K, 1024K, 2048K

  Type                 : FAT32
  Allocation Unit Sizes: 512, 1024, 2048, 4096, 8192, 16K, 32K, 64K

  Type                 : exFAT
  Allocation Unit Sizes: 512, 1024, 2048, 4096, 8192, 16K, 32K, 64K, 128K, 256K, 512K, 1024K, 2048K, 4096K, 8192K, 16384K, 32768K`,
  };
}

function getMainHelp(): string {
  return `Microsoft DiskPart version 10.0.22621.1

ACTIVE      - Mark the selected partition as active.
ADD         - Add a mirror to a simple volume.
ASSIGN      - Assign a drive letter or mount point to the selected volume.
ATTRIBUTES  - Manipulate volume or disk attributes.
ATTACH      - Attaches a virtual disk file.
AUTOMOUNT   - Enable and disable automatic mounting of basic volumes.
BREAK       - Break a mirror set.
CLEAN       - Clear the configuration information, or all information, off the
              disk.
COMPACT     - Attempts to reduce the physical size of the file.
CONVERT     - Convert between different disk formats.
CREATE      - Create a volume, partition or virtual disk.
DELETE      - Delete an object.
DETAIL      - Provide details about an object.
DETACH      - Detaches a virtual disk file.
EXIT        - Exit DiskPart.
EXTEND      - Extend a volume.
EXPAND      - Expands the maximum size available on a virtual disk.
FILESYSTEMS - Display current and supported filesystems on the volume.
FORMAT      - Format the volume or partition.
GPT         - Assign attributes to the selected GPT partition.
HELP        - Display a list of commands.
IMPORT      - Import a disk group.
INACTIVE    - Mark the selected partition as inactive.
LIST        - Display a list of objects.
MERGE       - Merges a child disk with its parents.
OFFLINE     - Offline an object that is currently marked as offline.
ONLINE      - Online an object that is currently marked as offline.
RECOVER     - Refreshes the state of all disks in the invalid pack.
REM         - Does nothing. Used to comment scripts.
REMOVE      - Remove a drive letter or mount point assignment.
REPAIR      - Repair a RAID-5 volume with a failed member.
RESCAN      - Rescan the computer looking for disks and volumes.
RETAIN      - Place a retained partition under a simple volume.
SAN         - Display or set the SAN policy for the currently booted OS.
SELECT      - Shift the focus to an object.
SETID       - Change the partition type.
SHRINK      - Reduce the size of the selected volume.
UNIQUEID    - Displays or sets the GUID partition table (GPT) identifier or
              master boot record (MBR) signature of a disk.`;
}

function getSpecificHelp(cmd: string): string {
  const c = cmd.toLowerCase();
  switch (c) {
    case 'list':
      return `Displays a list of objects.

Syntax:  LIST [DISK | VOLUME | PARTITION | VDISK]

  DISK        - Display a list of disks.
  VOLUME      - Display a list of volumes.
  PARTITION   - Display a list of partitions on the selected disk.
  VDISK       - Displays a list of virtual disks.`;

    case 'select':
      return `Shifts the focus to an object.

Syntax:  SELECT [DISK | VOLUME | PARTITION | VDISK] [n]

  DISK        - Shift the focus to the disk.
  VOLUME      - Shift the focus to the volume.
  PARTITION   - Shift the focus to the partition.
  VDISK       - Shifts the focus to the virtual disk.`;

    case 'detail':
      return `Provides details about an object.

Syntax:  DETAIL [DISK | VOLUME | PARTITION | VDISK]

  DISK        - Display the properties of the selected disk.
  VOLUME      - Display the properties of the selected volume.
  PARTITION   - Display the properties of the selected partition.
  VDISK       - Displays the properties of the selected virtual disk.`;

    case 'create':
      return `Creates a partition, volume or virtual disk.

Syntax:  CREATE PARTITION [PRIMARY | EFI | MSR | EXTENDED] [SIZE=<N>] [OFFSET=<N>]
         CREATE VOLUME [SIMPLE | STRIPE | RAID] [SIZE=<N>] [DISK=<N>]`;

    case 'format':
      return `Formats the specified volume for use with Windows.

Syntax:  FORMAT [[FS=<FS>] [REVISION=<X.XX>] | RECOMMENDED] [LABEL=<"label">]
                [UNIT=<N>] [QUICK] [COMPRESS] [OVERRIDE] [NOWAIT] [NOERR]

  FS=<FS>     - Specifies the type of file system (NTFS, FAT32, exFAT, ReFS).
  LABEL=<"label"> - Specifies the volume label.
  QUICK       - Performs a quick format.`;

    case 'assign':
      return `Assigns a drive letter or mount point to the selected volume.

Syntax:  ASSIGN [[LETTER=<L>] | [MOUNT=<path>]] [NOERR]

  LETTER=<L>  - The drive letter you want to assign to the volume.`;

    case 'remove':
      return `Removes a drive letter or mount point assignment.

Syntax:  REMOVE [[LETTER=<L>] | [MOUNT=<path>] | [ALL]] [DISMOUNT] [NOERR]`;

    case 'delete':
      return `Deletes an object.

Syntax:  DELETE [DISK | PARTITION | VOLUME] [NOERR] [OVERRIDE]`;

    case 'clean':
      return `Removes any and all partition or volume formatting from the disk with focus.

Syntax:  CLEAN [ALL]

  ALL         - Specifies that each and every sector on the disk is zeroed.`;

    case 'convert':
      return `Converts between different disk formats.

Syntax:  CONVERT [BASIC | DYNAMIC | GPT | MBR]

  BASIC       - Converts a dynamic disk to a basic disk.
  DYNAMIC     - Converts a basic disk to a dynamic disk.
  GPT         - Converts an MBR disk to a GPT disk.
  MBR         - Converts a GPT disk to an MBR disk.`;

    case 'attributes':
      return `Manipulate volume or disk attributes.

Syntax:  ATTRIBUTES DISK [SET | CLEAR] [READONLY] [NOERR]
         ATTRIBUTES VOLUME [SET | CLEAR] [READONLY | HIDDEN | NODEFAULTDRIVELETTER | SHADOWCOPY] [NOERR]`;

    case 'extend':
      return `Extends the volume with focus into next contiguous unallocated space.

Syntax:  EXTEND [SIZE=<N>] [DISK=<N>] [NOERR]`;

    case 'active':
      return `Marks the selected partition as active.

Syntax:  ACTIVE`;

    case 'online':
      return `Takes an offline object to the online state.

Syntax:  ONLINE [DISK | VOLUME] [NOERR]`;

    case 'offline':
      return `Takes an online object to the offline state.

Syntax:  OFFLINE [DISK | VOLUME] [NOERR]`;

    default:
      return `Help for "${cmd.toUpperCase()}" is available in the main DiskPart documentation.`;
  }
}
