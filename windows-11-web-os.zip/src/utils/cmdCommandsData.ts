// Comprehensive metadata and help dictionary for all 245 Windows 11 commands + Group 7 project commands

export interface CommandDoc {
  name: string;
  group: number;
  groupName: string;
  shortDesc: string;
  syntax: string;
  detailedHelp: string;
  aliases?: string[];
}

export const COMMAND_GROUPS = [
  { id: 1, name: 'NHÓM 1: LỆNH CƠ BẢN — AI CŨNG BIẾT (30 LỆNH)' },
  { id: 2, name: 'NHÓM 2: QUẢN LÝ TỆP & THƯ MỤC — THƯỜNG DÙNG (40 LỆNH)' },
  { id: 3, name: 'NHÓM 3: QUẢN LÝ HỆ THỐNG — TRUNG BÌNH (45 LỆNH)' },
  { id: 4, name: 'NHÓM 4: MẠNG & KẾT NỐI — ÍT NGƯỜI DÙNG (35 LỆNH)' },
  { id: 5, name: 'NHÓM 5: LỆNH NỘI BỘ & BÍ MẬT — RẤT ÍT NGƯỜI BIẾT (50 LỆNH)' },
  { id: 6, name: 'NHÓM 6: LỆNH NÂNG CAO & CHUYÊN GIA — HẦU NHƯ KHÔNG AI DÙNG (40 LỆNH)' },
  { id: 7, name: 'NHÓM 7: LỆNH ĐỘC NHẤT DỰ ÁN — WINDOWS THẬT KHÔNG CÓ (5 LỆNH)' },
];

export const COMMAND_REGISTRY: Record<string, CommandDoc> = {
  // ==========================================
  // NHÓM 1: LỆNH CƠ BẢN (30 LỆNH)
  // ==========================================
  dir: {
    name: 'dir',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Hiển thị danh sách tệp và thư mục con với đầy đủ tham số.',
    syntax: 'DIR [drive:][path][filename] [/A[[:]attributes]] [/B] [/C] [/D] [/L] [/N] [/O[[:]sortorder]] [/P] [/Q] [/R] [/S] [/T[[:]timefield]] [/W] [/X] [/4]',
    detailedHelp: `Hiển thị danh sách các tệp và thư mục con trong một thư mục.

Cú pháp đầy đủ:
  DIR [ổ_đĩa:][đường_dẫn][tên_tệp] [/tham_số]

Tất cả các tham số:
  /P          Dừng lại sau mỗi màn hình đầy (Nhấn phím bất kỳ để tiếp tục...).
  /W          Định dạng danh sách rộng (nhiều cột, chỉ hiển thị tên).
  /D          Tương tự /W nhưng sắp xếp theo cột theo chiều dọc.
  /A          Hiển thị tệp theo thuộc tính:
                D  Thư mục                -D  Chỉ tệp (bỏ thư mục)
                R  Chỉ đọc                -R  Bỏ tệp chỉ đọc
                H  Tệp ẩn                 -H  Bỏ tệp ẩn
                S  Tệp hệ thống           -S  Bỏ tệp hệ thống
                A  Sẵn lưu (Archive)      -A  Bỏ tệp sẵn lưu
                Kết hợp: /A:D, /A:-D, /A:DH, /A:-R-S-H, /A:HS...
  /O          Sắp xếp danh sách theo thứ tự:
                N  Theo tên (A → Z)       -N  Theo tên (Z → A)
                S  Theo kích thước (nhỏ→lớn) -S Theo kích thước (lớn→nhỏ)
                E  Theo đuôi tệp (A → Z)   -E  Theo đuôi tệp (Z → A)
                D  Theo ngày (cũ → mới)   -D  Theo ngày (mới → cũ)
                G  Nhóm thư mục trước     -G  Tệp trước, thư mục sau
                Kết hợp: /O:N, /O:-S, /O:D, /O:GN, /O:-S-D...
  /T          Chọn trường thời gian hiển thị hoặc sắp xếp:
                C  Ngày tạo (Creation)
                A  Ngày truy cập cuối (Last Access)
                W  Ngày sửa đổi cuối (Last Written - Mặc định)
  /S          Liệt kê thư mục hiện tại và tất cả các thư mục con đệ quy.
  /B          Định dạng rút gọn (chỉ hiển thị tên tệp/thư mục). Kết hợp /S /B hiển thị đường dẫn đầy đủ.
  /L          Hiển thị tên tệp và thư mục bằng chữ thường.
  /N          Định dạng danh sách dài mới với tên ở bên phải (Mặc định).
  /X          Hiển thị tên ngắn 8.3 kèm tên dài cho các tệp/thư mục.
  /Q          Hiển thị chủ sở hữu của tệp hoặc thư mục.
  /R          Hiển thị luồng dữ liệu thay thế (Alternate Data Streams - NTFS).
  /V          Hiển thị thông tin chi tiết hơn (ngày tạo, ngày truy cập).
  /-C         Bỏ dấu phân cách nghìn trong kích thước tệp (ví dụ 1024 thay vì 1,024).
  /4          Hiển thị năm dưới dạng 4 chữ số (mặc định).

Hỗ trợ dạng viết liền không dấu cách:
  DIR/S, DIR/P, DIR/W, DIR/D, DIR/A, DIR/O, DIR/B, DIR/L, DIR/N, DIR/X, DIR/Q, DIR/R, DIR/V, DIR/-C, DIR/4, DIR/S/B...

Ký tự đại diện (Wildcards):
  DIR *.*        Tất cả các tệp
  DIR *.txt      Tất cả tệp có đuôi .txt
  DIR B??.doc    Tên bắt đầu bằng B + 2 ký tự bất kỳ + .doc
  DIR Test?.txt  Tên Test + 1 ký tự bất kỳ + .txt`,
  },
  cd: {
    name: 'cd',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Hiển thị tên của hoặc thay đổi thư mục hiện tại.',
    syntax: 'CD [/D] [drive:][path]\nCD [..]\nCD [\\|/]',
    detailedHelp: `Hiển thị tên hoặc thay đổi thư mục hiện tại.

Cú pháp:
  cd               Hiển thị đường dẫn thư mục hiện tại.
  cd ..            Di chuyển ra thư mục cha (lên 1 cấp).
  cd \\             Di chuyển về thư mục gốc của ổ đĩa hiện tại (C:\\).
  cd [đường_dẫn]   Di chuyển đến thư mục chỉ định.
  cd /d [ổ_đĩa:]   Chuyển cả ổ đĩa và thư mục.`,
    aliases: ['chdir'],
  },
  cls: {
    name: 'cls',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Xóa toàn bộ nội dung màn hình Terminal.',
    syntax: 'CLS',
    detailedHelp: `Xóa toàn bộ văn bản đang hiển thị trên cửa sổ Terminal và đưa dấu nhắc lệnh về góc trên cùng bên trái.

Cú pháp:
  cls`,
    aliases: ['clear'],
  },
  echo: {
    name: 'echo',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'In nội dung ra màn hình hoặc bật/tắt hiển thị câu lệnh.',
    syntax: 'ECHO [ON | OFF]\nECHO [tin nhắn]\nECHO.',
    detailedHelp: `Hiển thị thông báo hoặc bật/tắt tính năng phản hồi lệnh.

Cú pháp:
  echo [nội_dung]  In văn bản ra màn hình.
  echo off         Tắt hiển thị dòng lệnh khi chạy script.
  echo on          Bật hiển thị dòng lệnh.
  echo.            In một dòng trống xuống hàng.`,
  },
  pause: {
    name: 'pause',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Tạm dừng chương trình, chờ người dùng nhấn phím bất kỳ.',
    syntax: 'PAUSE',
    detailedHelp: `Tạm dừng việc thực thi một tệp bó (.bat) và hiển thị thông báo:
"Press any key to continue . . . (Nhấn phím bất kỳ để tiếp tục...)"`,
  },
  rem: {
    name: 'rem',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Ghi chú trong tệp kịch bản (không thực thi lệnh).',
    syntax: 'REM [ghi_chú]',
    detailedHelp: `Dòng ghi chú (Remark) trong tệp bó hoặc cấu hình. Trình thông dịch sẽ bỏ qua dòng này.`,
  },
  '::': {
    name: '::',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Dòng ghi chú nhanh (tương tự REM, không hiển thị khi chạy).',
    syntax: ':: [ghi_chú]',
    detailedHelp: `Ký hiệu nhãn không hợp lệ được dùng như một ghi chú nhanh trong Windows Batch Script.`,
  },
  ver: {
    name: 'ver',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Hiển thị phiên bản hệ điều hành Windows.',
    syntax: 'VER',
    detailedHelp: `Hiển thị phiên bản Windows đang chạy (ví dụ: Microsoft Windows [Version 10.0.22631.3296]).`,
  },
  winver: {
    name: 'winver',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Mở cửa sổ Thông tin Phiên bản Windows (About Windows) chính thức.',
    syntax: 'WINVER',
    detailedHelp: `Mở cửa sổ đồ họa hiển thị thông tin chi tiết về phiên bản Windows 11, số hiệu bản dựng (OS Build), bản quyền người dùng và logo Microsoft.`,
    aliases: ['winver.exe'],
  },
  vol: {
    name: 'vol',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Hiển thị nhãn và số sê-ri của ổ đĩa.',
    syntax: 'VOL [drive:]',
    detailedHelp: `Hiển thị nhãn âm lượng ổ đĩa (Volume Label) và số sê-ri nếu có.

Cú pháp:
  vol
  vol c:`,
  },
  time: {
    name: 'time',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Hiển thị hoặc đặt lại giờ hệ thống.',
    syntax: 'TIME [/T | thời_gian]',
    detailedHelp: `Hiển thị hoặc đặt giờ hệ thống.

Cú pháp:
  time        Hiển thị giờ hiện tại và nhắc nhập giờ mới.
  time /t     Chỉ hiển thị giờ hiện tại mà không yêu cầu nhập mới.`,
  },
  date: {
    name: 'date',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Hiển thị hoặc đặt lại ngày hệ thống.',
    syntax: 'DATE [/T | ngày]',
    detailedHelp: `Hiển thị hoặc đặt ngày hệ thống.

Cú pháp:
  date        Hiển thị ngày hiện tại và nhắc nhập ngày mới.
  date /t     Chỉ hiển thị ngày hiện tại mà không nhắc nhập mới.`,
  },
  title: {
    name: 'title',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Đặt tiêu đề cho cửa sổ Terminal.',
    syntax: 'TITLE [tiêu_đề_mới]',
    detailedHelp: `Thiết lập tiêu đề hiển thị trên thanh tab/cửa sổ Terminal.

Cú pháp:
  title Quản trị Windows 11`,
  },
  prompt: {
    name: 'prompt',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Thay đổi định dạng dấu nhắc lệnh.',
    syntax: 'PROMPT [văn_bản_hoặc_mã]',
    detailedHelp: `Thay đổi dấu nhắc lệnh của Command Prompt.

Các mã ký tự đặc biệt:
  $P   Thư mục và ổ đĩa hiện tại
  $G   Dấu '>' (lớn hơn)
  $L   Dấu '<' (nhỏ hơn)
  $D   Ngày hiện tại
  $T   Giờ hiện tại
  $V   Phiên bản Windows`,
  },
  color: {
    name: 'color',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Thay đổi màu nền và màu chữ trong cửa sổ CMD (hỗ trợ đầy đủ 256 màu).',
    syntax: 'COLOR [attr]\nCOLOR [mã_chữ]\nCOLOR [mã_nền][mã_chữ]\nCOLOR\nCOLOR /?',
    detailedHelp: `Thiết lập màu nền và màu chữ mặc định của bảng điều khiển Terminal.

Cú pháp:
  COLOR             Khôi phục màu mặc định của hệ thống.
  COLOR /?          Hiển thị trợ giúp và bảng mã màu.
  COLOR X           Chỉ đổi màu chữ (X = mã chữ 0-F).
  COLOR XY          X = mã màu nền, Y = mã màu chữ (viết liền không dấu cách).

Bảng mã màu đầy đủ (16 màu):
  0 = Đen                 8 = Xám đậm
  1 = Xanh dương đậm      9 = Xanh dương sáng
  2 = Xanh lá đậm         A = Xanh lá sáng
  3 = Xanh ngọc đậm       B = Xanh ngọc sáng
  4 = Đỏ đậm              C = Đỏ sáng
  5 = Tím đậm             D = Tím sáng
  6 = Vàng đậm / Nâu      E = Vàng sáng
  7 = Trắng xám           F = Trắng sáng

Tất cả 16 × 16 = 256 cách kết hợp (COLOR 00 đến COLOR FF) đều hợp lệ và hoạt động!
Ví dụ:
  COLOR 0A    Nền Đen, chữ Xanh lá sáng (phổ biến nhất)
  COLOR 02    Nền Đen, chữ Xanh lá đậm
  COLOR 1F    Nền Xanh dương đậm, chữ Trắng sáng
  COLOR 00    Nền Đen, chữ Đen (ẩn chữ)
  COLOR FC    Nền Trắng sáng, chữ Đỏ sáng`,
  },
  hostname: {
    name: 'hostname',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Hiển thị tên máy tính trong mạng cục bộ.',
    syntax: 'HOSTNAME',
    detailedHelp: `In tên định danh máy tính (Host Name) hiện tại.`,
  },
  whoami: {
    name: 'whoami',
    group: 1,
    groupName: 'Lệnh Cơ Bản',
    shortDesc: 'Hiển thị tên người dùng và miền hiện tại.',
    syntax: 'WHOAMI [/USER] [/GROUPS] [/PRIV] [/ALL]',
    detailedHelp: `Hiển thị thông tin người dùng đang đăng nhập vào phiên hiện tại.`,
  },

  // ==========================================
  // NHÓM 2: QUẢN LÝ TỆP & THƯ MỤC (40 LỆNH)
  // ==========================================
  copy: {
    name: 'copy',
    group: 2,
    groupName: 'Quản lý Tệp & Thư mục',
    shortDesc: 'Sao chép một hoặc nhiều tệp từ nguồn đến đích.',
    syntax: 'COPY [/D] [/V] [/N] [/Y | /-Y] [/Z] [/L] [/A | /B] nguồn [/A | /B] [+ nguồn [/A | /B] ...] [đích [/A | /B]]',
    detailedHelp: `Sao chép tệp từ vị trí này sang vị trí khác.

Cú pháp:
  copy [nguồn] [đích]
  copy /y [nguồn] [đích]   Sao chép không hỏi xác nhận ghi đè.
  copy /b [nguồn] [đích]   Sao chép ở chế độ nhị phân.`,
    aliases: ['cp'],
  },
  xcopy: {
    name: 'xcopy',
    group: 2,
    groupName: 'Quản lý Tệp & Thư mục',
    shortDesc: 'Sao chép tệp và cây thư mục nâng cao.',
    syntax: 'XCOPY nguồn [đích] [/A | /M] [/D[:date]] [/P] [/S [/E]] [/V] [/W] [/C] [/I] [/Q] [/F] [/L] [/G] [/H] [/R] [/T] [/U] [/K] [/N] [/O] [/X] [/Y] [/-Y] [/Z] [/B] [/J]',
    detailedHelp: `Sao chép tệp và cấu trúc cây thư mục.

Cú pháp:
  xcopy [nguồn] [đích] [/s] [/e] [/h] [/y]
  /s    Sao chép các thư mục con (trừ thư mục rỗng).
  /e    Sao chép tất cả thư mục con kể cả thư mục rỗng.
  /h    Sao chép cả tệp ẩn và tệp hệ thống.
  /y    Tắt nhắc nhở xác nhận ghi đè tệp đích.`,
  },
  move: {
    name: 'move',
    group: 2,
    groupName: 'Quản lý Tệp & Thư mục',
    shortDesc: 'Di chuyển tệp hoặc đổi tên tệp/thư mục.',
    syntax: 'MOVE [/Y | /-Y] [drive:][path]filename1[,...] destination',
    detailedHelp: `Di chuyển tệp và đổi tên tệp hoặc thư mục.

Cú pháp:
  move [nguồn] [đích]
  move /y [nguồn] [đích]   Di chuyển không hỏi xác nhận khi ghi đè.`,
    aliases: ['mv'],
  },
  del: {
    name: 'del',
    group: 2,
    groupName: 'Quản lý Tệp & Thư mục',
    shortDesc: 'Xóa một hoặc nhiều tệp.',
    syntax: 'DEL [/P] [/F] [/S] [/Q] [/A[[:]attributes]] names',
    detailedHelp: `Xóa một hoặc nhiều tệp được chỉ định.

Cú pháp:
  del [tên_tệp]
  del /f    Bắt buộc xóa các tệp chỉ đọc.
  del /q    Chế độ im lặng (Quiet), không hỏi xác nhận.
  del /s    Xóa các tệp chỉ định từ thư mục hiện tại và tất cả thư mục con.
  del /a    Xóa tệp theo thuộc tính (như tệp ẩn: /a:h).`,
    aliases: ['erase', 'rm'],
  },
  ren: {
    name: 'ren',
    group: 2,
    groupName: 'Quản lý Tệp & Thư mục',
    shortDesc: 'Đổi tên một tệp hoặc thư mục.',
    syntax: 'REN [drive:][path]tên_cũ tên_mới',
    detailedHelp: `Đổi tên tệp hoặc thư mục mà không làm thay đổi vị trí của nó.

Cú pháp:
  ren [tên_cũ] [tên_mới]
  rename [tên_cũ] [tên_mới]`,
    aliases: ['rename'],
  },
  md: {
    name: 'md',
    group: 2,
    groupName: 'Quản lý Tệp & Thư mục',
    shortDesc: 'Tạo một thư mục mới.',
    syntax: 'MD [drive:]path\nMKDIR [drive:]path',
    detailedHelp: `Tạo một thư mục hoặc cấu trúc thư mục con mới.

Cú pháp:
  md [tên_thư_mục]
  mkdir [tên_thư_mục]`,
    aliases: ['mkdir'],
  },
  rd: {
    name: 'rd',
    group: 2,
    groupName: 'Quản lý Tệp & Thư mục',
    shortDesc: 'Xóa một thư mục.',
    syntax: 'RD [/S] [/Q] [drive:]path\nRMDIR [/S] [/Q] [drive:]path',
    detailedHelp: `Xóa thư mục khỏi hệ thống.

Cú pháp:
  rd [thư_mục]       Xóa thư mục (thư mục phải rỗng).
  rd /s [thư_mục]    Xóa thư mục và TẤT CẢ nội dung bên trong.
  rd /s /q [thư_mục] Xóa im lặng toàn bộ cây thư mục không hỏi xác nhận.`,
    aliases: ['rmdir'],
  },
  attrib: {
    name: 'attrib',
    group: 2,
    groupName: 'Quản lý Tệp & Thư mục',
    shortDesc: 'Hiển thị hoặc thay đổi thuộc tính tệp (ẩn, chỉ đọc, hệ thống).',
    syntax: 'ATTRIB [+R | -R] [+A | -A] [+S | -S] [+H | -H] [drive:][path][filename] [/S [/D]]',
    detailedHelp: `Xem hoặc thiết lập thuộc tính tệp.

Cú pháp:
  attrib [tệp]       Xem thuộc tính hiện tại.
  attrib +h [tệp]    Đặt thuộc tính ẨN (Hidden).
  attrib -h [tệp]    Bỏ thuộc tính ẨN.
  attrib +r [tệp]    Đặt thuộc tính Chỉ Đọc (Read-Only).
  attrib -r [tệp]    Bỏ thuộc tính Chỉ Đọc.
  attrib +s [tệp]    Đặt thuộc tính Hệ Thống (System).
  attrib -s [tệp]    Bỏ thuộc tính Hệ Thống.`,
  },
  tree: {
    name: 'tree',
    group: 2,
    groupName: 'Quản lý Tệp & Thư mục',
    shortDesc: 'Hiển thị cấu trúc thư mục dạng cây đồ họa trực quan.',
    syntax: 'TREE [drive:][path] [/F] [/A]',
    detailedHelp: `Hiển thị cấu trúc thư mục theo biểu đồ hình cây.

Cú pháp:
  tree        Hiển thị cây thư mục.
  tree /f     Hiển thị tên các tệp trong mỗi thư mục.
  tree /a     Sử dụng bộ ký tự ASCII thay vì ký tự đồ họa.`,
  },
  type: {
    name: 'type',
    group: 2,
    groupName: 'Quản lý Tệp & Thư mục',
    shortDesc: 'Hiển thị nội dung của một hoặc nhiều tệp văn bản.',
    syntax: 'TYPE [drive:][path]filename',
    detailedHelp: `In trực tiếp nội dung văn bản của tệp ra màn hình Terminal.

Cú pháp:
  type [tên_tệp]
  type Notes.txt`,
    aliases: ['cat'],
  },
  more: {
    name: 'more',
    group: 2,
    groupName: 'Quản lý Tệp & Thư mục',
    shortDesc: 'Hiển thị nội dung tệp theo từng màn hình một.',
    syntax: 'MORE [drive:][path]filename\ncommand | MORE',
    detailedHelp: `Hiển thị nội dung văn bản từng trang một, tạm dừng khi đầy màn hình.`,
  },
  robocopy: {
    name: 'robocopy',
    group: 2,
    groupName: 'Quản lý Tệp & Thư mục',
    shortDesc: 'Công cụ sao chép tệp mạnh mẽ Robust File Copy for Windows.',
    syntax: 'ROBOCOPY nguồn đích [tệp...] [tùy_chọn]',
    detailedHelp: `Sao chép dữ liệu tệp nâng cao với khả năng đồng bộ, giữ nguyên quyền truy cập, nối lại khi ngắt kết nối.`,
  },
  replace: {
    name: 'replace',
    group: 2,
    groupName: 'Quản lý Tệp & Thư mục',
    shortDesc: 'Thay thế các tệp trong thư mục đích bằng tệp nguồn.',
    syntax: 'REPLACE [drive1:][path1]filename [drive2:][path2] [/A] [/P] [/R] [/S] [/U] [/W]',
    detailedHelp: `Thay thế hoặc thêm mới các tệp vào thư mục đích.`,
  },
  mklink: {
    name: 'mklink',
    group: 2,
    groupName: 'Quản lý Tệp & Thư mục',
    shortDesc: 'Tạo liên kết tượng trưng (Symbolic Link), Hardlink hoặc Junction.',
    syntax: 'MKLINK [[/D] | [/H] | [/J]] Liên_kết Mục_tiêu',
    detailedHelp: `Tạo liên kết hệ thống tệp.

Cú pháp:
  mklink [tên] [đích]       Tạo liên kết tượng trưng tệp.
  mklink /d [tên] [đích]    Tạo liên kết tượng trưng thư mục.
  mklink /h [tên] [đích]    Tạo liên kết cứng (Hard link).
  mklink /j [tên] [đích]    Tạo điểm nối thư mục (Junction).`,
  },
  expand: {
    name: 'expand',
    group: 2,
    groupName: 'Quản lý Tệp & Thư mục',
    shortDesc: 'Giải nén một hoặc nhiều tệp nén CAB (.cab).',
    syntax: 'EXPAND [-r] nguồn đích',
    detailedHelp: `Giải nén các tệp nén CAB của Windows.`,
  },

  // ==========================================
  // NHÓM 3: QUẢN LÝ HỆ THỐNG (45 LỆNH)
  // ==========================================
  control: {
    name: 'control',
    group: 3,
    groupName: 'Quản lý Hệ thống',
    shortDesc: 'Mở Bảng Điều khiển (Control Panel) hoặc mở trực tiếp trang cài đặt và applet .cpl.',
    syntax: 'CONTROL [/NAME pageName] [/PAGE pageName] [/APPLET appletName] [/ADMIN] [applet.cpl] [/?]',
    detailedHelp: `Khởi chạy Bảng Điều khiển Windows 11 với đầy đủ tham số và applet.

CÁCH DÙNG CƠ BẢN:
  control                  Mở Bảng Điều khiển chính
  control /?              Hiển thị trợ giúp tham số
  control /admin           Mở với quyền Quản trị viên (Elevated)

MỞ TRANG CỤ THỂ BẰNG /NAME:
  control /name Microsoft.System                      Hệ thống (thông tin máy)
  control /name Microsoft.DateAndTime                 Ngày & Giờ
  control /name Microsoft.RegionAndLanguage           Vùng & Ngôn ngữ
  control /name Microsoft.UserAccounts                Tài khoản người dùng
  control /name Microsoft.DeviceManager               Trình quản lý Thiết bị
  control /name Microsoft.NetworkAndSharingCenter     Mạng & Trung tâm chia sẻ
  control /name Microsoft.Sound                       Âm thanh
  control /name Microsoft.PowerOptions                Tùy chọn Nguồn
  control /name Microsoft.WindowsUpdate               Cập nhật Windows
  control /name Microsoft.Defender                    Bảo mật Windows
  control /name Microsoft.Display                     Hiển thị
  control /name Microsoft.Personalization             Cá nhân hóa
  control /name Microsoft.DefaultPrograms             Chương trình mặc định
  control /name Microsoft.ProgramsAndFeatures         Gỡ cài đặt chương trình
  control /name Microsoft.Firewall                    Tường lửa Windows
  control /name Microsoft.BitLockerDriveEncryption    Mã hóa ổ đĩa BitLocker
  control /name Microsoft.StorageSpaces               Không gian lưu trữ
  control /name Microsoft.Fonts                       Phông chữ
  control /name Microsoft.TextToSpeech                Giọng nói & Text-to-Speech
  control /name Microsoft.Keyboard                    Bàn phím
  control /name Microsoft.Mouse                       Chuột
  control /name Microsoft.PenAndTouch                 Bút & Cảm ứng
  control /name Microsoft.AutoPlay                    Tự động phát
  control /name Microsoft.FolderOptions               Tùy chọn Thư mục
  control /name Microsoft.IndexingOptions             Tùy chọn Lập chỉ mục
  control /name Microsoft.InternetOptions             Tùy chọn Internet
  control /name Microsoft.PhoneAndModem               Điện thoại & Điều giải
  control /name Microsoft.RemoteAppAndDesktopConnections Kết nối từ xa
  control /name Microsoft.SecurityCenter              Trung tâm Bảo mật
  control /name Microsoft.ActionCenter                Trung tâm Hành động
  control /name Microsoft.Troubleshooting             Trợ giúp & Khắc phục sự cố
  control /name Microsoft.WorkFolders                 Thư mục làm việc

MỞ TRỰC TIẾP APPLET .CPL:
  control appwiz.cpl       Gỡ cài đặt chương trình
  control timedate.cpl     Ngày & Giờ
  control desk.cpl         Cài đặt Hiển thị
  control mouse.cpl        Tùy chọn Chuột (main.cpl)
  control mmsys.cpl        Âm thanh
  control powercfg.cpl     Tùy chọn Nguồn
  control ncpa.cpl         Kết nối Mạng
  control firewall.cpl     Tường lửa Windows Defender
  control sysdm.cpl        Thuộc tính Hệ thống
  control inetcpl.cpl      Tùy chọn Internet
  control intl.cpl         Vùng & Ngôn ngữ
  control joy.cpl          Thiết bị trò chơi
  control ks.cpl           Cài đặt máy ảnh
  control telephon.cpl     Điện thoại & Điều giải`,
    aliases: ['control.exe', 'appwiz.cpl', 'timedate.cpl', 'ncpa.cpl', 'sysdm.cpl', 'firewall.cpl'],
  },
  systeminfo: {
    name: 'systeminfo',
    group: 3,
    groupName: 'Quản lý Hệ thống',
    shortDesc: 'Hiển thị thông tin cấu hình chi tiết của hệ điều hành và phần cứng.',
    syntax: 'SYSTEMINFO [/S system [/U username [/P [password]]]] [/FO format]',
    detailedHelp: `Truy vấn và hiển thị thông tin toàn diện về máy tính: Tên HĐH, Phiên bản, Nhà sản xuất, Bộ vi xử lý, RAM, Card mạng, Bản vá Hotfix...`,
  },
  tasklist: {
    name: 'tasklist',
    group: 3,
    groupName: 'Quản lý Hệ thống',
    shortDesc: 'Hiển thị danh sách tất cả các tiến trình (Processes) đang chạy.',
    syntax: 'TASKLIST [/S system [/U username [/P [password]]]] [/M [module] | /SVC | /V] [/FI filter] [/FO format]',
    detailedHelp: `Liệt kê các tác vụ và tiến trình đang thực thi trên hệ thống.

Cú pháp:
  tasklist        Xem danh sách tiến trình, PID, bộ nhớ.
  tasklist /v     Hiển thị thông tin chi tiết (Verbose).
  tasklist /svc   Hiển thị dịch vụ Windows gắn với mỗi tiến trình.`,
  },
  taskkill: {
    name: 'taskkill',
    group: 3,
    groupName: 'Quản lý Hệ thống',
    shortDesc: 'Dừng hoặc buộc kết thúc một tiến trình đang chạy.',
    syntax: 'TASKKILL [/S system [/U username [/P [password]]]] { [/FI filter] [/PID processid | /IM imagename] } [/T] [/F]',
    detailedHelp: `Dừng tiến trình theo số PID hoặc tên ứng dụng.

Cú pháp:
  taskkill /PID [số]   Dừng tiến trình theo PID.
  taskkill /im [tên]   Dừng tiến trình theo tên (vd: notepad.exe).
  taskkill /f          Buộc dừng ngay lập tức (Force).
  taskkill /t          Dừng cả tiến trình con (Tree).`,
  },
  shutdown: {
    name: 'shutdown',
    group: 3,
    groupName: 'Quản lý Hệ thống',
    shortDesc: 'Tắt máy, khởi động lại hoặc đăng xuất người dùng.',
    syntax: 'SHUTDOWN [/i | /l | /s | /sg | /r | /g | /a | /p | /h | /e | /o] [/f] [/m \\\\computer] [/t xxx] [/d [p|u:]xx:yy [/c "comment"]]',
    detailedHelp: `Điều khiển tắt máy và khởi động lại.

Cú pháp:
  shutdown /s          Tắt máy tính (mặc định trễ 30s).
  shutdown /r          Khởi động lại máy tính.
  shutdown /l          Đăng xuất tài khoản hiện tại.
  shutdown /a          Hủy lệnh tắt máy đang đếm ngược.
  shutdown /t [số]     Đặt thời gian trễ trước khi tắt (giây).
  shutdown /p          Tắt máy ngay lập tức không trễ.
  shutdown /o          Khởi động vào Môi trường Phục hồi WinRE.`,
  },
  logoff: {
    name: 'logoff',
    group: 3,
    groupName: 'Quản lý Hệ thống',
    shortDesc: 'Đăng xuất phiên làm việc của người dùng hiện tại.',
    syntax: 'LOGOFF [sessionname | sessionid] [/SERVER:servername] [/V]',
    detailedHelp: `Kết thúc phiên làm việc hiện tại và quay về màn hình đăng nhập.`,
  },
  tskill: {
    name: 'tskill',
    group: 3,
    groupName: 'Quản lý Hệ thống',
    shortDesc: 'Kết thúc tiến trình của phiên người dùng Terminal Server.',
    syntax: 'TSKILL {processid | processname} [/SERVER:servername] [/ID:sessionid | /A] [/V]',
    detailedHelp: `Dừng tiến trình nhanh theo tên hoặc ID.`,
  },
  nbtstat: {
    name: 'nbtstat',
    group: 3,
    groupName: 'Quản lý Hệ thống',
    shortDesc: 'Hiển thị thống kê giao thức NetBIOS qua TCP/IP (NetBT).',
    syntax: 'NBTSTAT [-a RemoteName] [-A IP] [-c] [-n] [-r] [-R] [-s] [-S] [interval]',
    detailedHelp: `Kiểm tra tên NetBIOS và bảng bộ nhớ đệm phân giải tên.`,
  },
  netstat: {
    name: 'netstat',
    group: 3,
    groupName: 'Quản lý Hệ thống',
    shortDesc: 'Hiển thị các kết nối mạng TCP/IP đang hoạt động và cổng lắng nghe.',
    syntax: 'NETSTAT [-a] [-b] [-e] [-f] [-n] [-o] [-p proto] [-r] [-s] [-t] [interval]',
    detailedHelp: `Xem trạng thái kết nối mạng và các cổng đang mở.

Cú pháp:
  netstat          Xem các kết nối đang hoạt động.
  netstat -ano     Hiển thị địa chỉ số + cổng + PID tiến trình sở hữu.
  netstat -r       Hiển thị bảng định tuyến IP.`,
  },
  net: {
    name: 'net',
    group: 3,
    groupName: 'Quản lý Hệ thống',
    shortDesc: 'Quản lý người dùng, nhóm, dịch vụ và tài nguyên chia sẻ.',
    syntax: 'NET [ ACCOUNTS | COMPUTER | CONFIG | CONTINUE | FILE | GROUP | HELP | LOCALGROUP | PAUSE | SESSION | SHARE | START | STOP | TIME | USE | USER | VIEW ]',
    detailedHelp: `Bộ lệnh quản trị hệ thống và mạng nội bộ.

Cú pháp:
  net user             Xem danh sách người dùng.
  net user [tên] [mk]  Thêm hoặc đổi mật khẩu người dùng.
  net localgroup       Quản lý nhóm người dùng cục bộ.
  net start [dịch_vụ]  Khởi động một dịch vụ hệ thống.
  net stop [dịch_vụ]   Dừng một dịch vụ hệ thống.
  net share            Quản lý thư mục chia sẻ mạng.
  net use              Kết nối ổ đĩa mạng.
  net accounts         Xem chính sách mật khẩu và tài khoản.
  net config           Xem cấu hình Workstation / Server.
  net view             Xem danh sách máy tính trong mạng.`,
  },
  wmic: {
    name: 'wmic',
    group: 3,
    groupName: 'Quản lý Hệ thống',
    shortDesc: 'Giao diện dòng lệnh Windows Management Instrumentation (WMI).',
    syntax: 'WMIC [bí_danh] [tùy_chọn] <động_từ> [tham_số]',
    detailedHelp: `Truy vấn phần cứng và phần mềm qua WMI.

Ví dụ:
  wmic cpu get name
  wmic os get version
  wmic bios get version
  wmic diskdrive get model,size
  wmic memorychip get capacity`,
  },
  driverquery: {
    name: 'driverquery',
    group: 3,
    groupName: 'Quản lý Hệ thống',
    shortDesc: 'Liệt kê tất cả trình điều khiển thiết bị (Drivers) đã cài đặt.',
    syntax: 'DRIVERQUERY [/S system [/U username [/P [password]]]] [/FO format] [/NH] [/SI] [/V]',
    detailedHelp: `Xem danh sách driver kèm tên mô-đun, loại driver, ngày tạo.

Cú pháp:
  driverquery
  driverquery /v    Xem chi tiết trạng thái bộ nhớ và tệp .sys.`,
  },
  sc: {
    name: 'sc',
    group: 3,
    groupName: 'Quản lý Hệ thống',
    shortDesc: 'Giao tiếp với Bộ điều khiển Quản lý Dịch vụ (Service Controller).',
    syntax: 'SC [server] [command] [service_name] <option1> <option2>...',
    detailedHelp: `Quản lý dịch vụ Windows ở cấp hệ thống.

Cú pháp:
  sc query           Xem trạng thái các dịch vụ đang chạy.
  sc start [tên]     Khởi động dịch vụ.
  sc stop [tên]      Dừng dịch vụ.
  sc config [tên]    Cấu hình chế độ khởi động (start= auto/demand/disabled).
  sc queryex         Truy vấn chi tiết kèm PID tiến trình.
  sc create [tên]    Tạo dịch vụ mới.
  sc delete [tên]    Xóa dịch vụ khỏi hệ thống.`,
  },
  sfc: {
    name: 'sfc',
    group: 3,
    groupName: 'Quản lý Hệ thống',
    shortDesc: 'Kiểm tra và sửa chữa tính toàn vẹn của tệp hệ thống Windows (System File Checker).',
    syntax: 'SFC [/SCANNOW] [/VERIFYONLY] [/SCANFILE=<file>] [/VERIFYFILE=<file>] [/OFFWINDIR=<dir> /OFFBOOTDIR=<dir>]',
    detailedHelp: `Kiểm tra và sửa chữa các tệp hệ thống Windows được bảo vệ.
  
Cú pháp:
  sfc /scannow       Quét toàn bộ tệp hệ thống và tự động sửa chữa tệp hỏng.
  sfc /verifyonly    Chỉ quét kiểm tra tính toàn vẹn mà không sửa chữa.
  sfc /scanfile=...  Quét và sửa một tệp cụ thể.
  sfc /verifyfile=.. Chỉ kiểm tra tính toàn vẹn của một tệp cụ thể.`,
  },
  dxdiag: {
    name: 'dxdiag',
    group: 3,
    groupName: 'Quản lý Hệ thống',
    shortDesc: 'Công cụ chẩn đoán DirectX (DirectX Diagnostic Tool).',
    syntax: 'DXDIAG [/x outfile.xml] [/t outfile.txt] [/whql:on | /whql:off] [/64bit] [/dontretry]',
    detailedHelp: `Hiển thị báo cáo toàn diện về phần cứng và các thành phần DirectX:
  - Thông tin hệ thống (Hệ điều hành, CPU, RAM, DirectX Version)
  - Thiết bị hiển thị (Card đồ họa GPU, VRAM, Màn hình, HDR)
  - Trình điều khiển (Drivers WDDM 3.1, WHQL Logo'd, DDI)
  - Thiết bị âm thanh (Sound devices, Drivers)
  - Thiết bị nhập (DirectInput / XInput, bàn phím, chuột, gamepad)

Cú pháp:
  dxdiag                 Mở giao diện Công cụ chẩn đoán DirectX và hiển thị báo cáo.
  dxdiag /t [tệp.txt]    Xuất báo cáo chẩn đoán DirectX ra tệp văn bản.
  dxdiag /x [tệp.xml]    Xuất báo cáo định dạng XML.`,
  },

  // ==========================================
  // NHÓM 4: MẠNG & KẾT NỐI (35 LỆNH)
  // ==========================================
  ping: {
    name: 'ping',
    group: 4,
    groupName: 'Mạng & Kết nối',
    shortDesc: 'Kiểm tra khả năng kết nối mạng đến địa chỉ IP hoặc tên miền.',
    syntax: 'PING [-t] [-a] [-n count] [-l size] [-f] [-i TTL] [-v TOS] [-r count] [-s count] [[-j host-list] | [-k host-list]] [-w timeout] [-R] [-S srcaddr] [-c compartment] [-p] [-4] [-6] target_name',
    detailedHelp: `Gửi gói tin ICMP Echo Request để kiểm tra phản hồi từ máy chủ đích.

Cú pháp:
  ping [địa_chỉ]       Gửi 4 gói tin kiểm tra.
  ping -t [địa_chỉ]    Ping liên tục cho đến khi dừng (Ctrl+C).
  ping -n [số] [đích]  Chỉ định số gói tin gửi đi.
  ping -l [bytes]      Chỉ định kích thước gói tin gửi đi.`,
  },
  ipconfig: {
    name: 'ipconfig',
    group: 4,
    groupName: 'Mạng & Kết nối',
    shortDesc: 'Hiển thị và làm mới cấu hình mạng TCP/IP của các adapter.',
    syntax: 'IPCONFIG [/allcompartments] [/? | /all | /renew [adapter] | /release [adapter] | /renew6 [adapter] | /release6 [adapter] | /flushdns | /displaydns | /registerdns | /showclassid adapter | /setclassid adapter [classid] | /showclassid6 adapter | /setclassid6 adapter [classid] ]',
    detailedHelp: `Xem và quản lý thông tin IP mạng.

Cú pháp:
  ipconfig             Xem IP, Subnet Mask, Default Gateway.
  ipconfig /all        Xem toàn bộ: MAC Address, DHCP Server, DNS...
  ipconfig /release    Giải phóng địa chỉ IP được cấp phát từ DHCP.
  ipconfig /renew      Xin cấp mới địa chỉ IP từ DHCP Server.
  ipconfig /flushdns   Xóa sạch bộ nhớ đệm phân giải tên miền DNS.
  ipconfig /displaydns Xem danh sách các bản ghi DNS đang cache.`,
  },
  tracert: {
    name: 'tracert',
    group: 4,
    groupName: 'Mạng & Kết nối',
    shortDesc: 'Theo dõi lộ trình (Trace Route) của gói tin đến máy chủ đích.',
    syntax: 'TRACERT [-d] [-h maximum_hops] [-j host-list] [-w timeout] [-R] [-S srcaddr] [-4] [-6] target_name',
    detailedHelp: `Xác định đường đi và độ trễ qua từng router trung gian.

Cú pháp:
  tracert [địa_chỉ]
  tracert -d [địa_chỉ]   Không phân giải ngược tên miền (chạy nhanh hơn).`,
  },
  pathping: {
    name: 'pathping',
    group: 4,
    groupName: 'Mạng & Kết nối',
    shortDesc: 'Kết hợp ping và tracert để phân tích tỷ lệ mất gói tin trên từng chặng.',
    syntax: 'PATHPING [-g host-list] [-h maximum_hops] [-i address] [-n] [-p period] [-q num_queries] [-w timeout] [-4] [-6] target_name',
    detailedHelp: `Theo dõi lộ trình và đo lường tổn thất gói tin mạng chi tiết.`,
  },
  nslookup: {
    name: 'nslookup',
    group: 4,
    groupName: 'Mạng & Kết nối',
    shortDesc: 'Truy vấn máy chủ DNS để tìm địa chỉ IP hoặc bản ghi tên miền.',
    syntax: 'NSLOOKUP [-option] [host-to-find | - [server]]',
    detailedHelp: `Tra cứu DNS trực tiếp.

Cú pháp:
  nslookup [tên_miền]
  nslookup -type=a [tên_miền]
  nslookup -type=mx [tên_miền]`,
  },
  arp: {
    name: 'arp',
    group: 4,
    groupName: 'Mạng & Kết nối',
    shortDesc: 'Hiển thị và sửa đổi bảng ánh xạ địa chỉ IP sang MAC (Address Resolution Protocol).',
    syntax: 'ARP -s inet_addr eth_addr [if_addr]\nARP -d inet_addr [if_addr]\nARP -a [inet_addr] [-N if_addr] [-v]',
    detailedHelp: `Quản lý bảng ARP cục bộ.

Cú pháp:
  arp -a    Xem danh sách ánh xạ IP <-> MAC Address.
  arp -d    Xóa toàn bộ bộ nhớ đệm bảng ARP.`,
  },
  route: {
    name: 'route',
    group: 4,
    groupName: 'Mạng & Kết nối',
    shortDesc: 'Thao tác và hiển thị bảng định tuyến mạng IP.',
    syntax: 'ROUTE [-f] [-p] [-4|-6] command [destination] [MASK netmask] [gateway] [METRIC metric] [IF interface]',
    detailedHelp: `Quản lý bảng định tuyến tĩnh của Windows.

Cú pháp:
  route print      Xem bảng định tuyến hiện tại.
  route add        Thêm tuyến đường mới.
  route delete     Xóa tuyến đường đã định cấu hình.`,
  },
  netsh: {
    name: 'netsh',
    group: 4,
    groupName: 'Mạng & Kết nối',
    shortDesc: 'Công cụ cấu hình mạng nâng cao Network Shell.',
    syntax: 'NETSH [-a AliasFile] [-c Context] [-r RemoteMachine] [-u [DomainName\\]UserName] [-p Password | *] [{Cmd | -f ScriptFile}]',
    detailedHelp: `Cấu hình giao diện mạng, Wi-Fi, tường lửa, TCP/IP.

Ví dụ:
  netsh wlan show networks   Xem các mạng Wi-Fi xung quanh.
  netsh wlan show profiles   Xem các hồ sơ Wi-Fi đã lưu mật khẩu.
  netsh interface show interface  Xem danh sách card mạng.`,
  },
  ftp: {
    name: 'ftp',
    group: 4,
    groupName: 'Mạng & Kết nối',
    shortDesc: 'Truyền tệp đến và đi từ máy chủ FTP.',
    syntax: 'FTP [-v] [-d] [-i] [-n] [-g] [-s:filename] [-a] [-A] [-x:sendbuffer] [-r:recvbuffer] [-b:asyncbuffers] [-w:windowsize] [host]',
    detailedHelp: `Kết nối máy chủ File Transfer Protocol để gửi/nhận tệp.`,
  },
  telnet: {
    name: 'telnet',
    group: 4,
    groupName: 'Mạng & Kết nối',
    shortDesc: 'Kết nối giao tiếp với máy chủ từ xa qua giao thức Telnet.',
    syntax: 'TELNET [host [port]]',
    detailedHelp: `Kiểm tra mở cổng kết nối hoặc điều khiển từ xa qua giao thức Telnet.`,
  },
  tftp: {
    name: 'tftp',
    group: 4,
    groupName: 'Mạng & Kết nối',
    shortDesc: 'Truyền tệp qua giao thức TFTP đơn giản (Trivial File Transfer Protocol).',
    syntax: 'TFTP [-i] host [GET | PUT] source [destination]',
    detailedHelp: `Gửi hoặc nhận tệp qua giao thức TFTP không xác thực.`,
  },
  bitsadmin: {
    name: 'bitsadmin',
    group: 4,
    groupName: 'Mạng & Kết nối',
    shortDesc: 'Quản lý các tác vụ truyền tệp nền BITS (Background Intelligent Transfer Service).',
    syntax: 'BITSADMIN [/RAWRETURN] [/WRAP | /NOWRAP] command',
    detailedHelp: `Tạo, giám sát và điều khiển việc tải tệp nền qua BITS.`,
  },
  certutil: {
    name: 'certutil',
    group: 4,
    groupName: 'Mạng & Kết nối',
    shortDesc: 'Công cụ cấu hình và quản lý dịch vụ chứng chỉ bảo mật (Certificate Utility).',
    syntax: 'CertUtil [Options] [DumpString | Certificate | CRL | CertificateRequest | Key]',
    detailedHelp: `Xem, xác minh chứng chỉ SSL hoặc xóa bộ nhớ đệm chứng chỉ:
  certutil -urlcache * delete`,
  },

  // ==========================================
  // NHÓM 5: LỆNH NỘI BỘ & BÍ MẬT (50 LỆNH)
  // ==========================================
  deltree: {
    name: 'deltree',
    group: 5,
    groupName: 'Lệnh Nội bộ & Bí mật',
    shortDesc: 'Xóa thư mục và toàn bộ cấu trúc tệp/thư mục con (di sản MS-DOS).',
    syntax: 'DELTREE [/Y] [drive:]path',
    detailedHelp: `Lệnh xóa cây thư mục triệt để từ MS-DOS, xóa ngay lập tức mọi thứ bên trong thư mục.`,
  },
  reagentc: {
    name: 'reagentc',
    group: 5,
    groupName: 'Lệnh Nội bộ & Bí mật',
    shortDesc: 'Công cụ cấu hình Môi trường Phục hồi Windows (WinRE - Windows Recovery Environment).',
    syntax: 'REAGENTC [/info | /enable | /disable | /boottore | /setreimage | /setosimage | /setbootshell]',
    detailedHelp: `Quản lý phân vùng phục hồi Windows RE.

Cú pháp:
  reagentc /info       Xem trạng thái kích hoạt và vị trí file Winre.wim.
  reagentc /enable     Bật môi trường phục hồi WinRE.
  reagentc /boottore   Cấu hình lần khởi động tiếp theo vào thẳng WinRE.`,
  },
  takeown: {
    name: 'takeown',
    group: 5,
    groupName: 'Lệnh Nội bộ & Bí mật',
    shortDesc: 'Chiếm quyền sở hữu tệp hoặc thư mục (Take Ownership).',
    syntax: 'TAKEOWN [/S system [/U username [/P [password]]]] /F filename [/A] [/R [/D prompt]]',
    detailedHelp: `Chiếm quyền sở hữu từ TrustedInstaller hoặc tài khoản khác để có toàn quyền quản trị.

Cú pháp:
  takeown /f [tệp_hoặc_thư_mục]
  takeown /f [thư_mục] /r    Chiếm quyền đệ quy toàn bộ thư mục con.`,
  },
  icacls: {
    name: 'icacls',
    group: 5,
    groupName: 'Lệnh Nội bộ & Bí mật',
    shortDesc: 'Hiển thị, sửa đổi, sao lưu hoặc khôi phục danh sách điều khiển truy cập (ACL) của tệp/thư mục.',
    syntax: 'ICACLS name /grant[:r] User:perm [/deny User:perm] [/remove[:g|:d]] [/setintegritylevel Level] [/inheritance:e|d|r]',
    detailedHelp: `Phân quyền tệp nâng cao trong hệ thống NTFS.

Cú pháp:
  icacls [tệp] /grant Administrator:F   Cấp toàn quyền (Full Control).
  icacls [tệp] /deny User:W             Từ chối quyền ghi.
  icacls [tệp] /reset                   Khôi phục quyền mặc định.`,
  },
  bcdedit: {
    name: 'bcdedit',
    group: 5,
    groupName: 'Lệnh Nội bộ & Bí mật',
    shortDesc: 'Công cụ chỉnh sửa Dữ liệu Cấu hình Khởi động Windows (Boot Configuration Data).',
    syntax: 'BCDEDIT [/store <filename>] [command] [parameters]',
    detailedHelp: `Quản lý cấu hình nạp hệ điều hành (Boot loader, Safe Mode, Timeout).

Cú pháp:
  bcdedit /enum    Xem danh sách các mục khởi động (Windows Boot Manager / Loader).
  bcdedit /set     Đặt tham số khởi động.
  bcdedit /copy    Sao chép một mục nạp khởi động.`,
  },
  fsutil: {
    name: 'fsutil',
    group: 5,
    groupName: 'Lệnh Nội bộ & Bí mật',
    shortDesc: 'Công cụ hệ thống tệp cấp thấp File System Utility.',
    syntax: 'FSUTIL [8dot3name | behavior | dirty | file | fsinfo | hardlink | objectid | quota | repair | reparsepoint | resource | sparse | tiering | transaction | usn | volume | wim]',
    detailedHelp: `Thao tác trực tiếp với phân vùng NTFS và các thuộc tính chuyên sâu.

Ví dụ:
  fsutil fsinfo drives             Xem danh sách ổ đĩa.
  fsutil fsinfo volumeinfo C:      Xem thông số volume NTFS.
  fsutil file createnew test.dat 1048576  Tạo tệp rỗng đúng 1MB.
  fsutil dirty query C:            Kiểm tra cờ bẩn của ổ đĩa.`,
  },
  wevtutil: {
    name: 'wevtutil',
    group: 5,
    groupName: 'Lệnh Nội bộ & Bí mật',
    shortDesc: 'Công cụ quản lý Nhật ký Sự kiện Windows Event Log.',
    syntax: 'WEVTUTIL [{el | enum-logs | gl | get-log | sl | set-log | ep | enum-publishers | gp | get-publisher | im | install-manifest | um | uninstall-manifest | qe | query-events | gli | get-loginfo | cl | clear-log | al | archive-log}]',
    detailedHelp: `Xem và xuất nhật ký sự kiện hệ thống.

Cú pháp:
  wevtutil el           Xem danh sách các kênh log (Application, System, Security...).
  wevtutil qe System    Truy vấn sự kiện từ kênh System.
  wevtutil cl System    Xóa sạch log System.`,
  },
  schtasks: {
    name: 'schtasks',
    group: 5,
    groupName: 'Lệnh Nội bộ & Bí mật',
    shortDesc: 'Lập lịch và quản lý các tác vụ tự động chạy (Task Scheduler).',
    syntax: 'SCHTASKS [/parameter [arguments]]',
    detailedHelp: `Quản lý các tác vụ định kỳ của Windows.

Cú pháp:
  schtasks /query     Xem danh sách các tác vụ đã lên lịch.
  schtasks /create    Tạo tác vụ mới với lịch chạy (Daily, Weekly...).
  schtasks /delete    Xóa tác vụ theo tên.
  schtasks /run       Chạy ngay một tác vụ đã tạo.`,
  },
  reg: {
    name: 'reg',
    group: 5,
    groupName: 'Lệnh Nội bộ & Bí mật',
    shortDesc: 'Công cụ chỉnh sửa Cơ sở Đăng ký Windows Registry.',
    syntax: 'REG [QUERY | ADD | DELETE | COPY | SAVE | RESTORE | LOAD | UNLOAD | COMPARE | EXPORT | IMPORT | FLAGS]',
    detailedHelp: `Truy vấn và thay đổi khóa Registry dòng lệnh.

Cú pháp:
  reg query [đường_dẫn]    Đọc giá trị của khóa Registry (HKLM, HKCU...).
  reg add [khóa] /v [tên] /t [kiểu] /d [dữ_liệu]  Thêm giá trị.
  reg delete [khóa] /f     Xóa khóa Registry.
  reg export [khóa] [tệp]  Xuất Registry ra tệp .reg.
  reg import [tệp.reg]     Nhập tệp .reg vào hệ thống.`,
  },
  pnputil: {
    name: 'pnputil',
    group: 5,
    groupName: 'Lệnh Nội bộ & Bí mật',
    shortDesc: 'Công cụ quản lý gói trình điều khiển Plug and Play (PnP Utility).',
    syntax: 'PNPUTIL [/add-driver <*.inf> | /delete-driver <oem#.inf> | /export-driver <oem#.inf> | /enum-drivers | /enum-devices | /restart-device]',
    detailedHelp: `Cài đặt, gỡ bỏ và liệt kê các gói driver bên thứ ba (.inf).

Cú pháp:
  pnputil /enum-drivers   Liệt kê tất cả driver đã cài đặt (oem*.inf).
  pnputil /add-driver     Cài đặt driver mới từ tệp .inf.`,
  },

  // ==========================================
  // NHÓM 6: LỆNH NÂNG CAO & CHUYÊN GIA (40 LỆNH)
  // ==========================================
  chkdsk: {
    name: 'chkdsk',
    group: 6,
    groupName: 'Lệnh Nâng cao & Chuyên gia',
    shortDesc: 'Kiểm tra ổ đĩa và hiển thị báo cáo trạng thái lỗi hệ thống tệp.',
    syntax: 'CHKDSK [volume[[path]filename]]] [/F] [/V] [/R] [/X] [/I] [/C] [/L[:size]] [/B] [/scan] [/spotfix]',
    detailedHelp: `Quét và sửa chữa lỗi cấu trúc ổ cứng.

Cú pháp:
  chkdsk [ổ:]       Quét kiểm tra không sửa đổi.
  chkdsk /f [ổ:]    Tự động sửa chữa các lỗi hệ thống tệp tìm thấy.
  chkdsk /r [ổ:]    Định vị các sector hỏng và phục hồi thông tin có thể đọc được.`,
  },
  defrag: {
    name: 'defrag',
    group: 6,
    groupName: 'Lệnh Nâng cao & Chuyên gia',
    shortDesc: 'Tối ưu hóa và chống phân mảnh dữ liệu trên ổ đĩa.',
    syntax: 'DEFRAG <volumes> | /C | /E <volumes> [/H] [/M | [/U] [/V]] [/X] | [/T]',
    detailedHelp: `Chống phân mảnh ổ cứng và thực hiện lệnh TRIM cho ổ SSD.

Cú pháp:
  defrag C:         Tối ưu ổ C:
  defrag /c         Thực hiện tối ưu trên tất cả các ổ đĩa.
  defrag /o         Tự động phát hiện loại ổ đĩa và tối ưu phù hợp.`,
  },
  compact: {
    name: 'compact',
    group: 6,
    groupName: 'Lệnh Nâng cao & Chuyên gia',
    shortDesc: 'Hiển thị hoặc thay đổi trạng thái nén tệp trên phân vùng NTFS.',
    syntax: 'COMPACT [/C | /U] [/S[:dir]] [/A] [/I] [/F] [/Q] [/EXE[:algorithm]] [/CompactOS[:query|always|never]] [filename [...]]',
    detailedHelp: `Nén tệp NTFS để tiết kiệm dung lượng ổ đĩa.

Cú pháp:
  compact              Xem tỷ lệ nén thư mục hiện tại.
  compact /c [tệp/thư_mục] Nén tệp hoặc thư mục chỉ định.
  compact /u [tệp/thư_mục] Giải nén tệp hoặc thư mục.`,
  },
  cipher: {
    name: 'cipher',
    group: 6,
    groupName: 'Lệnh Nâng cao & Chuyên gia',
    shortDesc: 'Hiển thị hoặc thay đổi mã hóa tệp/thư mục trên phân vùng NTFS (EFS).',
    syntax: 'CIPHER [/E | /D | /C] [/S:dir] [/A] [/I] [/F] [/Q] [/H] [/K] [/R:filename] [/W:directory] [filename [...]]',
    detailedHelp: `Quản lý mã hóa EFS (Encrypting File System).

Cú pháp:
  cipher /e [tệp]   Mã hóa tệp hoặc thư mục.
  cipher /d [tệp]   Giải mã tệp hoặc thư mục.
  cipher /k         Tạo khóa mã hóa mới.
  cipher /w:C:\\dir  Xóa an toàn vùng trống (Wipe free space).`,
  },
  diskpart: {
    name: 'diskpart',
    group: 6,
    groupName: 'Lệnh Nâng cao & Chuyên gia',
    shortDesc: 'Công cụ quản lý phân vùng ổ đĩa Disk Partition Utility.',
    syntax: 'DISKPART [/s script_file]',
    detailedHelp: `Quản lý đĩa, phân vùng, volume, định dạng, gán ký tự ổ đĩa ở cấp phần cứng.`,
  },
  format: {
    name: 'format',
    group: 6,
    groupName: 'Lệnh Nâng cao & Chuyên gia',
    shortDesc: 'Định dạng một đĩa để sử dụng với Windows.',
    syntax: 'FORMAT volume [/FS:file-system] [/V:label] [/Q] [/L[:state]] [/A:size] [/C] [/I:state] [/X] [/P:passes]',
    detailedHelp: `Định dạng lại phân vùng ổ đĩa (Xóa toàn bộ dữ liệu).

Cú pháp:
  format [ổ:]
  format [ổ:] /q         Định dạng nhanh (Quick Format).
  format [ổ:] /fs:NTFS   Định dạng theo hệ thống tệp NTFS.`,
  },
  convert: {
    name: 'convert',
    group: 6,
    groupName: 'Lệnh Nâng cao & Chuyên gia',
    shortDesc: 'Chuyển đổi volume FAT hoặc FAT32 sang NTFS mà không mất dữ liệu.',
    syntax: 'CONVERT volume /FS:NTFS [/V] [/CvtArea:filename] [/NoSecurity] [/X]',
    detailedHelp: `Nâng cấp hệ thống tệp từ FAT32 sang NTFS an toàn.`,
  },
  label: {
    name: 'label',
    group: 6,
    groupName: 'Lệnh Nâng cao & Chuyên gia',
    shortDesc: 'Tạo, thay đổi hoặc xóa nhãn volume của ổ đĩa.',
    syntax: 'LABEL [drive:][label]',
    detailedHelp: `Đặt tên hiển thị (Volume Label) cho ổ đĩa:
  label C: Windows11`,
  },
  mountvol: {
    name: 'mountvol',
    group: 6,
    groupName: 'Lệnh Nâng cao & Chuyên gia',
    shortDesc: 'Tạo, xóa hoặc liệt kê điểm gắn kết volume (Volume Mount Point).',
    syntax: 'MOUNTVOL [drive:]path VolumeName\nMOUNTVOL [drive:]path /D\nMOUNTVOL [drive:]path /L\nMOUNTVOL [drive:]path /P\nMOUNTVOL /R\nMOUNTVOL /N\nMOUNTVOL /E',
    detailedHelp: `Quản lý kết nối các phân vùng mà không cần gán ký tự ổ đĩa.`,
  },
  subst: {
    name: 'subst',
    group: 6,
    groupName: 'Lệnh Nâng cao & Chuyên gia',
    shortDesc: 'Gán một ký tự ổ đĩa ảo cho một đường dẫn thư mục.',
    syntax: 'SUBST [drive1: [drive2:]path]\nSUBST drive1: /D',
    detailedHelp: `Tạo ổ đĩa ảo ánh xạ trực tiếp đến một thư mục.

Cú pháp:
  subst Z: C:\\Users\\User\\Documents   Tạo ổ Z: trỏ tới Documents.
  subst Z: /d                           Xóa ánh xạ ổ Z:.`,
  },
  ftype: {
    name: 'ftype',
    group: 6,
    groupName: 'Lệnh Nâng cao & Chuyên gia',
    shortDesc: 'Hiển thị hoặc sửa đổi loại tệp được dùng trong liên kết đuôi tệp.',
    syntax: 'FTYPE [fileType[=[openCommandString]]]',
    detailedHelp: `Xem và đặt chương trình mặc định mở loại tệp hệ thống.`,
  },
  assoc: {
    name: 'assoc',
    group: 6,
    groupName: 'Lệnh Nâng cao & Chuyên gia',
    shortDesc: 'Hiển thị hoặc sửa đổi liên kết phần mở rộng tên tệp (.txt, .exe...).',
    syntax: 'ASSOC [.ext[=[fileType]]]',
    detailedHelp: `Xem liên kết phần mở rộng tệp với loại ứng dụng xử lý.

Ví dụ:
  assoc .txt
  assoc .exe`,
  },
  set: {
    name: 'set',
    group: 6,
    groupName: 'Lệnh Nâng cao & Chuyên gia',
    shortDesc: 'Hiển thị, đặt hoặc xóa các biến môi trường trong phiên hiện tại.',
    syntax: 'SET [variable=[string]]\nSET /A expression\nSET /P variable=[promptString]',
    detailedHelp: `Quản lý biến môi trường và tính toán số học.

Cú pháp:
  set                  Xem toàn bộ danh sách biến môi trường.
  set VAR=value        Gán giá trị cho biến VAR.
  set /a 5+10*2        Tính toán biểu thức số học ngay lập tức.`,
  },
  setx: {
    name: 'setx',
    group: 6,
    groupName: 'Lệnh Nâng cao & Chuyên gia',
    shortDesc: 'Tạo hoặc sửa đổi các biến môi trường vĩnh viễn trong Registry.',
    syntax: 'SETX [/M] variable value',
    detailedHelp: `Đặt biến môi trường lưu trữ vĩnh viễn trên máy tính.

Cú pháp:
  setx MY_VAR "Hello"
  setx PATH "%PATH%;C:\\MyTools" /M`,
  },
  mode: {
    name: 'mode',
    group: 6,
    groupName: 'Lệnh Nâng cao & Chuyên gia',
    shortDesc: 'Cấu hình các thiết bị hệ thống, kích thước cửa sổ Terminal (cột, dòng).',
    syntax: 'MODE [device] [/STATUS]\nMODE CON[:] [COLS=c] [LINES=n]',
    detailedHelp: `Cấu hình kích thước bộ đệm màn hình và cổng giao tiếp.

Ví dụ:
  mode con cols=100 lines=30`,
  },

  // ==========================================
  // NHÓM 7: LỆNH ĐỘC NHẤT DỰ ÁN (5 LỆNH)
  // ==========================================
  'install-app': {
    name: 'install-app',
    group: 7,
    groupName: 'Lệnh Độc nhất Dự án',
    shortDesc: 'Tạo ứng dụng HTML trực tiếp từ dòng lệnh → tự động cài vào hệ thống.',
    syntax: 'INSTALL-APP [tên_ứng_dụng]',
    detailedHelp: `Tạo ứng dụng HTML/Web trực tiếp từ dòng lệnh Terminal và tự động cài đặt vào hệ sinh thái ứng dụng Windows 11.

Cú pháp:
  install-app [tên_ứng_dụng]

Ví dụ:
  install-app MyAwesomeTool`,
  },
  winfetch: {
    name: 'winfetch',
    group: 7,
    groupName: 'Lệnh Độc nhất Dự án',
    shortDesc: 'Hiển thị thông tin hệ thống đẹp mắt với biểu tượng Windows bằng ký tự ASCII.',
    syntax: 'WINFETCH',
    detailedHelp: `Hiển thị bảng thông số hệ thống Windows 11 bao gồm OS, Host, Kernel, Uptime, Packages, Shell, Resolution, DE, WM, CPU, GPU, Memory với logo Windows nghệ thuật.`,
  },
  neofetch: {
    name: 'neofetch',
    group: 7,
    groupName: 'Lệnh Độc nhất Dự án',
    shortDesc: 'Phiên bản tương tự winfetch (tương thích cho người dùng Linux).',
    syntax: 'NEOFETCH',
    detailedHelp: `Hiển thị thông tin hệ thống dạng neofetch cổ điển với logo nghệ thuật ASCII.`,
  },
  defltr: {
    name: 'defltr',
    group: 7,
    groupName: 'Lệnh Độc nhất Dự án',
    shortDesc: 'Xóa thư mục — tên viết tắt nội bộ "Delete Folder" (giữ cho tương thích dự án).',
    syntax: 'DEFLTR [đường_dẫn_thư_mục]',
    detailedHelp: `Lệnh nội bộ đặc biệt viết tắt của Delete Folder. Xóa sạch thư mục chỉ định và các tệp bên trong.

Cú pháp:
  defltr [tên_thư_mục]`,
  },
  'recover-system': {
    name: 'recover-system',
    group: 7,
    groupName: 'Lệnh Độc nhất Dự án',
    shortDesc: 'Khôi phục toàn bộ hệ thống về trạng thái trước khi bị lỗi/xóa tệp hệ thống.',
    syntax: 'RECOVER-SYSTEM',
    detailedHelp: `Khôi phục toàn bộ các tệp hệ thống bị hỏng hoặc bị xóa, làm sạch trạng thái lỗi và khôi phục điểm sao lưu an toàn của Windows 11.`,
  },
};

// Help indexer
export function getHelpForCommand(cmdName: string): CommandDoc | null {
  const clean = cmdName.toLowerCase().trim();
  if (COMMAND_REGISTRY[clean]) {
    return COMMAND_REGISTRY[clean];
  }
  for (const doc of Object.values(COMMAND_REGISTRY)) {
    if (doc.aliases && doc.aliases.includes(clean)) {
      return doc;
    }
  }
  return null;
}
