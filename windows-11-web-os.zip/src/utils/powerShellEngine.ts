import type React from 'react';
import { FileSystemItem } from '../types';
import { CmdContext, TerminalOutputLine, resolvePath, WINDOWS_COLOR_MAP, executeDirCommand } from './cmdBatchEngine';
import { generateDxDiagReportText } from '../components/Apps/DxDiagDialog';
import { parseControlCommand, CONTROL_HELP_TEXT } from './controlPanelData';

export interface PowerShellContext extends CmdContext {
  psVars: Record<string, any>;
  setPsVars: React.Dispatch<React.SetStateAction<Record<string, any>>>;
  psHistory: string[];
  setPsHistory: React.Dispatch<React.SetStateAction<string[]>>;
}

// Windows Registry Database
export const WINDOWS_REGISTRY: Record<string, Record<string, any>> = {
  'hklm:\\software\\microsoft\\windows nt\\currentversion': {
    DisplayVersion: '23H2',
    ProductName: 'Windows 11 Pro',
    CurrentBuild: '22631',
    CurrentBuildNumber: '22631',
    UBR: 3296,
    ReleaseId: '2009',
    EditionID: 'Professional',
    CompositionEditionID: 'Enterprise',
    RegisteredOwner: 'User',
    RegisteredOrganization: '',
    InstallationType: 'Client',
    SystemRoot: 'C:\\Windows',
    PathName: 'C:\\Windows',
    ProductId: '00330-80000-00000-AAOEM',
    BuildLab: '22621.ni_release.220506-1250',
    BuildLabEx: '22621.1.amd64fre.ni_release.220506-1250',
    SoftwareType: 'System',
    CurrentMajorVersionNumber: 10,
    CurrentMinorVersionNumber: 0,
    CurrentVersion: '6.3',
  },
  'hklm:\\hardware\\description\\system\\centralprocessor\\0': {
    ProcessorNameString: 'AMD Ryzen 9 7950X 16-Core Processor',
    Identifier: 'AMD64 Family 25 Model 97 Stepping 2',
    '~MHz': 4500,
    VendorIdentifier: 'AuthenticAMD',
  },
  'hklm:\\system\\currentcontrolset\\control\\computername\\computername': {
    ComputerName: 'DESKTOP-WIN11-OS',
  },
  'hklm:\\software\\microsoft\\windows\\currentversion': {
    ProgramFilesDir: 'C:\\Program Files',
    CommonFilesDir: 'C:\\Program Files\\Common Files',
    DevicePath: 'C:\\Windows\\inf',
  },
  'hkcu:\\control panel\\desktop': {
    Wallpaper: 'C:\\Windows\\Web\\Wallpaper\\Windows\\img0.jpg',
    ScreenSaveActive: '0',
  },
  'hkcu:\\software\\microsoft\\windows\\currentversion\\explorer': {
    ShellState: '24 00 00 00 3c 28 00 00',
  },
};

export function normalizeRegistryPath(pathStr: string): string {
  let p = pathStr.trim().replace(/^["']|["']$/g, '');
  p = p.replace(/^microsoft\.powershell\.core\\registry::/i, '');
  p = p.replace(/^registry::/i, '');
  p = p.replace(/^hkey_local_machine\\?/i, 'hklm:\\');
  p = p.replace(/^hkey_current_user\\?/i, 'hkcu:\\');
  p = p.replace(/^hkey_classes_root\\?/i, 'hkcr:\\');
  p = p.replace(/^hkey_users\\?/i, 'hku:\\');
  p = p.replace(/^hkey_current_config\\?/i, 'hkcc:\\');
  p = p.replace(/^hklm:(?!\\)/i, 'hklm:\\');
  p = p.replace(/^hkcu:(?!\\)/i, 'hkcu:\\');
  p = p.replace(/\\+$/, '');
  return p.toLowerCase();
}

export function getRegistryKeyData(pathStr: string): { data: Record<string, any>; normalizedPath: string } | null {
  const norm = normalizeRegistryPath(pathStr);
  if (WINDOWS_REGISTRY[norm]) {
    return { data: WINDOWS_REGISTRY[norm], normalizedPath: norm };
  }
  for (const [k, v] of Object.entries(WINDOWS_REGISTRY)) {
    if (k.toLowerCase() === norm || k.toLowerCase().replace(/\\/g, '/') === norm.replace(/\\/g, '/')) {
      return { data: v, normalizedPath: k };
    }
  }
  return null;
}

// Windows 11 PowerShell Version Table Data & Formatters
export const PS_VERSION_TABLE_MAP: Record<string, any> = {
  PSVersion: '5.1.22621.2506',
  PSEdition: 'Desktop',
  PSCompatibleVersions: ['1.0', '2.0', '3.0', '4.0', '5.0', '5.1.22621.2506'],
  BuildVersion: '10.0.22621.2506',
  CLRVersion: '4.0.30319.42000',
  WSManStackVersion: '3.0',
  PSRemotingProtocolVersion: '2.3',
  SerializationVersion: '1.1.0.1',
};

export function formatPSVersionTable(): string {
  const colWidth = 31;
  const lines = [
    '',
    'Name'.padEnd(colWidth) + 'Value',
    '----'.padEnd(colWidth) + '-----',
    'PSVersion'.padEnd(colWidth) + '5.1.22621.2506',
    'PSEdition'.padEnd(colWidth) + 'Desktop',
    'PSCompatibleVersions'.padEnd(colWidth) + '{1.0, 2.0, 3.0, 4.0...}',
    'BuildVersion'.padEnd(colWidth) + '10.0.22621.2506',
    'CLRVersion'.padEnd(colWidth) + '4.0.30319.42000',
    'WSManStackVersion'.padEnd(colWidth) + '3.0',
    'PSRemotingProtocolVersion'.padEnd(colWidth) + '2.3',
    'SerializationVersion'.padEnd(colWidth) + '1.1.0.1',
    '',
  ];
  return lines.join('\n');
}

export function formatPSVersionList(): string {
  return [
    '',
    'Key   : PSVersion',
    'Value : 5.1.22621.2506',
    '',
    'Key   : PSEdition',
    'Value : Desktop',
    '',
    'Key   : PSCompatibleVersions',
    'Value : {1.0, 2.0, 3.0, 4.0, 5.0, 5.1.22621.2506}',
    '',
    'Key   : BuildVersion',
    'Value : 10.0.22621.2506',
    '',
    'Key   : CLRVersion',
    'Value : 4.0.30319.42000',
    '',
    'Key   : WSManStackVersion',
    'Value : 3.0',
    '',
    'Key   : PSRemotingProtocolVersion',
    'Value : 2.3',
    '',
    'Key   : SerializationVersion',
    'Value : 1.1.0.1',
    '',
  ].join('\n');
}

export function handlePSVersionTableAccess(propPath?: string): string {
  if (!propPath) return formatPSVersionTable();

  const clean = propPath.trim().toLowerCase();

  if (clean === 'psversion') {
    return 'Major  Minor  Build  Revision\n-----  -----  -----  --------\n5      1      22621  2506';
  }
  if (clean === 'psversion.major') return '5';
  if (clean === 'psversion.minor') return '1';
  if (clean === 'psversion.build') return '22621';
  if (clean === 'psversion.revision') return '2506';
  if (clean === 'psversion.tostring()' || clean === 'psversion.tostring') return '5.1.22621.2506';

  if (clean === 'psedition') {
    return 'Desktop';
  }
  if (clean === 'pscompatibleversions') {
    return 'Major  Minor  Build  Revision\n-----  -----  -----  --------\n1      0      -1     -1\n2      0      -1     -1\n3      0      -1     -1\n4      0      -1     -1\n5      0      -1     -1\n5      1      22621  2506';
  }
  if (clean === 'buildversion') {
    return 'Major  Minor  Build  Revision\n-----  -----  -----  --------\n10     0      22621  2506';
  }
  if (clean === 'clrversion') {
    return 'Major  Minor  Build  Revision\n-----  -----  -----  --------\n4      0      30319  42000';
  }
  if (clean === 'wsmanstackversion') {
    return 'Major  Minor  Build  Revision\n-----  -----  -----  --------\n3      0      -1     -1';
  }
  if (clean === 'psremotingprotocolversion') {
    return 'Major  Minor  Build  Revision\n-----  -----  -----  --------\n2      3      -1     -1';
  }
  if (clean === 'serializationversion') {
    return 'Major  Minor  Build  Revision\n-----  -----  -----  --------\n1      1      0      1';
  }
  if (clean === 'keys') {
    return 'PSVersion\nPSEdition\nPSCompatibleVersions\nBuildVersion\nCLRVersion\nWSManStackVersion\nPSRemotingProtocolVersion\nSerializationVersion';
  }
  if (clean === 'values') {
    return '5.1.22621.2506\nDesktop\n{1.0, 2.0, 3.0, 4.0, 5.0, 5.1.22621.2506}\n10.0.22621.2506\n4.0.30319.42000\n3.0\n2.3\n1.1.0.1';
  }
  if (clean === 'count') {
    return '8';
  }

  return formatPSVersionTable();
}

export function executePowerShellCommand(
  cmdStr: string,
  ctx: CmdContext,
  psVars: Record<string, any>,
  setPsVars: React.Dispatch<React.SetStateAction<Record<string, any>>>,
  psHistory: string[],
  setPsHistory: React.Dispatch<React.SetStateAction<string[]>>
): TerminalOutputLine[] {
  let trimmed = cmdStr.trim();
  if (!trimmed) return [];

  const output: TerminalOutputLine[] = [];

  // 0. Unwrap powershell / powershell.exe / pwsh CLI prefixes
  // e.g. powershell (Get-ItemProperty -Path "HKLM:\...").DisplayVersion
  // e.g. powershell "(Get-ItemProperty -Path 'HKLM:\...').DisplayVersion"
  // e.g. powershell -Command "..."
  const psPrefixMatch = trimmed.match(/^(?:powershell(?:\.exe)?|pwsh(?:\.exe)?)\s*(.*)$/i);
  if (psPrefixMatch) {
    let sub = psPrefixMatch[1].trim();
    if (!sub) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: 'Windows PowerShell\nCopyright (C) Microsoft Corporation. All rights reserved.\n\nInstall the latest PowerShell for new features and improvements! https://aka.ms/PSWindows',
      });
      return output;
    }
    // Strip flags like -Command / -c / -NoProfile / -ExecutionPolicy Bypass / -EncodedCommand
    sub = sub.replace(/^-(?:command|c)\s+/i, '');
    sub = sub.replace(/^-(?:noprofile|ep\s+bypass|executionpolicy\s+bypass)\s+/i, '');
    sub = sub.trim();
    if ((sub.startsWith('"') && sub.endsWith('"')) || (sub.startsWith("'") && sub.endsWith("'"))) {
      sub = sub.substring(1, sub.length - 1).trim();
    }
    if (sub.startsWith('{') && sub.endsWith('}')) {
      sub = sub.substring(1, sub.length - 1).trim();
    }
    if (sub) {
      trimmed = sub;
    }
  }

  // 1. Pipeline Processing (e.g. Get-ItemProperty ... | Select-Object -ExpandProperty DisplayVersion, or $PSVersionTable | ft)
  if (trimmed.includes('|')) {
    const pipeParts = trimmed.split('|').map((s) => s.trim());
    const firstStage = pipeParts[0];
    const secondStage = pipeParts[1] || '';

    // Handle $PSVersionTable pipeline
    if (firstStage.toLowerCase() === '$psversiontable' || firstStage.toLowerCase() === 'get-variable psversiontable' || firstStage.toLowerCase() === 'gv psversiontable') {
      const stage2Tokens = secondStage.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || [];
      const stage2Cmd = stage2Tokens[0]?.toLowerCase() || '';
      const stage2Args = stage2Tokens.slice(1).map((a) => a.replace(/^["']|["']$/g, ''));

      if (stage2Cmd === 'format-list' || stage2Cmd === 'fl') {
        output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: formatPSVersionList() });
        return output;
      }
      if (stage2Cmd === 'format-table' || stage2Cmd === 'ft' || stage2Cmd === 'out-string') {
        output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: formatPSVersionTable() });
        return output;
      }
      if (stage2Cmd === 'select-object' || stage2Cmd === 'select') {
        const expIdx = stage2Args.findIndex((a) => a.toLowerCase() === '-expandproperty' || a.toLowerCase() === '-expand');
        const prop = expIdx !== -1 && expIdx + 1 < stage2Args.length ? stage2Args[expIdx + 1] : stage2Args.find((a) => !a.startsWith('-')) || '';
        if (prop) {
          output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: handlePSVersionTableAccess(prop) });
          return output;
        }
        output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: formatPSVersionTable() });
        return output;
      }
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: formatPSVersionTable() });
      return output;
    }

    const stage1Tokens = firstStage.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || [];
    const stage1Cmd = stage1Tokens[0]?.toLowerCase() || '';
    const stage1Args = stage1Tokens.slice(1).map((a) => a.replace(/^["']|["']$/g, ''));

    if (stage1Cmd === 'get-itemproperty' || stage1Cmd === 'gp' || stage1Cmd === 'get-itempropertyvalue' || stage1Cmd === 'gpv') {
      const pIdx = stage1Args.findIndex((a) => a.toLowerCase() === '-path' || a.toLowerCase() === '-literalpath');
      let rawPath = pIdx !== -1 && pIdx + 1 < stage1Args.length ? stage1Args[pIdx + 1] : stage1Args.find((a) => !a.startsWith('-')) || '';
      if (!rawPath) rawPath = 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion';
      const reg = getRegistryKeyData(rawPath);

      const stage2Tokens = secondStage.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || [];
      const stage2Cmd = stage2Tokens[0]?.toLowerCase() || '';
      const stage2Args = stage2Tokens.slice(1).map((a) => a.replace(/^["']|["']$/g, ''));

      if (stage2Cmd === 'select-object' || stage2Cmd === 'select') {
        const expIdx = stage2Args.findIndex((a) => a.toLowerCase() === '-expandproperty' || a.toLowerCase() === '-expand');
        let prop = expIdx !== -1 && expIdx + 1 < stage2Args.length ? stage2Args[expIdx + 1] : stage2Args.find((a) => !a.startsWith('-')) || 'DisplayVersion';
        if (reg) {
          const found = Object.entries(reg.data).find(([k]) => k.toLowerCase() === prop.toLowerCase());
          if (found) {
            output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: String(found[1]) });
            return output;
          }
        }
        if (prop.toLowerCase() === 'displayversion') {
          output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: '23H2' });
          return output;
        }
      }
    }
  }

  // 2. Evaluate Parenthesized Expressions and Member Access:
  // e.g. (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").DisplayVersion
  // e.g. (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").DisplayVersion
  // e.g. (gp "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").DisplayVersion
  // e.g. (Get-Date).Year
  // e.g. (Get-Process explorer).Id
  const parenMatch = trimmed.match(/^\(([\s\S]+?)\)(?:\.([a-zA-Z0-9_]+))?$/);
  if (parenMatch) {
    const innerExpr = parenMatch[1].trim();
    const targetProp = parenMatch[2]; // e.g. "DisplayVersion"

    if (innerExpr.toLowerCase() === '$psversiontable' || innerExpr.toLowerCase() === 'get-variable psversiontable' || innerExpr.toLowerCase() === 'gv psversiontable') {
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: handlePSVersionTableAccess(targetProp) });
      return output;
    }

    const innerTokens = innerExpr.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || [];
    const innerCmd = innerTokens[0]?.toLowerCase() || '';
    const innerArgs = innerTokens.slice(1).map((a) => a.replace(/^["']|["']$/g, ''));

    // Check if inner is registry command
    if (innerCmd === 'get-itemproperty' || innerCmd === 'gp' || innerCmd === 'get-itempropertyvalue' || innerCmd === 'gpv' || innerCmd === 'get-item' || innerCmd === 'gi') {
      const pIdx = innerArgs.findIndex((a) => a.toLowerCase() === '-path' || a.toLowerCase() === '-literalpath');
      let rawPath = pIdx !== -1 && pIdx + 1 < innerArgs.length ? innerArgs[pIdx + 1] : innerArgs.find((a) => !a.startsWith('-')) || '';
      if (!rawPath) rawPath = 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion';

      const propIdx = innerArgs.findIndex((a) => a.toLowerCase() === '-name' || a.toLowerCase() === '-property');
      const paramProp = propIdx !== -1 && propIdx + 1 < innerArgs.length ? innerArgs[propIdx + 1] : null;
      const desiredProp = targetProp || paramProp;

      const reg = getRegistryKeyData(rawPath);

      if (reg) {
        if (desiredProp) {
          const propEntry = Object.entries(reg.data).find(
            ([k]) => k.toLowerCase() === desiredProp.toLowerCase()
          );
          if (propEntry !== undefined) {
            output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: String(propEntry[1]) });
            return output;
          }
          if (desiredProp.toLowerCase() === 'displayversion') {
            output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: '23H2' });
            return output;
          }
        } else {
          const lines: string[] = [];
          Object.entries(reg.data).forEach(([k, v]) => {
            lines.push(`${k.padEnd(25)} : ${v}`);
          });
          lines.push(`${'PSPath'.padEnd(25)} : Microsoft.PowerShell.Core\\Registry::HKEY_LOCAL_MACHINE\\${rawPath.replace(/^hklm:\\?/i, '')}`);
          lines.push(`${'PSParentPath'.padEnd(25)} : Microsoft.PowerShell.Core\\Registry::HKEY_LOCAL_MACHINE`);
          lines.push(`${'PSChildName'.padEnd(25)} : CurrentVersion`);
          lines.push(`${'PSDrive'.padEnd(25)} : HKLM`);
          lines.push(`${'PSProvider'.padEnd(25)} : Microsoft.PowerShell.Core\\Registry`);
          output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: lines.join('\n') });
          return output;
        }
      } else if (desiredProp && desiredProp.toLowerCase() === 'displayversion') {
        output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: '23H2' });
        return output;
      }
    }

    // Check if inner is Get-Date
    if (innerCmd === 'get-date') {
      const now = new Date();
      if (targetProp) {
        const pLower = targetProp.toLowerCase();
        if (pLower === 'year') output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: String(now.getFullYear()) });
        else if (pLower === 'month') output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: String(now.getMonth() + 1) });
        else if (pLower === 'day') output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: String(now.getDate()) });
        else if (pLower === 'hour') output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: String(now.getHours()) });
        else if (pLower === 'minute') output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: String(now.getMinutes()) });
        else output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: now.toLocaleString('vi-VN') });
        return output;
      }
    }

    // Check if inner is Get-ComputerInfo
    if (innerCmd === 'get-computerinfo') {
      if (targetProp) {
        const pLower = targetProp.toLowerCase();
        if (pLower.includes('version')) output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: '23H2' });
        else if (pLower.includes('product')) output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: 'Windows 11 Pro' });
        else if (pLower.includes('name')) output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: 'DESKTOP-WIN11-OS' });
        else output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: '23H2' });
        return output;
      }
    }

    // Evaluate arithmetic/parenthesized code
    try {
      const sanitized = innerExpr.replace(/\[math\]::/gi, 'Math.');
      const evaluated = Function(`'use strict'; return (${sanitized})`)();
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: String(evaluated) });
      return output;
    } catch {
      // Execute inner command directly if not matched
      const subRes = executePowerShellCommand(innerExpr, ctx, psVars, setPsVars, psHistory, setPsHistory);
      if (subRes.length > 0) {
        return subRes;
      }
    }
  }

  // 1. Variable Assignment (e.g. $a = 10, $name = "Windows", $list = 1,2,3,4,5, $env:MYVAR = "123")
  const varAssignMatch = trimmed.match(/^\$([a-zA-Z0-9_:]+)\s*=\s*(.*)$/);
  if (varAssignMatch) {
    const varName = varAssignMatch[1];
    const rawVal = varAssignMatch[2].trim();

    if (varName.toLowerCase() === 'psversiontable') {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'error',
        text: `Cannot overwrite variable PSVersionTable because it is read-only or constant.\nAt line:1 char:1\n+ ${trimmed}\n+ ${'~'.repeat(trimmed.length)}\n    + CategoryInfo          : WriteError: (PSVersionTable:String) [], SessionStateUnauthorizedAccessException\n    + FullyQualifiedErrorId : VariableNotWritable`,
      });
      return output;
    }

    if (varName.toLowerCase().startsWith('env:')) {
      const envKey = varName.substring(4).toUpperCase();
      const cleanVal = rawVal.replace(/^["']|["']$/g, '');
      ctx.setEnvVars((prev) => ({ ...prev, [envKey]: cleanVal }));
      return output;
    }

    // Evaluate expressions or literals
    let parsedVal: any = rawVal;
    if (rawVal.startsWith('"') && rawVal.endsWith('"')) {
      parsedVal = rawVal.substring(1, rawVal.length - 1);
    } else if (rawVal.startsWith("'") && rawVal.endsWith("'")) {
      parsedVal = rawVal.substring(1, rawVal.length - 1);
    } else if (!isNaN(Number(rawVal))) {
      parsedVal = Number(rawVal);
    } else if (rawVal.includes(',')) {
      parsedVal = rawVal.split(',').map((s) => s.trim().replace(/^["']|["']$/g, ''));
    } else if (rawVal.startsWith('@{') && rawVal.endsWith('}')) {
      // Hash table
      parsedVal = { Type: 'Hashtable', Raw: rawVal };
    } else {
      // Try resolving existing variables
      const resolved = rawVal.replace(/\$([a-zA-Z0-9_]+)/g, (_, n) => {
        return psVars[n] !== undefined ? String(psVars[n]) : '0';
      });
      try {
        const sanitized = resolved.replace(/[^0-9+\-*/%() ~^&|<>\s]/g, '');
        parsedVal = Function(`'use strict'; return (${sanitized || '0'})`)();
      } catch {
        parsedVal = rawVal;
      }
    }

    setPsVars((prev) => ({ ...prev, [varName]: parsedVal }));
    return output;
  }

  // 2. Direct variable output (e.g. $a, $env:USERNAME, $global:var, $PSVersionTable)
  if (trimmed.startsWith('$')) {
    const vName = trimmed.substring(1).trim();

    // Built-in $PSVersionTable (e.g. $PSVersionTable, $PSVersionTable.PSVersion, $PSVersionTable['PSVersion'])
    const psTableMatch = vName.match(/^psversiontable(?:\.([a-zA-Z0-9_().]+)|\[['"]?([a-zA-Z0-9_]+)['"]?\])?$/i);
    if (psTableMatch) {
      const prop = psTableMatch[1] || psTableMatch[2];
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: handlePSVersionTableAccess(prop) });
      return output;
    }

    if (vName.toLowerCase().startsWith('env:')) {
      const envKey = vName.substring(4).toUpperCase();
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: ctx.envVars[envKey] || '' });
      return output;
    }

    // Built-in automatic variables
    const lowerVar = vName.toLowerCase();
    if (lowerVar === 'true') {
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: 'True' });
      return output;
    }
    if (lowerVar === 'false') {
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: 'False' });
      return output;
    }
    if (lowerVar === 'null') {
      return output;
    }
    if (lowerVar === 'pid') {
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: '4184' });
      return output;
    }
    if (lowerVar === 'profile') {
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: 'C:\\Users\\User\\Documents\\WindowsPowerShell\\Microsoft.PowerShell_profile.ps1' });
      return output;
    }
    if (lowerVar === 'home') {
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: 'C:\\Users\\User' });
      return output;
    }
    if (lowerVar === 'host') {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: `Name             : ConsoleHost\nVersion          : 5.1.22621.2506\nInstanceId       : d18e2446-5e58-4723-9588-cfd43ca86e24\nUI               : System.Management.Automation.Internal.Host.InternalHostUserInterface\nCurrentCulture   : en-US\nCurrentUICulture : en-US\nPrivateData      : Microsoft.PowerShell.ConsoleHost+ConsoleColorProxy\nDebuggerEnabled  : True\nIsRunspacePushed : False\nRunspace         : System.Management.Automation.Runspaces.LocalRunspace`,
      });
      return output;
    }

    const val = psVars[vName];
    if (val !== undefined) {
      if (Array.isArray(val)) {
        output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: val.join('\n') });
      } else if (typeof val === 'object') {
        output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: JSON.stringify(val, null, 2) });
      } else {
        output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: String(val) });
      }
      return output;
    }
  }

  // Parse command and arguments
  const rawParts = trimmed.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || [];
  const cmdName = rawParts[0]?.toLowerCase() || '';
  const args = rawParts.slice(1).map((a) => a.replace(/^["']|["']$/g, ''));

  // Helper to extract named parameters (e.g. -Path, -Name, -Force, -Recurse)
  const getParam = (paramName: string): string | null => {
    const idx = args.findIndex((a) => a.toLowerCase() === `-${paramName.toLowerCase()}`);
    if (idx !== -1 && idx + 1 < args.length && !args[idx + 1].startsWith('-')) {
      return args[idx + 1];
    }
    return null;
  };
  const hasFlag = (flagName: string): boolean => {
    return args.some((a) => a.toLowerCase() === `-${flagName.toLowerCase()}`);
  };

  // --- Group P9: TRỢ GIÚP & THÔNG TIN HỆ THỐNG ---
  if (cmdName === 'get-help' || cmdName === 'help' || cmdName === 'man') {
    const target = args[0] ? args[0].replace(/^-name/i, '').trim() : '';
    if (!target) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: `TOPIC
    Windows PowerShell Help System

SHORT DESCRIPTION
    Displays help about Windows PowerShell cmdlets, functions, and concepts.

POPULAR CMDS:
    Get-ChildItem       (gci, ls, dir)     Liệt kê tệp / thư mục
    Get-Content         (cat, gc, type)    Đọc nội dung tệp
    Set-Content         (sc)               Ghi đè nội dung tệp
    New-Item            (ni)               Tạo tệp hoặc thư mục mới
    Remove-Item         (rm, del)          Xóa tệp hoặc thư mục
    Get-Process         (ps, gps)          Xem danh sách tiến trình
    Stop-Process        (kill)             Dừng tiến trình theo PID / Tên
    Get-Service         (gsv)              Trạng thái dịch vụ Windows
    Get-Date                               Xem ngày giờ hệ thống
    Get-ComputerInfo                       Thông tin chi tiết toàn bộ máy
    Test-Connection     (ping)             Kiểm tra kết nối mạng
    Clear-Host          (cls, clear)       Xóa màn hình dòng lệnh
    $PSVersionTable                        Bảng thông tin phiên bản PowerShell

Để xem trợ giúp chi tiết một lệnh:
    Get-Help <Tên-Lệnh>
    Get-Help <Tên-Lệnh> -Full
    Get-Help <Tên-Lệnh> -Examples`,
      });
      return output;
    }

    if (target.toLowerCase() === '$psversiontable' || target.toLowerCase() === 'psversiontable') {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: `NAME
    $PSVersionTable

SYNOPSIS
    Biến tự động (Automatic Variable) chứa bảng thông tin chi tiết về phiên bản Windows PowerShell.

SYNTAX
    $PSVersionTable
    $PSVersionTable.<Tên-Thuộc-Tính>

DESCRIPTION
    Hiển thị bảng 8 thông số phiên bản PowerShell và môi trường Windows 11:
    - PSVersion                 : 5.1.22621.2506
    - PSEdition                 : Desktop
    - PSCompatibleVersions      : {1.0, 2.0, 3.0, 4.0...}
    - BuildVersion              : 10.0.22621.2506
    - CLRVersion                : 4.0.30319.42000
    - WSManStackVersion         : 3.0
    - PSRemotingProtocolVersion : 2.3
    - SerializationVersion      : 1.1.0.1`,
      });
      return output;
    }

    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `NAME
    ${target}

SYNOPSIS
    Cmdlet trợ giúp và quản trị hệ thống Windows PowerShell 5.1 / 7.

SYNTAX
    ${target} [[-Path] <String>] [-Force] [-Recurse] [-Verbose]

DESCRIPTION
    Thực thi tác vụ và trả về kết quả dạng đối tượng pipeline theo tiêu chuẩn PowerShell.`,
    });
    return output;
  }

  if (cmdName === 'get-command' || cmdName === 'gcm') {
    const noun = getParam('noun');
    const verb = getParam('verb');
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `CommandType     Name                                               Version    Source
-----------     ----                                               -------    ------
Cmdlet          Get-ChildItem                                      7.0.0.0    Microsoft.PowerShell.Management
Cmdlet          Get-Content                                        7.0.0.0    Microsoft.PowerShell.Management
Cmdlet          Set-Content                                        7.0.0.0    Microsoft.PowerShell.Management
Cmdlet          New-Item                                           7.0.0.0    Microsoft.PowerShell.Management
Cmdlet          Remove-Item                                        7.0.0.0    Microsoft.PowerShell.Management
Cmdlet          Rename-Item                                        7.0.0.0    Microsoft.PowerShell.Management
Cmdlet          Get-Process                                        7.0.0.0    Microsoft.PowerShell.Management
Cmdlet          Stop-Process                                       7.0.0.0    Microsoft.PowerShell.Management
Cmdlet          Start-Process                                      7.0.0.0    Microsoft.PowerShell.Management
Cmdlet          Get-Service                                        7.0.0.0    Microsoft.PowerShell.Management
Cmdlet          Get-Date                                           7.0.0.0    Microsoft.PowerShell.Utility
Cmdlet          Get-ComputerInfo                                   7.0.0.0    Microsoft.PowerShell.Management
Cmdlet          Test-Connection                                    7.0.0.0    Microsoft.PowerShell.Management
Cmdlet          Resolve-DnsName                                    7.0.0.0    DnsClient
Cmdlet          Get-NetIPAddress                                   7.0.0.0    NetTCPIP
Cmdlet          Get-NetRoute                                       7.0.0.0    NetTCPIP
Cmdlet          Where-Object                                       7.0.0.0    Microsoft.PowerShell.Core
Cmdlet          Select-Object                                      7.0.0.0    Microsoft.PowerShell.Utility
Cmdlet          Sort-Object                                        7.0.0.0    Microsoft.PowerShell.Utility
Cmdlet          ConvertTo-Json                                     7.0.0.0    Microsoft.PowerShell.Utility`,
    });
    return output;
  }

  if (cmdName === 'get-module') {
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `ModuleType Version    PreRelease Name                                ExportedCommands
---------- -------    ---------- ----                                ----------------
Manifest   7.0.0.0               Microsoft.PowerShell.Management     {Add-Content, Clear-Content, Clear-Item...}
Manifest   7.0.0.0               Microsoft.PowerShell.Utility        {Export-Csv, Format-List, Format-Table...}
Manifest   7.0.0.0               Microsoft.PowerShell.Security       {Get-Acl, Set-Acl, Get-Credential...}
Manifest   1.0.0.0               NetTCPIP                            {Get-NetIPAddress, Get-NetRoute...}`,
    });
    return output;
  }

  if (cmdName === 'get-verb') {
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `Verb        Group       Description
----        -----       -----------
Add         Common      Adds a resource to a container
Clear       Common      Removes all the content from a resource
Close       Common      Closes a resource
Copy        Common      Copies a resource to another name or location
Get         Common      Retrieves a resource
New         Common      Creates a resource
Remove      Common      Deletes a resource
Rename      Common      Changes the name of a resource
Set         Common      Replaces data on an existing resource
Start       Lifecycle   Initiates an operation
Stop        Lifecycle   Discontinues an operation
Test        Diagnostic  Verifies the operation or consistency of a resource`,
    });
    return output;
  }

  if (cmdName === 'get-history' || cmdName === 'history' || cmdName === 'h') {
    const list = psHistory.map((cmd, idx) => `  ${idx + 1}  ${cmd}`).join('\n');
    output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: list || '  (Lịch sử lệnh trống)' });
    return output;
  }

  if (cmdName === 'clear-history' || cmdName === 'clh') {
    setPsHistory([]);
    return output;
  }

  // --- Group P1: QUẢN LÝ TỆP & THƯ MỤC ---
  if (cmdName === 'get-childitem' || cmdName === 'gci' || cmdName === 'ls' || cmdName === 'dir' || cmdName.startsWith('dir/')) {
    // If user passed CMD-style switches (e.g. dir /s, dir /b, dir /w, dir /a, dir/s/b)
    const hasCmdSwitches = args.some((a) => a.startsWith('/') || a.startsWith('dir/')) || cmdName.startsWith('dir/');
    if (hasCmdSwitches) {
      const allTokens = [cmdName, ...args];
      const cmdOut = executeDirCommand(allTokens, ctx);
      return cmdOut.map((l) => ({ ...l, id: 'ps-' + l.id }));
    }

    const recurse = hasFlag('recurse') || hasFlag('s');
    const force = hasFlag('force') || hasFlag('a');
    const fileOnly = hasFlag('file');
    const dirOnly = hasFlag('directory');
    const targetPath = getParam('path') || args.find((a) => !a.startsWith('-')) || ctx.currentDir;

    const resolved = resolvePath(targetPath, ctx.currentDir);
    let items = ctx.fileSystem.filter((f) => {
      if (recurse) {
        return f.path.toLowerCase().startsWith(resolved.toLowerCase()) && f.path.toLowerCase() !== resolved.toLowerCase();
      }
      return f.path.toLowerCase().startsWith(resolved.toLowerCase()) && f.path.toLowerCase() !== resolved.toLowerCase();
    });

    // Simple directory items
    const directItems = ctx.getFilesByDirectory(resolved);
    if (!recurse) items = directItems;

    if (fileOnly) items = items.filter((i) => !i.isDirectory);
    if (dirOnly) items = items.filter((i) => i.isDirectory);
    if (!force) items = items.filter((i) => !i.hidden);

    const lines: string[] = [];
    lines.push(`\n    Directory: ${resolved}\n`);
    lines.push('Mode                 LastWriteTime         Length Name');
    lines.push('----                 -------------         ------ ----');

    items.forEach((item) => {
      const mode = item.isDirectory ? 'd-----' : item.isReadOnly ? '-ar---' : '-a----';
      const date = new Date(item.modifiedAt || Date.now());
      const dateStr = date.toLocaleDateString('vi-VN') + '  ' + date.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
      const sizeStr = item.isDirectory ? '' : String(item.size || (item.content?.length || 0));
      lines.push(`${mode.padEnd(20, ' ')} ${dateStr.padEnd(20, ' ')} ${sizeStr.padStart(8, ' ')} ${item.name}`);
    });

    output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: lines.join('\n') });
    return output;
  }

  if (cmdName === 'get-content' || cmdName === 'gc' || cmdName === 'cat' || cmdName === 'type') {
    const raw = hasFlag('raw');
    const tailCount = Number(getParam('tail')) || 0;
    const targetPath = getParam('path') || args.find((a) => !a.startsWith('-')) || '';

    if (!targetPath) {
      output.push({ id: 'ps-err-' + Date.now(), type: 'error', text: 'Get-Content : Không có đường dẫn tệp được chỉ định.' });
      return output;
    }

    const resolved = resolvePath(targetPath, ctx.currentDir);
    const file = ctx.fileSystem.find((f) => f.path.toLowerCase() === resolved.toLowerCase() && !f.isDirectory);

    if (!file) {
      output.push({ id: 'ps-err-' + Date.now(), type: 'error', text: `Get-Content : Không thể tìm thấy tệp '${resolved}'.` });
      return output;
    }

    let text = file.content || '';
    if (tailCount > 0) {
      const lines = text.split('\n');
      text = lines.slice(Math.max(0, lines.length - tailCount)).join('\n');
    }

    output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: text || '(Tệp trống)' });
    return output;
  }

  if (cmdName === 'set-content' || cmdName === 'sc') {
    const targetPath = getParam('path') || args[0] || '';
    const val = getParam('value') || args[1] || '';
    if (!targetPath) {
      output.push({ id: 'ps-err-' + Date.now(), type: 'error', text: 'Set-Content : Thiếu tham số -Path.' });
      return output;
    }
    const resolved = resolvePath(targetPath, ctx.currentDir);
    if (ctx.updateFileContent) {
      ctx.updateFileContent(resolved, val);
    } else {
      ctx.addFile({
        name: resolved.split('\\').pop() || 'file.txt',
        path: resolved,
        isDirectory: false,
        content: val,
        size: val.length,
      });
    }
    return output;
  }

  if (cmdName === 'add-content' || cmdName === 'ac') {
    const targetPath = getParam('path') || args[0] || '';
    const val = getParam('value') || args[1] || '';
    const resolved = resolvePath(targetPath, ctx.currentDir);
    const file = ctx.fileSystem.find((f) => f.path.toLowerCase() === resolved.toLowerCase());
    const newContent = file ? (file.content ? `${file.content}\n${val}` : val) : val;
    if (ctx.updateFileContent) {
      ctx.updateFileContent(resolved, newContent);
    }
    return output;
  }

  if (cmdName === 'clear-content' || cmdName === 'clc') {
    const targetPath = getParam('path') || args[0] || '';
    const resolved = resolvePath(targetPath, ctx.currentDir);
    if (ctx.updateFileContent) {
      ctx.updateFileContent(resolved, '');
    }
    return output;
  }

  if (cmdName === 'new-item' || cmdName === 'ni') {
    const itemType = (getParam('itemtype') || (hasFlag('directory') ? 'Directory' : 'File')).toLowerCase();
    const targetPath = getParam('path') || getParam('name') || args.find((a) => !a.startsWith('-')) || 'NewFile.txt';
    const val = getParam('value') || '';
    const resolved = resolvePath(targetPath, ctx.currentDir);
    const name = resolved.split('\\').pop() || targetPath;

    ctx.addFile({
      name,
      path: resolved,
      isDirectory: itemType.startsWith('dir'),
      content: val,
      size: val.length,
    });

    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `    Directory: ${resolvePath('..', resolved)}\n\nMode                 LastWriteTime         Length Name\n----                 -------------         ------ ----\n${itemType.startsWith('dir') ? 'd-----' : '-a----'}              ${new Date().toLocaleDateString('vi-VN')}             ${val.length} ${name}`,
    });
    return output;
  }

  if (cmdName === 'remove-item' || cmdName === 'rm' || cmdName === 'ri' || cmdName === 'del' || cmdName === 'erase') {
    const targetPath = getParam('path') || args.find((a) => !a.startsWith('-')) || '';
    if (!targetPath) {
      output.push({ id: 'ps-err-' + Date.now(), type: 'error', text: 'Remove-Item : Thiếu tham số -Path.' });
      return output;
    }
    const resolved = resolvePath(targetPath, ctx.currentDir);
    const found = ctx.fileSystem.find((f) => f.path.toLowerCase() === resolved.toLowerCase());
    if (found) {
      ctx.deleteFile(found.id, true);
    } else {
      output.push({ id: 'ps-err-' + Date.now(), type: 'error', text: `Remove-Item : Không thể tìm thấy '${resolved}'.` });
    }
    return output;
  }

  if (cmdName === 'copy-item' || cmdName === 'cp' || cmdName === 'cpi' || cmdName === 'copy') {
    const src = getParam('path') || args[0] || '';
    const dest = getParam('destination') || args[1] || '';
    const resolvedSrc = resolvePath(src, ctx.currentDir);
    const resolvedDest = resolvePath(dest, ctx.currentDir);
    const file = ctx.fileSystem.find((f) => f.path.toLowerCase() === resolvedSrc.toLowerCase());
    if (file) {
      const newName = resolvedDest.split('\\').pop() || file.name;
      ctx.addFile({
        name: newName,
        path: resolvedDest.includes('\\') ? resolvedDest : `${ctx.currentDir}\\${newName}`,
        isDirectory: file.isDirectory,
        content: file.content,
        size: file.size,
      });
    }
    return output;
  }

  if (cmdName === 'move-item' || cmdName === 'mv' || cmdName === 'mi' || cmdName === 'move') {
    const src = getParam('path') || args[0] || '';
    const dest = getParam('destination') || args[1] || '';
    const resolvedSrc = resolvePath(src, ctx.currentDir);
    const resolvedDest = resolvePath(dest, ctx.currentDir);
    const file = ctx.fileSystem.find((f) => f.path.toLowerCase() === resolvedSrc.toLowerCase());
    if (file) {
      ctx.deleteFile(file.id, true);
      const newName = resolvedDest.split('\\').pop() || file.name;
      ctx.addFile({
        name: newName,
        path: resolvedDest.includes('\\') ? resolvedDest : `${ctx.currentDir}\\${newName}`,
        isDirectory: file.isDirectory,
        content: file.content,
        size: file.size,
      });
    }
    return output;
  }

  if (cmdName === 'rename-item' || cmdName === 'rni' || cmdName === 'ren') {
    const src = getParam('path') || args[0] || '';
    const newName = getParam('newname') || args[1] || '';
    const resolvedSrc = resolvePath(src, ctx.currentDir);
    if (ctx.renameFile) {
      ctx.renameFile(resolvedSrc, newName);
    }
    return output;
  }

  if (cmdName === 'get-itemproperty' || cmdName === 'gp') {
    const rawPath = getParam('path') || getParam('literalpath') || args.find((a) => !a.startsWith('-')) || '';
    const propName = getParam('name');

    if (!rawPath) {
      output.push({ id: 'ps-err-' + Date.now(), type: 'error', text: 'Get-ItemProperty : Thiếu tham số -Path.' });
      return output;
    }

    const reg = getRegistryKeyData(rawPath);
    if (reg) {
      if (propName) {
        const found = Object.entries(reg.data).find(([k]) => k.toLowerCase() === propName.toLowerCase());
        if (found) {
          output.push({
            id: 'ps-out-' + Date.now(),
            type: 'output',
            text: `${found[0].padEnd(25)} : ${found[1]}\n${'PSPath'.padEnd(25)} : Microsoft.PowerShell.Core\\Registry::HKEY_LOCAL_MACHINE\\${rawPath.replace(/^hklm:\\?/i, '')}\n${'PSParentPath'.padEnd(25)} : Microsoft.PowerShell.Core\\Registry::HKEY_LOCAL_MACHINE\n${'PSChildName'.padEnd(25)} : CurrentVersion\n${'PSDrive'.padEnd(25)} : HKLM\n${'PSProvider'.padEnd(25)} : Microsoft.PowerShell.Core\\Registry`,
          });
        } else {
          output.push({ id: 'ps-err-' + Date.now(), type: 'error', text: `Get-ItemProperty : Không tìm thấy thuộc tính '${propName}'.` });
        }
        return output;
      }

      const lines: string[] = [];
      Object.entries(reg.data).forEach(([k, v]) => {
        lines.push(`${k.padEnd(25)} : ${v}`);
      });
      lines.push(`${'PSPath'.padEnd(25)} : Microsoft.PowerShell.Core\\Registry::HKEY_LOCAL_MACHINE\\${rawPath.replace(/^hklm:\\?/i, '')}`);
      lines.push(`${'PSParentPath'.padEnd(25)} : Microsoft.PowerShell.Core\\Registry::HKEY_LOCAL_MACHINE`);
      lines.push(`${'PSChildName'.padEnd(25)} : CurrentVersion`);
      lines.push(`${'PSDrive'.padEnd(25)} : HKLM`);
      lines.push(`${'PSProvider'.padEnd(25)} : Microsoft.PowerShell.Core\\Registry`);
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: lines.join('\n') });
      return output;
    }

    // Filesystem path fallback
    const resolved = resolvePath(rawPath, ctx.currentDir);
    const file = ctx.fileSystem.find((f) => f.path.toLowerCase() === resolved.toLowerCase());
    if (file) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: `Mode                : ${file.isDirectory ? 'd-----' : '-a----'}\nLastWriteTime       : ${new Date(file.modifiedAt || Date.now()).toLocaleString('vi-VN')}\nLength              : ${file.size || (file.content?.length || 0)}\nName                : ${file.name}`,
      });
      return output;
    }

    output.push({ id: 'ps-err-' + Date.now(), type: 'error', text: `Get-ItemProperty : Không thể tìm thấy đường dẫn '${rawPath}' vì nó không tồn tại.` });
    return output;
  }

  if (cmdName === 'get-itempropertyvalue' || cmdName === 'gpv') {
    const rawPath = getParam('path') || getParam('literalpath') || args.find((a) => !a.startsWith('-')) || '';
    const propName = getParam('name') || args.filter((a) => !a.startsWith('-'))[1] || '';

    if (!rawPath) {
      output.push({ id: 'ps-err-' + Date.now(), type: 'error', text: 'Get-ItemPropertyValue : Thiếu tham số -Path.' });
      return output;
    }

    const reg = getRegistryKeyData(rawPath);
    if (reg) {
      if (propName) {
        const found = Object.entries(reg.data).find(([k]) => k.toLowerCase() === propName.toLowerCase());
        if (found) {
          output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: String(found[1]) });
        } else {
          output.push({ id: 'ps-err-' + Date.now(), type: 'error', text: `Get-ItemPropertyValue : Không tìm thấy thuộc tính '${propName}'.` });
        }
      } else {
        const firstVal = Object.values(reg.data)[0];
        output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: String(firstVal) });
      }
      return output;
    }

    output.push({ id: 'ps-err-' + Date.now(), type: 'error', text: `Get-ItemPropertyValue : Không thể tìm thấy đường dẫn '${rawPath}'.` });
    return output;
  }

  if (cmdName === 'get-item' || cmdName === 'gi') {
    const rawPath = getParam('path') || args.find((a) => !a.startsWith('-')) || '';
    const reg = getRegistryKeyData(rawPath);
    if (reg) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: `    Hive: HKEY_LOCAL_MACHINE\\${rawPath.replace(/^hklm:\\?/i, '')}\n\nName                           Property\n----                           --------\n${rawPath.split('\\').pop() || 'CurrentVersion'}                 ${Object.keys(reg.data).slice(0, 5).join(', ')}...`,
      });
      return output;
    }

    const resolved = resolvePath(rawPath, ctx.currentDir);
    const file = ctx.fileSystem.find((f) => f.path.toLowerCase() === resolved.toLowerCase());
    if (file) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: `    Directory: ${resolvePath('..', resolved)}\n\nMode                 LastWriteTime         Length Name\n----                 -------------         ------ ----\n${file.isDirectory ? 'd-----' : '-a----'}              ${new Date(file.modifiedAt || Date.now()).toLocaleDateString('vi-VN')}             ${file.size || 0} ${file.name}`,
      });
      return output;
    }
    output.push({ id: 'ps-err-' + Date.now(), type: 'error', text: `Get-Item : Không thể tìm thấy '${rawPath}'.` });
    return output;
  }

  if (cmdName === 'set-itemproperty' || cmdName === 'sp' || cmdName === 'new-itemproperty') {
    const rawPath = getParam('path') || args[0] || '';
    const propName = getParam('name') || args[1] || '';
    const val = getParam('value') || args[2] || '';
    const norm = normalizeRegistryPath(rawPath);
    if (WINDOWS_REGISTRY[norm]) {
      WINDOWS_REGISTRY[norm][propName] = val;
    } else {
      WINDOWS_REGISTRY[norm] = { [propName]: val };
    }
    return output;
  }

  if (cmdName === 'test-path') {
    const targetPath = getParam('path') || args[0] || '';
    if (targetPath.toLowerCase().startsWith('hklm:') || targetPath.toLowerCase().startsWith('hkcu:') || targetPath.toLowerCase().startsWith('registry::')) {
      const reg = getRegistryKeyData(targetPath);
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: reg ? 'True' : 'False' });
      return output;
    }
    const resolved = resolvePath(targetPath, ctx.currentDir);
    const exists = ctx.fileSystem.some((f) => f.path.toLowerCase() === resolved.toLowerCase());
    output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: exists ? 'True' : 'False' });
    return output;
  }

  if (cmdName === 'split-path') {
    const target = getParam('path') || args[0] || ctx.currentDir;
    const leaf = hasFlag('leaf');
    const parent = hasFlag('parent');
    if (leaf) {
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: target.split('\\').pop() || '' });
    } else {
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: resolvePath('..', target) });
    }
    return output;
  }

  if (cmdName === 'resolve-path') {
    const target = args[0] || ctx.currentDir;
    output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: `Path\n----\n${resolvePath(target, ctx.currentDir)}` });
    return output;
  }

  if (cmdName === 'get-location' || cmdName === 'gl' || cmdName === 'pwd') {
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `Path\n----\n${ctx.currentDir}`,
    });
    return output;
  }

  if (cmdName === 'set-location' || cmdName === 'sl' || cmdName === 'cd' || cmdName === 'chdir') {
    const target = getParam('path') || args[0] || 'C:\\Users\\User';
    const resolved = resolvePath(target, ctx.currentDir);
    ctx.setCurrentDir(resolved);
    return output;
  }

  if (cmdName === 'push-location' || cmdName === 'pushd') {
    const target = args[0] || '';
    ctx.setDirStack((prev) => [...prev, ctx.currentDir]);
    if (target) {
      ctx.setCurrentDir(resolvePath(target, ctx.currentDir));
    }
    return output;
  }

  if (cmdName === 'pop-location' || cmdName === 'popd') {
    if (ctx.dirStack.length > 0) {
      const prev = ctx.dirStack[ctx.dirStack.length - 1];
      ctx.setDirStack((s) => s.slice(0, -1));
      ctx.setCurrentDir(prev);
    }
    return output;
  }

  // --- Group P3: TIẾN TRÌNH & DỊCH VỤ ---
  if (cmdName === 'get-process' || cmdName === 'ps' || cmdName === 'gps') {
    const targetName = getParam('name') || args.find((a) => !a.startsWith('-'));
    const rows = [
      { Handles: 612, NPM: 24, PM: 45200, WS: 78900, CPU: '1.24', Id: 1044, ProcessName: 'explorer' },
      { Handles: 380, NPM: 18, PM: 32000, WS: 54100, CPU: '0.45', Id: 2180, ProcessName: 'msedge' },
      { Handles: 210, NPM: 12, PM: 18400, WS: 29300, CPU: '0.12', Id: 3412, ProcessName: 'powershell' },
      { Handles: 195, NPM: 10, PM: 15200, WS: 22100, CPU: '0.08', Id: 4120, ProcessName: 'cmd' },
      { Handles: 145, NPM: 8, PM: 12000, WS: 19800, CPU: '0.02', Id: 5088, ProcessName: 'taskmgr' },
      { Handles: 95, NPM: 6, PM: 8500, WS: 14200, CPU: '0.01', Id: 6192, ProcessName: 'notepad' },
      { Handles: 820, NPM: 40, PM: 92000, WS: 134000, CPU: '2.89', Id: 820, ProcessName: 'System' },
    ];

    let filtered = rows;
    if (targetName) {
      filtered = rows.filter((r) => r.ProcessName.toLowerCase().includes(targetName.toLowerCase()));
    }

    const lines = [' Handles  NPM(K)    PM(K)      WS(K)     CPU(s)     Id  SI ProcessName', ' -------  ------    -----      -----     ------     --  -- -----------'];
    filtered.forEach((r) => {
      lines.push(
        ` ${String(r.Handles).padStart(7)}  ${String(r.NPM).padStart(6)}  ${String(r.PM).padStart(7)}    ${String(r.WS).padStart(7)}     ${r.CPU.padStart(6)}   ${String(r.Id).padStart(4)}   1 ${r.ProcessName}`
      );
    });

    output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: lines.join('\n') });
    return output;
  }

  if (cmdName === 'stop-process' || cmdName === 'kill' || cmdName === 'spps') {
    const targetName = getParam('name') || getParam('id') || args[0] || '';
    output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: `Stop-Process : Đã dừng tiến trình '${targetName}'.` });
    return output;
  }

  if (cmdName === 'start-process' || cmdName === 'start' || cmdName === 'saps') {
    const app = getParam('filepath') || args[0] || 'notepad.exe';
    ctx.openApp(app.replace('.exe', ''));
    return output;
  }

  if (cmdName === 'get-service' || cmdName === 'gsv') {
    const rows = [
      { Status: 'Running', Name: 'wuauserv', DisplayName: 'Windows Update' },
      { Status: 'Running', Name: 'WinDefend', DisplayName: 'Microsoft Defender Antivirus Service' },
      { Status: 'Running', Name: 'Dhcp', DisplayName: 'DHCP Client' },
      { Status: 'Running', Name: 'Dnscache', DisplayName: 'DNS Client' },
      { Status: 'Running', Name: 'LanmanServer', DisplayName: 'Server' },
      { Status: 'Running', Name: 'LanmanWorkstation', DisplayName: 'Workstation' },
      { Status: 'Stopped', Name: 'Spooler', DisplayName: 'Print Spooler' },
      { Status: 'Stopped', Name: 'RemoteRegistry', DisplayName: 'Remote Registry' },
      { Status: 'Running', Name: 'W32Time', DisplayName: 'Windows Time' },
    ];
    const lines = ['Status   Name               DisplayName', '------   ----               -----------'];
    rows.forEach((s) => {
      lines.push(`${s.Status.padEnd(8)} ${s.Name.padEnd(18)} ${s.DisplayName}`);
    });
    output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: lines.join('\n') });
    return output;
  }

  if (cmdName === 'start-service' || cmdName === 'sasv' || cmdName === 'stop-service' || cmdName === 'spsv' || cmdName === 'restart-service') {
    const svc = getParam('name') || args[0] || 'Service';
    output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: `Dịch vụ '${svc}' đã được cập nhật trạng thái.` });
    return output;
  }

  // --- Group P4: THÔNG TIN HỆ THỐNG ---
  if (cmdName === 'get-date') {
    const fmt = getParam('format');
    const now = new Date();
    if (fmt) {
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: now.toLocaleString('vi-VN') });
    } else {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: `\n${now.toLocaleDateString('vi-VN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })} ${now.toLocaleTimeString('vi-VN')}\n`,
      });
    }
    return output;
  }

  if (cmdName === 'get-timezone') {
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `Id                         : SE Asia Standard Time\nDisplayName                : (UTC+07:00) Bangkok, Hanoi, Jakarta\nStandardName               : SE Asia Standard Time\nDaylightName               : SE Asia Daylight Time\nBaseUtcOffset              : 07:00:00\nSupportsDaylightSavingTime : False`,
    });
    return output;
  }

  if (cmdName === 'get-computerinfo') {
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `WindowsCurrentVersion            : 10.0.22631\nWindowsProductName               : Windows 11 Pro\nWindowsVersion                   : 23H2\nCsName                           : DESKTOP-WIN11-OS\nCsManufacturer                   : Microsoft Corporation\nCsModel                          : Virtual Machine Pro\nCsProcessors                     : {Intel(R) Core(TM) i9-14900K CPU @ 3.20GHz}\nCsTotalPhysicalMemory            : 17179869184 (16 GB)\nOsArchitecture                   : 64-bit\nOsLanguage                       : vi-VN\nBiosVersion                      : AMERICAN MEGATRENDS - UEFI 2.80`,
    });
    return output;
  }

  if (cmdName === 'wmic') {
    const rawQuery = args.join(' ').toLowerCase();
    if (rawQuery.startsWith('logicaldisk')) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: 'Caption  FreeSpace     Size          VolumeName\nC:       197775982592  274877906944  Windows11\nD:       490723819520  549755813888  Data',
      });
      return output;
    }
    if (rawQuery.startsWith('diskdrive')) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: 'DeviceID            Model                           Size              Status\n\\\\.\\PHYSICALDRIVE0  NVMe Samsung SSD 990 PRO 2TB    2000396321280     OK',
      });
      return output;
    }
    if (rawQuery.startsWith('cpu')) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: 'Name                                  NumberOfCores  MaxClockSpeed\nAMD Ryzen 9 7950X 16-Core Processor   16             4500',
      });
      return output;
    }
    if (rawQuery.startsWith('os')) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: 'Caption                   Version       BuildNumber\nMicrosoft Windows 11 Pro  10.0.22631    22631',
      });
      return output;
    }
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: 'WMIC1.0 - Windows Management Instrumentation Command-line Utility\n[WMI Object Model Ready]',
    });
    return output;
  }

  if (cmdName === 'get-volume') {
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `DriveLetter FileSystemLabel FileSystem DriveType HealthStatus OperationalStatus SizeRemaining      Size\n----------- --------------- ---------- --------- ------------ ----------------- -------------      ----\nC           Windows11       NTFS       Fixed     Healthy      OK                    184.20 GB 256.00 GB\nD           Data            NTFS       Fixed     Healthy      OK                    468.00 GB 512.00 GB`,
    });
    return output;
  }

  if (cmdName === 'get-disk') {
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `Number Friendly Name                Serial Number                    HealthStatus         OperationalStatus      Total Size Partition\n------ -------------                -------------                    ------------         -----------------      ---------- ---------\n0      NVMe Samsung SSD 990 PRO 2TB S6X4NF0W102948X                 Healthy              Online                    1.82 TB GPT      `,
    });
    return output;
  }

  if (cmdName === 'get-wmiobject' || cmdName === 'gwmi' || cmdName === 'get-ciminstance' || cmdName === 'gcim') {
    const className = (getParam('class') || args[0] || '').toLowerCase();
    if (className.includes('processor') || className.includes('cpu')) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: `Name                          : 13th Gen Intel(R) Core(TM) i9-13900K\nNumberOfCores                 : 8\nNumberOfLogicalProcessors     : 16\nMaxClockSpeed                 : 3200 MHz\nSocketDesignation             : LGA1700`,
      });
    } else if (className.includes('logicaldisk') || className.includes('disk')) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: `DeviceID DriveType FreeSpace(GB) Size(GB) VolumeName\n-------- --------- ------------- -------- ----------\nC:       3         184.2         256.0    WINDOWS11 \nD:       3         412.5         512.0    DATA_DRIVE`,
      });
    } else if (className.includes('physicalmemory') || className.includes('ram')) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: `Capacity    Manufacturer Speed DeviceLocator\n--------    ------------ ----- -------------\n8589934592  Crucial      3200  DIMM 1       \n8589934592  Crucial      3200  DIMM 2       `,
      });
    } else {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: `Caption        : Microsoft Windows 11 Pro\nVersion        : 10.0.22631\nBuildNumber    : 22631\nOSArchitecture : 64-bit\nStatus         : OK`,
      });
    }
    return output;
  }

  if (cmdName === 'get-hotfix') {
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `Source        Description      HotFixID      InstalledBy          InstalledOn\n------        -----------      --------      -----------          -----------\nDESKTOP-WIN11 Security Update  KB5034441     NT AUTHORITY\\SYSTEM  30/08/2026 \nDESKTOP-WIN11 Update           KB5034123     NT AUTHORITY\\SYSTEM  15/08/2026 `,
    });
    return output;
  }

  if (cmdName === 'get-eventlog') {
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `   Index Time          EntryType   Source                 InstanceID Message\n   ----- ----          ---------   ------                 ---------- -------\n    1204 04:30:15      Information Service Control Mgr    1073748864 The Windows Defender service entered the running state.\n    1203 04:29:40      Information Microsoft-Windows-Kern 1          The operating system started at system time.`,
    });
    return output;
  }

  // --- Group P5: MẠNG & KẾT NỐI ---
  if (cmdName === 'test-connection' || cmdName === 'ping') {
    const host = getParam('computername') || getParam('targetname') || args[0] || '127.0.0.1';
    const quiet = hasFlag('quiet');
    if (quiet) {
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: 'True' });
      return output;
    }
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `Source        Destination     IPV4Address      IPV6Address                              Bytes    Time(ms)\n------        -----------     -----------      -----------                              -----    --------\nDESKTOP-WIN11 ${host.padEnd(15)} 127.0.0.1        ::1                                      32       <1      \nDESKTOP-WIN11 ${host.padEnd(15)} 127.0.0.1        ::1                                      32       <1      `,
    });
    return output;
  }

  if (cmdName === 'resolve-dnsname' || cmdName === 'nslookup') {
    const target = getParam('name') || args[0] || 'google.com';
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `Name                                           Type   TTL   Section    IPAddress\n----                                           ----   ---   -------    ---------\n${target.padEnd(46)} A      300   Answer     142.250.190.46\n${target.padEnd(46)} AAAA   300   Answer     2607:f8b0:4004:800::200e`,
    });
    return output;
  }

  if (cmdName === 'get-netipaddress') {
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `IPAddress         : 192.168.1.105\nInterfaceAlias    : Wi-Fi\nAddressFamily     : IPv4\nType              : Unicast\nPrefixLength      : 24\nIPAddress         : 127.0.0.1\nInterfaceAlias    : Loopback Pseudo-Interface 1\nAddressFamily     : IPv4`,
    });
    return output;
  }

  if (cmdName === 'get-netroute') {
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `ifIndex DestinationPrefix                              NextHop                                  RouteMetric\n------- -----------------                              -------                                  -----------\n12      0.0.0.0/0                                      192.168.1.1                              25         \n12      192.168.1.0/24                                 0.0.0.0                                  281        `,
    });
    return output;
  }

  if (cmdName === 'get-netfirewallprofile') {
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `Name    : Domain\nEnabled : True\n\nName    : Private\nEnabled : True\n\nName    : Public\nEnabled : True`,
    });
    return output;
  }

  // --- Group P7: UTILITIES, FORMATTING & PIPELINES ---
  if (cmdName === 'write-host' || cmdName === 'write-output' || cmdName === 'echo') {
    const text = args.join(' ').replace(/-foregroundcolor\s+[a-zA-Z]+/i, '').trim();
    if (text.toLowerCase() === '$psversiontable') {
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: formatPSVersionTable() });
      return output;
    }
    const propMatch = text.match(/^\$psversiontable(?:\.([a-zA-Z0-9_().]+)|\[['"]?([a-zA-Z0-9_]+)['"]?\])$/i);
    if (propMatch) {
      const prop = propMatch[1] || propMatch[2];
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: handlePSVersionTableAccess(prop) });
      return output;
    }
    output.push({ id: 'ps-out-' + Date.now(), type: 'output', text });
    return output;
  }

  if (cmdName === 'get-variable' || cmdName === 'gv') {
    const targetVar = args[0]?.replace(/^[-$]/, '').trim().toLowerCase();
    if (!targetVar) {
      const list = [
        'Name                           Value',
        '----                           -----',
        'PSVersionTable                 {[PSVersion, 5.1.22621.2506], [PSEdition, Desktop], [PSCompatibleVersions, System.Version[]], [BuildVersion, 10.0.22621.2506]...}',
        'PID                            4184',
        'HOME                           C:\\Users\\User',
        'PROFILE                        C:\\Users\\User\\Documents\\WindowsPowerShell\\Microsoft.PowerShell_profile.ps1',
        'True                           True',
        'False                          False',
        'Null                           ',
        'Host                           System.Management.Automation.Internal.Host.InternalHost',
        'MaximumHistoryCount            4096',
        ...Object.entries(psVars).map(([k, v]) => `${k.padEnd(31)}${typeof v === 'object' ? JSON.stringify(v) : String(v)}`),
      ];
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: list.join('\n') });
      return output;
    }

    if (targetVar === 'psversiontable') {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: `Name                           Value\n----                           -----\nPSVersionTable                 {[PSVersion, 5.1.22621.2506], [PSEdition, Desktop], [PSCompatibleVersions, System.Version[]], [BuildVersion, 10.0.22621.2506]...}`,
      });
      return output;
    }

    if (psVars[targetVar] !== undefined) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: `Name                           Value\n----                           -----\n${targetVar.padEnd(31)}${String(psVars[targetVar])}`,
      });
      return output;
    }

    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'error',
      text: `Get-Variable : Cannot find a variable with the name '${targetVar}'.\nAt line:1 char:1\n+ Get-Variable ${targetVar}\n+ ~~~~~~~~~~~~~~~~~~~~~~~~\n    + CategoryInfo          : ObjectNotFound: (${targetVar}:String) [Get-Variable], ItemNotFoundException\n    + FullyQualifiedErrorId : VariableNotFound,Microsoft.PowerShell.Commands.GetVariableCommand`,
    });
    return output;
  }

  if (cmdName === 'new-guid') {
    // Generate UUID
    const uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
    output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: `Guid\n----\n${uuid}` });
    return output;
  }

  if (cmdName === 'get-random') {
    const min = Number(getParam('minimum')) || 1;
    const max = Number(getParam('maximum')) || 100;
    const rnd = Math.floor(Math.random() * (max - min)) + min;
    output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: String(rnd) });
    return output;
  }

  if (cmdName === 'get-psdrive') {
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `Name           Used (GB)     Free (GB) Provider      Root                               CurrentLocation\n----           ---------     --------- --------      ----                               ---------------\nC                  71.80        184.20 FileSystem    C:\\                                      Users\\User\nD                  99.50        412.50 FileSystem    D:\\                                                \nHKCU                                   Registry      HKEY_CURRENT_USER                                  \nHKLM                                   Registry      HKEY_LOCAL_MACHINE                                 \nEnv                                    Environment                                                      \nVariable                               Variable                                                         `,
    });
    return output;
  }

  if (cmdName === 'get-executionpolicy') {
    output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: 'RemoteSigned' });
    return output;
  }

  if (cmdName === 'set-executionpolicy') {
    output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: 'Chính sách thực thi tập lệnh đã được cập nhật thành RemoteSigned.' });
    return output;
  }

  if (cmdName === 'get-culture' || cmdName === 'get-uiculture') {
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `LCID             Name             DisplayName\n----             ----             -----------\n1066             vi-VN            Vietnamese (Vietnam)`,
    });
    return output;
  }

  if (cmdName === 'get-filehash') {
    const target = getParam('path') || args[0] || '';
    const algo = getParam('algorithm') || 'SHA256';
    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: `Algorithm       Hash                                                                   Path\n---------       ----                                                                   ----\n${algo.padEnd(15)} 9F86D081884C7D659A2FEAA0C55AD015A3BF4F1B2B0B822CD15D6C15B0F00A08     ${resolvePath(target, ctx.currentDir)}`,
    });
    return output;
  }

  // --- Project Unique Commands in PS mode ---
  if (cmdName === 'control' || cmdName === 'control.exe' || cmdName.endsWith('.cpl')) {
    const rawArgs = cmdName.endsWith('.cpl') ? [cmdName, ...args] : args;
    const parsed = parseControlCommand(rawArgs);

    if (parsed.isHelp) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: CONTROL_HELP_TEXT,
      });
      return output;
    }

    ctx.openApp('control', {
      page: parsed.page,
      cpl: parsed.cpl,
      isAdmin: parsed.isAdmin,
      windowTitle: parsed.isAdmin
        ? 'Administrator: Control Panel'
        : parsed.targetItem
        ? `${parsed.targetItem.name} - Control Panel`
        : 'Control Panel',
    });

    const targetDesc = parsed.targetItem
      ? `${parsed.targetItem.name} (${parsed.targetItem.canonicalName})`
      : parsed.page || parsed.cpl || 'Bảng Điều khiển chính (Control Panel)';

    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'success',
      text: `Đang mở Bảng Điều khiển: ${targetDesc}${parsed.isAdmin ? ' [Quyền Quản trị viên]' : ''}...`,
    });
    return output;
  }

  if (cmdName === 'winver' || cmdName === 'winver.exe') {
    ctx.openApp('winver');
    return output;
  }

  if (cmdName === 'winfetch' || cmdName === 'neofetch') {
    const banner = [
      '  ████████   ████████     User@DESKTOP-WIN11-OS',
      '  ████████   ████████     ---------------------',
      '  ████████   ████████     OS: Windows 11 Pro x64 23H2',
      '                          Host: Hyper-V Virtual Machine',
      '  ████████   ████████     Kernel: 10.0.22631.3296',
      '  ████████   ████████     Shell: Windows PowerShell 7.0',
      '  ████████   ████████     CPU: Intel Core i9-13900K (16) @ 3.20GHz',
      '  ████████   ████████     Memory: 4120MiB / 16384MiB (25%)',
      '                          Disk (C:): 71.8GB / 256GB (28%)',
    ].join('\n');
    output.push({ id: 'ps-out-' + Date.now(), type: 'ascii', text: banner });
    return output;
  }

  if (cmdName === 'recover-system') {
    if (ctx.clearSystemFailure) ctx.clearSystemFailure();
    output.push({ id: 'ps-out-' + Date.now(), type: 'success', text: '[PowerShell Recovery] Toàn bộ hệ thống đã được phục hồi hoàn chỉnh.' });
    return output;
  }

  if (cmdName === 'defltr') {
    output.push({ id: 'ps-out-' + Date.now(), type: 'success', text: '[DEFLTR] Đã dọn dẹp các tệp tạm và bộ nhớ đệm PowerShell thành công.' });
    return output;
  }

  if (cmdName === 'sfc' || cmdName === 'sfc.exe') {
    if (args.includes('/?') || args.includes('-?') || args.includes('/help') || args.includes('-help')) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: `Microsoft (R) Windows (R) Resource Checker Version 6.0\nSFC [/SCANNOW] [/VERIFYONLY] [/SCANFILE=<file>] [/VERIFYFILE=<file>] [/OFFWINDIR=<dir> /OFFBOOTDIR=<dir>]`,
      });
      return output;
    }

    const sfcResult = [
      'Bắt đầu quá trình quét hệ thống...',
      '',
      'Đang xác minh giai đoạn 1/3...  10%',
      'Đang xác minh giai đoạn 1/3...  30%',
      'Đang xác minh giai đoạn 1/3...  50%',
      'Đang xác minh giai đoạn 1/3...  100%',
      '',
      'Đang xác minh giai đoạn 2/3...  100%',
      '',
      'Đang xác minh giai đoạn 3/3...  100%',
      '',
      '',
      'Kiểm tra 100% hoàn tất.',
      '',
      'Bảo vệ tài nguyên Windows không tìm thấy vi phạm tính toàn vẹn.',
      'Không thực hiện bất kỳ thao tác nào.',
    ].join('\n');

    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: sfcResult,
    });
    return output;
  }

  if (cmdName === 'dxdiag' || cmdName === 'dxdiag.exe' || cmdName === 'get-dxdiag') {
    const reportText = generateDxDiagReportText();
    const tIdx = args.indexOf('/t') !== -1 ? args.indexOf('/t') : (args.indexOf('-t') !== -1 ? args.indexOf('-t') : -1);
    const xIdx = args.indexOf('/x') !== -1 ? args.indexOf('/x') : (args.indexOf('-x') !== -1 ? args.indexOf('-x') : -1);
    const fileArg = tIdx !== -1 ? args[tIdx + 1] : xIdx !== -1 ? args[xIdx + 1] : null;

    if (fileArg) {
      const fileName = fileArg.split('\\').pop() || 'DxDiag.txt';
      const filePath = fileArg.includes('\\') ? fileArg : `${ctx.currentDir}\\${fileName}`;
      ctx.addFile({
        name: fileName,
        path: filePath,
        isDirectory: false,
        content: reportText,
        size: reportText.length,
      });
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'success',
        text: `DirectX Diagnostic Tool: Đã lưu thông tin chẩn đoán thành công vào "${filePath}".`,
      });
      return output;
    }

    // Launch GUI tool
    ctx.openApp('dxdiag');

    output.push({
      id: 'ps-out-' + Date.now(),
      type: 'output',
      text: reportText.trim(),
    });
    return output;
  }

  if (cmdName === 'color') {
    if (args.includes('/?') || args.includes('-?') || args.includes('/help') || args.includes('-help')) {
      output.push({
        id: 'ps-out-' + Date.now(),
        type: 'output',
        text: `Thiết lập màu nền và màu chữ mặc định của bảng điều khiển.

COLOR [attr]

  attr        Chỉ định thuộc tính màu của đầu ra bảng điều khiển

Các thuộc tính màu được chỉ định bởi HAI chữ số thập lục phân -- chữ số
đầu tiên tương ứng với nền; chữ số thứ hai tương ứng với chữ.
Mỗi chữ số có thể là bất kỳ giá trị nào sau đây:

    0 = Đen                 8 = Xám đậm
    1 = Xanh dương đậm      9 = Xanh dương sáng
    2 = Xanh lá đậm         A = Xanh lá sáng
    3 = Xanh ngọc đậm       B = Xanh ngọc sáng
    4 = Đỏ đậm              C = Đỏ sáng
    5 = Tím đậm             D = Tím sáng
    6 = Vàng đậm / Nâu      E = Vàng sáng
    7 = Trắng xám           F = Trắng sáng

Cú pháp:
  COLOR           → Trở về màu mặc định của hệ thống
  COLOR /?        → Hiển thị trợ giúp + bảng mã màu
  COLOR X         → Chỉ đổi màu chữ (X = mã chữ từ 0-F)
  COLOR XY        → X = mã màu nền, Y = mã màu chữ (viết liền không dấu cách)

Tất cả 16 × 16 = 256 cách kết hợp (COLOR 00 đến COLOR FF) đều hợp lệ!
Ví dụ: "COLOR 0A" (chữ xanh lá sáng trên nền đen), "COLOR 1F" (chữ trắng sáng trên nền xanh dương).`,
      });
      return output;
    }

    if (args.length === 0) {
      ctx.setColor?.('#0c0c0c', '#cccccc');
      return output;
    }

    if (args.length > 1) {
      output.push({
        id: 'ps-err-' + Date.now(),
        type: 'error',
        text: 'Cú pháp lệnh COLOR không hợp lệ. Viết liền 2 mã màu không có dấu cách (ví dụ: COLOR 02, COLOR 0A). Gõ "COLOR /?" để xem hướng dẫn.',
      });
      return output;
    }

    const code = args[0].toLowerCase();
    if (code.length === 1 && WINDOWS_COLOR_MAP[code]) {
      ctx.setColor?.('#0c0c0c', WINDOWS_COLOR_MAP[code]);
      return output;
    }

    if (code.length === 2 && WINDOWS_COLOR_MAP[code[0]] && WINDOWS_COLOR_MAP[code[1]]) {
      ctx.setColor?.(WINDOWS_COLOR_MAP[code[0]], WINDOWS_COLOR_MAP[code[1]]);
      return output;
    }

    output.push({
      id: 'ps-err-' + Date.now(),
      type: 'error',
      text: 'Mã màu không hợp lệ. Vui lòng nhập từ 0-9 hoặc A-F (ví dụ: COLOR 0A, COLOR 1F). Gõ "COLOR /?" để xem bảng mã.',
    });
    return output;
  }

  // Expression evaluation or unknown cmdlet
  if (trimmed.startsWith('[') || /^[0-9+\-*/%() .]+$/.test(trimmed)) {
    try {
      const sanitized = trimmed.replace(/\[math\]::/gi, 'Math.').replace(/\[convert\]::/gi, '');
      const evaluated = Function(`'use strict'; return (${sanitized})`)();
      output.push({ id: 'ps-out-' + Date.now(), type: 'output', text: String(evaluated) });
      return output;
    } catch {
      // Pass through
    }
  }

  // Default PowerShell message
  output.push({
    id: 'ps-err-' + Date.now(),
    type: 'error',
    text: `${cmdName} : Thuật ngữ '${cmdName}' không được nhận dạng là tên của cmdlet, hàm, tệp script hoặc chương trình có thể thực thi.\nKiểm tra lại chính tả hoặc sử dụng 'Get-Command' để xem danh sách lệnh có sẵn.`,
  });
  return output;
}
