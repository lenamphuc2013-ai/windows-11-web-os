import { AppDefinition } from '../types';
import { FileSystemItem } from '../types';

export interface AppContextTarget {
  id: string;
  name: string;
  title: string;
  icon: string;
  path: string;
  isHtmlApp: boolean;
  isBuiltIn: boolean;
  isPinned: boolean;
  fileItem: FileSystemItem;
}

const BUILTIN_APP_PATHS: Record<string, string> = {
  explorer: 'C:\\Windows\\explorer.exe',
  edge: 'C:\\Program Files\\Microsoft Edge\\Application\\msedge.exe',
  cmd: 'C:\\Windows\\System32\\cmd.exe',
  powershell: 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe',
  terminal: 'C:\\Windows\\System32\\wt.exe',
  notepad: 'C:\\Windows\\System32\\notepad.exe',
  calc: 'C:\\Windows\\System32\\calc.exe',
  paint: 'C:\\Windows\\System32\\mspaint.exe',
  store: 'C:\\Program Files\\WindowsApps\\Microsoft.WindowsStore.exe',
  copilot: 'C:\\Windows\\System32\\copilot.exe',
  mediaplayer: 'C:\\Program Files\\Windows Media Player\\wmplayer.exe',
  clock: 'C:\\Windows\\System32\\TimeBroker.exe',
  camera: 'C:\\Windows\\System32\\WindowsCamera.exe',
  weather: 'C:\\Windows\\System32\\BingWeather.exe',
  snippingtool: 'C:\\Windows\\System32\\SnippingTool.exe',
  taskmanager: 'C:\\Windows\\System32\\taskmgr.exe',
  photos: 'C:\\Windows\\System32\\PhotosApp.exe',
  settings: 'C:\\Windows\\System32\\SystemSettings.exe',
  security: 'C:\\Windows\\System32\\SecHealthUI.exe',
  voicerecorder: 'C:\\Windows\\System32\\SoundRecorder.exe',
  maps: 'C:\\Windows\\System32\\MapsApp.exe',
  phonelink: 'C:\\Windows\\System32\\PhoneExperienceHost.exe',
  xbox: 'C:\\Program Files\\WindowsApps\\Microsoft.XboxApp.exe',
  winver: 'C:\\Windows\\System32\\winver.exe',
  dxdiag: 'C:\\Windows\\System32\\dxdiag.exe',
  appsfolder: 'C:\\Apps',
};

export function getAppFileItem(
  app: AppDefinition | { id: string; name?: string; title?: string; icon?: string },
  fileSystem: FileSystemItem[]
): FileSystemItem {
  const expectedPath = BUILTIN_APP_PATHS[app.id] || `C:\\Windows\\System32\\${app.id}.exe`;

  // Check if exists in file system
  const found = fileSystem.find(
    (f) => f.path.toLowerCase() === expectedPath.toLowerCase() || f.name.toLowerCase() === `${app.id}.exe`
  );

  if (found) {
    return found;
  }

  // Create virtual system file representation for Properties dialog
  const fileName = expectedPath.substring(expectedPath.lastIndexOf('\\') + 1);
  const appTitle = (app as any).name || (app as any).title || app.id;
  return {
    id: `app-file-${app.id}`,
    name: fileName,
    path: expectedPath,
    isDirectory: false,
    content: `Microsoft Windows Executable Binary [${app.id}]`,
    size: 2457600, // ~2.4 MB
    createdAt: Date.now() - 86400000 * 45,
    modifiedAt: Date.now() - 86400000 * 12,
    icon: app.icon || 'FileCode',
    owner: 'TrustedInstaller',
    isSystem: true,
    isReadOnly: true,
    protectionLevel: 'BẢO VỆ',
    description: `Tệp thực thi ứng dụng Windows 11 (${appTitle})`,
  };
}
