import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  WindowItem,
  FileSystemItem,
  SystemSettings,
  ContextMenuState,
  NotificationItem,
  SnapType,
  AppId,
  BootState,
  SystemFailureState,
  AccessDeniedDialogState,
  FilePropertiesDialogState,
  DefenderScanDialogState,
  DrivePropertiesDialogState,
} from '../types';
import { INITIAL_FILE_SYSTEM, DEFAULT_WALLPAPERS } from '../utils/fileSystem';
import { BUILT_IN_APPS } from '../utils/appRegistry';
import { soundManager } from '../utils/sound';
import { TRANSLATIONS, TranslationDict, LanguageCode, getLanguageFromRegion } from '../utils/i18n';
import { loadLocalData, saveLocalData, deleteLocalData } from '../utils/localPersistence';

interface OSContextType {
  // Windows
  windows: WindowItem[];
  activeWindowId: string | null;
  openApp: (appId: AppId, customData?: any) => string;
  closeWindow: (id: string) => void;
  minimizeWindow: (id: string) => void;
  maximizeWindow: (id: string) => void;
  restoreWindow: (id: string) => void;
  snapWindow: (id: string, snap: SnapType) => void;
  focusWindow: (id: string) => void;
  updateWindowPosition: (id: string, x: number, y: number) => void;
  updateWindowSize: (id: string, width: number, height: number) => void;

  // i18n Translations
  t: TranslationDict;
  currentLang: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;

  // Flyouts & Shell UI
  isStartOpen: boolean;
  setIsStartOpen: (open: boolean | ((prev: boolean) => boolean)) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean | ((prev: boolean) => boolean)) => void;
  isActionCenterOpen: boolean;
  setIsActionCenterOpen: (open: boolean | ((prev: boolean) => boolean)) => void;
  isWidgetsOpen: boolean;
  setIsWidgetsOpen: (open: boolean | ((prev: boolean) => boolean)) => void;
  isRunDialogOpen: boolean;
  setIsRunDialogOpen: (open: boolean) => void;
  isAddAppModalOpen: boolean;
  setIsAddAppModalOpen: (open: boolean) => void;
  isAltTabOpen: boolean;
  setIsAltTabOpen: (open: boolean) => void;
  isLockScreen: boolean;
  setIsLockScreen: (locked: boolean) => void;
  isSleeping: boolean;
  enterSleepMode: () => void;
  wakeUpSystem: () => void;
  bootState: BootState;
  setBootState: (state: BootState) => void;
  restartSystem: () => void;
  shutdownSystem: () => void;
  powerOnSystem: () => void;

  // OOBE Setup
  oobeCompleted: boolean;
  completeOOBE: (data: {
    region: string;
    keyboardLayout: string;
    secondKeyboardLayout?: string;
    wifiNetwork: string;
    userName: string;
    userEmail: string;
    deviceName: string;
    privacyLocation: boolean;
    privacyDiagnostic: boolean;
    privacyFindDevice: boolean;
    privacyTailored: boolean;
    termsAccepted: boolean;
  }) => void;
  triggerOOBESetup: () => void;

  // WinRE (Windows Recovery Environment) & Safe Mode
  winREActive: boolean;
  winREView: import('../types/winre').WinREView;
  safeMode: import('../types/winre').SafeModeType;
  uefiConfig: import('../types/winre').UEFIConfig;
  enterWinRE: (initialView?: import('../types/winre').WinREView) => void;
  exitWinRE: () => void;
  restartToWinRE: () => void;
  startSafeMode: (mode: import('../types/winre').SafeModeType) => void;
  performPCReset: (keepFiles: boolean) => void;
  updateUEFIConfig: (config: import('../types/winre').UEFIConfig) => void;

  // File System
  fileSystem: FileSystemItem[];
  addFile: (file: Omit<FileSystemItem, 'id' | 'createdAt' | 'modifiedAt'>) => FileSystemItem;
  deleteFile: (idOrPath: string, bypassSecurity?: boolean) => boolean;
  renameFile: (idOrPath: string, newName: string) => boolean;
  updateFileContent: (path: string, content: string) => void;
  createHtmlApp: (title: string, icon: string, htmlContent: string, category?: string) => FileSystemItem;
  getFilesByDirectory: (dirPath: string) => FileSystemItem[];
  getHtmlApps: () => FileSystemItem[];
  clipboard: { item: FileSystemItem; op: 'copy' | 'cut' } | null;
  setClipboard: (item: FileSystemItem | null, op?: 'copy' | 'cut') => void;
  pasteFile: (targetDirPath: string) => FileSystemItem | null;
  createArchiveFile: (sourceItem: FileSystemItem, format?: 'rar' | 'zip' | 'iso') => FileSystemItem;
  createShortcutFile: (sourceItem: FileSystemItem, targetDirPath?: string) => FileSystemItem;
  copyFileToFolder: (sourceItem: FileSystemItem, targetDirPath: string) => FileSystemItem;
  pinnedFolders: string[];
  pinFolder: (path: string) => void;
  unpinFolder: (path: string) => void;

  // System Security & Command-line Access
  takeOwnership: (idOrPath: string) => { success: boolean; path: string };
  grantPermission: (idOrPath: string) => { success: boolean; notOwned?: boolean; path: string };

  // System Failure & 5-way Recovery Options
  systemFailure: SystemFailureState;
  triggerSystemFailure: (fileName: string, filePath: string, errorCode?: string) => void;
  clearSystemFailure: () => void;
  restoreFromRestorePoint: () => void;
  repairStartup: () => void;
  resetPCKeepPersonalFiles: () => void;
  resetPCRemoveEverything: () => void;
  shutdownSystemFailure: () => void;

  // Dialog States
  accessDeniedDialog: AccessDeniedDialogState;
  closeAccessDeniedDialog: () => void;
  filePropertiesDialog: FilePropertiesDialogState;
  openFileProperties: (item: FileSystemItem) => void;
  closeFileProperties: () => void;
  defenderScanDialog: DefenderScanDialogState;
  openDefenderScan: (targetName: string) => void;
  closeDefenderScan: () => void;
  drivePropertiesDialog: DrivePropertiesDialogState;
  openDriveProperties: (driveLetter: 'C' | 'D') => void;
  closeDriveProperties: () => void;

  // Settings
  settings: SystemSettings;
  updateSettings: (partial: Partial<SystemSettings>) => void;

  // Context Menu
  contextMenu: ContextMenuState;
  showContextMenu: (x: number, y: number, items: ContextMenuState['items'], targetType?: any, targetData?: any) => void;
  closeContextMenu: () => void;

  // Notifications
  notifications: NotificationItem[];
  addNotification: (title: string, message: string, appId?: string) => void;
  dismissNotification: (id: string) => void;
  clearNotifications: () => void;

  // Shell Helpers
  minimizeAll: () => void;
}

const OSContext = createContext<OSContextType | null>(null);

const STORAGE_KEY_FILES = 'win11_web_fs_v3';
const STORAGE_KEY_SETTINGS = 'win11_web_settings_v2';
const STORAGE_KEY_OOBE = 'win11_oobe_completed_v2';

export const RESET_AUTH_SETTINGS = {
  hasPin: false,
  hasPassword: false,
  hasLockScreen: false,
  requireLockOnStartup: false,
  requireLockPin: false,
  lockPin: '',
  password: '',
  passwordHint: '',
  authMethod: 'pin' as const,
};

export const DEFAULT_SYSTEM_SETTINGS: SystemSettings = {
  theme: 'dark',
  wallpaper: DEFAULT_WALLPAPERS[0].url,
  accentColor: '#0078d4',
  taskbarAlignment: 'center',
  soundEnabled: true,
  volume: 80,
  brightness: 100,
  isWifiOn: true,
  isBluetoothOn: true,
  isAirplaneMode: false,
  isNightLight: false,
  isBatterySaver: false,
  searchEngine: 'edge://search?q=',
  scale: 100,
  autoHideTaskbar: false,
  deviceName: 'LAPTOP-LENAMPHUC',
  userName: 'lenamphuc',
  userEmail: 'lenamphuc2013@gmail.com',
  region: 'Việt Nam',
  keyboardLayout: 'Tiếng Việt (Telex)',
  language: 'vi',
  wifiNetwork: 'Lenamphuc-5G-UltraSpeed',
  oobeCompleted: false,
  ...RESET_AUTH_SETTINGS,
  lockScreenType: 'spotlight',
  lockScreenStatusWidget: 'weather',
  showLockBackgroundOnSignIn: true,
  lockScreenWallpaper: DEFAULT_WALLPAPERS[1]?.url || DEFAULT_WALLPAPERS[0].url,
};

export const OSProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Initialize File System with localStorage persistence and system file integrity
  const [fileSystem, setFileSystem] = useState<FileSystemItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_FILES);
      if (saved) {
        const parsed: FileSystemItem[] = JSON.parse(saved);
        // Map initial metadata to ensure updated protection levels & descriptions
        const initialMap = new Map(INITIAL_FILE_SYSTEM.map((item) => [item.path.toLowerCase(), item]));
        const merged = parsed.map((p) => {
          const initial = initialMap.get(p.path.toLowerCase());
          if (initial) {
            return {
              ...p,
              protectionLevel: p.protectionLevel || initial.protectionLevel,
              description: p.description || initial.description,
              owner: p.owner || initial.owner,
              isSystem: p.isSystem ?? initial.isSystem,
              isReadOnly: p.isReadOnly ?? initial.isReadOnly,
              isCriticalSystemFile: p.isCriticalSystemFile ?? initial.isCriticalSystemFile,
            };
          }
          return p;
        });

        const existingPaths = new Set(merged.map((f) => f.path.toLowerCase()));
        for (const item of INITIAL_FILE_SYSTEM) {
          if (!existingPaths.has(item.path.toLowerCase())) {
            merged.push(item);
          }
        }
        return merged;
      }
    } catch (e) {
      console.warn('Failed to load file system from localStorage', e);
    }
    return INITIAL_FILE_SYSTEM;
  });

  // Save File System to IndexedDB (with localStorage fast-boot fallback) on change
  useEffect(() => {
    // Persistent IndexedDB save (unlimited quota for files, GIFs, videos, wallpapers)
    saveLocalData(STORAGE_KEY_FILES, fileSystem).catch((e) => {
      console.warn('Failed to save filesystem to IndexedDB', e);
    });

    try {
      localStorage.setItem(STORAGE_KEY_FILES, JSON.stringify(fileSystem));
    } catch (e) {
      // If quota exceeded in localStorage, IndexedDB safely retains the entire filesystem!
    }
  }, [fileSystem]);

  // Hydrate files & settings from IndexedDB on startup
  useEffect(() => {
    let isMounted = true;
    (async () => {
      try {
        const idbFiles = await loadLocalData<FileSystemItem[]>(STORAGE_KEY_FILES);
        if (idbFiles && Array.isArray(idbFiles) && idbFiles.length > 0 && isMounted) {
          const initialMap = new Map(INITIAL_FILE_SYSTEM.map((item) => [item.path.toLowerCase(), item]));
          const merged = idbFiles.map((p) => {
            const initial = initialMap.get(p.path.toLowerCase());
            if (initial) {
              return {
                ...p,
                protectionLevel: p.protectionLevel || initial.protectionLevel,
                description: p.description || initial.description,
                owner: p.owner || initial.owner,
                isSystem: p.isSystem ?? initial.isSystem,
                isReadOnly: p.isReadOnly ?? initial.isReadOnly,
                isCriticalSystemFile: p.isCriticalSystemFile ?? initial.isCriticalSystemFile,
              };
            }
            return p;
          });

          const existingPaths = new Set(merged.map((f) => f.path.toLowerCase()));
          for (const item of INITIAL_FILE_SYSTEM) {
            if (!existingPaths.has(item.path.toLowerCase())) {
              merged.push(item);
            }
          }
          setFileSystem(merged);
        }

        const idbSettings = await loadLocalData<SystemSettings>(STORAGE_KEY_SETTINGS);
        if (idbSettings && isMounted) {
          setSettings((prev) => ({
            ...prev,
            ...idbSettings,
          }));
        }
      } catch (err) {
        console.warn('Error hydrating from IndexedDB:', err);
      }
    })();

    return () => {
      isMounted = false;
    };
  }, []);

  // Check if OOBE setup is completed
  const [oobeCompleted, setOobeCompleted] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEY_OOBE) === 'true';
    } catch (e) {
      return false;
    }
  });

  // System Settings with persistence
  const [settings, setSettings] = useState<SystemSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SETTINGS);
      if (saved) {
        const parsed = JSON.parse(saved);
        const lang = parsed.language || getLanguageFromRegion(parsed.region || 'Việt Nam');
        let initialWallpaper = parsed.wallpaper;
        // Migrate old unencoded svg or broken wallpaper URIs
        if (!initialWallpaper || initialWallpaper.includes('utf8,<svg') || initialWallpaper.length < 10) {
          initialWallpaper = DEFAULT_WALLPAPERS[0].url;
        }

        return {
          ...DEFAULT_SYSTEM_SETTINGS,
          ...parsed,
          language: lang,
          wallpaper: initialWallpaper,
        };
      }
    } catch (e) {}
    return DEFAULT_SYSTEM_SETTINGS;
  });

  const currentLang: LanguageCode = settings.language || getLanguageFromRegion(settings.region) || 'vi';
  const t = TRANSLATIONS[currentLang] || TRANSLATIONS.vi;

  const setLanguage = useCallback((lang: LanguageCode) => {
    setSettings((prev) => ({
      ...prev,
      language: lang,
    }));
  }, []);

  useEffect(() => {
    saveLocalData(STORAGE_KEY_SETTINGS, settings).catch((e) => {
      console.warn('Failed to save settings to IndexedDB', e);
    });
    try {
      localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
    } catch (e) {}
    soundManager.enabled = settings.soundEnabled;
  }, [settings]);

  // Windows State
  const [windows, setWindows] = useState<WindowItem[]>([]);
  const [activeWindowId, setActiveWindowId] = useState<string | null>(null);
  const [nextZIndex, setNextZIndex] = useState<number>(100);

  // Flyouts
  const [isStartOpen, setIsStartOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isActionCenterOpen, setIsActionCenterOpen] = useState(false);
  const [isWidgetsOpen, setIsWidgetsOpen] = useState(false);
  const [isRunDialogOpen, setIsRunDialogOpen] = useState(false);
  const [isAddAppModalOpen, setIsAddAppModalOpen] = useState(false);
  const [isAltTabOpen, setIsAltTabOpen] = useState(false);
  const [isLockScreen, setIsLockScreen] = useState(false);

  // Boot and Power State
  const [bootState, setBootState] = useState<BootState>('booting');

  // Complete OOBE Handler
  const completeOOBE = useCallback(
    (data: {
      region: string;
      keyboardLayout: string;
      secondKeyboardLayout?: string;
      wifiNetwork: string;
      userName: string;
      userEmail: string;
      deviceName: string;
      privacyLocation: boolean;
      privacyDiagnostic: boolean;
      privacyFindDevice: boolean;
      privacyTailored: boolean;
      termsAccepted: boolean;
    }) => {
      setOobeCompleted(true);
      try {
        localStorage.setItem(STORAGE_KEY_OOBE, 'true');
      } catch (e) {}

      const autoLang = getLanguageFromRegion(data.region);

      setSettings((prev) => {
        const completedSettings = {
          ...prev,
          region: data.region,
          keyboardLayout: data.keyboardLayout,
          wifiNetwork: data.wifiNetwork,
          userName: data.userName,
          userEmail: data.userEmail,
          deviceName: data.deviceName,
          language: autoLang,
          oobeCompleted: true,
          ...RESET_AUTH_SETTINGS,
        };
        saveLocalData(STORAGE_KEY_SETTINGS, completedSettings).catch(() => {});
        try {
          localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(completedSettings));
        } catch (e) {}
        return completedSettings;
      });

      setBootState('desktop');
    },
    []
  );

  const triggerOOBESetup = useCallback(() => {
    setOobeCompleted(false);
    try {
      localStorage.removeItem(STORAGE_KEY_OOBE);
    } catch (e) {}
    setSettings((prev) => {
      const resetSettings = {
        ...prev,
        ...RESET_AUTH_SETTINGS,
        oobeCompleted: false,
      };
      saveLocalData(STORAGE_KEY_SETTINGS, resetSettings).catch(() => {});
      try {
        localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(resetSettings));
      } catch (e) {}
      return resetSettings;
    });
    setIsLockScreen(false);
    setWindows([]);
    setIsStartOpen(false);
    setBootState('booting');
  }, []);

  // WinRE (Windows Recovery Environment) & Safe Mode
  const [winREActive, setWinREActive] = useState<boolean>(false);
  const [winREView, setWinREView] = useState<import('../types/winre').WinREView>('main');
  const [safeMode, setSafeMode] = useState<import('../types/winre').SafeModeType>('none');
  const [uefiConfig, setUefiConfig] = useState<import('../types/winre').UEFIConfig>({
    secureBoot: true,
    tpmEnabled: true,
    virtualization: true,
    fastBoot: true,
    xmpProfile: 'Profile 1 (DDR5-6000)',
    bootOrder: [
      'Windows Boot Manager (Samsung SSD 990 PRO)',
      'UEFI: Generic USB Flash Disk 32GB',
      'UEFI: Realtek PXE IPv4/IPv6 Network Boot',
    ],
    systemDate: new Date().toLocaleDateString('en-US'),
    systemTime: new Date().toLocaleTimeString('en-US'),
  });

  const enterWinRE = useCallback((initialView: import('../types/winre').WinREView = 'main') => {
    setIsStartOpen(false);
    setWindows([]);
    setWinREView(initialView);
    setWinREActive(true);
  }, []);

  const exitWinRE = useCallback(() => {
    setWinREActive(false);
    setBootState('restarting');
    setTimeout(() => {
      setBootState('booting');
    }, 1200);
  }, []);

  const restartToWinRE = useCallback(() => {
    setIsSleeping(false);
    setIsLockScreen(false);
    setIsStartOpen(false);
    setWindows([]);
    setBootState('restarting');
    setTimeout(() => {
      setWinREView('main');
      setWinREActive(true);
      setBootState('desktop');
    }, 1500);
  }, []);

  const startSafeMode = useCallback((mode: import('../types/winre').SafeModeType) => {
    setWinREActive(false);
    setSafeMode(mode);
    setBootState('restarting');
    setTimeout(() => {
      setBootState('booting');
    }, 1200);
  }, []);

  const performPCReset = useCallback((keepFiles: boolean) => {
    setWinREActive(false);
    setOobeCompleted(false);
    try {
      localStorage.removeItem(STORAGE_KEY_OOBE);
    } catch (e) {}

    if (!keepFiles) {
      // Clear all files back to initial filesystem
      setFileSystem(INITIAL_FILE_SYSTEM);
      deleteLocalData(STORAGE_KEY_FILES).catch(() => {});
      deleteLocalData(STORAGE_KEY_SETTINGS).catch(() => {});
      try {
        localStorage.removeItem(STORAGE_KEY_FILES);
        localStorage.removeItem(STORAGE_KEY_SETTINGS);
        localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(DEFAULT_SYSTEM_SETTINGS));
      } catch (e) {}
      saveLocalData(STORAGE_KEY_SETTINGS, DEFAULT_SYSTEM_SETTINGS).catch(() => {});
      setSettings(DEFAULT_SYSTEM_SETTINGS);
    } else {
      // Keep files: preserve personal files, but wipe all passwords, PINs, lock screen auth, and reset OOBE
      setSettings((prev) => {
        const wipedSettings = {
          ...prev,
          ...RESET_AUTH_SETTINGS,
          oobeCompleted: false,
        };
        saveLocalData(STORAGE_KEY_SETTINGS, wipedSettings).catch(() => {});
        try {
          localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(wipedSettings));
        } catch (e) {}
        return wipedSettings;
      });
    }

    setIsLockScreen(false);
    setWindows([]);
    setIsStartOpen(false);
    setIsSearchOpen(false);
    setIsActionCenterOpen(false);
    setIsWidgetsOpen(false);
    setSafeMode('none');
    setBootState('restarting');
    setTimeout(() => {
      setBootState('booting');
    }, 1500);
  }, []);

  const updateUEFIConfig = useCallback((cfg: import('../types/winre').UEFIConfig) => {
    setUefiConfig(cfg);
  }, []);

  const [isSleeping, setIsSleeping] = useState(false);

  const restartSystem = useCallback(() => {
    setIsSleeping(false);
    setIsLockScreen(false);
    setIsStartOpen(false);
    setIsSearchOpen(false);
    setIsActionCenterOpen(false);
    setIsWidgetsOpen(false);
    setWindows([]);
    setBootState('restarting');
    setTimeout(() => {
      setBootState('booting');
    }, 1400);
  }, []);

  const shutdownSystem = useCallback(() => {
    setIsSleeping(false);
    setIsLockScreen(false);
    setIsStartOpen(false);
    setIsSearchOpen(false);
    setIsActionCenterOpen(false);
    setIsWidgetsOpen(false);
    // Transition smoothly: first show "Đang tắt máy..." screen with spinner, then power off to pure black screen
    setBootState('shutting_down');
    setTimeout(() => {
      setWindows([]);
      setBootState('shutdown');
    }, 2400);
  }, []);

  const enterSleepMode = useCallback(() => {
    setIsStartOpen(false);
    setIsSearchOpen(false);
    setIsActionCenterOpen(false);
    setIsWidgetsOpen(false);
    setIsSleeping(true);
  }, []);

  const wakeUpSystem = useCallback(() => {
    setIsSleeping(false);
  }, []);

  const powerOnSystem = useCallback(() => {
    setIsSleeping(false);
    setBootState('booting');
  }, []);

  // System Failure & Error Screen State
  const [systemFailure, setSystemFailure] = useState<SystemFailureState>({
    isFailed: false,
  });

  // Modal Dialogs
  const [accessDeniedDialog, setAccessDeniedDialog] = useState<AccessDeniedDialogState>({
    isOpen: false,
  });
  const [filePropertiesDialog, setFilePropertiesDialog] = useState<FilePropertiesDialogState>({
    isOpen: false,
  });
  const [defenderScanDialog, setDefenderScanDialog] = useState<DefenderScanDialogState>({
    isOpen: false,
  });
  const [drivePropertiesDialog, setDrivePropertiesDialog] = useState<DrivePropertiesDialogState>({
    isOpen: false,
    driveLetter: 'C',
  });

  const closeAccessDeniedDialog = useCallback(() => {
    setAccessDeniedDialog({ isOpen: false });
  }, []);

  const openFileProperties = useCallback((item: FileSystemItem) => {
    setFilePropertiesDialog({ isOpen: true, fileItem: item });
  }, []);

  const closeFileProperties = useCallback(() => {
    setFilePropertiesDialog({ isOpen: false });
  }, []);

  const openDefenderScan = useCallback((targetName: string) => {
    setDefenderScanDialog({ isOpen: true, targetName, isScanning: true });
  }, []);

  const closeDefenderScan = useCallback(() => {
    setDefenderScanDialog({ isOpen: false });
  }, []);

  const openDriveProperties = useCallback((driveLetter: 'C' | 'D') => {
    setDrivePropertiesDialog({ isOpen: true, driveLetter });
  }, []);

  const closeDriveProperties = useCallback(() => {
    setDrivePropertiesDialog({ isOpen: false, driveLetter: 'C' });
  }, []);

  const triggerSystemFailure = useCallback((fileName: string, filePath: string, errorCode: string = '0xc0000098') => {
    setWindows([]);
    setSystemFailure({
      isFailed: true,
      failedFileName: fileName,
      failedFilePath: filePath,
      errorCode,
      errorDescription: 'Tệp hệ thống quan trọng bị thiếu hoặc bị xóa (Critical system file missing/deleted)',
    });
  }, []);

  const clearSystemFailure = useCallback(() => {
    setSystemFailure({ isFailed: false });
  }, []);

  // System Recovery Actions
  const restoreFromRestorePoint = useCallback(() => {
    // Merge back all system files from INITIAL_FILE_SYSTEM, keep user files/credentials intact!
    setFileSystem((prev) => {
      const existingPaths = new Set(prev.map((f) => f.path.toLowerCase()));
      const restored = [...prev];
      for (const item of INITIAL_FILE_SYSTEM) {
        if (!existingPaths.has(item.path.toLowerCase())) {
          restored.push(item);
        }
      }
      return restored;
    });
    setSystemFailure({ isFailed: false });
    setBootState('restarting');
    setTimeout(() => {
      setBootState('booting');
    }, 1200);
  }, []);

  const repairStartup = useCallback(() => {
    // Repair kernel & bootmgr files
    setFileSystem((prev) => {
      const existingPaths = new Set(prev.map((f) => f.path.toLowerCase()));
      const restored = [...prev];
      for (const item of INITIAL_FILE_SYSTEM) {
        if (
          !existingPaths.has(item.path.toLowerCase()) &&
          (item.path.toLowerCase().includes('ntoskrnl') ||
            item.path.toLowerCase().includes('boot') ||
            item.path.toLowerCase().includes('config'))
        ) {
          restored.push(item);
        }
      }
      return restored;
    });
    setSystemFailure({ isFailed: false });
    setBootState('restarting');
    setTimeout(() => {
      setBootState('booting');
    }, 1200);
  }, []);

  const resetPCKeepPersonalFiles = useCallback(() => {
    // Keep user documents, downloads, desktop files, D: drive, restore system files to initial
    setFileSystem((prev) => {
      const userPersonalFiles = prev.filter(
        (f) =>
          f.path.toLowerCase().startsWith('c:\\users\\user\\documents') ||
          f.path.toLowerCase().startsWith('c:\\users\\user\\desktop') ||
          f.path.toLowerCase().startsWith('c:\\users\\user\\downloads') ||
          f.path.toLowerCase().startsWith('c:\\users\\user\\pictures') ||
          f.path.toLowerCase().startsWith('c:\\users\\user\\music') ||
          f.path.toLowerCase().startsWith('c:\\users\\user\\videos') ||
          f.path.toLowerCase().startsWith('d:')
      );
      const restored = [...INITIAL_FILE_SYSTEM];
      const restoredPaths = new Set(restored.map((f) => f.path.toLowerCase()));
      for (const uf of userPersonalFiles) {
        if (!restoredPaths.has(uf.path.toLowerCase())) {
          restored.push(uf);
        }
      }
      return restored;
    });
    setOobeCompleted(false);
    try {
      localStorage.removeItem(STORAGE_KEY_OOBE);
    } catch (e) {}

    // Factory reset wipes password, PIN, lock screen
    setSettings((prev) => {
      const wipedSettings = {
        ...prev,
        ...RESET_AUTH_SETTINGS,
        oobeCompleted: false,
      };
      saveLocalData(STORAGE_KEY_SETTINGS, wipedSettings).catch(() => {});
      try {
        localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(wipedSettings));
      } catch (e) {}
      return wipedSettings;
    });

    setIsLockScreen(false);
    setWindows([]);
    setIsStartOpen(false);
    setIsSearchOpen(false);
    setIsActionCenterOpen(false);
    setIsWidgetsOpen(false);
    setSystemFailure({ isFailed: false });
    setBootState('restarting');
    setTimeout(() => {
      setBootState('booting');
    }, 1200);
  }, []);

  const resetPCRemoveEverything = useCallback(() => {
    // Full wipe - reset filesystem to INITIAL_FILE_SYSTEM, reset settings, show OOBE like new PC
    setFileSystem(INITIAL_FILE_SYSTEM);
    setOobeCompleted(false);
    deleteLocalData(STORAGE_KEY_FILES).catch(() => {});
    deleteLocalData(STORAGE_KEY_SETTINGS).catch(() => {});
    try {
      localStorage.removeItem(STORAGE_KEY_FILES);
      localStorage.removeItem(STORAGE_KEY_SETTINGS);
      localStorage.removeItem(STORAGE_KEY_OOBE);
      localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(DEFAULT_SYSTEM_SETTINGS));
    } catch (e) {}
    saveLocalData(STORAGE_KEY_SETTINGS, DEFAULT_SYSTEM_SETTINGS).catch(() => {});
    setSettings(DEFAULT_SYSTEM_SETTINGS);

    setIsLockScreen(false);
    setWindows([]);
    setIsStartOpen(false);
    setIsSearchOpen(false);
    setIsActionCenterOpen(false);
    setIsWidgetsOpen(false);
    setSystemFailure({ isFailed: false });
    setBootState('restarting');
    setTimeout(() => {
      setBootState('booting');
    }, 1200);
  }, []);

  const shutdownSystemFailure = useCallback(() => {
    setWindows([]);
    setBootState('shutdown');
  }, []);

  const takeOwnership = useCallback((idOrPath: string) => {
    let matched = false;
    let targetPath = '';
    const norm = idOrPath.trim().replace(/^"+|"+$/g, '').toLowerCase();

    setFileSystem((prev) =>
      prev.map((f) => {
        const p = f.path.toLowerCase();
        const n = f.name.toLowerCase();
        if (f.id === idOrPath || p === norm || n === norm || p.endsWith('\\' + norm) || p.startsWith(norm + '\\')) {
          matched = true;
          targetPath = f.path;
          return {
            ...f,
            owner: 'Administrators',
          };
        }
        return f;
      })
    );
    return { success: matched, path: targetPath };
  }, []);

  const grantPermission = useCallback((idOrPath: string) => {
    let matched = false;
    let notOwned = false;
    let targetPath = '';
    const norm = idOrPath.trim().replace(/^"+|"+$/g, '').toLowerCase();

    setFileSystem((prev) =>
      prev.map((f) => {
        const p = f.path.toLowerCase();
        const n = f.name.toLowerCase();
        if (f.id === idOrPath || p === norm || n === norm || p.endsWith('\\' + norm) || p.startsWith(norm + '\\')) {
          matched = true;
          targetPath = f.path;
          if (f.owner !== 'Administrators') {
            notOwned = true;
            return f;
          }
          return {
            ...f,
            icaclsGranted: true,
          };
        }
        return f;
      })
    );
    return { success: matched && !notOwned, notOwned, path: targetPath };
  }, []);

  // Context Menu
  const [contextMenu, setContextMenu] = useState<ContextMenuState>({
    isOpen: false,
    x: 0,
    y: 0,
    items: [],
  });

  // Notifications
  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'welcome-notif',
      title: 'Windows 11 Web OS Ready',
      message: 'You can now drag & drop HTML files into C:\\Apps or Desktop to run custom apps!',
      timestamp: new Date(),
      unread: true,
      appId: 'explorer',
    },
  ]);

  const addNotification = useCallback((title: string, message: string, appId?: string) => {
    const newNotif: NotificationItem = {
      id: 'notif-' + Date.now(),
      title,
      message,
      timestamp: new Date(),
      unread: true,
      appId,
    };
    setNotifications((prev) => [newNotif, ...prev]);
    soundManager.playNotification();
  }, []);

  const dismissNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const clearNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  const updateSettings = useCallback((partial: Partial<SystemSettings>) => {
    setSettings((prev) => ({ ...prev, ...partial }));
  }, []);

  const showContextMenu = useCallback(
    (x: number, y: number, items: ContextMenuState['items'], targetType?: any, targetData?: any) => {
      setContextMenu({
        isOpen: true,
        x: Math.min(x, window.innerWidth - 240),
        y: Math.min(y, window.innerHeight - 300),
        items,
        targetType,
        targetData,
      });
    },
    []
  );

  const closeContextMenu = useCallback(() => {
    setContextMenu((prev) => ({ ...prev, isOpen: false }));
  }, []);

  // Window Focus
  const focusWindow = useCallback((id: string) => {
    setActiveWindowId(id);
    setWindows((prev) => {
      const target = prev.find((w) => w.id === id);
      if (!target) return prev;
      const maxZ = prev.reduce((m, w) => Math.max(m, w.zIndex || 0), 10);
      const newZ = maxZ + 1;
      setNextZIndex(newZ + 1);
      return prev.map((w) => (w.id === id ? { ...w, zIndex: newZ, isMinimized: false } : w));
    });
  }, []);

  // Open App
  const openApp = useCallback(
    (appId: AppId, customData?: any): string => {
      // Close shell flyouts
      setIsStartOpen(false);
      setIsSearchOpen(false);
      setIsActionCenterOpen(false);
      setIsWidgetsOpen(false);
      closeContextMenu();

      // Check if this is an HTML App from file system or custom data
      let appTitle = 'Application';
      let appIcon = 'LayoutGrid';
      let appWidth = 800;
      let appHeight = 520;

      // Special folder shortcuts
      if (appId === 'appsfolder') {
        appId = 'explorer';
        customData = { initialPath: 'C:\\Apps' };
      }

      const builtIn = BUILT_IN_APPS.find((a) => a.id === appId);
      if (builtIn) {
        appTitle = builtIn.name;
        appIcon = builtIn.icon;
        appWidth = builtIn.defaultWidth || 800;
        appHeight = builtIn.defaultHeight || 520;
      }

      if (customData?.appName) {
        appTitle = customData.appName;
      }
      if (customData?.appTitle) {
        appTitle = customData.appTitle;
      }
      if (customData?.icon) {
        appIcon = customData.icon;
      }

      // If window already exists and is a singleton app (not multi-instance HTML runner or custom path)
      if (
        !customData?.filePath &&
        !customData?.htmlContent &&
        appId !== 'app-runner' &&
        appId !== 'notepad'
      ) {
        const existing = windows.find((w) => w.appId === appId);
        if (existing) {
          focusWindow(existing.id);
          setWindows((prev) =>
            prev.map((w) =>
              w.id === existing.id
                ? {
                    ...w,
                    isMinimized: false,
                    customData: customData ? { ...w.customData, ...customData } : w.customData,
                  }
                : w
            )
          );
          return existing.id;
        }
      }

      // If it's an existing HTML file launched, check if already open
      if (customData?.filePath) {
        const existingFile = windows.find(
          (w) => w.customData?.filePath === customData.filePath
        );
        if (existingFile) {
          focusWindow(existingFile.id);
          if (existingFile.isMinimized) {
            setWindows((prev) =>
              prev.map((w) => (w.id === existingFile.id ? { ...w, isMinimized: false } : w))
            );
          }
          return existingFile.id;
        }
      }

      const windowId = 'win-' + Date.now() + '-' + Math.floor(Math.random() * 1000);
      const maxZ = windows.reduce((m, w) => Math.max(m, w.zIndex || 0), 10);
      const newZ = maxZ + 1;
      setNextZIndex(newZ + 1);

      // Stagger initial position or center dialogs
      const offset = (windows.length % 8) * 28 + 40;
      const screenW = typeof window !== 'undefined' ? window.innerWidth : 1280;
      const screenH = typeof window !== 'undefined' ? window.innerHeight : 800;

      const isDialog = appId === 'winver' || appId === 'run';
      const posX = isDialog
        ? Math.max(20, Math.round((screenW - appWidth) / 2))
        : Math.max(20, Math.min(screenW - appWidth - 40, offset + 60));
      const posY = isDialog
        ? Math.max(40, Math.round((screenH - appHeight - 48) / 2))
        : Math.max(20, Math.min(screenH - appHeight - 80, offset + 20));

      const newWindow: WindowItem = {
        id: windowId,
        appId,
        title: appTitle,
        icon: appIcon,
        iconType: customData?.iconType || 'lucide',
        isMinimized: false,
        isMaximized: false,
        position: { x: posX, y: posY },
        size: {
          width: Math.min(appWidth, screenW - 40),
          height: Math.min(appHeight, screenH - 100),
        },
        zIndex: newZ,
        customData,
      };

      setWindows((prev) => [...prev, newWindow]);
      setActiveWindowId(windowId);
      soundManager.playWindowAction('open');

      return windowId;
    },
    [windows, focusWindow, closeContextMenu]
  );

  const closeWindow = useCallback((id: string) => {
    setWindows((prev) => {
      const remaining = prev.filter((w) => w.id !== id);
      if (remaining.length > 0) {
        const highest = remaining.reduce((prevW, currW) =>
          currW.zIndex > prevW.zIndex ? currW : prevW
        );
        setActiveWindowId(highest.id);
      } else {
        setActiveWindowId(null);
      }
      return remaining;
    });
    soundManager.playClick();
  }, []);

  const minimizeWindow = useCallback((id: string) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === id ? { ...w, isMinimized: true } : w))
    );
    setActiveWindowId((prevActive) => (prevActive === id ? null : prevActive));
    soundManager.playWindowAction('minimize');
  }, []);

  const maximizeWindow = useCallback((id: string) => {
    setWindows((prev) =>
      prev.map((w) => {
        if (w.id !== id) return w;
        if (w.isMaximized) {
          // Restore
          return {
            ...w,
            isMaximized: false,
            snapType: null,
            position: w.previousBounds ? { x: w.previousBounds.x, y: w.previousBounds.y } : w.position,
            size: w.previousBounds ? { width: w.previousBounds.width, height: w.previousBounds.height } : w.size,
          };
        } else {
          // Maximize
          return {
            ...w,
            isMaximized: true,
            snapType: null,
            previousBounds: {
              x: w.position.x,
              y: w.position.y,
              width: w.size.width,
              height: w.size.height,
            },
          };
        }
      })
    );
    soundManager.playWindowAction('maximize');
  }, []);

  const restoreWindow = useCallback((id: string) => {
    setWindows((prev) =>
      prev.map((w) => {
        if (w.id !== id) return w;
        return {
          ...w,
          isMaximized: false,
          isMinimized: false,
          snapType: null,
          position: w.previousBounds ? { x: w.previousBounds.x, y: w.previousBounds.y } : w.position,
          size: w.previousBounds ? { width: w.previousBounds.width, height: w.previousBounds.height } : w.size,
        };
      })
    );
    focusWindow(id);
  }, [focusWindow]);

  const snapWindow = useCallback((id: string, snap: SnapType) => {
    setWindows((prev) =>
      prev.map((w) => {
        if (w.id !== id) return w;
        return {
          ...w,
          isMaximized: false,
          snapType: snap,
          previousBounds: w.previousBounds || {
            x: w.position.x,
            y: w.position.y,
            width: w.size.width,
            height: w.size.height,
          },
        };
      })
    );
    soundManager.playWindowAction('snap');
  }, []);

  const updateWindowPosition = useCallback((id: string, x: number, y: number) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === id ? { ...w, position: { x, y }, snapType: null } : w))
    );
  }, []);

  const updateWindowSize = useCallback((id: string, width: number, height: number) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === id ? { ...w, size: { width, height } } : w))
    );
  }, []);

  const minimizeAll = useCallback(() => {
    setWindows((prev) => prev.map((w) => ({ ...w, isMinimized: true })));
    setActiveWindowId(null);
  }, []);

  // File System Helpers
  const addFile = useCallback((fileData: Omit<FileSystemItem, 'id' | 'createdAt' | 'modifiedAt'>) => {
    const newFile: FileSystemItem = {
      ...fileData,
      id: 'file-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
      createdAt: Date.now(),
      modifiedAt: Date.now(),
    };
    setFileSystem((prev) => {
      // Replace if file with same path exists
      const filtered = prev.filter((f) => f.path !== newFile.path);
      return [...filtered, newFile];
    });
    return newFile;
  }, []);

  const deleteFile = useCallback((idOrPath: string, bypassSecurity: boolean = false): boolean => {
    const norm = idOrPath.trim().replace(/^"+|"+$/g, '').toLowerCase();
    const target = fileSystem.find(
      (f) =>
        f.id === idOrPath ||
        f.path.toLowerCase() === norm ||
        f.name.toLowerCase() === norm ||
        f.path.toLowerCase().endsWith('\\' + norm)
    );
    if (!target) return false;

    const isProtected =
      target.protectionLevel === 'KHÔNG XOÁ' ||
      target.protectionLevel === 'BẢO VỆ' ||
      target.isSystem ||
      target.isReadOnly ||
      target.path.toLowerCase().startsWith('c:\\windows') ||
      target.path.toLowerCase().startsWith('c:\\recovery') ||
      target.path.toLowerCase().startsWith('c:\\efi') ||
      target.path.toLowerCase() === 'c:\\pagefile.sys' ||
      target.path.toLowerCase() === 'c:\\hiberfil.sys';

    if (!bypassSecurity && isProtected) {
      setAccessDeniedDialog({
        isOpen: true,
        fileItem: target,
        action: 'delete',
      });
      soundManager.playNotification();
      return false;
    }

    const isCritical =
      target.protectionLevel === 'KHÔNG XOÁ' ||
      target.protectionLevel === 'BẢO VỆ' ||
      target.isCriticalSystemFile ||
      target.name.toLowerCase() === 'ntoskrnl.exe' ||
      target.path.toLowerCase().includes('\\windows\\boot') ||
      target.path.toLowerCase().includes('\\system32\\config') ||
      target.path.toLowerCase().includes('\\windows\\winsxs');

    const criticalName = target.name;
    const criticalPath = target.path;

    setFileSystem((prev) =>
      prev.filter(
        (f) =>
          f.id !== target.id &&
          f.path.toLowerCase() !== target.path.toLowerCase() &&
          !f.path.toLowerCase().startsWith(target.path.toLowerCase() + '\\')
      )
    );

    if (isCritical) {
      setTimeout(() => {
        triggerSystemFailure(
          criticalName,
          criticalPath,
          criticalName.toLowerCase().includes('ntoskrnl')
            ? '0xc0000098'
            : criticalPath.toLowerCase().includes('boot')
            ? '0xc000000f'
            : criticalPath.toLowerCase().includes('config')
            ? '0xc0000225'
            : '0xc0000034'
        );
      }, 1000);
    }

    return true;
  }, [fileSystem, triggerSystemFailure]);

  const updateFileContent = useCallback((path: string, content: string) => {
    setFileSystem((prev) =>
      prev.map((f) =>
        f.path === path
          ? { ...f, content, size: content.length, modifiedAt: Date.now() }
          : f
      )
    );
  }, []);

  const createHtmlApp = useCallback(
    (title: string, icon: string, htmlContent: string, category: string = 'custom') => {
      const sanitizedName = title.replace(/[^a-zA-Z0-9_-]/g, '') || 'CustomApp';
      const fileName = `${sanitizedName}.html`;
      const path = `C:\\Apps\\${fileName}`;

      const newApp = addFile({
        name: fileName,
        path,
        isDirectory: false,
        content: htmlContent,
        size: htmlContent.length,
        icon,
        isHtmlApp: true,
        appMetadata: {
          title,
          icon,
          category,
          description: `Custom Windows 11 HTML App - ${title}`,
        },
      });

      addNotification('App Installed', `${title} was added to C:\\Apps and Desktop!`, 'appsfolder');
      return newApp;
    },
    [addFile, addNotification]
  );

  const getFilesByDirectory = useCallback(
    (dirPath: string) => {
      const normalized = dirPath.replace(/\/$/, '').replace(/\\$/, '');
      return fileSystem.filter((f) => {
        if (f.path === normalized) return false;
        const lastSlash = Math.max(f.path.lastIndexOf('\\'), f.path.lastIndexOf('/'));
        if (lastSlash === -1) return false;
        const parent = f.path.substring(0, lastSlash);
        return parent === normalized;
      });
    },
    [fileSystem]
  );

  const getHtmlApps = useCallback(() => {
    return fileSystem.filter((f) => f.isHtmlApp || f.name.endsWith('.html') || f.name.endsWith('.htm'));
  }, [fileSystem]);

  // Rename File / Folder
  const renameFile = useCallback((idOrPath: string, newName: string): boolean => {
    if (!newName || !newName.trim()) return false;
    const trimmedNewName = newName.trim();
    const norm = idOrPath.trim().replace(/^"+|"+$/g, '').toLowerCase();

    const target = fileSystem.find(
      (f) =>
        f.id === idOrPath ||
        f.path.toLowerCase() === norm ||
        f.name.toLowerCase() === norm ||
        f.path.toLowerCase().endsWith('\\' + norm)
    );
    if (!target) return false;

    if (
      target.protectionLevel === 'KHÔNG XOÁ' ||
      target.protectionLevel === 'BẢO VỆ' ||
      target.isSystem ||
      target.isReadOnly
    ) {
      setAccessDeniedDialog({
        isOpen: true,
        fileItem: target,
        action: 'rename',
      });
      soundManager.playNotification();
      return false;
    }

    const lastSlash = Math.max(target.path.lastIndexOf('\\'), target.path.lastIndexOf('/'));
    const parentDir = lastSlash !== -1 ? target.path.substring(0, lastSlash) : 'C:\\';
    const newPath = `${parentDir}\\${trimmedNewName}`;
    const oldPath = target.path;

    setFileSystem((prev) =>
      prev.map((f) => {
        if (f.id === target.id) {
          return { ...f, name: trimmedNewName, path: newPath, modifiedAt: Date.now() };
        }
        if (target.isDirectory && f.path.toLowerCase().startsWith(oldPath.toLowerCase() + '\\')) {
          const subPath = f.path.substring(oldPath.length);
          return { ...f, path: `${newPath}${subPath}` };
        }
        return f;
      })
    );

    addNotification('Đổi tên tệp', `Đã đổi tên thành "${trimmedNewName}"`, 'explorer');
    soundManager.playNotification();
    return true;
  }, [fileSystem, addNotification]);

  // Clipboard & Cut / Copy / Paste
  const [clipboard, setClipboardState] = useState<{ item: FileSystemItem; op: 'copy' | 'cut' } | null>(null);

  const setClipboard = useCallback((item: FileSystemItem | null, op: 'copy' | 'cut' = 'copy') => {
    if (!item) {
      setClipboardState(null);
    } else {
      setClipboardState({ item, op });
      try {
        if (typeof navigator !== 'undefined' && navigator.clipboard) {
          navigator.clipboard.writeText(item.path);
        }
      } catch (e) {
        // ignore
      }
    }
  }, []);

  const pasteFile = useCallback((targetDirPath: string): FileSystemItem | null => {
    if (!clipboard || !clipboard.item) return null;
    const src = clipboard.item;
    const normTargetDir = targetDirPath.replace(/[\\/]+$/, '');

    let newName = src.name;
    const srcLastSlash = Math.max(src.path.lastIndexOf('\\'), src.path.lastIndexOf('/'));
    const srcParent = srcLastSlash !== -1 ? src.path.substring(0, srcLastSlash) : '';

    if (clipboard.op === 'copy' && srcParent.toLowerCase() === normTargetDir.toLowerCase()) {
      const dotIdx = src.name.lastIndexOf('.');
      if (dotIdx !== -1 && !src.isDirectory) {
        const namePart = src.name.substring(0, dotIdx);
        const extPart = src.name.substring(dotIdx);
        newName = `${namePart} - Copy${extPart}`;
      } else {
        newName = `${src.name} - Copy`;
      }
    }

    const newPath = `${normTargetDir}\\${newName}`;
    const newFile: FileSystemItem = {
      ...src,
      id: 'file-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
      name: newName,
      path: newPath,
      createdAt: Date.now(),
      modifiedAt: Date.now(),
      protectionLevel: 'AN TOÀN XOÁ',
    };

    setFileSystem((prev) => {
      const filtered = prev.filter((f) => f.path.toLowerCase() !== newPath.toLowerCase());
      return [...filtered, newFile];
    });

    if (clipboard.op === 'cut') {
      deleteFile(src.id, true);
      setClipboardState(null);
    }

    addNotification('File Explorer', `Đã dán "${newName}" vào ${normTargetDir}`, 'explorer');
    soundManager.playNotification();
    return newFile;
  }, [clipboard, deleteFile, addNotification]);

  // Create Archive file (.rar / .zip / .iso)
  const createArchiveFile = useCallback((sourceItem: FileSystemItem, format: 'rar' | 'zip' | 'iso' = 'rar'): FileSystemItem => {
    const lastSlash = Math.max(sourceItem.path.lastIndexOf('\\'), sourceItem.path.lastIndexOf('/'));
    const parentDir = lastSlash !== -1 ? sourceItem.path.substring(0, lastSlash) : 'C:\\Users\\User\\Desktop';
    const baseName = sourceItem.name.replace(/\.[^/.]+$/, '');
    const archiveName = `${baseName}.${format}`;
    const archivePath = `${parentDir}\\${archiveName}`;

    const archiveItem: FileSystemItem = {
      id: `archive-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name: archiveName,
      path: archivePath,
      isDirectory: false,
      content: `[Tệp lưu trữ ${format.toUpperCase()} nén dữ liệu của: ${sourceItem.name}]`,
      size: Math.round((sourceItem.size || 2048) * 0.65),
      createdAt: Date.now(),
      modifiedAt: Date.now(),
      icon: format === 'iso' ? 'Disc' : 'Archive',
      protectionLevel: 'AN TOÀN XOÁ',
      description: `Tệp nén ${format.toUpperCase()} của ${sourceItem.name}`,
    };

    setFileSystem((prev) => {
      const filtered = prev.filter((f) => f.path.toLowerCase() !== archivePath.toLowerCase());
      return [...filtered, archiveItem];
    });

    addNotification(
      format === 'iso' ? 'PowerISO' : 'WinRAR',
      `Đã tạo tệp nén lưu trữ "${archiveName}" thành công!`,
      'explorer'
    );
    soundManager.playNotification();
    return archiveItem;
  }, [addNotification]);

  // Create Shortcut (.lnk)
  const createShortcutFile = useCallback((sourceItem: FileSystemItem, targetDirPath?: string): FileSystemItem => {
    const lastSlash = Math.max(sourceItem.path.lastIndexOf('\\'), sourceItem.path.lastIndexOf('/'));
    const parentDir = targetDirPath || (lastSlash !== -1 ? sourceItem.path.substring(0, lastSlash) : 'C:\\Users\\User\\Desktop');
    const shortcutName = `${sourceItem.name} - Shortcut.lnk`;
    const shortcutPath = `${parentDir}\\${shortcutName}`;

    const shortcutItem: FileSystemItem = {
      id: `shortcut-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name: shortcutName,
      path: shortcutPath,
      isDirectory: false,
      content: `Shortcut to ${sourceItem.path}`,
      size: 1024,
      createdAt: Date.now(),
      modifiedAt: Date.now(),
      icon: sourceItem.icon || 'CornerUpRight',
      symlinkTarget: sourceItem.path,
      protectionLevel: 'AN TOÀN XOÁ',
      description: `Lối tắt liên kết đến ${sourceItem.path}`,
    };

    setFileSystem((prev) => {
      const filtered = prev.filter((f) => f.path.toLowerCase() !== shortcutPath.toLowerCase());
      return [...filtered, shortcutItem];
    });

    addNotification('Lối tắt (Shortcut)', `Đã tạo lối tắt cho "${sourceItem.name}"`, 'explorer');
    soundManager.playNotification();
    return shortcutItem;
  }, [addNotification]);

  // Copy file to folder
  const copyFileToFolder = useCallback((sourceItem: FileSystemItem, targetDirPath: string): FileSystemItem => {
    const newPath = `${targetDirPath}\\${sourceItem.name}`;
    const newFile: FileSystemItem = {
      ...sourceItem,
      id: `copy-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      path: newPath,
      createdAt: Date.now(),
      modifiedAt: Date.now(),
      protectionLevel: 'AN TOÀN XOÁ',
    };

    setFileSystem((prev) => {
      const filtered = prev.filter((f) => f.path.toLowerCase() !== newPath.toLowerCase());
      return [...filtered, newFile];
    });

    addNotification('Sao chép', `Đã sao chép "${sourceItem.name}" vào ${targetDirPath}`, 'explorer');
    soundManager.playNotification();
    return newFile;
  }, [addNotification]);

  // Pinned Quick Access Folders
  const [pinnedFolders, setPinnedFolders] = useState<string[]>([
    'C:\\Apps',
    'C:\\Users\\User\\Desktop',
    'C:\\Users\\User\\Documents',
    'C:\\Users\\User\\Downloads',
    'C:\\Users\\User\\Pictures',
  ]);

  const pinFolder = useCallback((path: string) => {
    setPinnedFolders((prev) => {
      if (prev.includes(path)) return prev;
      return [...prev, path];
    });
    addNotification('Truy cập nhanh', `Đã ghim "${path}" vào danh sách Truy cập nhanh`, 'explorer');
  }, [addNotification]);

  const unpinFolder = useCallback((path: string) => {
    setPinnedFolders((prev) => prev.filter((p) => p !== path));
    addNotification('Truy cập nhanh', `Đã bỏ ghim "${path}"`, 'explorer');
  }, [addNotification]);

  return (
    <OSContext.Provider
      value={{
        windows,
        activeWindowId,
        openApp,
        closeWindow,
        minimizeWindow,
        maximizeWindow,
        restoreWindow,
        snapWindow,
        focusWindow,
        updateWindowPosition,
        updateWindowSize,
        t,
        currentLang,
        setLanguage,
        isStartOpen,
        setIsStartOpen,
        isSearchOpen,
        setIsSearchOpen,
        isActionCenterOpen,
        setIsActionCenterOpen,
        isWidgetsOpen,
        setIsWidgetsOpen,
        isRunDialogOpen,
        setIsRunDialogOpen,
        isAddAppModalOpen,
        setIsAddAppModalOpen,
        isAltTabOpen,
        setIsAltTabOpen,
        isLockScreen,
        setIsLockScreen,
        isSleeping,
        enterSleepMode,
        wakeUpSystem,
        bootState,
        setBootState,
        restartSystem,
        shutdownSystem,
        powerOnSystem,
        oobeCompleted,
        completeOOBE,
        triggerOOBESetup,
        winREActive,
        winREView,
        safeMode,
        uefiConfig,
        enterWinRE,
        exitWinRE,
        restartToWinRE,
        startSafeMode,
        performPCReset,
        updateUEFIConfig,
        fileSystem,
        addFile,
        deleteFile,
        renameFile,
        updateFileContent,
        createHtmlApp,
        getFilesByDirectory,
        getHtmlApps,
        clipboard,
        setClipboard,
        pasteFile,
        createArchiveFile,
        createShortcutFile,
        copyFileToFolder,
        pinnedFolders,
        pinFolder,
        unpinFolder,
        takeOwnership,
        grantPermission,
        systemFailure,
        triggerSystemFailure,
        clearSystemFailure,
        restoreFromRestorePoint,
        repairStartup,
        resetPCKeepPersonalFiles,
        resetPCRemoveEverything,
        shutdownSystemFailure,
        accessDeniedDialog,
        closeAccessDeniedDialog,
        filePropertiesDialog,
        openFileProperties,
        closeFileProperties,
        defenderScanDialog,
        openDefenderScan,
        closeDefenderScan,
        drivePropertiesDialog,
        openDriveProperties,
        closeDriveProperties,
        settings,
        updateSettings,
        contextMenu,
        showContextMenu,
        closeContextMenu,
        notifications,
        addNotification,
        dismissNotification,
        clearNotifications,
        minimizeAll,
      }}
    >
      {children}
    </OSContext.Provider>
  );
};

export const useOS = () => {
  const context = useContext(OSContext);
  if (!context) {
    throw new Error('useOS must be used within an OSProvider');
  }
  return context;
};
