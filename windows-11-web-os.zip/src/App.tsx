import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'motion/react';
import { OSProvider, useOS } from './context/OSContext';
import { Desktop } from './components/Desktop/Desktop';
import { Taskbar } from './components/Taskbar/Taskbar';
import { StartMenu } from './components/StartMenu/StartMenu';
import { QuickSettings } from './components/Taskbar/QuickSettings';
import { NotificationCenter } from './components/Taskbar/NotificationCenter';
import { WidgetsPanel } from './components/Taskbar/WidgetsPanel';
import { BootScreen } from './components/BootScreen/BootScreen';
import { ContextMenu } from './components/Desktop/ContextMenu';
import { WinRE } from './components/WinRE/WinRE';
import { SystemRecoveryErrorScreen } from './components/SystemRecovery/SystemRecoveryErrorScreen';
import { AccessDeniedModal } from './components/Dialogs/AccessDeniedModal';
import { FilePropertiesModal } from './components/Dialogs/FilePropertiesModal';
import { DefenderScanModal } from './components/Dialogs/DefenderScanModal';
import { DrivePropertiesModal } from './components/Dialogs/DrivePropertiesModal';
import { RunDialogModal } from './components/Dialogs/RunDialogModal';
import { EmojiPickerModal } from './components/Dialogs/EmojiPickerModal';
import { ClipboardHistoryModal } from './components/Dialogs/ClipboardHistoryModal';
import { ProjectFlyoutModal } from './components/Dialogs/ProjectFlyoutModal';
import { AltTabModal } from './components/Dialogs/AltTabModal';
import { VoiceTypingOverlay } from './components/Dialogs/VoiceTypingOverlay';
import { SleepOverlay } from './components/Common/SleepOverlay';
import { LockScreen } from './components/Common/LockScreen';
import { useGlobalShortcuts } from './hooks/useGlobalShortcuts';

const Windows11Shell: React.FC = () => {
  const {
    settings,
    bootState,
    setBootState,
    powerOnSystem,
    shutdownSystem,
    oobeCompleted,
    completeOOBE,
    winREActive,
    winREView,
    exitWinRE,
    startSafeMode,
    performPCReset,
    uefiConfig,
    updateUEFIConfig,
    systemFailure,
    repairStartup,
    restoreFromRestorePoint,
    resetPCKeepPersonalFiles,
    resetPCRemoveEverything,
    shutdownSystemFailure,
    accessDeniedDialog,
    closeAccessDeniedDialog,
    filePropertiesDialog,
    closeFileProperties,
    takeOwnership,
    defenderScanDialog,
    closeDefenderScan,
    drivePropertiesDialog,
    closeDriveProperties,
    openApp,
    addNotification,
    isSleeping,
    wakeUpSystem,
    isLockScreen,
    setIsLockScreen,
  } = useOS();

  const [isStartOpen, setIsStartOpen] = useState(false);
  const [isWidgetsOpen, setIsWidgetsOpen] = useState(false);
  const [isQuickSettingsOpen, setIsQuickSettingsOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  // Shortcut Modals
  const [isRunOpen, setIsRunOpen] = useState(false);
  const [isEmojiOpen, setIsEmojiOpen] = useState(false);
  const [isClipboardOpen, setIsClipboardOpen] = useState(false);
  const [isProjectOpen, setIsProjectOpen] = useState(false);
  const [isAltTabOpen, setIsAltTabOpen] = useState(false);
  const [isVoiceOpen, setIsVoiceOpen] = useState(false);

  const closeAllFlyouts = () => {
    setIsStartOpen(false);
    setIsWidgetsOpen(false);
    setIsQuickSettingsOpen(false);
    setIsNotificationsOpen(false);
  };

  // Full Windows 11 Global Keyboard Shortcuts
  useGlobalShortcuts({
    isStartOpen,
    setIsStartOpen,
    isWidgetsOpen,
    setIsWidgetsOpen,
    isQuickSettingsOpen,
    setIsQuickSettingsOpen,
    isNotificationsOpen,
    setIsNotificationsOpen,
    setIsRunOpen,
    setIsEmojiOpen,
    setIsClipboardOpen,
    setIsProjectOpen,
    setIsAltTabOpen,
    setIsVoiceOpen,
  });

  return (
    <div
      id="win11-os-root"
      className={`fixed inset-0 w-full h-full overflow-hidden font-sans select-none ${
        settings.theme === 'dark' ? 'dark' : ''
      }`}
    >
      {/* Windows 11 Boot / Startup Screen with OEM lenamphuc logo, 4-square logo, and OOBE */}
      <BootScreen
        bootState={bootState}
        oobeCompleted={oobeCompleted}
        userName={settings.userName}
        userEmail={settings.userEmail}
        deviceName={settings.deviceName}
        requireLockOnStartup={Boolean(
          ((settings.hasPin && settings.lockPin) || (settings.hasPassword && settings.password)) &&
          settings.requireLockOnStartup !== false
        )}
        onBootComplete={(shouldLock) => {
          setBootState('desktop');
          if (shouldLock) {
            setIsLockScreen(true);
          }
        }}
        onPowerOn={powerOnSystem}
        onCompleteOOBE={completeOOBE}
      />

      {/* Desktop Canvas & Windows */}
      <Desktop onCloseFlyouts={closeAllFlyouts} />

      {/* Flyouts Dismiss Overlay Backdrop */}
      {(isStartOpen || isWidgetsOpen || isQuickSettingsOpen || isNotificationsOpen) && (
        <div
          id="flyout-dismiss-overlay"
          onClick={closeAllFlyouts}
          className="fixed inset-0 z-35 bg-transparent"
        />
      )}

      {/* Start Menu Flyout */}
      <AnimatePresence>
        {isStartOpen && <StartMenu key="start-menu-flyout" onClose={() => setIsStartOpen(false)} />}
      </AnimatePresence>

      {/* Widgets Board Flyout */}
      {isWidgetsOpen && <WidgetsPanel onClose={() => setIsWidgetsOpen(false)} />}

      {/* Quick Settings (Wi-Fi / Volume / Brightness) */}
      {isQuickSettingsOpen && (
        <QuickSettings onClose={() => setIsQuickSettingsOpen(false)} />
      )}

      {/* Notification Center & Calendar */}
      {isNotificationsOpen && (
        <NotificationCenter onClose={() => setIsNotificationsOpen(false)} />
      )}

      {/* Windows 11 Taskbar */}
      <Taskbar
        isStartOpen={isStartOpen}
        setIsStartOpen={setIsStartOpen}
        isWidgetsOpen={isWidgetsOpen}
        setIsWidgetsOpen={setIsWidgetsOpen}
        isQuickSettingsOpen={isQuickSettingsOpen}
        setIsQuickSettingsOpen={setIsQuickSettingsOpen}
        isNotificationsOpen={isNotificationsOpen}
        setIsNotificationsOpen={setIsNotificationsOpen}
      />

      {/* Windows Recovery Environment (WinRE) */}
      {winREActive && (
        <WinRE
          initialView={winREView}
          onContinue={exitWinRE}
          onTurnOff={shutdownSystem}
          onStartSafeMode={startSafeMode}
          onResetComplete={performPCReset}
          uefiConfig={uefiConfig}
          onUpdateUEFI={updateUEFIConfig}
        />
      )}

      {/* Global Windows 11 Fluent Context Menu */}
      <ContextMenu />

      {/* Access Denied Modal (Truy cập bị từ chối / Không đủ quyền) */}
      <AccessDeniedModal
        isOpen={accessDeniedDialog.isOpen}
        fileItem={accessDeniedDialog.fileItem}
        action={accessDeniedDialog.action}
        onClose={closeAccessDeniedDialog}
        onOpenTerminal={() => openApp('terminal')}
      />

      {/* File / Folder Properties Modal with Security Permissions */}
      <FilePropertiesModal
        isOpen={filePropertiesDialog.isOpen}
        fileItem={filePropertiesDialog.fileItem}
        onClose={closeFileProperties}
        onTakeOwnership={(item) => takeOwnership(item.path)}
      />

      {/* Microsoft Defender Antivirus Scanner */}
      <DefenderScanModal
        isOpen={defenderScanDialog.isOpen}
        targetName={defenderScanDialog.targetName}
        onClose={closeDefenderScan}
      />

      {/* Local Disk Drive Properties */}
      <DrivePropertiesModal
        isOpen={drivePropertiesDialog.isOpen}
        driveLetter={drivePropertiesDialog.driveLetter}
        onClose={closeDriveProperties}
        onDiskCleanup={() => addNotification('Dọn dẹp đĩa', 'Đã xóa các tệp rác tạm thời!', 'info')}
      />

      {/* Windows 11 Shortcuts Modals & Flyouts */}
      {isRunOpen && <RunDialogModal onClose={() => setIsRunOpen(false)} />}
      {isEmojiOpen && <EmojiPickerModal onClose={() => setIsEmojiOpen(false)} />}
      {isClipboardOpen && <ClipboardHistoryModal onClose={() => setIsClipboardOpen(false)} />}
      {isProjectOpen && <ProjectFlyoutModal onClose={() => setIsProjectOpen(false)} />}
      {isAltTabOpen && <AltTabModal onClose={() => setIsAltTabOpen(false)} />}
      {isVoiceOpen && <VoiceTypingOverlay onClose={() => setIsVoiceOpen(false)} />}

      {/* Windows 11 Sleep / Hibernation Fullscreen Overlay */}
      <SleepOverlay isSleeping={isSleeping} onWakeUp={wakeUpSystem} />

      {/* Windows 11 Lock Screen */}
      <LockScreen isLocked={isLockScreen} onUnlock={() => setIsLockScreen(false)} />

      {/* System Recovery Error Screen (Khi xóa file hệ thống mà không khôi phục) */}
      <SystemRecoveryErrorScreen
        isOpen={systemFailure.isFailed}
        fileName={systemFailure.failedFileName}
        filePath={systemFailure.failedFilePath}
        errorCode={systemFailure.errorCode}
        onStartupRepair={repairStartup}
        onSystemRestore={restoreFromRestorePoint}
        onResetKeepFiles={resetPCKeepPersonalFiles}
        onResetRemoveAll={resetPCRemoveEverything}
        onShutdown={shutdownSystemFailure}
      />

      {/* Windows 11 Real Hardware Screen Brightness & Night Light Overlay */}
      <div
        id="win11-hardware-brightness-overlay"
        aria-hidden="true"
        className="fixed inset-0 pointer-events-none z-[99999] transition-all duration-150"
        style={{
          backgroundColor: `rgba(0, 0, 0, ${Math.max(0, (100 - (settings.brightness || 100)) * 0.0075)})`,
          backdropFilter: settings.isNightLight ? 'sepia(25%) saturate(115%) hue-rotate(-12deg)' : undefined,
        }}
      />
    </div>
  );
};

export default function App() {
  return (
    <OSProvider>
      <Windows11Shell />
    </OSProvider>
  );
}
