export type WinREView =
  | 'main'
  | 'use-device'
  | 'troubleshoot'
  | 'reset-option'
  | 'reset-source'
  | 'reset-clean-drive'
  | 'reset-confirm'
  | 'reset-progress'
  | 'advanced-options'
  | 'startup-repair'
  | 'startup-repair-progress'
  | 'startup-repair-result'
  | 'system-restore'
  | 'system-restore-scan'
  | 'system-restore-progress'
  | 'system-image'
  | 'system-image-progress'
  | 'uninstall-updates'
  | 'uninstall-updates-progress'
  | 'command-prompt'
  | 'uefi-settings'
  | 'startup-settings-info'
  | 'startup-settings-menu';

export type SafeModeType = 'none' | 'minimal' | 'network' | 'cmd';

export interface UEFIConfig {
  secureBoot: boolean;
  tpmEnabled: boolean;
  virtualization: boolean;
  fastBoot: boolean;
  xmpProfile: string;
  bootOrder: string[];
  systemDate: string;
  systemTime: string;
}
