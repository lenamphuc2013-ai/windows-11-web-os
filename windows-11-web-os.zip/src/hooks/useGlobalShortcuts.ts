import React, { useEffect, useRef } from 'react';
import { useOS } from '../context/OSContext';
import { soundManager } from '../utils/sound';

interface GlobalShortcutsOptions {
  isStartOpen: boolean;
  setIsStartOpen: React.Dispatch<React.SetStateAction<boolean>>;
  isWidgetsOpen: boolean;
  setIsWidgetsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  isQuickSettingsOpen: boolean;
  setIsQuickSettingsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  isNotificationsOpen: boolean;
  setIsNotificationsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setIsRunOpen: (open: boolean) => void;
  setIsEmojiOpen: (open: boolean) => void;
  setIsClipboardOpen: (open: boolean) => void;
  setIsProjectOpen: (open: boolean) => void;
  setIsAltTabOpen: (open: boolean) => void;
  setIsVoiceOpen: (open: boolean) => void;
}

export function useGlobalShortcuts({
  isStartOpen,
  setIsStartOpen,
  isWidgetsOpen,
  setIsWidgetsOpen,
  isQuickSettingsOpen,
  setIsQuickSettingsOpen,
  isNotificationsOpen,
  setIsNotificationsOpen,
  setIsRunOpen,
  setIsEmojiOpen,
  setIsClipboardOpen,
  setIsProjectOpen,
  setIsAltTabOpen,
  setIsVoiceOpen,
}: GlobalShortcutsOptions) {
  const {
    windows,
    activeWindowId,
    focusWindow,
    minimizeWindow,
    closeWindow,
    openApp,
    isLockScreen,
    setIsLockScreen,
    bootState,
    isSleeping,
    winREActive,
    systemFailure,
    addNotification,
    updateWindowPosition,
  } = useOS();

  // Track if a Windows Key combination was triggered during the current keydown cycle
  const metaComboUsedRef = useRef(false);
  const metaKeyDownTimeRef = useRef(0);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // ONLY trigger shortcuts when user is actively inside Windows Desktop
      // (Not during boot, shutdown, restarting, sleep mode, recovery screen, or WinRE)
      if (bootState !== 'desktop' || isSleeping || winREActive || systemFailure.isFailed) {
        return;
      }

      // When the lock screen is active, hotkeys should not open desktop flyouts or apps
      if (isLockScreen) {
        return;
      }

      const isMeta = e.metaKey || e.key === 'Meta' || e.key === 'OS';
      const isCtrl = e.ctrlKey;
      const isAlt = e.altKey;
      const isShift = e.shiftKey;
      const key = e.key.toLowerCase();

      // Track Meta key down
      if (e.key === 'Meta' || e.key === 'OS') {
        metaComboUsedRef.current = false;
        metaKeyDownTimeRef.current = Date.now();
        return;
      }

      // Escape -> Close all flyouts & overlays
      if (e.key === 'Escape') {
        setIsStartOpen(false);
        setIsWidgetsOpen(false);
        setIsQuickSettingsOpen(false);
        setIsNotificationsOpen(false);
        setIsRunOpen(false);
        setIsEmojiOpen(false);
        setIsClipboardOpen(false);
        setIsProjectOpen(false);
        setIsAltTabOpen(false);
        setIsVoiceOpen(false);
        return;
      }

      // Windows Key + Combination hotkeys (Win+...)
      if (isMeta) {
        metaComboUsedRef.current = true;

        // Win + A: Quick Settings (Action Center)
        if (key === 'a') {
          e.preventDefault();
          setIsQuickSettingsOpen((prev) => !prev);
          setIsStartOpen(false);
          setIsNotificationsOpen(false);
          return;
        }

        // Win + B: Focus Notification area
        if (key === 'b') {
          e.preventDefault();
          setIsQuickSettingsOpen(true);
          return;
        }

        // Win + C: Microsoft Copilot AI
        if (key === 'c') {
          e.preventDefault();
          openApp('copilot');
          return;
        }

        // Win + D: Toggle Show / Hide Desktop
        if (key === 'd') {
          e.preventDefault();
          const allMinimized = windows.length > 0 && windows.every((w) => w.isMinimized);
          if (allMinimized) {
            windows.forEach((w) => focusWindow(w.id));
          } else {
            windows.forEach((w) => minimizeWindow(w.id));
          }
          return;
        }

        // Win + E: File Explorer
        if (key === 'e') {
          e.preventDefault();
          openApp('explorer');
          return;
        }

        // Win + F: Feedback Hub
        if (key === 'f') {
          e.preventDefault();
          addNotification('Feedback Hub', 'Cảm ơn bạn đã đóng góp phản hồi cho Windows 11!', 'system');
          return;
        }

        // Win + G: Xbox Game Bar
        if (key === 'g') {
          e.preventDefault();
          openApp('xbox');
          return;
        }

        // Win + H: Voice Typing
        if (key === 'h') {
          e.preventDefault();
          setIsVoiceOpen(true);
          return;
        }

        // Win + I: Settings
        if (key === 'i') {
          e.preventDefault();
          openApp('settings');
          return;
        }

        // Win + K: Wireless display / Cast
        if (key === 'k') {
          e.preventDefault();
          setIsProjectOpen(true);
          return;
        }

        // Win + L: Lock computer
        if (key === 'l') {
          e.preventDefault();
          setIsLockScreen(true);
          return;
        }

        // Win + M: Minimize all windows
        if (key === 'm') {
          e.preventDefault();
          if (isShift) {
            // Win + Shift + M: Restore all
            windows.forEach((w) => focusWindow(w.id));
          } else {
            windows.forEach((w) => minimizeWindow(w.id));
          }
          return;
        }

        // Win + N: Notification Center + Calendar
        if (key === 'n') {
          e.preventDefault();
          setIsNotificationsOpen((prev) => !prev);
          setIsStartOpen(false);
          setIsQuickSettingsOpen(false);
          return;
        }

        // Win + P: Project display
        if (key === 'p') {
          e.preventDefault();
          setIsProjectOpen(true);
          return;
        }

        // Win + Q or Win + S: Search
        if (key === 'q' || key === 's') {
          e.preventDefault();
          setIsStartOpen(true);
          return;
        }

        // Win + R: Run Dialog
        if (key === 'r') {
          e.preventDefault();
          setIsRunOpen(true);
          return;
        }

        // Win + U: Accessibility / Settings
        if (key === 'u') {
          e.preventDefault();
          openApp('settings');
          return;
        }

        // Win + V: Clipboard History
        if (key === 'v') {
          e.preventDefault();
          setIsClipboardOpen(true);
          return;
        }

        // Win + W: Widgets Board
        if (key === 'w') {
          e.preventDefault();
          setIsWidgetsOpen((prev) => !prev);
          return;
        }

        // Win + X: Win+X Quick Link Menu / Start Menu
        if (key === 'x') {
          e.preventDefault();
          setIsStartOpen(true);
          return;
        }

        // Win + . or Win + ;: Emoji Picker
        if (key === '.' || key === ';' || key === 'period') {
          e.preventDefault();
          setIsEmojiOpen(true);
          return;
        }

        // Win + Shift + S: Snipping Tool
        if (isShift && key === 's') {
          e.preventDefault();
          openApp('snippingtool');
          return;
        }

        // Win + Number (1-9): Open corresponding pinned app
        const num = parseInt(key, 10);
        if (!isNaN(num) && num >= 1 && num <= 9) {
          e.preventDefault();
          const pinnedApps = ['explorer', 'edge', 'store', 'settings', 'notepad', 'calculator', 'terminal', 'photos', 'paint'];
          if (pinnedApps[num - 1]) {
            openApp(pinnedApps[num - 1]);
          }
          return;
        }

        // Win + Arrow Snap Shortcuts
        if (activeWindowId) {
          const win = windows.find((w) => w.id === activeWindowId);
          if (win) {
            if (e.key === 'ArrowLeft') {
              e.preventDefault();
              updateWindowPosition(win.id, {
                x: 0,
                y: 0,
                width: Math.floor(window.innerWidth / 2),
                height: window.innerHeight - 48,
              });
              return;
            }
            if (e.key === 'ArrowRight') {
              e.preventDefault();
              updateWindowPosition(win.id, {
                x: Math.floor(window.innerWidth / 2),
                y: 0,
                width: Math.floor(window.innerWidth / 2),
                height: window.innerHeight - 48,
              });
              return;
            }
            if (e.key === 'ArrowUp') {
              e.preventDefault();
              updateWindowPosition(win.id, {
                x: 0,
                y: 0,
                width: window.innerWidth,
                height: window.innerHeight - 48,
              });
              return;
            }
            if (e.key === 'ArrowDown') {
              e.preventDefault();
              minimizeWindow(win.id);
              return;
            }
          }
        }
      }

      // Ctrl + Shift + Esc -> Task Manager
      if (isCtrl && isShift && e.key === 'Escape') {
        e.preventDefault();
        openApp('taskmanager');
        return;
      }

      // Alt + Tab -> Window Switcher
      if (isAlt && key === 'tab') {
        e.preventDefault();
        setIsAltTabOpen(true);
        return;
      }

      // Alt + L or Ctrl + Alt + L -> Lock Screen fallback (in case browser blocks Win+L)
      if ((isAlt && key === 'l') || (isCtrl && isAlt && key === 'l')) {
        e.preventDefault();
        setIsLockScreen(true);
        return;
      }

      // Alt + F4 -> Close active window or trigger Start Menu
      if (isAlt && e.key === 'F4') {
        e.preventDefault();
        if (activeWindowId) {
          closeWindow(activeWindowId);
        } else {
          setIsStartOpen(true);
        }
        return;
      }

      // PrintScreen / Win + PrtSc -> Take Screenshot
      if (e.key === 'PrintScreen') {
        e.preventDefault();
        soundManager.playCameraShutter();
        addNotification('Ảnh chụp màn hình (Screenshot)', 'Đã lưu ảnh chụp màn hình vào thư mục Pictures\\Screenshots', 'photos');
        return;
      }

      // F11 -> Fullscreen toggle
      if (e.key === 'F11') {
        e.preventDefault();
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().catch(() => {});
        } else {
          document.exitFullscreen().catch(() => {});
        }
        return;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      // Check if user is actively in Windows desktop
      if (bootState !== 'desktop' || isSleeping || isLockScreen || winREActive || systemFailure.isFailed) {
        return;
      }

      // Single Windows Key tap (Meta / OS key released without combining another key)
      if (e.key === 'Meta' || e.key === 'OS') {
        if (!metaComboUsedRef.current) {
          e.preventDefault();
          setIsStartOpen((prev) => !prev);
          setIsWidgetsOpen(false);
          setIsQuickSettingsOpen(false);
          setIsNotificationsOpen(false);
        }
        metaComboUsedRef.current = false;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [
    windows,
    activeWindowId,
    focusWindow,
    minimizeWindow,
    closeWindow,
    openApp,
    isLockScreen,
    setIsLockScreen,
    bootState,
    isSleeping,
    winREActive,
    systemFailure,
    addNotification,
    updateWindowPosition,
    setIsStartOpen,
    setIsWidgetsOpen,
    setIsQuickSettingsOpen,
    setIsNotificationsOpen,
    setIsRunOpen,
    setIsEmojiOpen,
    setIsClipboardOpen,
    setIsProjectOpen,
    setIsAltTabOpen,
    setIsVoiceOpen,
  ]);
}
