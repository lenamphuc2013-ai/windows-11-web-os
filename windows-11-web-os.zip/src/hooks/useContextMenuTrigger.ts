import React, { useRef, useCallback } from 'react';

interface UseContextMenuOptions {
  onTrigger: (coords: { x: number; y: number }) => void;
  holdDuration?: number;
}

export function useContextMenuTrigger({
  onTrigger,
  holdDuration = 400,
}: UseContextMenuOptions) {
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const startPosRef = useRef<{ x: number; y: number } | null>(null);
  const isTriggeredRef = useRef<boolean>(false);
  const resetTimerRef = useRef<NodeJS.Timeout | null>(null);

  const clearTimer = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const handleContextMenu = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      clearTimer();
      onTrigger({ x: e.clientX, y: e.clientY });
    },
    [clearTimer, onTrigger]
  );

  const handleTouchStart = useCallback(
    (e: React.TouchEvent) => {
      if (e.touches.length !== 1) {
        clearTimer();
        return;
      }

      const touch = e.touches[0];
      startPosRef.current = { x: touch.clientX, y: touch.clientY };
      isTriggeredRef.current = false;

      clearTimer();
      timerRef.current = setTimeout(() => {
        isTriggeredRef.current = true;
        // Haptic feedback for mobile devices
        if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
          try {
            navigator.vibrate(50);
          } catch (_) {}
        }
        onTrigger({ x: touch.clientX, y: touch.clientY });

        // Reset after 400ms to allow normal clicks later
        if (resetTimerRef.current) clearTimeout(resetTimerRef.current);
        resetTimerRef.current = setTimeout(() => {
          isTriggeredRef.current = false;
        }, 400);
      }, holdDuration);
    },
    [clearTimer, holdDuration, onTrigger]
  );

  const handleTouchMove = useCallback(
    (e: React.TouchEvent) => {
      if (!startPosRef.current || e.touches.length !== 1) return;
      const touch = e.touches[0];
      const dx = touch.clientX - startPosRef.current.x;
      const dy = touch.clientY - startPosRef.current.y;
      // Allow slight finger movement jitter (28px tolerance on touchscreens)
      if (Math.hypot(dx, dy) > 28) {
        clearTimer();
      }
    },
    [clearTimer]
  );

  const handleTouchEnd = useCallback(() => {
    clearTimer();
    if (isTriggeredRef.current) {
      // Keep isTriggered true for 250ms to swallow synthetic click after long press
      if (resetTimerRef.current) clearTimeout(resetTimerRef.current);
      resetTimerRef.current = setTimeout(() => {
        isTriggeredRef.current = false;
      }, 250);
    }
  }, [clearTimer]);

  const handleTouchCancel = useCallback(() => {
    clearTimer();
    isTriggeredRef.current = false;
  }, [clearTimer]);

  // Pure DOM event handlers object without custom non-DOM fields
  const touchProps = {
    onContextMenu: handleContextMenu,
    onTouchStart: handleTouchStart,
    onTouchMove: handleTouchMove,
    onTouchEnd: handleTouchEnd,
    onTouchCancel: handleTouchCancel,
  };

  return {
    touchProps,
    isTriggeredRef,
    onContextMenu: handleContextMenu,
    onTouchStart: handleTouchStart,
    onTouchMove: handleTouchMove,
    onTouchEnd: handleTouchEnd,
    onTouchCancel: handleTouchCancel,
  };
}
