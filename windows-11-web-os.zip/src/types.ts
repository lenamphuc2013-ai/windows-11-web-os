export type AppId =
  | 'explorer'
  | 'settings'
  | 'control'
  | 'edge'
  | 'terminal'
  | 'notepad'
  | 'calc'
  | 'paint'
  | 'store'
  | 'copilot'
  | 'taskmanager'
  | 'photos'
  | 'appsfolder'
  | 'widgets'
  | 'run'
  | 'clock'
  | 'mediaplayer'
  | 'camera'
  | 'snippingtool'
  | 'weather'
  | 'maps'
  | 'youtube'
  | 'voicerecorder'
  | 'app-runner'
  | string;

export interface AppDefinition {
  id: AppId;
  name: string;
  icon: string;
  iconType?: 'lucide' | 'image' | 'emoji' | 'svg';
  color?: string;
  category?: 'productivity' | 'utilities' | 'entertainment' | 'system' | 'custom';
  description?: string;
  pinnedToTaskbar?: boolean;
  pinnedToStart?: boolean;
  defaultWidth?: number;
  defaultHeight?: number;
  isHtmlApp?: boolean;
  htmlContent?: string;
  filePath?: string;
  windowBackdrop?: 'mica' | 'acrylic' | 'slate' | 'canvas' | 'ambient' | 'glow';
}

export type SnapType =
  | 'left'
  | 'right'
  | 'top'
  | 'top-left'
  | 'top-right'
  | 'bottom-left'
  | 'bottom-right'
  | null;

export interface WindowItem {
  id: string;
  appId: AppId;
  title: string;
  icon: string;
  iconType?: 'lucide' | 'image' | 'emoji' | 'svg';
  isMinimized: boolean;
  isMaximized: boolean;
  position: { x: number; y: number };
  size: { width: number; height: number };
  previousBounds?: { x: number; y: number; width: number; height: number };
  zIndex: number;
  snapType?: SnapType;
  windowBackdrop?: 'mica' | 'acrylic' | 'slate' | 'canvas' | 'ambient' | 'glow';
  accentTint?: string;
  customData?: {
    htmlContent?: string;
    filePath?: string;
    appName?: string;
    initialPath?: string;
    fileContent?: string;
    imageUrl?: string;
    fileName?: string;
    content?: string;
    [key: string]: any;
  };
  data?: any;
}

export type SystemProtectionLevel = 'KHÔNG XOÁ' | 'BẢO VỆ' | 'CẨN THẬN' | 'AN TOÀN XOÁ';

export interface FileSystemItem {
  id: string;
  name: string;
  path: string; // e.g. "C:\\Apps\\FlappyBird.html"
  isDirectory: boolean;
  content?: string;
  size?: number; // in bytes
  createdAt: number;
  modifiedAt: number;
  lastAccessedAt?: number;
  icon?: string;
  iconType?: 'lucide' | 'image' | 'emoji';
  isHtmlApp?: boolean;
  isSystem?: boolean;
  isReadOnly?: boolean;
  hidden?: boolean;
  owner?: 'TrustedInstaller' | 'SYSTEM' | 'Administrators' | 'User' | string;
  icaclsGranted?: boolean; // Granted Administrators:F full control
  isCriticalSystemFile?: boolean; // ntoskrnl.exe, boot, config, WinSxS
  protectionLevel?: SystemProtectionLevel;
  description?: string;
  symlinkTarget?: string;
  associatedApp?: AppId;
  appMetadata?: {
    title: string;
    icon: string;
    iconType?: 'lucide' | 'image' | 'emoji';
    category?: string;
    version?: string;
    description?: string;
  };
}

export interface SystemFailureState {
  isFailed: boolean;
  failedFileName?: string;
  failedFilePath?: string;
  errorCode?: string;
  errorDescription?: string;
}

export interface AccessDeniedDialogState {
  isOpen: boolean;
  fileItem?: FileSystemItem;
  action?: 'delete' | 'rename' | 'move';
}

export interface FilePropertiesDialogState {
  isOpen: boolean;
  fileItem?: FileSystemItem;
}

export interface DefenderScanDialogState {
  isOpen: boolean;
  targetName?: string;
  isScanning?: boolean;
  scanFinished?: boolean;
}

export interface DrivePropertiesDialogState {
  isOpen: boolean;
  driveLetter: 'C' | 'D';
}

export type BootState =
  | 'oem_boot'
  | 'booting'
  | 'oobe'
  | 'oobe_finishing'
  | 'welcome'
  | 'desktop'
  | 'restarting'
  | 'shutting_down'
  | 'shutdown';

export interface SystemSettings {
  theme: 'dark' | 'light';
  wallpaper: string;
  customWallpaperUrl?: string;
  accentColor: string;
  taskbarAlignment: 'center' | 'left';
  soundEnabled: boolean;
  volume: number;
  brightness: number;
  isWifiOn: boolean;
  isBluetoothOn: boolean;
  isAirplaneMode: boolean;
  isNightLight: boolean;
  isBatterySaver: boolean;
  searchEngine: string;
  scale: number;
  autoHideTaskbar: boolean;
  // OOBE & Device Identity
  deviceName: string;
  userName: string;
  userEmail: string;
  region: string;
  keyboardLayout: string;
  language?: 'vi' | 'en' | 'ja' | 'ko' | 'fr' | 'de' | 'zh';
  wifiNetwork?: string;
  oobeCompleted: boolean;
  // Lock Screen & Sign-in Authentication Configuration
  lockScreenWallpaper?: string;
  lockScreenType?: 'spotlight' | 'picture' | 'desktop';
  requireLockOnStartup?: boolean;
  hasLockScreen?: boolean;
  hasPin?: boolean;
  lockPin?: string;
  hasPassword?: boolean;
  password?: string;
  passwordHint?: string;
  authMethod?: 'pin' | 'password';
  requireLockPin?: boolean;
  lockScreenStatusWidget?: 'weather' | 'calendar' | 'none';
  showLockBackgroundOnSignIn?: boolean;
}

export interface ContextMenuItem {
  id: string;
  label: string;
  icon?: string;
  iconComponent?: any;
  shortcut?: string;
  disabled?: boolean;
  danger?: boolean;
  checked?: boolean;
  separator?: boolean;
  header?: string;
  onClick?: () => void;
  submenu?: ContextMenuItem[];
}

export interface ContextMenuState {
  isOpen: boolean;
  x: number;
  y: number;
  items: ContextMenuItem[];
  targetType?: 'desktop' | 'taskbar' | 'file' | 'start' | 'window';
  targetData?: any;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: Date | string;
  appId?: string;
  appIcon?: string;
  icon?: string;
  unread: boolean;
}

export interface VirtualDesktop {
  id: number;
  name: string;
  wallpaper?: string;
}
