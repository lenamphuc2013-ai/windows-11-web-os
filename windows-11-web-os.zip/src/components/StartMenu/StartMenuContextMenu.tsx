import React, { useState, useEffect, useRef } from 'react';
import {
  Pin,
  PinOff,
  MoreHorizontal,
  ChevronRight,
  FolderOpen,
  Link2,
  Trash2,
  Edit3,
  Trash,
  Copy,
  Zap,
  FileText,
  Sliders,
  Check,
} from 'lucide-react';
import { AppContextTarget } from '../../utils/startMenuAppHelpers';

interface StartMenuContextMenuProps {
  target: AppContextTarget;
  position: { x: number; y: number };
  isStartup: boolean;
  onClose: () => void;
  onTogglePin: () => void;
  onOpenFileLocation: () => void;
  onCopyPath: () => void;
  onUninstall: () => void;
  onRename: () => void;
  onDelete: () => void;
  onCopy: () => void;
  onToggleStartup: () => void;
  onProperties: () => void;
}

export const StartMenuContextMenu: React.FC<StartMenuContextMenuProps> = ({
  target,
  position,
  isStartup,
  onClose,
  onTogglePin,
  onOpenFileLocation,
  onCopyPath,
  onUninstall,
  onRename,
  onDelete,
  onCopy,
  onToggleStartup,
  onProperties,
}) => {
  const [isMoreHovered, setIsMoreHovered] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const moreItemRef = useRef<HTMLDivElement>(null);

  // Position calculation to ensure menu stays within viewport
  const [adjustedPos, setAdjustedPos] = useState({ x: position.x, y: position.y });
  const [submenuSide, setSubmenuSide] = useState<'right' | 'left'>('right');

  useEffect(() => {
    const menuWidth = 240;
    const menuHeight = 350;
    const screenWidth = window.innerWidth;
    const screenHeight = window.innerHeight;

    let x = position.x;
    let y = position.y;

    if (x + menuWidth > screenWidth - 10) {
      x = screenWidth - menuWidth - 10;
    }
    if (y + menuHeight > screenHeight - 10) {
      y = screenHeight - menuHeight - 10;
    }

    if (x + menuWidth + 200 > screenWidth) {
      setSubmenuSide('left');
    } else {
      setSubmenuSide('right');
    }

    setAdjustedPos({ x, y });
  }, [position]);

  return (
    <>
      {/* Backdrop for click outside dismissal */}
      <div
        className="fixed inset-0 z-[120] bg-transparent"
        onClick={(e) => {
          e.stopPropagation();
          onClose();
        }}
        onContextMenu={(e) => {
          e.preventDefault();
          e.stopPropagation();
          onClose();
        }}
      />

      {/* Main Context Menu */}
      <div
        ref={menuRef}
        onClick={(e) => e.stopPropagation()}
        style={{
          left: `${adjustedPos.x}px`,
          top: `${adjustedPos.y}px`,
        }}
        className="fixed z-[125] min-w-[240px] bg-[#1f1f1f]/95 dark:bg-[#1c1c1c]/95 backdrop-blur-2xl text-white rounded-xl shadow-2xl shadow-black/80 border border-white/10 p-1.5 text-[12.5px] select-none animate-win11-flyin"
      >
        {/* 1. Ghim vào màn hình Bắt đầu */}
        <div
          onClick={() => {
            onTogglePin();
            onClose();
          }}
          className="flex items-center gap-3 px-2.5 py-1.5 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer text-slate-100 hover:text-white"
        >
          {target.isPinned ? (
            <PinOff size={15} className="text-slate-300 shrink-0" />
          ) : (
            <Pin size={15} className="text-slate-300 shrink-0" />
          )}
          <span className="truncate">
            {target.isPinned ? 'Bỏ ghim khỏi màn hình Bắt đầu' : 'Ghim vào màn hình Bắt đầu'}
          </span>
        </div>

        {/* 2. More with Submenu */}
        <div
          ref={moreItemRef}
          onMouseEnter={() => setIsMoreHovered(true)}
          onMouseLeave={() => setIsMoreHovered(false)}
          className="relative"
        >
          <div className="flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer text-slate-100 hover:text-white">
            <div className="flex items-center gap-3">
              <MoreHorizontal size={15} className="text-slate-300 shrink-0" />
              <span>More</span>
            </div>
            <ChevronRight size={13} className="text-slate-400 shrink-0" />
          </div>

          {/* Submenu */}
          {isMoreHovered && (
            <div
              className={`absolute top-0 ${
                submenuSide === 'right' ? 'left-full ml-1' : 'right-full mr-1'
              } min-w-[200px] bg-[#1f1f1f]/95 dark:bg-[#1c1c1c]/95 backdrop-blur-2xl text-white rounded-xl shadow-2xl shadow-black/80 border border-white/10 p-1.5 text-[12.5px] select-none animate-win11-fade`}
            >
              {/* Mở vị trí tệp */}
              <div
                onClick={() => {
                  onOpenFileLocation();
                  onClose();
                }}
                className="flex items-center gap-3 px-2.5 py-1.5 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer text-slate-100 hover:text-white"
              >
                <FolderOpen size={15} className="text-slate-300 shrink-0" />
                <span className="truncate">Mở vị trí tệp</span>
              </div>

              {/* Đường dẫn đến tệp */}
              <div
                onClick={() => {
                  onCopyPath();
                  onClose();
                }}
                className="flex items-center gap-3 px-2.5 py-1.5 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer text-slate-100 hover:text-white"
              >
                <Link2 size={15} className="text-slate-300 shrink-0" />
                <span className="truncate">Đường dẫn đến tệp</span>
              </div>
            </div>
          )}
        </div>

        <div className="my-1 border-t border-white/10" />

        {/* 3. Gỡ cài đặt */}
        <div
          onClick={() => {
            onUninstall();
            onClose();
          }}
          className="flex items-center gap-3 px-2.5 py-1.5 rounded-lg hover:bg-rose-500/20 active:bg-rose-500/30 transition-colors cursor-pointer text-rose-300 hover:text-rose-200"
        >
          <Trash2 size={15} className="text-rose-400 shrink-0" />
          <span className="truncate">Gỡ cài đặt</span>
        </div>

        {/* 4. Đổi tên */}
        <div
          onClick={() => {
            onRename();
            onClose();
          }}
          className="flex items-center gap-3 px-2.5 py-1.5 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer text-slate-100 hover:text-white"
        >
          <Edit3 size={15} className="text-slate-300 shrink-0" />
          <span className="truncate">Đổi tên</span>
        </div>

        {/* 5. Xóa */}
        <div
          onClick={() => {
            onDelete();
            onClose();
          }}
          className="flex items-center gap-3 px-2.5 py-1.5 rounded-lg hover:bg-rose-500/20 active:bg-rose-500/30 transition-colors cursor-pointer text-rose-300 hover:text-rose-200"
        >
          <Trash size={15} className="text-rose-400 shrink-0" />
          <span className="truncate">Xóa</span>
        </div>

        <div className="my-1 border-t border-white/10" />

        {/* 6. Sao chép */}
        <div
          onClick={() => {
            onCopy();
            onClose();
          }}
          className="flex items-center gap-3 px-2.5 py-1.5 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer text-slate-100 hover:text-white"
        >
          <Copy size={15} className="text-slate-300 shrink-0" />
          <span className="truncate">Sao chép</span>
        </div>

        {/* 7. Tính toán bắt đầu khi khởi động */}
        <div
          onClick={() => {
            onToggleStartup();
            onClose();
          }}
          className="flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer text-slate-100 hover:text-white"
        >
          <div className="flex items-center gap-3 truncate">
            <Zap size={15} className={isStartup ? 'text-amber-400 shrink-0' : 'text-slate-300 shrink-0'} />
            <span className="truncate">Tính toán bắt đầu khi khởi động</span>
          </div>
          {isStartup && <Check size={14} className="text-sky-400 shrink-0 ml-1" />}
        </div>

        {/* 8. Đường dẫn tệp */}
        <div
          onClick={() => {
            onCopyPath();
            onClose();
          }}
          className="flex items-center gap-3 px-2.5 py-1.5 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer text-slate-100 hover:text-white"
        >
          <FileText size={15} className="text-slate-300 shrink-0" />
          <span className="truncate">Đường dẫn tệp</span>
        </div>

        <div className="my-1 border-t border-white/10" />

        {/* 9. Thuộc tính */}
        <div
          onClick={() => {
            onProperties();
            onClose();
          }}
          className="flex items-center gap-3 px-2.5 py-1.5 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer text-slate-100 hover:text-white"
        >
          <Sliders size={15} className="text-slate-300 shrink-0" />
          <span className="truncate">Thuộc tính</span>
        </div>
      </div>
    </>
  );
};
