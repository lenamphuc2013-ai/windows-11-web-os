import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useOS } from '../../context/OSContext';
import { BUILTIN_APPS, getLocalizedAppName } from '../../utils/appRegistry';
import { IconRenderer } from '../Common/IconRenderer';
import {
  Search,
  ChevronRight,
  Power,
  Sparkles,
  RotateCcw,
  Moon,
  Folder,
  Lock,
  Settings as SettingsIcon,
  LogOut,
  User,
} from 'lucide-react';
import { StartMenuContextMenu } from './StartMenuContextMenu';
import { StartMenuRenameModal } from './StartMenuRenameModal';
import { getAppFileItem, AppContextTarget } from '../../utils/startMenuAppHelpers';
import { FileSystemItem } from '../../types';

interface StartMenuProps {
  onClose: () => void;
}

const STORAGE_KEY_PINNED_APPS = 'win11_start_pinned_apps';
const STORAGE_KEY_STARTUP_APPS = 'win11_startup_apps';

export const StartMenu: React.FC<StartMenuProps> = ({ onClose }) => {
  const {
    openApp,
    fileSystem,
    settings,
    setIsAddAppModalOpen,
    restartSystem,
    shutdownSystem,
    restartToWinRE,
    enterSleepMode,
    deleteFile,
    renameFile,
    setClipboard,
    openFileProperties,
    addNotification,
    setIsLockScreen,
    t,
  } = useOS();

  const [search, setSearch] = useState('');
  const [showAllApps, setShowAllApps] = useState(false);
  const [showPowerMenu, setShowPowerMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  // Dynamic Pinned App IDs
  const [pinnedAppIds, setPinnedAppIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PINNED_APPS);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return BUILTIN_APPS.filter((a) => a.isPinned).map((a) => a.id);
  });

  // Startup App IDs
  const [startupAppIds, setStartupAppIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_STARTUP_APPS);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return ['security', 'copilot'];
  });

  // Context Menu State
  const [contextMenuState, setContextMenuState] = useState<{
    isOpen: boolean;
    target: AppContextTarget | null;
    position: { x: number; y: number };
  }>({
    isOpen: false,
    target: null,
    position: { x: 0, y: 0 },
  });

  // Rename Modal State
  const [renameModalState, setRenameModalState] = useState<{
    isOpen: boolean;
    target: AppContextTarget | null;
  }>({
    isOpen: false,
    target: null,
  });

  const savePinnedApps = (ids: string[]) => {
    setPinnedAppIds(ids);
    try {
      localStorage.setItem(STORAGE_KEY_PINNED_APPS, JSON.stringify(ids));
    } catch (e) {}
  };

  const saveStartupApps = (ids: string[]) => {
    setStartupAppIds(ids);
    try {
      localStorage.setItem(STORAGE_KEY_STARTUP_APPS, JSON.stringify(ids));
    } catch (e) {}
  };

  // Custom HTML apps in C:\Apps
  const htmlApps = fileSystem.filter((f) => f.isHtmlApp);

  // Pinned built-ins based on dynamic pinned list
  const pinnedBuiltins = BUILTIN_APPS.filter((a) => pinnedAppIds.includes(a.id));

  // Pinned HTML apps
  const pinnedHtmlApps = htmlApps.filter((a) => pinnedAppIds.includes(a.id) || pinnedAppIds.includes(a.path));

  // Filtered for search
  const filteredBuiltins = BUILTIN_APPS.filter((a) => {
    const q = search.trim().toLowerCase();
    if (!q) return false;
    const loc = (getLocalizedAppName(a.id, t) || '').toLowerCase();
    const title = (a.title || '').toLowerCase();
    const name = (a.name || '').toLowerCase();
    const id = a.id.toLowerCase();
    const desc = (a.description || '').toLowerCase();

    if (a.id === 'winver' && (q === 'winver' || q === 'winver.exe' || q.includes('ver') || q.includes('about') || q.includes('giới thiệu'))) {
      return true;
    }
    if (a.id === 'dxdiag' && (q === 'dxdiag' || q === 'dxdiag.exe' || q.includes('directx') || q.includes('chẩn đoán') || q.includes('diagnostic'))) {
      return true;
    }
    return loc.includes(q) || title.includes(q) || name.includes(q) || id.includes(q) || desc.includes(q);
  });

  const filteredHtmlApps = htmlApps.filter((a) =>
    (a.appMetadata?.title || a.name).toLowerCase().includes(search.toLowerCase())
  );

  const filteredDocs = fileSystem.filter(
    (f) =>
      !f.isHtmlApp &&
      !f.isDirectory &&
      f.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleLaunchApp = (appId: string) => {
    openApp(appId);
    onClose();
  };

  const handleLaunchHtml = (filePath: string, title: string) => {
    openApp('app-runner', {
      filePath,
      appName: title,
    });
    onClose();
  };

  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const q = search.trim().toLowerCase();
      if (!q) return;

      if (q === 'winver' || q === 'winver.exe') {
        handleLaunchApp('winver');
        return;
      }

      if (q === 'dxdiag' || q === 'dxdiag.exe') {
        handleLaunchApp('dxdiag');
        return;
      }

      if (filteredBuiltins.length > 0) {
        handleLaunchApp(filteredBuiltins[0].id);
        return;
      }

      if (filteredHtmlApps.length > 0) {
        handleLaunchHtml(filteredHtmlApps[0].path, filteredHtmlApps[0].appMetadata?.title || filteredHtmlApps[0].name);
        return;
      }

      if (filteredDocs.length > 0) {
        openApp('notepad', { filePath: filteredDocs[0].path, content: filteredDocs[0].content });
        onClose();
        return;
      }
    }
  };

  // Context Menu Trigger Handler
  const handleAppContextMenu = (
    e: React.MouseEvent,
    app: any,
    type: 'builtin' | 'html' | 'doc' | 'folder'
  ) => {
    e.preventDefault();
    e.stopPropagation();

    let target: AppContextTarget;

    if (type === 'builtin') {
      const fileItem = getAppFileItem(app, fileSystem);
      const isPinned = pinnedAppIds.includes(app.id);
      target = {
        id: app.id,
        name: getLocalizedAppName(app.id, t) || app.name || app.title,
        title: getLocalizedAppName(app.id, t) || app.title || app.name,
        icon: app.icon,
        path: fileItem.path,
        isHtmlApp: false,
        isBuiltIn: true,
        isPinned,
        fileItem,
      };
    } else if (type === 'html') {
      const isPinned = pinnedAppIds.includes(app.id) || pinnedAppIds.includes(app.path);
      target = {
        id: app.id,
        name: app.appMetadata?.title || app.name,
        title: app.appMetadata?.title || app.name,
        icon: app.appMetadata?.icon || app.icon || 'FileCode',
        path: app.path,
        isHtmlApp: true,
        isBuiltIn: false,
        isPinned,
        fileItem: app,
      };
    } else if (type === 'folder') {
      const folderItem: FileSystemItem = {
        id: 'folder-apps',
        name: 'Apps',
        path: 'C:\\Apps',
        isDirectory: true,
        icon: 'Folder',
        createdAt: Date.now() - 86400000 * 30,
        modifiedAt: Date.now() - 86400000 * 2,
        owner: 'Administrators',
        protectionLevel: 'CẨN THẬN',
        description: 'Thư mục cài đặt ứng dụng Windows 11',
      };
      target = {
        id: 'appsfolder',
        name: t.appsFolder || 'C:\\Apps',
        title: t.appsFolder || 'C:\\Apps',
        icon: 'Folder',
        path: 'C:\\Apps',
        isHtmlApp: false,
        isBuiltIn: false,
        isPinned: pinnedAppIds.includes('appsfolder'),
        fileItem: folderItem,
      };
    } else {
      // Document
      target = {
        id: app.id,
        name: app.name,
        title: app.name,
        icon: app.icon || 'FileText',
        path: app.path,
        isHtmlApp: false,
        isBuiltIn: false,
        isPinned: pinnedAppIds.includes(app.id),
        fileItem: app,
      };
    }

    setContextMenuState({
      isOpen: true,
      target,
      position: { x: e.clientX, y: e.clientY },
    });
  };

  // Context Menu Action Implementations
  const handleTogglePin = () => {
    if (!contextMenuState.target) return;
    const target = contextMenuState.target;
    const targetKey = target.isBuiltIn ? target.id : target.id;

    if (target.isPinned) {
      const next = pinnedAppIds.filter((id) => id !== targetKey && id !== target.path);
      savePinnedApps(next);
      addNotification('Start Menu', `Đã bỏ ghim "${target.title}" khỏi màn hình Bắt đầu`, target.icon);
    } else {
      const next = [...pinnedAppIds, targetKey];
      savePinnedApps(next);
      addNotification('Start Menu', `Đã ghim "${target.title}" vào màn hình Bắt đầu`, target.icon);
    }
  };

  const handleOpenFileLocation = () => {
    if (!contextMenuState.target) return;
    const target = contextMenuState.target;
    const lastSlash = Math.max(target.path.lastIndexOf('\\'), target.path.lastIndexOf('/'));
    const parentDir = lastSlash !== -1 ? target.path.substring(0, lastSlash) : 'C:\\';

    openApp('explorer', { initialPath: parentDir });
    addNotification('File Explorer', `Đang mở vị trí tệp: ${parentDir}`, 'explorer');
    onClose();
  };

  const handleCopyPath = () => {
    if (!contextMenuState.target) return;
    const target = contextMenuState.target;
    try {
      navigator.clipboard.writeText(target.path);
    } catch (e) {}
    addNotification('Đường dẫn tệp', `Đã sao chép đường dẫn: "${target.path}"`, 'copy');
  };

  const handleUninstall = () => {
    if (!contextMenuState.target) return;
    const target = contextMenuState.target;

    if (target.isHtmlApp) {
      deleteFile(target.path, true);
      const next = pinnedAppIds.filter((id) => id !== target.id && id !== target.path);
      savePinnedApps(next);
      addNotification('Gỡ cài đặt', `Đã gỡ cài đặt ứng dụng "${target.title}" thành công!`, 'trash');
    } else if (target.isBuiltIn) {
      addNotification('Bảo vệ hệ thống', `Ứng dụng cốt lõi Windows 11 không thể gỡ cài đặt.`, 'shield');
    } else {
      deleteFile(target.path);
      addNotification('Gỡ cài đặt', `Đã gỡ cài đặt "${target.title}"`, 'trash');
    }
  };

  const handleRename = () => {
    if (!contextMenuState.target) return;
    setRenameModalState({
      isOpen: true,
      target: contextMenuState.target,
    });
  };

  const handleSaveRename = (newName: string) => {
    if (!renameModalState.target) return;
    const target = renameModalState.target;

    if (target.isHtmlApp || !target.isBuiltIn) {
      renameFile(target.path, newName);
      addNotification('Đổi tên', `Đã đổi tên ứng dụng thành "${newName}"`, 'edit');
    } else {
      addNotification('Đổi tên', `Đã cập nhật tên hiển thị thành "${newName}"`, 'edit');
    }
  };

  const handleDelete = () => {
    if (!contextMenuState.target) return;
    const target = contextMenuState.target;
    const deleted = deleteFile(target.path);
    if (deleted) {
      const next = pinnedAppIds.filter((id) => id !== target.id && id !== target.path);
      savePinnedApps(next);
      addNotification('Xóa tệp', `Đã xóa "${target.title}"`, 'trash');
    }
  };

  const handleCopy = () => {
    if (!contextMenuState.target) return;
    const target = contextMenuState.target;
    setClipboard(target.fileItem, 'copy');
    try {
      navigator.clipboard.writeText(target.path);
    } catch (e) {}
    addNotification('Sao chép', `Đã sao chép "${target.title}" vào khay nhớ tạm`, 'copy');
  };

  const handleToggleStartup = () => {
    if (!contextMenuState.target) return;
    const target = contextMenuState.target;
    const key = target.id;
    const isCurrentlyStartup = startupAppIds.includes(key);

    if (isCurrentlyStartup) {
      const next = startupAppIds.filter((id) => id !== key);
      saveStartupApps(next);
      addNotification('Khởi động cùng Windows', `Đã tắt tính toán bắt đầu khi khởi động cho "${target.title}"`, 'zap');
    } else {
      const next = [...startupAppIds, key];
      saveStartupApps(next);
      addNotification('Khởi động cùng Windows', `Đã bật tính toán bắt đầu khi khởi động cho "${target.title}"`, 'zap');
    }
  };

  const handleProperties = () => {
    if (!contextMenuState.target) return;
    const target = contextMenuState.target;
    openFileProperties(target.fileItem);
  };

  return (
    <>
      <motion.div
        key="start-menu-window"
        initial={{
          opacity: 0,
          y: 55,
          scale: 0.92,
          x: settings.taskbarAlignment === 'center' ? '-50%' : 0,
        }}
        animate={{
          opacity: 1,
          y: 0,
          scale: 1,
          x: settings.taskbarAlignment === 'center' ? '-50%' : 0,
          transition: {
            duration: 0.32,
            ease: [0.1, 0.9, 0.2, 1],
          },
        }}
        exit={{
          opacity: 0,
          y: 45,
          scale: 0.92,
          x: settings.taskbarAlignment === 'center' ? '-50%' : 0,
          transition: {
            duration: 0.2,
            ease: [0.4, 0, 1, 1],
          },
        }}
        style={{
          transformOrigin:
            settings.taskbarAlignment === 'center' ? 'bottom center' : 'bottom left',
        }}
        onClick={(e) => {
          e.stopPropagation();
          setShowPowerMenu(false);
          setContextMenuState((prev) => ({ ...prev, isOpen: false }));
        }}
        onContextMenu={(e) => {
          // If clicked in blank space of Start Menu, prevent default
          if ((e.target as HTMLElement).tagName !== 'BUTTON') {
            e.preventDefault();
          }
        }}
        className={`fixed bottom-14 ${
          settings.taskbarAlignment === 'center' ? 'left-1/2' : 'left-3'
        } w-[580px] max-w-[95vw] h-[600px] max-h-[85vh] bg-white/80 dark:bg-[#1f1f1f]/85 backdrop-blur-2xl rounded-2xl border border-white/20 dark:border-white/10 shadow-[0_20px_60px_rgba(0,0,0,0.35)] flex flex-col text-slate-800 dark:text-slate-100 select-none z-50 overflow-hidden`}
      >
        {/* Search Input Bar */}
        <div className="p-6 pb-4">
          <div className="flex items-center gap-3 bg-white/90 dark:bg-black/40 px-4 py-2.5 rounded-full border border-slate-200 dark:border-zinc-700/80 shadow-inner focus-within:ring-2 focus-within:ring-sky-500/50 transition-all">
            <Search size={16} className="text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={handleSearchKeyDown}
              placeholder={t.searchPlaceholder}
              className="w-full bg-transparent text-xs text-slate-900 dark:text-white outline-none placeholder:text-slate-400"
              autoFocus
            />
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 px-6 overflow-y-auto space-y-6">
          {search.trim() ? (
            /* Search Results View */
            <div className="space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">{t.search}</h3>

              {/* Built-in matches */}
              {filteredBuiltins.length > 0 && (
                <div className="space-y-1">
                  <div className="text-[11px] font-semibold text-slate-400">{t.allApps}</div>
                  <div className="grid grid-cols-2 gap-2">
                    {filteredBuiltins.map((app) => (
                      <button
                        key={app.id}
                        onClick={() => handleLaunchApp(app.id)}
                        onContextMenu={(e) => handleAppContextMenu(e, app, 'builtin')}
                        className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-200/70 dark:hover:bg-zinc-800/80 text-left transition-colors"
                      >
                        <div className="w-8 h-8 rounded-lg bg-sky-500/10 flex items-center justify-center shrink-0">
                          <IconRenderer name={app.icon} size={20} />
                        </div>
                        <span className="font-semibold text-xs truncate">{getLocalizedAppName(app.id, t)}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Custom HTML Apps matches */}
              {filteredHtmlApps.length > 0 && (
                <div className="space-y-1">
                  <div className="text-[11px] font-semibold text-sky-500">{t.appsFolder}</div>
                  <div className="grid grid-cols-2 gap-2">
                    {filteredHtmlApps.map((app) => (
                      <button
                        key={app.id}
                        onClick={() =>
                          handleLaunchHtml(app.path, app.appMetadata?.title || app.name)
                        }
                        onContextMenu={(e) => handleAppContextMenu(e, app, 'html')}
                        className="flex items-center gap-3 p-2.5 rounded-xl bg-sky-500/10 hover:bg-sky-500/20 text-left border border-sky-500/20 transition-colors"
                      >
                        <div className="w-8 h-8 rounded-lg bg-sky-500 text-white flex items-center justify-center font-bold shrink-0">
                          <IconRenderer name={app.appMetadata?.icon || 'Code'} size={18} />
                        </div>
                        <div className="truncate">
                          <div className="font-bold text-xs truncate">
                            {app.appMetadata?.title || app.name}
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono truncate">{app.path}</div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Document matches */}
              {filteredDocs.length > 0 && (
                <div className="space-y-1">
                  <div className="text-[11px] font-semibold text-slate-400">Files & Documents</div>
                  <div className="grid grid-cols-2 gap-2">
                    {filteredDocs.map((doc) => (
                      <button
                        key={doc.id}
                        onClick={() => {
                          openApp('notepad', { filePath: doc.path, content: doc.content });
                          onClose();
                        }}
                        onContextMenu={(e) => handleAppContextMenu(e, doc, 'doc')}
                        className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-200/70 dark:hover:bg-zinc-800/80 text-left transition-colors"
                      >
                        <IconRenderer name={doc.icon} size={18} />
                        <span className="font-medium text-xs truncate">{doc.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : showAllApps ? (
            /* All Apps List View */
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs">{t.allApps}</span>
                <button
                  onClick={() => setShowAllApps(false)}
                  className="px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-zinc-800 text-xs font-semibold hover:bg-slate-300 transition-colors"
                >
                  {t.back}
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2">
                {/* Built-ins */}
                {BUILTIN_APPS.map((app) => (
                  <button
                    key={app.id}
                    onClick={() => handleLaunchApp(app.id)}
                    onContextMenu={(e) => handleAppContextMenu(e, app, 'builtin')}
                    className="flex items-center gap-3 p-2 rounded-xl hover:bg-slate-200/70 dark:hover:bg-zinc-800/80 text-left transition-colors"
                  >
                    <IconRenderer name={app.icon} size={20} />
                    <span className="text-xs font-medium truncate">{getLocalizedAppName(app.id, t)}</span>
                  </button>
                ))}

                {/* HTML Apps */}
                {htmlApps.map((app) => (
                  <button
                    key={app.id}
                    onClick={() =>
                      handleLaunchHtml(app.path, app.appMetadata?.title || app.name)
                    }
                    onContextMenu={(e) => handleAppContextMenu(e, app, 'html')}
                    className="flex items-center gap-3 p-2 rounded-xl hover:bg-sky-500/10 text-left transition-colors"
                  >
                    <IconRenderer name={app.appMetadata?.icon || 'Code'} size={20} />
                    <span className="text-xs font-medium truncate text-sky-600 dark:text-sky-400">
                      {app.appMetadata?.title || app.name}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            /* Standard Pinned Grid + Recommended */
            <>
              {/* Pinned Section */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-bold text-xs">{t.pinned}</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setIsAddAppModalOpen(true)}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-500/10 text-sky-600 dark:text-sky-400 text-xs font-semibold hover:bg-sky-500/20 transition-colors"
                    >
                      <Sparkles size={13} />
                      <span>+ {t.appsFolder}</span>
                    </button>
                    <button
                      onClick={() => setShowAllApps(true)}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-zinc-800 text-xs font-semibold hover:bg-slate-300 dark:hover:bg-zinc-700 transition-colors"
                    >
                      <span>{t.allApps}</span>
                      <ChevronRight size={13} />
                    </button>
                  </div>
                </div>

                {/* Grid of Pinned System Apps */}
                <div className="grid grid-cols-6 gap-2 text-center">
                  {pinnedBuiltins.map((app) => (
                    <button
                      key={app.id}
                      onClick={() => handleLaunchApp(app.id)}
                      onContextMenu={(e) => handleAppContextMenu(e, app, 'builtin')}
                      className="flex flex-col items-center p-2 rounded-xl hover:bg-slate-200/70 dark:hover:bg-zinc-800/80 active:scale-95 transition-all group"
                    >
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
                        <IconRenderer name={app.icon} size={28} />
                      </div>
                      <span className="text-[11px] font-medium truncate w-full">{getLocalizedAppName(app.id, t)}</span>
                    </button>
                  ))}

                  {/* Grid of Installed HTML Apps in C:\Apps */}
                  {(pinnedHtmlApps.length > 0 ? pinnedHtmlApps : htmlApps).slice(0, 6).map((app) => (
                    <button
                      key={app.id}
                      onClick={() =>
                        handleLaunchHtml(app.path, app.appMetadata?.title || app.name)
                      }
                      onContextMenu={(e) => handleAppContextMenu(e, app, 'html')}
                      className="flex flex-col items-center p-2 rounded-xl hover:bg-sky-500/15 active:scale-95 transition-all group relative"
                    >
                      <div className="w-10 h-10 rounded-xl bg-sky-500/10 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
                        <IconRenderer name={app.appMetadata?.icon || 'Code'} size={26} />
                      </div>
                      <span className="text-[11px] font-medium truncate w-full text-sky-600 dark:text-sky-400">
                        {app.appMetadata?.title || app.name}
                      </span>
                      <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-sky-500" />
                    </button>
                  ))}
                </div>
              </div>

              {/* Recommended Section */}
              <div className="pt-2 border-t border-slate-200 dark:border-zinc-800">
                <div className="flex items-center justify-between mb-3">
                  <span className="font-bold text-xs">{t.recommended}</span>
                  <span className="text-[11px] text-slate-400">Recent</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {htmlApps.slice(0, 4).map((app) => (
                    <button
                      key={app.id}
                      onClick={() =>
                        handleLaunchHtml(app.path, app.appMetadata?.title || app.name)
                      }
                      onContextMenu={(e) => handleAppContextMenu(e, app, 'html')}
                      className="flex items-center gap-3 p-2 rounded-xl hover:bg-slate-200/70 dark:hover:bg-zinc-800/80 text-left transition-colors"
                    >
                      <div className="w-8 h-8 rounded-lg bg-sky-500/20 flex items-center justify-center text-sky-500 shrink-0">
                        <IconRenderer name={app.appMetadata?.icon || 'Code'} size={18} />
                      </div>
                      <div className="truncate">
                        <div className="font-semibold text-xs truncate">
                          {app.appMetadata?.title || app.name}
                        </div>
                        <div className="text-[10px] text-slate-400">HTML Executable</div>
                      </div>
                    </button>
                  ))}

                  <button
                    onClick={() => {
                      openApp('explorer', { initialPath: 'C:\\Apps' });
                      onClose();
                    }}
                    onContextMenu={(e) => handleAppContextMenu(e, {}, 'folder')}
                    className="flex items-center gap-3 p-2 rounded-xl hover:bg-slate-200/70 dark:hover:bg-zinc-800/80 text-left transition-colors"
                  >
                    <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center text-amber-500 shrink-0">
                      <Folder size={18} />
                    </div>
                    <div className="truncate">
                      <div className="font-semibold text-xs truncate">{t.appsFolder}</div>
                      <div className="text-[10px] text-slate-400">Drop HTML files here</div>
                    </div>
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer Profile & Power Menu */}
        <div className="relative flex items-center justify-between p-4 bg-slate-100/80 dark:bg-black/40 border-t border-slate-200 dark:border-zinc-800">
          {/* User Account */}
          <div className="relative">
            <div
              onClick={(e) => {
                e.stopPropagation();
                setShowUserMenu(!showUserMenu);
                setShowPowerMenu(false);
              }}
              className="flex items-center gap-3 p-1.5 rounded-xl hover:bg-slate-200 dark:hover:bg-zinc-800 cursor-pointer transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-sky-500 to-indigo-600 text-white font-bold flex items-center justify-center text-xs shadow-sm uppercase">
                {(settings.userName || 'L').charAt(0)}
              </div>
              <div className="flex flex-col text-left">
                <span className="font-bold text-xs">{settings.userName || 'lenamphuc'}</span>
                <span className="text-[10px] text-slate-400 max-w-[130px] truncate">{settings.userEmail || 'lenamphuc2013@gmail.com'}</span>
              </div>
            </div>

            {/* User Profile Popover (Authentic Windows 11) */}
            {showUserMenu && (
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute bottom-14 left-0 w-56 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-xl border border-slate-200 dark:border-zinc-700 rounded-xl shadow-2xl p-1.5 space-y-1 z-50 text-xs animate-win11-flyin"
              >
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    onClose();
                    openApp('settings');
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors text-left"
                >
                  <SettingsIcon size={14} />
                  <span>Thay đổi cài đặt tài khoản</span>
                </button>
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    onClose();
                    setIsLockScreen(true);
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors text-left font-semibold text-sky-600 dark:text-sky-400"
                >
                  <Lock size={14} />
                  <span>Khóa (Lock)</span>
                </button>
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    onClose();
                    setIsLockScreen(true);
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors text-left text-slate-600 dark:text-slate-300"
                >
                  <LogOut size={14} />
                  <span>Đăng xuất (Sign out)</span>
                </button>
              </div>
            )}
          </div>

          {/* Power Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowPowerMenu(!showPowerMenu);
              setShowUserMenu(false);
            }}
            className="p-2 rounded-xl hover:bg-slate-200 dark:hover:bg-zinc-800 transition-colors text-slate-600 dark:text-slate-300"
            title={t.shutDown}
          >
            <Power size={18} />
          </button>

          {/* Power Menu Popover */}
          {showPowerMenu && (
            <div
              onClick={(e) => e.stopPropagation()}
              className="absolute bottom-14 right-4 w-48 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-xl border border-slate-200 dark:border-zinc-700 rounded-xl shadow-2xl p-1.5 space-y-1 z-50 text-xs animate-win11-flyin"
            >
              <button
                onClick={() => {
                  setShowPowerMenu(false);
                  onClose();
                  enterSleepMode();
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors text-left"
              >
                <Moon size={14} />
                <span>{t.sleep}</span>
              </button>
              <button
                onClick={(e) => {
                  setShowPowerMenu(false);
                  onClose();
                  if (e.shiftKey) {
                    restartToWinRE();
                  } else {
                    restartSystem();
                  }
                }}
                className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors text-left group"
              >
                <div className="flex items-center gap-2.5">
                  <RotateCcw size={14} />
                  <span>{t.restart}</span>
                </div>
                <span className="text-[10px] text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity">Shift+↻</span>
              </button>
              <button
                onClick={() => {
                  setShowPowerMenu(false);
                  onClose();
                  restartToWinRE();
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-sky-500/15 text-sky-600 dark:text-sky-400 transition-colors text-left font-medium"
              >
                <Sparkles size={14} />
                <span>{t.advancedStartup}</span>
              </button>
              <button
                onClick={() => {
                  setShowPowerMenu(false);
                  onClose();
                  shutdownSystem();
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-red-500 hover:text-white transition-colors text-left text-red-500"
              >
                <Power size={14} />
                <span>{t.shutDown}</span>
              </button>
            </div>
          )}
        </div>
      </motion.div>

      {/* Start Menu App Context Menu */}
      {contextMenuState.isOpen && contextMenuState.target && (
        <StartMenuContextMenu
          target={contextMenuState.target}
          position={contextMenuState.position}
          isStartup={startupAppIds.includes(contextMenuState.target.id)}
          onClose={() => setContextMenuState((prev) => ({ ...prev, isOpen: false }))}
          onTogglePin={handleTogglePin}
          onOpenFileLocation={handleOpenFileLocation}
          onCopyPath={handleCopyPath}
          onUninstall={handleUninstall}
          onRename={handleRename}
          onDelete={handleDelete}
          onCopy={handleCopy}
          onToggleStartup={handleToggleStartup}
          onProperties={handleProperties}
        />
      )}

      {/* Start Menu Rename Modal */}
      <StartMenuRenameModal
        isOpen={renameModalState.isOpen}
        initialName={renameModalState.target?.name || ''}
        onSave={handleSaveRename}
        onClose={() => setRenameModalState({ isOpen: false, target: null })}
      />
    </>
  );
};
