import React, { useState, useEffect, useRef } from 'react';
import { Edit3, X, Check } from 'lucide-react';

interface StartMenuRenameModalProps {
  isOpen: boolean;
  initialName: string;
  onSave: (newName: string) => void;
  onClose: () => void;
}

export const StartMenuRenameModal: React.FC<StartMenuRenameModalProps> = ({
  isOpen,
  initialName,
  onSave,
  onClose,
}) => {
  const [name, setName] = useState(initialName);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setName(initialName);
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
        inputRef.current?.select();
      }, 50);
    }
  }, [initialName, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onSave(name.trim());
      onClose();
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-[150] flex items-center justify-center bg-black/50 backdrop-blur-sm animate-win11-fade"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-[360px] max-w-[90vw] bg-[#242424] text-white rounded-xl shadow-2xl border border-white/10 p-5 select-none"
      >
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Edit3 size={18} className="text-sky-400" />
            <h3 className="font-semibold text-sm">Đổi tên ứng dụng</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs text-slate-400 mb-1.5 font-medium">
              Nhập tên mới:
            </label>
            <input
              ref={inputRef}
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-[#181818] border border-white/20 rounded-lg px-3 py-2 text-xs text-white outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-500/30 transition-all"
              placeholder="Tên ứng dụng..."
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-xs font-medium text-slate-200 transition-colors"
            >
              Hủy
            </button>
            <button
              type="submit"
              disabled={!name.trim()}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-xs font-semibold text-white shadow-md transition-colors"
            >
              <Check size={14} />
              <span>Đổi tên</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
