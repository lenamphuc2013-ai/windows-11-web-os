import React, { useState, useEffect } from 'react';
import { UEFIConfig } from '../../types/winre';
import { Cpu, HardDrive, ShieldCheck, Settings2, Power, RotateCcw, Check, Save } from 'lucide-react';

interface UEFIUtilityProps {
  config: UEFIConfig;
  onSaveAndExit: (newConfig: UEFIConfig) => void;
  onDiscardAndExit: () => void;
}

export const UEFIUtility: React.FC<UEFIUtilityProps> = ({
  config: initialConfig,
  onSaveAndExit,
  onDiscardAndExit,
}) => {
  const [activeTab, setActiveTab] = useState<'main' | 'advanced' | 'security' | 'boot' | 'exit'>('main');
  const [config, setConfig] = useState<UEFIConfig>(initialConfig);
  const [selectedIndex, setSelectedIndex] = useState(0);

  // Keyboard navigation support for BIOS feel
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') {
        const tabs: Array<'main' | 'advanced' | 'security' | 'boot' | 'exit'> = ['main', 'advanced', 'security', 'boot', 'exit'];
        const nextIdx = (tabs.indexOf(activeTab) + 1) % tabs.length;
        setActiveTab(tabs[nextIdx]);
        setSelectedIndex(0);
      } else if (e.key === 'ArrowLeft') {
        const tabs: Array<'main' | 'advanced' | 'security' | 'boot' | 'exit'> = ['main', 'advanced', 'security', 'boot', 'exit'];
        const prevIdx = (tabs.indexOf(activeTab) - 1 + tabs.length) % tabs.length;
        setActiveTab(tabs[prevIdx]);
        setSelectedIndex(0);
      } else if (e.key === 'Escape') {
        onDiscardAndExit();
      } else if (e.key === 'F10') {
        onSaveAndExit(config);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeTab, config, onSaveAndExit, onDiscardAndExit]);

  return (
    <div className="fixed inset-0 z-50 bg-[#0a192f] text-slate-100 font-mono select-none flex flex-col p-4 md:p-8 overflow-auto">
      {/* Top Banner / BIOS Title */}
      <div className="border-b-2 border-sky-600 pb-3 mb-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <div className="text-xl font-bold text-sky-400 tracking-wider flex items-center gap-2">
            <span>Aptio Setup Utility - American Megatrends UEFI BIOS</span>
          </div>
          <div className="text-xs text-slate-400 mt-0.5">
            BIOS Version: 2.26.1200 | Build Date: 08/20/2026 | Core Version: 5.28
          </div>
        </div>
        <div className="text-right text-xs text-sky-300 font-semibold">
          <div>Processor: Intel(R) Core(TM) i9-14900K @ 3.20GHz</div>
          <div>Total Memory: 16384 MB (DDR5 6000MHz)</div>
        </div>
      </div>

      {/* Top Navigation Tabs */}
      <div className="flex border-b border-sky-800/80 mb-6 bg-slate-900/80 rounded-t-lg overflow-x-auto">
        {(['main', 'advanced', 'security', 'boot', 'exit'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => {
              setActiveTab(tab);
              setSelectedIndex(0);
            }}
            className={`px-6 py-2 text-sm font-bold uppercase tracking-wider transition-all border-b-2 ${
              activeTab === tab
                ? 'bg-sky-700/60 text-white border-sky-400 shadow-inner'
                : 'text-slate-400 hover:text-slate-200 border-transparent hover:bg-slate-800'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Main Tab Content */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 bg-slate-900/60 p-6 rounded-xl border border-sky-800/50 shadow-2xl">
        <div className="lg:col-span-2 space-y-4">
          {activeTab === 'main' && (
            <div className="space-y-4">
              <h3 className="text-sky-400 font-bold text-base border-b border-sky-900 pb-2">System Overview</h3>
              <div className="grid grid-cols-2 gap-y-3 text-xs">
                <span className="text-slate-400">BIOS Vendor:</span>
                <span className="text-white font-semibold">American Megatrends Inc.</span>

                <span className="text-slate-400">UEFI Specification Version:</span>
                <span className="text-white font-semibold">2.80 (64-bit Architecture)</span>

                <span className="text-slate-400">Processor Type:</span>
                <span className="text-white font-semibold">14th Gen Intel(R) Core(TM) i9-14900K</span>

                <span className="text-slate-400">Microcode Revision:</span>
                <span className="text-white font-semibold">0x123 (08/2026)</span>

                <span className="text-slate-400">Total System Memory:</span>
                <span className="text-emerald-400 font-semibold">16384 MB (Dual Channel)</span>

                <span className="text-slate-400">NVMe SSD Storage:</span>
                <span className="text-white font-semibold">Samsung SSD 990 PRO 1TB PCIe 4.0</span>

                <span className="text-slate-400">System Language:</span>
                <span className="text-sky-300 font-semibold">[English / US]</span>

                <span className="text-slate-400">System Date:</span>
                <span className="text-white font-semibold">{new Date().toLocaleDateString('en-US')}</span>

                <span className="text-slate-400">System Time:</span>
                <span className="text-white font-semibold">{new Date().toLocaleTimeString('en-US')}</span>
              </div>
            </div>
          )}

          {activeTab === 'advanced' && (
            <div className="space-y-4">
              <h3 className="text-sky-400 font-bold text-base border-b border-sky-900 pb-2">Advanced Chipset & CPU Configuration</h3>
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between p-3 rounded bg-slate-800/60 border border-sky-900/40">
                  <div>
                    <div className="text-white font-semibold">Intel (VMX) Virtualization Technology</div>
                    <div className="text-slate-400 text-[11px]">Enables hypervisor virtual machines (Hyper-V, WSL2, Sandbox)</div>
                  </div>
                  <button
                    onClick={() => setConfig((prev) => ({ ...prev, virtualization: !prev.virtualization }))}
                    className={`px-3 py-1.5 rounded font-bold ${
                      config.virtualization ? 'bg-emerald-600 text-white' : 'bg-rose-900 text-rose-200'
                    }`}
                  >
                    [{config.virtualization ? 'ENABLED' : 'DISABLED'}]
                  </button>
                </div>

                <div className="flex items-center justify-between p-3 rounded bg-slate-800/60 border border-sky-900/40">
                  <div>
                    <div className="text-white font-semibold">Extreme Memory Profile (X.M.P.)</div>
                    <div className="text-slate-400 text-[11px]">DDR5 Overclocking Profile for low latency gaming</div>
                  </div>
                  <button
                    onClick={() =>
                      setConfig((prev) => ({
                        ...prev,
                        xmpProfile: prev.xmpProfile === 'Disabled' ? 'Profile 1 (DDR5-6000)' : 'Disabled',
                      }))
                    }
                    className="px-3 py-1.5 rounded font-bold bg-sky-700 text-white"
                  >
                    [{config.xmpProfile}]
                  </button>
                </div>

                <div className="flex items-center justify-between p-3 rounded bg-slate-800/60 border border-sky-900/40">
                  <div>
                    <div className="text-white font-semibold">Fast Boot Option</div>
                    <div className="text-slate-400 text-[11px]">Bypasses extended hardware self-tests on startup</div>
                  </div>
                  <button
                    onClick={() => setConfig((prev) => ({ ...prev, fastBoot: !prev.fastBoot }))}
                    className={`px-3 py-1.5 rounded font-bold ${
                      config.fastBoot ? 'bg-emerald-600 text-white' : 'bg-rose-900 text-rose-200'
                    }`}
                  >
                    [{config.fastBoot ? 'ENABLED' : 'DISABLED'}]
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-4">
              <h3 className="text-sky-400 font-bold text-base border-b border-sky-900 pb-2">Security & Trusted Computing</h3>
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between p-3 rounded bg-slate-800/60 border border-sky-900/40">
                  <div>
                    <div className="text-white font-semibold">Secure Boot Mode</div>
                    <div className="text-slate-400 text-[11px]">Enables UEFI signature verification for boot components (Required for Windows 11)</div>
                  </div>
                  <button
                    onClick={() => setConfig((prev) => ({ ...prev, secureBoot: !prev.secureBoot }))}
                    className={`px-3 py-1.5 rounded font-bold ${
                      config.secureBoot ? 'bg-emerald-600 text-white' : 'bg-rose-900 text-rose-200'
                    }`}
                  >
                    [{config.secureBoot ? 'ENABLED' : 'DISABLED'}]
                  </button>
                </div>

                <div className="flex items-center justify-between p-3 rounded bg-slate-800/60 border border-sky-900/40">
                  <div>
                    <div className="text-white font-semibold">TPM 2.0 Security Device Support (Intel PTT)</div>
                    <div className="text-slate-400 text-[11px]">Hardware cryptographic processor for BitLocker & Windows Hello</div>
                  </div>
                  <button
                    onClick={() => setConfig((prev) => ({ ...prev, tpmEnabled: !prev.tpmEnabled }))}
                    className={`px-3 py-1.5 rounded font-bold ${
                      config.tpmEnabled ? 'bg-emerald-600 text-white' : 'bg-rose-900 text-rose-200'
                    }`}
                  >
                    [{config.tpmEnabled ? 'ENABLED' : 'DISABLED'}]
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'boot' && (
            <div className="space-y-4">
              <h3 className="text-sky-400 font-bold text-base border-b border-sky-900 pb-2">Boot Order Priority</h3>
              <div className="space-y-2 text-xs">
                {config.bootOrder.map((dev, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-3 rounded bg-slate-800/60 border border-sky-900/40"
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded bg-sky-800 text-white font-bold flex items-center justify-center">
                        #{idx + 1}
                      </span>
                      <span className="text-white font-semibold">{dev}</span>
                    </div>
                    {idx === 0 && (
                      <span className="text-[11px] bg-emerald-900/80 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/40">
                        Primary Boot
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'exit' && (
            <div className="space-y-4">
              <h3 className="text-sky-400 font-bold text-base border-b border-sky-900 pb-2">Exit Options</h3>
              <div className="space-y-3">
                <button
                  onClick={() => onSaveAndExit(config)}
                  className="w-full flex items-center justify-between p-4 rounded-xl bg-sky-700 hover:bg-sky-600 text-white font-semibold text-xs transition-colors shadow-lg"
                >
                  <div className="flex items-center gap-3">
                    <Save size={18} />
                    <div className="text-left">
                      <div className="text-sm font-bold">Save Changes and Reset (Lưu thay đổi & Khởi động lại)</div>
                      <div className="text-sky-200 text-[11px]">Save modified configuration into NVRAM and restart PC [F10]</div>
                    </div>
                  </div>
                  <span>Enter</span>
                </button>

                <button
                  onClick={onDiscardAndExit}
                  className="w-full flex items-center justify-between p-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors border border-sky-900/50"
                >
                  <div className="flex items-center gap-3">
                    <RotateCcw size={18} />
                    <div className="text-left">
                      <div className="text-sm font-bold">Discard Changes and Exit (Hủy thay đổi & Thoát)</div>
                      <div className="text-slate-400 text-[11px]">Quit without saving changes [ESC]</div>
                    </div>
                  </div>
                  <span>ESC</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Help / Legend Panel */}
        <div className="bg-slate-950/80 p-5 rounded-xl border border-sky-900/60 flex flex-col justify-between text-xs space-y-4">
          <div>
            <h4 className="font-bold text-sky-400 border-b border-sky-900 pb-2 mb-3">Item Description / Help</h4>
            <p className="text-slate-300 text-xs leading-relaxed">
              Use arrow keys or mouse to navigate menus. Windows 11 requires UEFI Secure Boot and TPM 2.0.
            </p>
          </div>

          <div className="border-t border-sky-900/60 pt-4 space-y-2 text-[11px] text-slate-400">
            <div className="flex justify-between">
              <span>← → :</span>
              <span className="text-sky-300">Select Screen</span>
            </div>
            <div className="flex justify-between">
              <span>↑ ↓ :</span>
              <span className="text-sky-300">Select Item</span>
            </div>
            <div className="flex justify-between">
              <span>Enter :</span>
              <span className="text-sky-300">Select / Toggle</span>
            </div>
            <div className="flex justify-between">
              <span>F10 :</span>
              <span className="text-sky-300">Save and Exit</span>
            </div>
            <div className="flex justify-between">
              <span>ESC :</span>
              <span className="text-sky-300">Discard & Exit</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Footer Actions */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
        <div>American Megatrends UEFI (C) 2026. All Rights Reserved.</div>
        <div className="flex gap-3">
          <button
            onClick={() => onSaveAndExit(config)}
            className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-lg shadow transition-colors"
          >
            F10: Save & Exit
          </button>
          <button
            onClick={onDiscardAndExit}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-lg border border-slate-700 transition-colors"
          >
            ESC: Exit
          </button>
        </div>
      </div>
    </div>
  );
};
