import React, { useEffect } from 'react';
import { SafeModeType } from '../../types/winre';

interface StartupSettingsScreenProps {
  onSelectOption: (optionNumber: number, safeModeType: SafeModeType) => void;
  onCancel: () => void;
}

export const StartupSettingsScreen: React.FC<StartupSettingsScreenProps> = ({
  onSelectOption,
  onCancel,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const num = parseInt(e.key);
      if (num >= 1 && num <= 9) {
        let sm: SafeModeType = 'none';
        if (num === 4) sm = 'minimal';
        else if (num === 5) sm = 'network';
        else if (num === 6) sm = 'cmd';
        onSelectOption(num, sm);
      } else if (e.key === 'Enter') {
        onSelectOption(0, 'none');
      } else if (e.key === 'Escape') {
        onCancel();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onSelectOption, onCancel]);

  const OPTIONS = [
    { num: 1, title: '1) Enable debugging (Bật chế độ gỡ lỗi)', sm: 'none' as SafeModeType },
    { num: 2, title: '2) Enable boot logging (Bật ghi nhật ký khởi động)', sm: 'none' as SafeModeType },
    { num: 3, title: '3) Enable low-resolution video (Bật video độ phân giải thấp)', sm: 'none' as SafeModeType },
    { num: 4, title: '4) Enable Safe Mode (Bật chế độ An toàn tối thiểu)', sm: 'minimal' as SafeModeType, badge: 'Safe Mode' },
    { num: 5, title: '5) Enable Safe Mode with Networking (Bật chế độ An toàn với mạng)', sm: 'network' as SafeModeType, badge: 'Safe Mode + Network' },
    { num: 6, title: '6) Enable Safe Mode with Command Prompt (Bật chế độ An toàn với Dấu nhắc lệnh)', sm: 'cmd' as SafeModeType, badge: 'Safe Mode + CMD' },
    { num: 7, title: '7) Disable driver signature enforcement (Tắt Tải chữ ký bắt buộc)', sm: 'none' as SafeModeType },
    { num: 8, title: '8) Disable early launch anti-malware protection (Tắt Bảo vệ chống mã độc khởi động)', sm: 'none' as SafeModeType },
    { num: 9, title: '9) Disable automatic restart on system failure (Tắt tự động khởi động lại khi lỗi)', sm: 'none' as SafeModeType },
  ];

  return (
    <div className="fixed inset-0 z-[100] bg-[#005a9e] text-white font-sans select-none flex flex-col items-center justify-center p-6 md:p-12 overflow-y-auto">
      <div className="w-full max-w-2xl space-y-6">
        <div>
          <h1 className="text-3xl font-light tracking-tight">Startup Settings (Cài đặt khởi động)</h1>
          <p className="text-sm text-sky-100 mt-2 font-normal">
            Press a number to choose from the options below (Nhấn số từ 1 đến 9 hoặc phím F1-F9 trên bàn phím):
          </p>
          <p className="text-xs text-sky-200 mt-1">Use number keys or click directly on an option to start.</p>
        </div>

        <div className="space-y-2 bg-black/20 p-4 rounded-xl border border-white/15">
          {OPTIONS.map((opt) => (
            <button
              key={opt.num}
              onClick={() => onSelectOption(opt.num, opt.sm)}
              className="w-full flex items-center justify-between p-2.5 rounded-lg text-left text-sm hover:bg-white/15 active:bg-white/25 transition-all text-white font-medium group"
            >
              <span>{opt.title}</span>
              {opt.badge && (
                <span className="text-[11px] bg-sky-400/30 group-hover:bg-sky-400 group-hover:text-black text-sky-200 px-2 py-0.5 rounded transition-colors font-bold">
                  {opt.badge}
                </span>
              )}
            </button>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
          <div className="text-xs text-sky-200">
            Press <strong className="text-white underline">Enter</strong> to return to your operating system.
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => onSelectOption(0, 'none')}
              className="px-5 py-2.5 bg-white/20 hover:bg-white/30 active:bg-white/40 text-white text-xs font-semibold rounded-lg transition-all border border-white/30"
            >
              Enter: Khởi động bình thường
            </button>
            <button
              onClick={onCancel}
              className="px-4 py-2.5 bg-black/30 hover:bg-black/40 text-sky-200 text-xs font-semibold rounded-lg transition-all border border-white/10"
            >
              Quay lại WinRE
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
