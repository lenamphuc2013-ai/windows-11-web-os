import React, { useState, useRef, useEffect } from 'react';
import { X, Square, Minus, Terminal as TerminalIcon } from 'lucide-react';
import { executeDiskPartCommand, DISKPART_BANNER } from '../../utils/diskpartEngine';
import { CONTROL_HELP_TEXT } from '../../utils/controlPanelData';

interface WinRETerminalProps {
  onClose: () => void;
  onRepairSuccess?: () => void;
}

interface CommandHistoryItem {
  id: string;
  type: 'input' | 'output' | 'error' | 'success';
  text: string;
}

export const WinRETerminal: React.FC<WinRETerminalProps> = ({ onClose, onRepairSuccess }) => {
  const [lines, setLines] = useState<CommandHistoryItem[]>([
    {
      id: 'init-1',
      type: 'output',
      text: 'Microsoft Windows [Version 10.0.22631.3296]\n(c) Microsoft Corporation. All rights reserved.\nWindows Recovery Environment (WinRE) Command Prompt',
    },
    {
      id: 'init-2',
      type: 'output',
      text: 'Available tools: sfc, chkdsk, diskpart, bootrec, bcdedit, regedit, dir, help, exit\n',
    },
  ]);
  const [inputVal, setInputVal] = useState('');
  const [currentDrive, setCurrentDrive] = useState('X:\\windows\\system32');
  const [isDiskpart, setIsDiskpart] = useState(false);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [lines]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    const raw = inputVal.trim();
    setInputVal('');
    if (!raw) return;

    const promptText = isDiskpart ? 'DISKPART> ' : `${currentDrive}> `;
    const newItems: CommandHistoryItem[] = [
      ...lines,
      { id: 'in-' + Date.now(), type: 'input', text: `${promptText}${raw}` },
    ];

    const parts = raw.split(/\s+/);
    const cmd = parts[0].toLowerCase();
    const args = parts.slice(1);

    if (isDiskpart) {
      if (cmd === 'exit' || cmd === 'quit') {
        setIsDiskpart(false);
        newItems.push({ id: 'out-' + Date.now(), type: 'output', text: 'Leaving DiskPart...' });
      } else {
        const res = executeDiskPartCommand(raw);
        if (res.isExit) {
          setIsDiskpart(false);
        }
        if (res.output) {
          newItems.push({ id: 'out-' + Date.now(), type: 'output', text: res.output });
        }
      }
      setLines(newItems);
      return;
    }

    // Normal WinRE Commands
    switch (cmd) {
      case 'cls':
        setLines([]);
        return;

      case 'exit':
        onClose();
        return;

      case 'control':
      case 'control.exe':
        if (args.includes('/?') || args.includes('-?') || args.includes('/help')) {
          newItems.push({
            id: 'out-' + Date.now(),
            type: 'output',
            text: CONTROL_HELP_TEXT,
          });
        } else {
          newItems.push({
            id: 'err-' + Date.now(),
            type: 'error',
            text: `Hệ thống Control Panel không khả dụng trong môi trường WinRE ngoại tuyến (Offline WinRE Mode).\nVui lòng khởi động lại vào Windows 11 để mở Bảng Điều khiển giao diện đồ họa.`,
          });
        }
        break;

      case 'help':
        newItems.push({
          id: 'out-' + Date.now(),
          type: 'output',
          text: `WinRE Offline Maintenance Commands:
  sfc /scannow         Scan and repair corrupted offline system files
  chkdsk [drive:] /f /r Scan and fix disk partition errors
  bootrec /fixmbr      Write standard master boot record to system partition
  bootrec /fixboot     Write new boot sector to system partition
  bootrec /rebuildbcd  Completely rebuild Boot Configuration Data (BCD)
  bcdedit              Inspect or modify BCD startup parameters
  diskpart             Open disk and volume partitioning environment
  regedit              Offline Windows Registry editor
  dir / cd             Navigate virtual file system
  exit                 Close Command Prompt and return to WinRE Menu`,
        });
        break;

      case 'sfc':
        newItems.push({
          id: 'out-' + Date.now(),
          type: 'output',
          text: `Beginning system scan. This process will take some time.\n\nBeginning verification phase of system scan.\nVerification 100% complete.\n\nWindows Resource Protection found corrupt files and successfully repaired them.\nDetails are included in the CBS.Log windir\\Logs\\CBS\\CBS.log.`,
        });
        if (onRepairSuccess) {
          onRepairSuccess();
        }
        break;

      case 'chkdsk':
        newItems.push({
          id: 'out-' + Date.now(),
          type: 'output',
          text: `The type of the file system is NTFS.\nVolume label is Windows11.\n\nStage 1: Examining basic file system structure ... done.\nStage 2: Examining file name linkage ... done.\nStage 3: Examining security descriptors ... done.\nStage 4: Looking for bad clusters in user file data ... done.\n\nWindows has scanned the file system and found no problems.\n480,000,000 KB total disk space.\n240,120,400 KB available on disk.`,
        });
        break;

      case 'bootrec':
      case 'bootrec.exe': {
        const flag = args[0]?.toLowerCase();
        if (flag === '/fixmbr') {
          newItems.push({ id: 'succ-' + Date.now(), type: 'success', text: 'The operation completed successfully. (Master Boot Record rewritten)' });
        } else if (flag === '/fixboot') {
          newItems.push({ id: 'succ-' + Date.now(), type: 'success', text: 'The operation completed successfully. (Boot sector updated)' });
        } else if (flag === '/rebuildbcd') {
          newItems.push({
            id: 'succ-' + Date.now(),
            type: 'success',
            text: `Scanning all disks for Windows installations.\n\nTotal identified Windows installations: 1\n[1]  C:\\Windows\nAdd installation to boot list? Yes(Y)/No(N)/All(A): Y\nThe operation completed successfully.`,
          });
        } else {
          newItems.push({
            id: 'out-' + Date.now(),
            type: 'output',
            text: `bootrec [/fixmbr | /fixboot | /scanos | /rebuildbcd]`,
          });
        }
        break;
      }

      case 'bcdedit':
        newItems.push({
          id: 'out-' + Date.now(),
          type: 'output',
          text: `Windows Boot Manager
--------------------
identifier              {bootmgr}
device                  partition=\\Device\\HarddiskVolume1
description             Windows Boot Manager
locale                  en-US
inherit                 {globalsettings}
default                 {current}
resumeobject            {d3381a18-6294-11ef-93e1-806e6f6e6963}
displayorder            {current}
toolsdisplayorder       {memdiag}
timeout                 30

Windows Boot Loader
-------------------
identifier              {current}
device                  partition=C:
path                    \\Windows\\system32\\winload.efi
description             Windows 11
locale                  en-US
inherit                 {bootloadersettings}
recoverysequence        {d3381a1a-6294-11ef-93e1-806e6f6e6963}
recoveryenabled         Yes
isolatedcontext         Yes
allowedinmemorysettings 0x15000075
osdevice                partition=C:
systemroot              \\Windows
resumeobject            {d3381a18-6294-11ef-93e1-806e6f6e6963}
nx                      OptIn
bootmenupolicy          Standard`,
        });
        break;

      case 'diskpart':
        setIsDiskpart(true);
        newItems.push({
          id: 'out-' + Date.now(),
          type: 'output',
          text: DISKPART_BANNER,
        });
        break;

      case 'regedit':
        newItems.push({
          id: 'out-' + Date.now(),
          type: 'output',
          text: 'Loaded offline registry hives from C:\\Windows\\System32\\config (SYSTEM, SOFTWARE, SAM, SECURITY).',
        });
        break;

      case 'dir':
        newItems.push({
          id: 'out-' + Date.now(),
          type: 'output',
          text: ` Directory of ${currentDrive}

08/20/2026  03:15 AM    <DIR>          .
08/20/2026  03:15 AM    <DIR>          ..
08/20/2026  03:12 AM           142,848 bcdedit.exe
08/20/2026  03:14 AM           215,040 bootrec.exe
08/20/2026  03:12 AM           481,280 chkdsk.exe
08/20/2026  03:13 AM           389,120 diskpart.exe
08/20/2026  03:15 AM           198,656 sfc.exe
08/20/2026  03:11 AM         1,245,184 ntoskrnl.exe
08/20/2026  03:12 AM         2,105,344 winload.efi
               7 File(s)      4,777,472 bytes
               2 Dir(s)  512,000,000,000 bytes free`,
        });
        break;

      default:
        newItems.push({
          id: 'err-' + Date.now(),
          type: 'error',
          text: `'${cmd}' is not recognized as an internal or external command, operable program or batch file. Type 'help' for available WinRE commands.`,
        });
    }

    setLines(newItems);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 select-none font-mono">
      <div className="w-full max-w-4xl h-[560px] bg-black border border-slate-700 rounded-lg shadow-2xl flex flex-col overflow-hidden text-slate-100 text-xs">
        {/* Titlebar */}
        <div className="bg-slate-900 px-3 py-2 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2 text-slate-300 font-sans font-semibold">
            <TerminalIcon size={14} className="text-sky-400" />
            <span>Administrator: X:\windows\system32\cmd.exe (WinRE)</span>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={onClose}
              className="p-1 hover:bg-red-600 rounded text-slate-400 hover:text-white transition-colors"
              title="Close (Exit WinRE CMD)"
            >
              <X size={14} />
            </button>
          </div>
        </div>

        {/* Terminal Body */}
        <div
          className="flex-1 p-4 overflow-y-auto space-y-2 selection:bg-white selection:text-black cursor-text"
          onClick={() => inputRef.current?.focus()}
        >
          {lines.map((item) => (
            <div
              key={item.id}
              className={`whitespace-pre-wrap leading-relaxed ${
                item.type === 'input'
                  ? 'text-white font-bold'
                  : item.type === 'error'
                  ? 'text-rose-400'
                  : item.type === 'success'
                  ? 'text-emerald-400'
                  : 'text-slate-300'
              }`}
            >
              {item.text}
            </div>
          ))}

          {/* Active Input Line */}
          <form onSubmit={handleCommand} className="flex items-center gap-1 text-white">
            <span className="shrink-0 text-sky-400 font-bold">
              {isDiskpart ? 'DISKPART> ' : `${currentDrive}> `}
            </span>
            <input
              ref={inputRef}
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              className="flex-1 bg-transparent border-none outline-none text-white font-mono text-xs"
              autoFocus
            />
          </form>
          <div ref={bottomRef} />
        </div>
      </div>
    </div>
  );
};
