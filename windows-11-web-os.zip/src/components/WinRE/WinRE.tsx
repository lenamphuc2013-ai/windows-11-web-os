import React, { useState, useEffect } from 'react';
import { WinREView, SafeModeType, UEFIConfig } from '../../types/winre';
import { WinRETerminal } from './WinRETerminal';
import { UEFIUtility } from './UEFIUtility';
import { StartupSettingsScreen } from './StartupSettingsScreen';
import { Win11Spinner } from '../BootScreen/Win11Spinner';
import {
  ArrowRight,
  HardDrive,
  Wrench,
  Power,
  RotateCcw,
  Sparkles,
  Shield,
  FileCode,
  Terminal,
  Settings,
  RefreshCw,
  Archive,
  Trash2,
  Download,
  FolderOpen,
  CheckCircle2,
  AlertTriangle,
  ChevronLeft,
  Sliders,
  Cpu,
} from 'lucide-react';

interface WinREProps {
  onContinue: () => void;
  onTurnOff: () => void;
  onStartSafeMode: (mode: SafeModeType) => void;
  onResetComplete: (keepFiles: boolean) => void;
  uefiConfig: UEFIConfig;
  onUpdateUEFI: (config: UEFIConfig) => void;
  initialView?: WinREView;
}

export const WinRE: React.FC<WinREProps> = ({
  onContinue,
  onTurnOff,
  onStartSafeMode,
  onResetComplete,
  uefiConfig,
  onUpdateUEFI,
  initialView = 'main',
}) => {
  const [currentView, setCurrentView] = useState<WinREView>(initialView);
  const [resetConfig, setResetConfig] = useState<{
    keepFiles: boolean;
    source: 'cloud' | 'local';
    cleanDrive: boolean;
  }>({
    keepFiles: true,
    source: 'local',
    cleanDrive: false,
  });

  // Progress state for various wizards
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [progressStage, setProgressStage] = useState<string>('');

  // Selected restore point
  const [selectedRestorePoint, setSelectedRestorePoint] = useState<string>('rp-1');
  const [selectedUpdateType, setSelectedUpdateType] = useState<'quality' | 'feature'>('quality');

  // Handle Startup Repair simulation
  const startStartupRepair = () => {
    setCurrentView('startup-repair-progress');
    setProgressPercent(15);
    setProgressStage('Đang chẩn đoán PC của bạn (Diagnosing your PC)...');

    setTimeout(() => {
      setProgressPercent(45);
      setProgressStage('Đang kiểm tra bảng phân vùng và bản ghi khởi động BCD...');
    }, 1800);

    setTimeout(() => {
      setProgressPercent(80);
      setProgressStage('Đang cố gắng sửa chữa các tệp khởi động (Attempting repairs)...');
    }, 3600);

    setTimeout(() => {
      setProgressPercent(100);
      setCurrentView('startup-repair-result');
    }, 5400);
  };

  // Handle System Restore simulation
  const startSystemRestore = () => {
    setCurrentView('system-restore-progress');
    setProgressPercent(10);
    setProgressStage('Khởi tạo Khôi phục Hệ thống (Initializing System Restore)...');

    setTimeout(() => {
      setProgressPercent(40);
      setProgressStage('Đang khôi phục tệp đăng ký Registry và trình điều khiển...');
    }, 1500);

    setTimeout(() => {
      setProgressPercent(75);
      setProgressStage('Đang xóa các bản cập nhật gần nhất gây lỗi...');
    }, 3200);

    setTimeout(() => {
      setProgressPercent(100);
      setProgressStage('Khôi phục thành công! Đang chuẩn bị khởi động lại...');
      setTimeout(() => {
        onContinue();
      }, 1500);
    }, 4800);
  };

  // Handle System Image Recovery simulation
  const startSystemImageRecovery = () => {
    setCurrentView('system-image-progress');
    setProgressPercent(10);
    setProgressStage('Đang đọc ảnh sao lưu WindowsImageBackup từ ổ đĩa...');

    setTimeout(() => {
      setProgressPercent(50);
      setProgressStage('Đang ghi cấu trúc phân vùng VHDX vào ổ đĩa hệ thống...');
    }, 2000);

    setTimeout(() => {
      setProgressPercent(100);
      setProgressStage('Khôi phục ảnh hoàn tất! Khởi động lại Windows...');
      setTimeout(() => {
        onContinue();
      }, 1500);
    }, 4000);
  };

  // Handle Uninstall Updates simulation
  const startUninstallUpdate = (type: 'quality' | 'feature') => {
    setSelectedUpdateType(type);
    setCurrentView('uninstall-updates-progress');
    setProgressPercent(15);
    setProgressStage(`Đang gỡ bỏ bản cập nhật ${type === 'quality' ? 'chất lượng KB5034848' : 'tính năng 23H2'}...`);

    setTimeout(() => {
      setProgressPercent(60);
      setProgressStage('Đang khôi phục các thành phần hệ thống trước đó...');
    }, 2000);

    setTimeout(() => {
      setProgressPercent(100);
      setProgressStage('Gỡ bản cập nhật thành công! Khởi động lại Windows 11...');
      setTimeout(() => {
        onContinue();
      }, 1500);
    }, 4000);
  };

  // Handle PC Reset progress simulation
  const startResetPC = () => {
    setCurrentView('reset-progress');
    setProgressPercent(1);
    setProgressStage('Đang chuẩn bị khôi phục máy tính này (Preparing to reset)...');

    let current = 1;
    const interval = setInterval(() => {
      current += Math.floor(Math.random() * 8) + 4;
      if (current >= 100) {
        current = 100;
        clearInterval(interval);
        setProgressPercent(100);
        setProgressStage('Cài đặt hoàn tất! Đang khởi động lại vào Windows 11 mới...');
        setTimeout(() => {
          onResetComplete(resetConfig.keepFiles);
        }, 1500);
      } else {
        setProgressPercent(current);
        if (current < 35) {
          setProgressStage(`Đang đặt lại PC này ${current}% (Resetting this PC)...`);
        } else if (current < 75) {
          setProgressStage(`Đang cài đặt lại Windows 11 ${current}% (Installing Windows 11)...`);
        } else {
          setProgressStage(`Đang hoàn tất cấu hình hệ thống ${current}% (Finishing up)...`);
        }
      }
    }, 300);
  };

  // Render Sub-Views
  if (currentView === 'uefi-settings') {
    return (
      <UEFIUtility
        config={uefiConfig}
        onSaveAndExit={(newCfg) => {
          onUpdateUEFI(newCfg);
          onContinue();
        }}
        onDiscardAndExit={() => setCurrentView('advanced-options')}
      />
    );
  }

  if (currentView === 'command-prompt') {
    return <WinRETerminal onClose={() => setCurrentView('advanced-options')} />;
  }

  if (currentView === 'startup-settings-menu') {
    return (
      <StartupSettingsScreen
        onSelectOption={(num, sm) => {
          onStartSafeMode(sm);
        }}
        onCancel={() => setCurrentView('advanced-options')}
      />
    );
  }

  return (
    <div className="fixed inset-0 z-[100] bg-[#005a9e] text-white font-sans select-none flex flex-col justify-between p-6 sm:p-12 overflow-y-auto">
      {/* Container Max Width */}
      <div className="w-full max-w-3xl mx-auto flex-1 flex flex-col justify-center animate-win11-fade">
        {/* ============================================================ */}
        {/* VIEW 1: MAIN MENU - CHOOSE AN OPTION */}
        {/* ============================================================ */}
        {currentView === 'main' && (
          <div className="space-y-8">
            <div>
              <h1 className="text-3xl sm:text-4xl font-light tracking-tight">Choose an option (Chọn một tùy chọn)</h1>
              <p className="text-sm text-sky-100 mt-2 font-normal">
                Windows Recovery Environment (WinRE) - Hệ thống phục hồi và sửa chữa Windows 11
              </p>
            </div>

            <div className="space-y-3">
              {/* Option 1: Continue */}
              <button
                onClick={onContinue}
                className="w-full flex items-center justify-between p-4 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-xl transition-all border border-white/20 text-left group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white/15 group-hover:bg-white/25 flex items-center justify-center text-white shrink-0">
                    <ArrowRight size={26} />
                  </div>
                  <div>
                    <div className="text-base font-semibold">Continue (Tiếp tục)</div>
                    <div className="text-xs text-sky-100 mt-0.5">
                      Exit and continue to Windows 11 (Thoát và khởi động vào Windows 11 bình thường)
                    </div>
                  </div>
                </div>
                <span className="text-xs text-sky-200 group-hover:text-white transition-colors">→</span>
              </button>

              {/* Option 2: Use a device */}
              <button
                onClick={() => setCurrentView('use-device')}
                className="w-full flex items-center justify-between p-4 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-xl transition-all border border-white/20 text-left group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white/15 group-hover:bg-white/25 flex items-center justify-center text-white shrink-0">
                    <HardDrive size={24} />
                  </div>
                  <div>
                    <div className="text-base font-semibold">Use a device (Sử dụng thiết bị)</div>
                    <div className="text-xs text-sky-100 mt-0.5">
                      Use a USB drive, network connection, or Windows recovery drive (Khởi động từ USB, mạng PXE...)
                    </div>
                  </div>
                </div>
                <span className="text-xs text-sky-200 group-hover:text-white transition-colors">→</span>
              </button>

              {/* Option 3: Troubleshoot */}
              <button
                onClick={() => setCurrentView('troubleshoot')}
                className="w-full flex items-center justify-between p-4 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-xl transition-all border border-white/20 text-left group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white/15 group-hover:bg-white/25 flex items-center justify-center text-white shrink-0">
                    <Wrench size={24} />
                  </div>
                  <div>
                    <div className="text-base font-semibold">Troubleshoot (Khắc phục sự cố)</div>
                    <div className="text-xs text-sky-100 mt-0.5">
                      Reset this PC or see advanced recovery options (Khôi phục máy này hoặc xem tùy chọn nâng cao)
                    </div>
                  </div>
                </div>
                <span className="text-xs text-sky-200 group-hover:text-white transition-colors">→</span>
              </button>

              {/* Option 4: Turn off your PC */}
              <button
                onClick={onTurnOff}
                className="w-full flex items-center justify-between p-4 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-xl transition-all border border-white/20 text-left group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white/15 group-hover:bg-white/25 flex items-center justify-center text-white shrink-0">
                    <Power size={24} />
                  </div>
                  <div>
                    <div className="text-base font-semibold">Turn off your PC (Tắt máy tính)</div>
                    <div className="text-xs text-sky-100 mt-0.5">
                      Completely shut down the computer (Tắt hoàn toàn nguồn máy tính)
                    </div>
                  </div>
                </div>
                <span className="text-xs text-sky-200 group-hover:text-white transition-colors">→</span>
              </button>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 2: USE A DEVICE */}
        {/* ============================================================ */}
        {currentView === 'use-device' && (
          <div className="space-y-6">
            <button
              onClick={() => setCurrentView('main')}
              className="flex items-center gap-2 text-xs font-semibold text-sky-200 hover:text-white transition-colors"
            >
              <ChevronLeft size={16} /> Quay lại (Back)
            </button>

            <div>
              <h1 className="text-3xl font-light">Use a device (Sử dụng thiết bị)</h1>
              <p className="text-xs text-sky-100 mt-1">Chọn thiết bị để khởi động máy tính:</p>
            </div>

            <div className="space-y-3">
              {[
                { name: 'UEFI: Generic USB Flash Disk 32GB', desc: 'USB cài đặt Windows 11 / Cứu hộ' },
                { name: 'UEFI: Realtek PXE IPv4/IPv6 Network Boot', desc: 'Khởi động qua mạng nội bộ' },
                { name: 'Windows Boot Manager (Samsung SSD 990 PRO)', desc: 'Ổ đĩa hệ thống chính' },
                { name: 'EFI File Boot (bootx64.efi)', desc: 'Duyệt tệp EFI trên phân vùng ESP' },
              ].map((item, idx) => (
                <button
                  key={idx}
                  onClick={onContinue}
                  className="w-full flex items-center gap-4 p-4 bg-white/10 hover:bg-white/20 rounded-xl transition-all border border-white/20 text-left"
                >
                  <HardDrive size={22} className="text-sky-300 shrink-0" />
                  <div>
                    <div className="text-sm font-semibold">{item.name}</div>
                    <div className="text-xs text-sky-200">{item.desc}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 3: TROUBLESHOOT */}
        {/* ============================================================ */}
        {currentView === 'troubleshoot' && (
          <div className="space-y-6">
            <button
              onClick={() => setCurrentView('main')}
              className="flex items-center gap-2 text-xs font-semibold text-sky-200 hover:text-white transition-colors"
            >
              <ChevronLeft size={16} /> Quay lại (Back)
            </button>

            <div>
              <h1 className="text-3xl font-light">Troubleshoot (Khắc phục sự cố)</h1>
              <p className="text-xs text-sky-100 mt-1">Chọn hành động để sửa chữa hoặc đặt lại máy tính:</p>
            </div>

            <div className="space-y-3">
              {/* Reset this PC */}
              <button
                onClick={() => setCurrentView('reset-option')}
                className="w-full flex items-center justify-between p-4 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-xl transition-all border border-white/20 text-left group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white/15 group-hover:bg-white/25 flex items-center justify-center text-white shrink-0">
                    <RotateCcw size={24} />
                  </div>
                  <div>
                    <div className="text-base font-semibold">Reset this PC (Khôi phục máy này)</div>
                    <div className="text-xs text-sky-100 mt-0.5">
                      Lets you choose to keep or remove your files, then reinstalls Windows (Đặt lại Windows về trạng thái gốc)
                    </div>
                  </div>
                </div>
                <span className="text-xs text-sky-200 group-hover:text-white">→</span>
              </button>

              {/* Advanced Options */}
              <button
                onClick={() => setCurrentView('advanced-options')}
                className="w-full flex items-center justify-between p-4 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-xl transition-all border border-white/20 text-left group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white/15 group-hover:bg-white/25 flex items-center justify-center text-white shrink-0">
                    <Sliders size={24} />
                  </div>
                  <div>
                    <div className="text-base font-semibold">Advanced options (Tùy chọn nâng cao)</div>
                    <div className="text-xs text-sky-100 mt-0.5">
                      Open detailed repair, restore, command prompt and UEFI tools (Mở danh sách công cụ sửa chữa chi tiết)
                    </div>
                  </div>
                </div>
                <span className="text-xs text-sky-200 group-hover:text-white">→</span>
              </button>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 4: RESET THIS PC - STEP 1: KEEP FILES VS REMOVE ALL */}
        {/* ============================================================ */}
        {currentView === 'reset-option' && (
          <div className="space-y-6">
            <button
              onClick={() => setCurrentView('troubleshoot')}
              className="flex items-center gap-2 text-xs font-semibold text-sky-200 hover:text-white transition-colors"
            >
              <ChevronLeft size={16} /> Quay lại (Back)
            </button>

            <div>
              <h1 className="text-3xl font-light">Reset this PC (Khôi phục máy này)</h1>
              <p className="text-xs text-sky-100 mt-1">Chọn tùy chọn lưu giữ dữ liệu của bạn:</p>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => {
                  setResetConfig((prev) => ({ ...prev, keepFiles: true }));
                  setCurrentView('reset-source');
                }}
                className="w-full p-4 bg-white/10 hover:bg-white/20 rounded-xl transition-all border border-white/20 text-left flex items-center justify-between group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
                    <FolderOpen size={20} />
                  </div>
                  <div>
                    <div className="text-sm font-bold">Keep my files (Giữ tệp của tôi)</div>
                    <div className="text-xs text-sky-100 mt-0.5">
                      Xóa ứng dụng, mật khẩu, mã PIN và cài đặt, nhưng giữ lại các tệp cá nhân (ảnh, video, tài liệu, Desktop).
                    </div>
                  </div>
                </div>
                <span className="text-xs text-sky-200">→</span>
              </button>

              <button
                onClick={() => {
                  setResetConfig((prev) => ({ ...prev, keepFiles: false }));
                  setCurrentView('reset-source');
                }}
                className="w-full p-4 bg-white/10 hover:bg-white/20 rounded-xl transition-all border border-white/20 text-left flex items-center justify-between group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-rose-500/30 flex items-center justify-center shrink-0">
                    <Trash2 size={20} />
                  </div>
                  <div>
                    <div className="text-sm font-bold">Remove everything (Xóa hết mọi thứ)</div>
                    <div className="text-xs text-sky-100 mt-0.5">
                      Xóa sạch toàn bộ tệp cá nhân, tài khoản, mật khẩu, mã PIN, ứng dụng và khôi phục cài đặt gốc như máy mới xuất xưởng.
                    </div>
                  </div>
                </div>
                <span className="text-xs text-sky-200">→</span>
              </button>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 5: RESET THIS PC - STEP 2: CLOUD DOWNLOAD VS LOCAL */}
        {/* ============================================================ */}
        {currentView === 'reset-source' && (
          <div className="space-y-6">
            <button
              onClick={() => setCurrentView('reset-option')}
              className="flex items-center gap-2 text-xs font-semibold text-sky-200 hover:text-white transition-colors"
            >
              <ChevronLeft size={16} /> Quay lại (Back)
            </button>

            <div>
              <h1 className="text-3xl font-light">How would you like to reinstall Windows?</h1>
              <p className="text-xs text-sky-100 mt-1">Chọn nguồn tệp cài đặt Windows:</p>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => {
                  setResetConfig((prev) => ({ ...prev, source: 'local' }));
                  if (!resetConfig.keepFiles) {
                    setCurrentView('reset-clean-drive');
                  } else {
                    setCurrentView('reset-confirm');
                  }
                }}
                className="w-full p-4 bg-white/10 hover:bg-white/20 rounded-xl transition-all border border-white/20 text-left flex items-center justify-between group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
                    <HardDrive size={20} />
                  </div>
                  <div>
                    <div className="text-sm font-bold">Local reinstall (Cài lại cục bộ)</div>
                    <div className="text-xs text-sky-100 mt-0.5">
                      Cài lại Windows bằng các tệp có sẵn trên phân vùng khôi phục của máy này (Nhanh).
                    </div>
                  </div>
                </div>
                <span className="text-xs text-sky-200">→</span>
              </button>

              <button
                onClick={() => {
                  setResetConfig((prev) => ({ ...prev, source: 'cloud' }));
                  if (!resetConfig.keepFiles) {
                    setCurrentView('reset-clean-drive');
                  } else {
                    setCurrentView('reset-confirm');
                  }
                }}
                className="w-full p-4 bg-white/10 hover:bg-white/20 rounded-xl transition-all border border-white/20 text-left flex items-center justify-between group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
                    <Download size={20} />
                  </div>
                  <div>
                    <div className="text-sm font-bold">Cloud download (Tải xuống từ đám mây)</div>
                    <div className="text-xs text-sky-100 mt-0.5">
                      Tải bản dựng Windows 11 mới nhất từ máy chủ Microsoft và cài đặt lại.
                    </div>
                  </div>
                </div>
                <span className="text-xs text-sky-200">→</span>
              </button>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 6: RESET THIS PC - STEP 3: CLEAN DRIVE (IF REMOVE ALL) */}
        {/* ============================================================ */}
        {currentView === 'reset-clean-drive' && (
          <div className="space-y-6">
            <button
              onClick={() => setCurrentView('reset-source')}
              className="flex items-center gap-2 text-xs font-semibold text-sky-200 hover:text-white transition-colors"
            >
              <ChevronLeft size={16} /> Quay lại (Back)
            </button>

            <div>
              <h1 className="text-3xl font-light">Do you want to clean the drives, too?</h1>
              <p className="text-xs text-sky-100 mt-1">Lựa chọn mức độ xóa ổ đĩa:</p>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => {
                  setResetConfig((prev) => ({ ...prev, cleanDrive: false }));
                  setCurrentView('reset-confirm');
                }}
                className="w-full p-4 bg-white/10 hover:bg-white/20 rounded-xl transition-all border border-white/20 text-left flex items-center justify-between group"
              >
                <div>
                  <div className="text-sm font-bold">Just remove my files (Chỉ xóa tệp của tôi)</div>
                  <div className="text-xs text-sky-100 mt-0.5">
                    Nhanh hơn, phù hợp khi bạn vẫn tiếp tục giữ máy tính này để sử dụng.
                  </div>
                </div>
                <span className="text-xs text-sky-200">→</span>
              </button>

              <button
                onClick={() => {
                  setResetConfig((prev) => ({ ...prev, cleanDrive: true }));
                  setCurrentView('reset-confirm');
                }}
                className="w-full p-4 bg-white/10 hover:bg-white/20 rounded-xl transition-all border border-white/20 text-left flex items-center justify-between group"
              >
                <div>
                  <div className="text-sm font-bold">Fully clean the drive (Hoàn toàn xóa ổ đĩa)</div>
                  <div className="text-xs text-sky-100 mt-0.5">
                    Xóa sạch ghi đè dữ liệu khó phục hồi, an toàn và bảo mật cao khi bạn muốn bán lại máy tính.
                  </div>
                </div>
                <span className="text-xs text-sky-200">→</span>
              </button>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 7: RESET THIS PC - CONFIRMATION */}
        {/* ============================================================ */}
        {currentView === 'reset-confirm' && (
          <div className="space-y-6">
            <button
              onClick={() => setCurrentView('reset-source')}
              className="flex items-center gap-2 text-xs font-semibold text-sky-200 hover:text-white transition-colors"
            >
              <ChevronLeft size={16} /> Quay lại (Back)
            </button>

            <div>
              <h1 className="text-3xl font-light">Ready to reset this PC (Sẵn sàng khôi phục)</h1>
              <p className="text-xs text-sky-100 mt-1">Quá trình này không thể hoàn tác. Các hành động sẽ diễn ra:</p>
            </div>

            <div className="p-4 bg-black/20 rounded-xl border border-white/15 space-y-2 text-xs">
              <div className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-emerald-400" />
                <span>
                  {resetConfig.keepFiles
                    ? 'Giữ lại các tệp cá nhân trong thư mục C:\\Users\\User'
                    : 'Xóa toàn bộ tệp cá nhân và tài khoản người dùng'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-emerald-400" />
                <span>Xóa các ứng dụng HTML và ứng dụng tùy chỉnh đã cài đặt</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-emerald-400" />
                <span>Khôi phục các cài đặt hệ thống về mặc định nhà sản xuất (xóa sạch mật khẩu, mã PIN & tài khoản cũ)</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-emerald-400" />
                <span>
                  Phương thức: {resetConfig.source === 'cloud' ? 'Tải xuống từ đám mây (Cloud)' : 'Cài đặt lại cục bộ (Local)'}
                </span>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={startResetPC}
                className="px-6 py-2.5 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-lg transition-all"
              >
                Reset (Đặt lại ngay)
              </button>
              <button
                onClick={() => setCurrentView('troubleshoot')}
                className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl transition-all"
              >
                Cancel (Hủy)
              </button>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 8: RESET THIS PC - PROGRESS SCREEN */}
        {/* ============================================================ */}
        {currentView === 'reset-progress' && (
          <div className="flex flex-col items-center justify-center space-y-8 text-center py-12">
            <Win11Spinner size={54} dotSize={6} color="#ffffff" />
            <div className="space-y-2">
              <h2 className="text-2xl font-light">{progressStage}</h2>
              <div className="text-3xl font-semibold font-mono text-sky-200">{progressPercent}%</div>
              <p className="text-xs text-sky-200 mt-2">Máy tính có thể khởi động lại vài lần. Vui lòng không tắt nguồn.</p>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 9: ADVANCED OPTIONS MENU */}
        {/* ============================================================ */}
        {currentView === 'advanced-options' && (
          <div className="space-y-6">
            <button
              onClick={() => setCurrentView('troubleshoot')}
              className="flex items-center gap-2 text-xs font-semibold text-sky-200 hover:text-white transition-colors"
            >
              <ChevronLeft size={16} /> Quay lại Troubleshoot (Back)
            </button>

            <div>
              <h1 className="text-3xl font-light">Advanced options (Tùy chọn nâng cao)</h1>
              <p className="text-xs text-sky-100 mt-1">Chọn công cụ chuyên sâu để sửa chữa và khắc phục:</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* 1. Startup Repair */}
              <button
                onClick={startStartupRepair}
                className="p-4 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-xl transition-all border border-white/20 text-left group flex items-start gap-3"
              >
                <div className="p-2 rounded-lg bg-white/15 shrink-0 text-sky-300">
                  <Wrench size={20} />
                </div>
                <div>
                  <div className="text-sm font-bold">Startup Repair (Sửa chữa khởi động)</div>
                  <div className="text-xs text-sky-100 mt-0.5">
                    Tự động chẩn đoán và khắc phục sự cố khiến Windows không thể khởi động được.
                  </div>
                </div>
              </button>

              {/* 2. Startup Settings */}
              <button
                onClick={() => setCurrentView('startup-settings-info')}
                className="p-4 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-xl transition-all border border-white/20 text-left group flex items-start gap-3"
              >
                <div className="p-2 rounded-lg bg-white/15 shrink-0 text-sky-300">
                  <Sliders size={20} />
                </div>
                <div>
                  <div className="text-sm font-bold">Startup Settings (Cài đặt khởi động)</div>
                  <div className="text-xs text-sky-100 mt-0.5">
                    Thay đổi hành vi khởi động: Bật chế độ An toàn (Safe Mode), tắt kiểm tra chữ ký...
                  </div>
                </div>
              </button>

              {/* 3. Command Prompt */}
              <button
                onClick={() => setCurrentView('command-prompt')}
                className="p-4 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-xl transition-all border border-white/20 text-left group flex items-start gap-3"
              >
                <div className="p-2 rounded-lg bg-white/15 shrink-0 text-sky-300">
                  <Terminal size={20} />
                </div>
                <div>
                  <div className="text-sm font-bold">Command Prompt (Dấu nhắc lệnh)</div>
                  <div className="text-xs text-sky-100 mt-0.5">
                    Mở CMD quyền quản trị WinRE chạy lệnh: sfc, chkdsk, diskpart, bootrec, bcdedit...
                  </div>
                </div>
              </button>

              {/* 4. Uninstall Updates */}
              <button
                onClick={() => setCurrentView('uninstall-updates')}
                className="p-4 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-xl transition-all border border-white/20 text-left group flex items-start gap-3"
              >
                <div className="p-2 rounded-lg bg-white/15 shrink-0 text-sky-300">
                  <RotateCcw size={20} />
                </div>
                <div>
                  <div className="text-sm font-bold">Uninstall Updates (Gỡ cài đặt bản cập nhật)</div>
                  <div className="text-xs text-sky-100 mt-0.5">
                    Gỡ bản cập nhật chất lượng hoặc tính năng đã cài gần đây gây lỗi hệ thống.
                  </div>
                </div>
              </button>

              {/* 5. UEFI Firmware Settings */}
              <button
                onClick={() => setCurrentView('uefi-settings')}
                className="p-4 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-xl transition-all border border-white/20 text-left group flex items-start gap-3"
              >
                <div className="p-2 rounded-lg bg-white/15 shrink-0 text-sky-300">
                  <Cpu size={20} />
                </div>
                <div>
                  <div className="text-sm font-bold">UEFI Firmware Settings (Cài đặt UEFI/BIOS)</div>
                  <div className="text-xs text-sky-100 mt-0.5">
                    Khởi động vào BIOS/UEFI cấu hình Secure Boot, TPM 2.0, thứ tự ổ đĩa, phần cứng.
                  </div>
                </div>
              </button>

              {/* 6. System Restore */}
              <button
                onClick={() => setCurrentView('system-restore')}
                className="p-4 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-xl transition-all border border-white/20 text-left group flex items-start gap-3"
              >
                <div className="p-2 rounded-lg bg-white/15 shrink-0 text-sky-300">
                  <RefreshCw size={20} />
                </div>
                <div>
                  <div className="text-sm font-bold">System Restore (Khôi phục hệ thống)</div>
                  <div className="text-xs text-sky-100 mt-0.5">
                    Dùng điểm khôi phục đã ghi lại để đưa Windows về trạng thái hoạt động tốt trước đó.
                  </div>
                </div>
              </button>

              {/* 7. System Image Recovery */}
              <button
                onClick={() => setCurrentView('system-image')}
                className="p-4 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-xl transition-all border border-white/20 text-left group flex items-start gap-3 md:col-span-2"
              >
                <div className="p-2 rounded-lg bg-white/15 shrink-0 text-sky-300">
                  <Archive size={20} />
                </div>
                <div>
                  <div className="text-sm font-bold">System Image Recovery (Khôi phục từ ảnh hệ thống)</div>
                  <div className="text-xs text-sky-100 mt-0.5">
                    Khôi phục toàn bộ máy tính từ tệp sao lưu hình ảnh hệ thống đã tạo trước đó.
                  </div>
                </div>
              </button>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 10: STARTUP REPAIR PROGRESS & RESULT */}
        {/* ============================================================ */}
        {currentView === 'startup-repair-progress' && (
          <div className="flex flex-col items-center justify-center space-y-6 text-center py-12">
            <Win11Spinner size={50} dotSize={6} color="#ffffff" />
            <div className="space-y-2">
              <h2 className="text-2xl font-light">{progressStage}</h2>
              <p className="text-xs text-sky-200">Đang kiểm tra ổ đĩa, tệp khởi động winload.efi và BCD registry...</p>
            </div>
          </div>
        )}

        {currentView === 'startup-repair-result' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-light">Startup Repair (Kết quả sửa chữa khởi động)</h1>
              <p className="text-xs text-sky-100 mt-1">Kết quả chẩn đoán và khắc phục sự cố:</p>
            </div>

            <div className="p-4 bg-black/20 rounded-xl border border-white/15 space-y-3 text-xs">
              <div className="flex items-center gap-2 text-emerald-300 font-bold text-sm">
                <CheckCircle2 size={18} />
                <span>Sửa chữa thành công: Hệ thống đã khắc phục lỗi khởi động!</span>
              </div>
              <p className="text-sky-100 leading-relaxed">
                Đã kiểm tra cấu hình EFI BCD, sửa chữa liên kết tệp hệ thống, và khôi phục bản ghi khởi động.
              </p>
              <div className="font-mono text-[11px] text-sky-300 bg-black/30 p-2.5 rounded">
                Log file: C:\Windows\System32\Logfiles\Srt\SrtTrail.txt
                <br />
                Status: 0x0 (Success)
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={onContinue}
                className="px-6 py-2.5 bg-white text-black font-bold text-xs rounded-xl shadow-lg hover:bg-slate-200 transition-colors"
              >
                Khởi động lại (Restart)
              </button>
              <button
                onClick={() => setCurrentView('advanced-options')}
                className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl transition-all"
              >
                Tùy chọn nâng cao khác
              </button>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 11: SYSTEM RESTORE */}
        {/* ============================================================ */}
        {currentView === 'system-restore' && (
          <div className="space-y-6">
            <button
              onClick={() => setCurrentView('advanced-options')}
              className="flex items-center gap-2 text-xs font-semibold text-sky-200 hover:text-white transition-colors"
            >
              <ChevronLeft size={16} /> Quay lại (Back)
            </button>

            <div>
              <h1 className="text-3xl font-light">System Restore (Khôi phục hệ thống)</h1>
              <p className="text-xs text-sky-100 mt-1">
                Chọn điểm khôi phục trước khi máy tính gặp sự cố (Không ảnh hưởng đến tài liệu, ảnh của bạn):
              </p>
            </div>

            <div className="space-y-2">
              {[
                {
                  id: 'rp-1',
                  date: '2026-08-25 14:30:00',
                  desc: 'Windows Update KB5034848 (Cập nhật hệ thống)',
                  type: 'System Checkpoint',
                },
                {
                  id: 'rp-2',
                  date: '2026-08-20 09:15:22',
                  desc: 'Cài đặt Visual Studio & Driver mở rộng (Thủ công)',
                  type: 'Manual',
                },
                {
                  id: 'rp-3',
                  date: '2026-08-15 18:00:00',
                  desc: 'Điểm khôi phục định kỳ tự động',
                  type: 'Auto',
                },
              ].map((rp) => (
                <div
                  key={rp.id}
                  onClick={() => setSelectedRestorePoint(rp.id)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all flex items-center justify-between text-xs ${
                    selectedRestorePoint === rp.id
                      ? 'bg-white/25 border-white shadow'
                      : 'bg-white/10 border-white/10 hover:bg-white/15'
                  }`}
                >
                  <div>
                    <div className="font-bold text-sm">{rp.desc}</div>
                    <div className="text-sky-200 mt-0.5">Thời gian: {rp.date}</div>
                  </div>
                  <span className="text-[11px] bg-black/30 px-2 py-1 rounded font-mono">{rp.type}</span>
                </div>
              ))}
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={startSystemRestore}
                className="px-6 py-2.5 bg-white text-black font-bold text-xs rounded-xl shadow-lg hover:bg-slate-200 transition-colors"
              >
                Tiếp tục khôi phục (Restore)
              </button>
              <button
                onClick={() => setCurrentView('advanced-options')}
                className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl transition-all"
              >
                Hủy (Cancel)
              </button>
            </div>
          </div>
        )}

        {currentView === 'system-restore-progress' && (
          <div className="flex flex-col items-center justify-center space-y-6 text-center py-12">
            <Win11Spinner size={50} dotSize={6} color="#ffffff" />
            <div className="space-y-2">
              <h2 className="text-2xl font-light">{progressStage}</h2>
              <div className="text-2xl font-mono font-semibold text-sky-200">{progressPercent}%</div>
              <p className="text-xs text-sky-200">Đang khôi phục tệp hệ thống...</p>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 12: SYSTEM IMAGE RECOVERY */}
        {/* ============================================================ */}
        {currentView === 'system-image' && (
          <div className="space-y-6">
            <button
              onClick={() => setCurrentView('advanced-options')}
              className="flex items-center gap-2 text-xs font-semibold text-sky-200 hover:text-white transition-colors"
            >
              <ChevronLeft size={16} /> Quay lại (Back)
            </button>

            <div>
              <h1 className="text-3xl font-light">System Image Recovery (Khôi phục từ ảnh hệ thống)</h1>
              <p className="text-xs text-sky-100 mt-1">Tìm thấy bản sao lưu hình ảnh hệ thống trên thiết bị:</p>
            </div>

            <div className="p-4 bg-black/20 rounded-xl border border-white/15 space-y-2 text-xs">
              <div className="flex items-center justify-between font-bold text-sm">
                <span>Vị trí: D:\WindowsImageBackup\WIN11-PC</span>
                <span className="text-sky-300">42.8 GB</span>
              </div>
              <div className="text-sky-200">Ngày tạo: 2026-08-10 22:45:10 | Ổ đĩa nguồn: C: (NTFS)</div>
              <div className="text-sky-200">Cấu hình: Toàn bộ phân vùng EFI + Windows 11 Pro</div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={startSystemImageRecovery}
                className="px-6 py-2.5 bg-white text-black font-bold text-xs rounded-xl shadow-lg hover:bg-slate-200 transition-colors"
              >
                Bắt đầu khôi phục ảnh (Start Re-imaging)
              </button>
              <button
                onClick={() => setCurrentView('advanced-options')}
                className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl transition-all"
              >
                Hủy (Cancel)
              </button>
            </div>
          </div>
        )}

        {currentView === 'system-image-progress' && (
          <div className="flex flex-col items-center justify-center space-y-6 text-center py-12">
            <Win11Spinner size={50} dotSize={6} color="#ffffff" />
            <div className="space-y-2">
              <h2 className="text-2xl font-light">{progressStage}</h2>
              <div className="text-2xl font-mono font-semibold text-sky-200">{progressPercent}%</div>
              <p className="text-xs text-sky-200">Đang ghi lại ảnh đĩa...</p>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 13: UNINSTALL UPDATES */}
        {/* ============================================================ */}
        {currentView === 'uninstall-updates' && (
          <div className="space-y-6">
            <button
              onClick={() => setCurrentView('advanced-options')}
              className="flex items-center gap-2 text-xs font-semibold text-sky-200 hover:text-white transition-colors"
            >
              <ChevronLeft size={16} /> Quay lại (Back)
            </button>

            <div>
              <h1 className="text-3xl font-light">Uninstall Updates (Gỡ cài đặt bản cập nhật)</h1>
              <p className="text-xs text-sky-100 mt-1">Chọn loại bản cập nhật muốn gỡ bỏ:</p>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => startUninstallUpdate('quality')}
                className="w-full p-4 bg-white/10 hover:bg-white/20 rounded-xl transition-all border border-white/20 text-left flex items-center justify-between group"
              >
                <div>
                  <div className="text-sm font-bold">Uninstall latest quality update (Gỡ bản cập nhật chất lượng)</div>
                  <div className="text-xs text-sky-100 mt-0.5">
                    Gỡ các bản cập nhật bảo mật & sửa lỗi nhỏ hàng tháng (Ví dụ: KB5034848).
                  </div>
                </div>
                <span className="text-xs text-sky-200">→</span>
              </button>

              <button
                onClick={() => startUninstallUpdate('feature')}
                className="w-full p-4 bg-white/10 hover:bg-white/20 rounded-xl transition-all border border-white/20 text-left flex items-center justify-between group"
              >
                <div>
                  <div className="text-sm font-bold">Uninstall latest feature update (Gỡ bản cập nhật tính năng)</div>
                  <div className="text-xs text-sky-100 mt-0.5">
                    Gỡ bản nâng cấp phiên bản lớn hàng năm (Ví dụ: 23H2 quay về bản trước).
                  </div>
                </div>
                <span className="text-xs text-sky-200">→</span>
              </button>
            </div>
          </div>
        )}

        {currentView === 'uninstall-updates-progress' && (
          <div className="flex flex-col items-center justify-center space-y-6 text-center py-12">
            <Win11Spinner size={50} dotSize={6} color="#ffffff" />
            <div className="space-y-2">
              <h2 className="text-2xl font-light">{progressStage}</h2>
              <div className="text-2xl font-mono font-semibold text-sky-200">{progressPercent}%</div>
              <p className="text-xs text-sky-200">Đang gỡ bản cập nhật...</p>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 14: STARTUP SETTINGS PRE-RESTART INFO */}
        {/* ============================================================ */}
        {currentView === 'startup-settings-info' && (
          <div className="space-y-6">
            <button
              onClick={() => setCurrentView('advanced-options')}
              className="flex items-center gap-2 text-xs font-semibold text-sky-200 hover:text-white transition-colors"
            >
              <ChevronLeft size={16} /> Quay lại (Back)
            </button>

            <div>
              <h1 className="text-3xl font-light">Startup Settings (Cài đặt khởi động)</h1>
              <p className="text-xs text-sky-100 mt-1">
                Restart to change Windows options such as (Khởi động lại để thay đổi các tùy chọn như):
              </p>
            </div>

            <div className="p-4 bg-black/20 rounded-xl border border-white/15 space-y-1.5 text-xs text-sky-100">
              <div>• Enable low-resolution video mode (Bật video độ phân giải thấp)</div>
              <div>• Enable debugging mode (Bật chế độ gỡ lỗi)</div>
              <div>• Enable boot logging (Bật ghi nhật ký khởi động)</div>
              <div>• Enable Safe Mode (Bật chế độ An toàn tối thiểu)</div>
              <div>• Enable Safe Mode with Networking (Bật chế độ An toàn với mạng)</div>
              <div>• Enable Safe Mode with Command Prompt (Bật chế độ An toàn với Dấu nhắc lệnh)</div>
              <div>• Disable driver signature enforcement (Tắt Tải chữ ký bắt buộc)</div>
              <div>• Disable early-launch anti-malware protection (Tắt Bảo vệ chống mã độc khởi động)</div>
              <div>• Disable automatic restart on system failure (Tắt tự động khởi động lại khi lỗi)</div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setCurrentView('startup-settings-menu')}
                className="px-6 py-2.5 bg-white text-black font-bold text-xs rounded-xl shadow-lg hover:bg-slate-200 transition-colors"
              >
                Restart (Khởi động lại ngay)
              </button>
              <button
                onClick={() => setCurrentView('advanced-options')}
                className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl transition-all"
              >
                Cancel (Hủy)
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className="w-full max-w-3xl mx-auto flex items-center justify-between text-xs text-sky-200 border-t border-white/10 pt-4">
        <span>Microsoft Windows 11 Recovery Environment (WinRE)</span>
        <span>Version 10.0.22631</span>
      </div>
    </div>
  );
};
