import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, X, Shield, FolderOpen } from 'lucide-react';
import { useOS } from '../../../context/OSContext';

interface NewTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewTaskModal: React.FC<NewTaskModalProps> = ({ isOpen, onClose }) => {
  const { openApp, addNotification } = useOS();
  const [command, setCommand] = useState('');
  const [runAsAdmin, setRunAsAdmin] = useState(false);

  if (!isOpen) return null;

  const handleRun = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cmd = command.trim().toLowerCase();
    if (!cmd) return;

    if (cmd === 'cmd' || cmd === 'terminal' || cmd === 'powershell') {
      openApp('terminal');
    } else if (cmd === 'notepad') {
      openApp('notepad');
    } else if (cmd === 'calc' || cmd === 'calculator') {
      openApp('calc');
    } else if (cmd === 'explorer' || cmd === 'files') {
      openApp('explorer');
    } else if (cmd === 'edge' || cmd === 'msedge' || cmd === 'browser' || cmd.startsWith('http')) {
      openApp('edge', { initialUrl: cmd.startsWith('http') ? cmd : 'https://www.bing.com' });
    } else if (cmd === 'settings' || cmd === 'control') {
      openApp('settings');
    } else if (cmd === 'paint' || cmd === 'mspaint') {
      openApp('paint');
    } else if (cmd === 'sec' || cmd === 'security' || cmd === 'windowsdefender') {
      openApp('security');
    } else if (cmd === 'taskmgr' || cmd === 'taskmanager') {
      openApp('taskmanager');
    } else {
      // Default to terminal execution or notify
      openApp('terminal', { initialCommand: cmd });
    }

    addNotification(
      'Tạo tác vụ mới',
      `Đã khởi chạy tác vụ "${command}" ${runAsAdmin ? '(Quyền quản trị viên)' : ''}`,
      'taskbar'
    );

    setCommand('');
    onClose();
  };

  return (
    <AnimatePresence>
      <div
        id="new-task-modal-backdrop"
        className="fixed inset-0 z-[10000] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          id="new-task-modal-container"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="w-full max-w-md bg-white dark:bg-[#202020] rounded-2xl shadow-2xl border border-slate-200 dark:border-zinc-700/80 p-5 flex flex-col gap-4 text-slate-800 dark:text-slate-100 select-none"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-zinc-800">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-sky-500/15 text-sky-600 dark:text-sky-400 flex items-center justify-center">
                <Play size={16} />
              </div>
              <div>
                <h3 className="text-sm font-bold">Tạo tác vụ mới</h3>
                <p className="text-[11px] text-slate-500 dark:text-zinc-400">
                  Gõ tên chương trình, thư mục, tài liệu hoặc tài nguyên Internet
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:bg-red-500 hover:text-white transition-colors"
            >
              <X size={15} />
            </button>
          </div>

          <form onSubmit={handleRun} className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-zinc-300">
                Mở (Open):
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={command}
                  onChange={(e) => setCommand(e.target.value)}
                  placeholder="Ví dụ: cmd, notepad, explorer, calc, edge..."
                  autoFocus
                  className="flex-1 px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-800 dark:text-slate-100 outline-none focus:ring-2 focus:ring-sky-500/50"
                />
                <button
                  type="button"
                  onClick={() => openApp('explorer')}
                  className="flex items-center gap-1 px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-zinc-700 bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 dark:hover:bg-zinc-700 transition-colors shrink-0"
                  title="Duyệt tệp tin..."
                >
                  <FolderOpen size={14} />
                  <span>Duyệt...</span>
                </button>
              </div>
            </div>

            <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-zinc-300 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={runAsAdmin}
                onChange={(e) => setRunAsAdmin(e.target.checked)}
                className="rounded border-slate-300 dark:border-zinc-700 text-sky-500 focus:ring-sky-500"
              />
              <span className="flex items-center gap-1">
                <Shield size={12} className="text-amber-500" />
                Tạo tác vụ này với đặc quyền quản trị viên (Admin)
              </span>
            </label>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-zinc-800">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-1.5 rounded-xl text-xs font-medium text-slate-600 dark:text-zinc-300 hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors"
              >
                Hủy
              </button>
              <button
                type="submit"
                disabled={!command.trim()}
                className="px-5 py-1.5 rounded-xl bg-sky-500 hover:bg-sky-600 disabled:opacity-50 text-white text-xs font-semibold shadow-sm transition-all active:scale-95"
              >
                OK
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
