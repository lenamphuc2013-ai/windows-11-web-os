export type TaskManagerTab =
  | 'processes'
  | 'performance'
  | 'app_history'
  | 'users'
  | 'details'
  | 'services';

export type PriorityLevel =
  | 'low'
  | 'below_normal'
  | 'normal'
  | 'above_normal'
  | 'high'
  | 'realtime';

export type PowerUsageLevel = 'Rất thấp' | 'Thấp' | 'Trung bình' | 'Cao' | 'Rất cao';

export interface ProcessItemData {
  id: string;
  name: string;
  displayName: string;
  group: 'apps' | 'background' | 'windows';
  status: 'Đang chạy' | 'Tạm dừng' | 'Không phản hồi';
  cpu: number; // percentage
  memory: number; // MB
  disk: number; // MB/s
  network: number; // Mbps
  powerUsage: PowerUsageLevel;
  publisher: string;
  pid: number;
  userName: string;
  version: string;
  filePath: string;
  commandLine: string;
  priority: PriorityLevel;
  architecture: '64-bit' | '32-bit';
  serviceName?: string;
  packageName?: string;
  uacVirtualization?: boolean;
  windowId?: string;
  icon?: string;
}

export interface AppHistoryItemData {
  id: string;
  appName: string;
  icon?: string;
  runtime: string; // e.g. "01:24:18"
  cpuTime: string; // e.g. "12m 45s"
  avgMemory: number; // MB
  diskUsage: string; // e.g. "45.8 MB"
  networkUsage: string; // e.g. "128.4 MB"
  activeDuration: string; // e.g. "3 ngày 4 giờ"
  lastOpened: string; // e.g. "Hôm nay 10:15"
  status: 'running' | 'closed';
}

export interface UserSessionData {
  id: string;
  userName: string;
  status: 'Đang hoạt động' | 'Ngắt kết nối';
  cpu: number;
  memory: number;
  disk: number;
  network: number;
  loginTime: string;
  loginAddress: string;
  clientVersion: string;
  processes: ProcessItemData[];
}

export type ServiceStatus =
  | 'Đang chạy'
  | 'Đã dừng'
  | 'Tạm dừng'
  | 'Đang dừng'
  | 'Đang khởi động';

export type ServiceStartupType =
  | 'Tự động'
  | 'Tự động (trễ)'
  | 'Thủ công'
  | 'Tắt'
  | 'Đã tắt';

export interface ServiceItemData {
  id: string;
  name: string;
  description: string;
  status: ServiceStatus;
  startupType: ServiceStartupType;
  executablePath: string;
  logOnAs: string;
  dependencies: string;
  pid?: number;
}

export type PerformanceDeviceType = 'cpu' | 'memory' | 'disk_c' | 'disk_d' | 'network' | 'gpu';

export interface ColumnVisibility {
  status: boolean;
  cpu: boolean;
  memory: boolean;
  disk: boolean;
  network: boolean;
  powerUsage: boolean;
  publisher: boolean;
  pid: boolean;
  userName: boolean;
  version: boolean;
  filePath: boolean;
  commandLine: boolean;
  priority: boolean;
  architecture: boolean;
}
