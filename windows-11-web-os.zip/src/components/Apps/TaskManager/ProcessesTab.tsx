import React, { useState } from 'react';
import { ChevronRight, ChevronDown, Activity, RefreshCw, XCircle, Search, FileText, ExternalLink, ArrowUpDown } from 'lucide-react';
import { IconRenderer } from '../../Common/IconRenderer';
import { ProcessItemData, PriorityLevel, ColumnVisibility } from './types';
import { useOS } from '../../../context/OSContext';

interface ProcessesTabProps {
  processes: ProcessItemData[];
  selectedProcessId: string | null;
  onSelectProcess: (id: string | null) => void;
  onEndProcess: (id: string) => void;
  onRestartProcess: (id: string) => void;
  onSetPriority: (id: string, priority: PriorityLevel) => void;
  onRenameProcess: (id: string, newName: string) => void;
  onSwitchToDetails: (pid: number) => void;
  onExportList: () => void;
  columns: ColumnVisibility;
  showFullPaths: boolean;
}

export const ProcessesTab: React.FC<ProcessesTabProps> = ({
  processes,
  selectedProcessId,
  onSelectProcess,
  onEndProcess,
  onRestartProcess,
  onSetPriority,
  onRenameProcess,
  onSwitchToDetails,
  onExportList,
  columns,
  showFullPaths,
}) => {
  const { openApp, showContextMenu, addNotification } = useOS();
  const [collapsedGroups, setCollapsedGroups] = useState<{
    apps: boolean;
    background: boolean;
    windows: boolean;
  }>({
    apps: false,
    background: false,
    windows: false,
  });

  const toggleGroup = (group: 'apps' | 'background' | 'windows') => {
    setCollapsedGroups((prev) => ({ ...prev, [group]: !prev[group] }));
  };

  const appProcesses = processes.filter((p) => p.group === 'apps');
  const bgProcesses = processes.filter((p) => p.group === 'background');
  const winProcesses = processes.filter((p) => p.group === 'windows');

  // Context menu on single process item
  const handleContextMenu = (e: React.MouseEvent, process: ProcessItemData) => {
    e.preventDefault();
    e.stopPropagation();
    onSelectProcess(process.id);

    const items = [
      {
        id: 'proc-open-location',
        label: 'Mở vị trí tệp',
        icon: 'FolderOpen',
        onClick: () => {
          openApp('explorer', { initialPath: process.filePath || 'C:\\Windows\\System32' });
        },
      },
      {
        id: 'proc-switch-details',
        label: 'Chuyển sang tab Chi tiết',
        icon: 'FileText',
        onClick: () => {
          onSwitchToDetails(process.pid);
        },
      },
      { separator: true, id: 'proc-sep-1', label: '' },
      {
        id: 'proc-end-task',
        label: 'Kết thúc tác vụ',
        icon: 'XCircle',
        shortcut: 'Del',
        onClick: () => {
          onEndProcess(process.id);
        },
      },
      {
        id: 'proc-restart',
        label: 'Khởi động lại',
        icon: 'RotateCw',
        onClick: () => {
          onRestartProcess(process.id);
        },
      },
      { separator: true, id: 'proc-sep-2', label: '' },
      {
        id: 'proc-priority',
        label: 'Đặt mức ưu tiên',
        icon: 'Sliders',
        submenu: [
          {
            id: 'prio-realtime',
            label: 'Thời gian thực (Realtime)',
            checked: process.priority === 'realtime',
            onClick: () => onSetPriority(process.id, 'realtime'),
          },
          {
            id: 'prio-high',
            label: 'Cao nhất / Cao (High)',
            checked: process.priority === 'high',
            onClick: () => onSetPriority(process.id, 'high'),
          },
          {
            id: 'prio-above-normal',
            label: 'Cao hơn bình thường (Above Normal)',
            checked: process.priority === 'above_normal',
            onClick: () => onSetPriority(process.id, 'above_normal'),
          },
          {
            id: 'prio-normal',
            label: 'Bình thường (Normal)',
            checked: process.priority === 'normal',
            onClick: () => onSetPriority(process.id, 'normal'),
          },
          {
            id: 'prio-below-normal',
            label: 'Thấp hơn bình thường (Below Normal)',
            checked: process.priority === 'below_normal',
            onClick: () => onSetPriority(process.id, 'below_normal'),
          },
          {
            id: 'prio-low',
            label: 'Thấp (Low)',
            checked: process.priority === 'low',
            onClick: () => onSetPriority(process.id, 'low'),
          },
        ],
      },
      {
        id: 'proc-compatibility',
        label: 'Đặt mức độ tương thích',
        icon: 'Shield',
        onClick: () => {
          addNotification(
            'Mức độ tương thích',
            `Tiến trình ${process.displayName} đang chạy ở chế độ tương thích Windows 11 mặc định.`,
            'taskmanager'
          );
        },
      },
      {
        id: 'proc-rename',
        label: 'Đổi tên tiến trình (tạm thời)',
        icon: 'Edit',
        onClick: () => {
          const newName = prompt('Nhập tên hiển thị mới cho tiến trình:', process.displayName);
          if (newName && newName.trim()) {
            onRenameProcess(process.id, newName.trim());
          }
        },
      },
      { separator: true, id: 'proc-sep-3', label: '' },
      {
        id: 'proc-export',
        label: 'Xuất danh sách ra tệp',
        icon: 'Download',
        onClick: onExportList,
      },
      {
        id: 'proc-search-online',
        label: 'Tìm kiếm trực tuyến',
        icon: 'Search',
        onClick: () => {
          openApp('edge', {
            initialUrl: `https://www.bing.com/search?q=${encodeURIComponent(
              process.name + ' windows process info'
            )}`,
          });
        },
      },
    ];

    showContextMenu(e.clientX, Math.min(e.clientY, window.innerHeight - 380), items, 'taskmanager');
  };

  const renderProcessGroup = (
    title: string,
    groupKey: 'apps' | 'background' | 'windows',
    items: ProcessItemData[]
  ) => {
    const isCollapsed = collapsedGroups[groupKey];

    return (
      <div key={groupKey} className="flex flex-col">
        {/* Group Header */}
        <div
          onClick={() => toggleGroup(groupKey)}
          className="flex items-center gap-1.5 px-4 py-1.5 bg-slate-100/90 dark:bg-zinc-800/80 font-bold text-[11px] text-slate-700 dark:text-slate-200 cursor-pointer hover:bg-slate-200/80 dark:hover:bg-zinc-700/80 transition-colors select-none sticky top-7 z-10 border-b border-slate-200/60 dark:border-zinc-700/60"
        >
          {isCollapsed ? (
            <ChevronRight size={14} className="text-slate-500" />
          ) : (
            <ChevronDown size={14} className="text-slate-500" />
          )}
          <span>{title}</span>
          <span className="text-[10px] text-slate-400 font-normal ml-1">({items.length})</span>
        </div>

        {/* Group Items */}
        {!isCollapsed &&
          items.map((proc) => {
            const isSelected = selectedProcessId === proc.id;
            return (
              <div
                key={proc.id}
                onClick={() => onSelectProcess(proc.id)}
                onContextMenu={(e) => handleContextMenu(e, proc)}
                className={`grid grid-cols-12 items-center px-4 py-1.5 text-xs transition-colors cursor-pointer border-b border-slate-100 dark:border-zinc-800/50 ${
                  isSelected
                    ? 'bg-sky-500/20 dark:bg-sky-500/30 text-sky-900 dark:text-sky-100 font-semibold'
                    : 'hover:bg-slate-100/80 dark:hover:bg-zinc-800/50 text-slate-700 dark:text-zinc-200'
                }`}
              >
                {/* Tên */}
                <div className="col-span-3 flex items-center gap-2 truncate pr-2">
                  <div className="w-4 h-4 flex items-center justify-center shrink-0">
                    <IconRenderer name={proc.icon || 'Activity'} size={15} />
                  </div>
                  <span className="truncate" title={showFullPaths ? proc.filePath : proc.displayName}>
                    {showFullPaths ? proc.filePath : proc.displayName}
                  </span>
                </div>

                {/* Trạng thái */}
                {columns.status && (
                  <div className="col-span-1 text-center truncate text-[11px]">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] ${
                        proc.status === 'Đang chạy'
                          ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10'
                          : 'text-amber-600 dark:text-amber-400 bg-amber-500/10'
                      }`}
                    >
                      {proc.status}
                    </span>
                  </div>
                )}

                {/* CPU */}
                {columns.cpu && (
                  <div className="col-span-1 text-right font-mono text-[11px] pr-2">
                    <span
                      className={
                        proc.cpu > 5
                          ? 'text-amber-600 dark:text-amber-400 font-bold'
                          : 'text-slate-600 dark:text-zinc-400'
                      }
                    >
                      {proc.cpu.toFixed(1)}%
                    </span>
                  </div>
                )}

                {/* Bộ nhớ */}
                {columns.memory && (
                  <div className="col-span-1 text-right font-mono text-[11px] pr-2">
                    <span className="text-slate-600 dark:text-zinc-400">
                      {proc.memory.toFixed(1)} MB
                    </span>
                  </div>
                )}

                {/* Đĩa */}
                {columns.disk && (
                  <div className="col-span-1 text-right font-mono text-[11px] pr-2">
                    <span className="text-slate-500 dark:text-zinc-400">
                      {proc.disk > 0 ? `${proc.disk.toFixed(1)} MB/s` : '0.0 MB/s'}
                    </span>
                  </div>
                )}

                {/* Mạng */}
                {columns.network && (
                  <div className="col-span-1 text-right font-mono text-[11px] pr-2">
                    <span className="text-slate-500 dark:text-zinc-400">
                      {proc.network > 0 ? `${proc.network.toFixed(1)} Mbps` : '0.0 Mbps'}
                    </span>
                  </div>
                )}

                {/* Năng lượng */}
                {columns.powerUsage && (
                  <div className="col-span-2 text-center text-[11px] truncate">
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded ${
                        proc.powerUsage === 'Rất cao' || proc.powerUsage === 'Cao'
                          ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 font-semibold'
                          : 'text-slate-500 dark:text-zinc-400'
                      }`}
                    >
                      {proc.powerUsage}
                    </span>
                  </div>
                )}

                {/* Nhà phát triển */}
                {columns.publisher && (
                  <div className="col-span-2 text-[11px] truncate text-slate-500 dark:text-zinc-400 pl-2">
                    {proc.publisher}
                  </div>
                )}
              </div>
            );
          })}
      </div>
    );
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-white dark:bg-[#1c1c1c]">
      {/* Table Header */}
      <div className="grid grid-cols-12 px-4 py-1.5 font-bold text-[11px] text-slate-500 dark:text-zinc-400 bg-slate-100 dark:bg-zinc-800/90 border-b border-slate-200 dark:border-zinc-700/80 sticky top-0 z-20 select-none">
        <div className="col-span-3">Tên tiến trình</div>
        {columns.status && <div className="col-span-1 text-center">Trạng thái</div>}
        {columns.cpu && <div className="col-span-1 text-right pr-2">CPU</div>}
        {columns.memory && <div className="col-span-1 text-right pr-2">Bộ nhớ</div>}
        {columns.disk && <div className="col-span-1 text-right pr-2">Đĩa</div>}
        {columns.network && <div className="col-span-1 text-right pr-2">Mạng</div>}
        {columns.powerUsage && <div className="col-span-2 text-center">Năng lượng</div>}
        {columns.publisher && <div className="col-span-2 pl-2">Nhà phát triển</div>}
      </div>

      {/* Main Process List */}
      <div className="flex-1 overflow-y-auto">
        {renderProcessGroup('Ứng dụng', 'apps', appProcesses)}
        {renderProcessGroup('Tiến trình nền', 'background', bgProcesses)}
        {renderProcessGroup('Tiến trình Windows', 'windows', winProcesses)}
      </div>
    </div>
  );
};
