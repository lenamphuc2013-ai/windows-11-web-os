import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Settings2, X, Play, Square, Pause, RotateCw, CheckCircle2 } from 'lucide-react';
import { ServiceItemData, ServiceStatus, ServiceStartupType } from './types';
import { useOS } from '../../../context/OSContext';

interface ServicePropertiesModalProps {
  service: ServiceItemData | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdateService: (updated: ServiceItemData) => void;
}

export const ServicePropertiesModal: React.FC<ServicePropertiesModalProps> = ({
  service,
  isOpen,
  onClose,
  onUpdateService,
}) => {
  const { addNotification } = useOS();
  const [activeTab, setActiveTab] = useState<'general' | 'logon' | 'recovery' | 'dependencies'>('general');
  const [currentStatus, setCurrentStatus] = useState<ServiceStatus>(service?.status || 'Đang chạy');
  const [startupType, setStartupType] = useState<ServiceStartupType>(service?.startupType || 'Tự động');

  if (!isOpen || !service) return null;

  const handleApply = () => {
    onUpdateService({
      ...service,
      status: currentStatus,
      startupType: startupType,
    });
    addNotification('Dịch vụ Windows', `Đã lưu cấu hình dịch vụ "${service.name}"`, 'taskbar');
    onClose();
  };

  return (
    <AnimatePresence>
      <div
        id="service-properties-backdrop"
        className="fixed inset-0 z-[10000] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          id="service-properties-container"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="w-full max-w-lg bg-white dark:bg-[#202020] rounded-2xl shadow-2xl border border-slate-200 dark:border-zinc-700/80 p-5 flex flex-col gap-3 text-slate-800 dark:text-slate-100 select-none"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-zinc-800">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-sky-500/15 text-sky-600 dark:text-sky-400 flex items-center justify-center">
                <Settings2 size={16} />
              </div>
              <div>
                <h3 className="text-sm font-bold truncate">Thuộc tính: {service.name} (Máy cục bộ)</h3>
                <p className="text-[11px] text-slate-500 dark:text-zinc-400 truncate">
                  {service.description}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:bg-red-500 hover:text-white transition-colors"
            >
              <X size={15} />
            </button>
          </div>

          {/* Sub tabs */}
          <div className="flex border-b border-slate-200 dark:border-zinc-800 gap-1 text-xs">
            <button
              onClick={() => setActiveTab('general')}
              className={`px-3 py-1.5 font-semibold rounded-t-lg transition-colors ${
                activeTab === 'general'
                  ? 'bg-slate-100 dark:bg-zinc-800 text-sky-600 dark:text-sky-400 border-b-2 border-sky-500'
                  : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
              }`}
            >
              Chung
            </button>
            <button
              onClick={() => setActiveTab('logon')}
              className={`px-3 py-1.5 font-semibold rounded-t-lg transition-colors ${
                activeTab === 'logon'
                  ? 'bg-slate-100 dark:bg-zinc-800 text-sky-600 dark:text-sky-400 border-b-2 border-sky-500'
                  : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
              }`}
            >
              Đăng nhập
            </button>
            <button
              onClick={() => setActiveTab('recovery')}
              className={`px-3 py-1.5 font-semibold rounded-t-lg transition-colors ${
                activeTab === 'recovery'
                  ? 'bg-slate-100 dark:bg-zinc-800 text-sky-600 dark:text-sky-400 border-b-2 border-sky-500'
                  : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
              }`}
            >
              Phục hồi
            </button>
            <button
              onClick={() => setActiveTab('dependencies')}
              className={`px-3 py-1.5 font-semibold rounded-t-lg transition-colors ${
                activeTab === 'dependencies'
                  ? 'bg-slate-100 dark:bg-zinc-800 text-sky-600 dark:text-sky-400 border-b-2 border-sky-500'
                  : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
              }`}
            >
              Phụ thuộc
            </button>
          </div>

          {/* Tab Content */}
          <div className="py-2 min-h-[220px] text-xs flex flex-col gap-3">
            {activeTab === 'general' && (
              <>
                <div className="grid grid-cols-3 gap-2 items-center">
                  <span className="text-slate-500 dark:text-zinc-400">Tên dịch vụ:</span>
                  <span className="col-span-2 font-mono font-semibold">{service.name}</span>
                </div>
                <div className="grid grid-cols-3 gap-2 items-center">
                  <span className="text-slate-500 dark:text-zinc-400">Tên hiển thị:</span>
                  <span className="col-span-2 font-medium">{service.description}</span>
                </div>
                <div className="grid grid-cols-3 gap-2 items-center">
                  <span className="text-slate-500 dark:text-zinc-400">Đường dẫn tệp thực thi:</span>
                  <span className="col-span-2 font-mono text-[11px] p-1.5 rounded bg-slate-100 dark:bg-zinc-800 break-all">
                    {service.executablePath}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 items-center">
                  <span className="text-slate-500 dark:text-zinc-400">Loại khởi động:</span>
                  <select
                    value={startupType}
                    onChange={(e) => setStartupType(e.target.value as ServiceStartupType)}
                    className="col-span-2 px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-800 dark:text-slate-100"
                  >
                    <option value="Tự động">Tự động (Automatic)</option>
                    <option value="Tự động (trễ)">Tự động (trễ) (Automatic Delayed)</option>
                    <option value="Thủ công">Thủ công (Manual)</option>
                    <option value="Tắt">Tắt (Disabled)</option>
                  </select>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/60 border border-slate-200 dark:border-zinc-700 flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 dark:text-zinc-400">Trạng thái dịch vụ:</span>
                    <span
                      className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                        currentStatus === 'Đang chạy'
                          ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                          : currentStatus === 'Đã dừng'
                          ? 'bg-red-500/15 text-red-600 dark:text-red-400'
                          : 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                      }`}
                    >
                      {currentStatus}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={() => setCurrentStatus('Đang chạy')}
                      disabled={currentStatus === 'Đang chạy'}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-100 disabled:opacity-40"
                    >
                      <Play size={11} className="text-emerald-500" />
                      <span>Bắt đầu</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setCurrentStatus('Đã dừng')}
                      disabled={currentStatus === 'Đã dừng'}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-100 disabled:opacity-40"
                    >
                      <Square size={11} className="text-red-500" />
                      <span>Dừng</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setCurrentStatus('Tạm dừng')}
                      disabled={currentStatus !== 'Đang chạy'}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-100 disabled:opacity-40"
                    >
                      <Pause size={11} className="text-amber-500" />
                      <span>Tạm dừng</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setCurrentStatus('Đang chạy');
                        addNotification('Dịch vụ Windows', `Đã khởi động lại dịch vụ "${service.name}"`, 'taskbar');
                      }}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-100"
                    >
                      <RotateCw size={11} className="text-sky-500" />
                      <span>Khởi động lại</span>
                    </button>
                  </div>
                </div>
              </>
            )}

            {activeTab === 'logon' && (
              <div className="flex flex-col gap-2.5">
                <span className="font-semibold text-slate-700 dark:text-slate-200">
                  Đăng nhập dưới tư cách tài khoản:
                </span>
                <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-50 dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700">
                  <input type="radio" name="logon" defaultChecked />
                  <span>Tài khoản Hệ thống Cục bộ (Local System Account)</span>
                </label>
                <div className="text-[11px] text-slate-500">
                  Tài khoản hiện tại: <span className="font-mono">{service.logOnAs}</span>
                </div>
              </div>
            )}

            {activeTab === 'recovery' && (
              <div className="flex flex-col gap-2.5">
                <span className="font-semibold text-slate-700 dark:text-slate-200">
                  Hành động khi dịch vụ gặp sự cố (Service Failure):
                </span>
                <div className="grid grid-cols-2 gap-2 text-slate-600 dark:text-zinc-300">
                  <span>Lần thất bại đầu tiên:</span>
                  <span className="font-semibold">Khởi động lại dịch vụ</span>
                  <span>Lần thất bại thứ hai:</span>
                  <span className="font-semibold">Khởi động lại dịch vụ</span>
                  <span>Các lần tiếp theo:</span>
                  <span className="font-semibold">Không thực hiện hành động</span>
                </div>
              </div>
            )}

            {activeTab === 'dependencies' && (
              <div className="flex flex-col gap-2">
                <span className="font-semibold text-slate-700 dark:text-slate-200">
                  Dịch vụ này phụ thuộc vào các thành phần hệ thống sau:
                </span>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 font-mono text-[11px]">
                  {service.dependencies || 'Không có dịch vụ phụ thuộc trực tiếp.'}
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-zinc-800">
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl text-xs font-medium text-slate-600 dark:text-zinc-300 hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors"
            >
              Hủy
            </button>
            <button
              onClick={handleApply}
              className="px-5 py-1.5 rounded-xl bg-sky-500 hover:bg-sky-600 text-white text-xs font-semibold shadow-sm transition-all"
            >
              Áp dụng & OK
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
