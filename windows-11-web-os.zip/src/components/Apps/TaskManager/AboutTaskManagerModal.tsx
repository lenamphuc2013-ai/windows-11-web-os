import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Activity, X, ShieldCheck, CheckCircle2, ExternalLink } from 'lucide-react';
import { useOS } from '../../../context/OSContext';

interface AboutTaskManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutTaskManagerModal: React.FC<AboutTaskManagerModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { openApp } = useOS();

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div
        id="about-taskmanager-modal-backdrop"
        className="fixed inset-0 z-[10000] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          id="about-taskmanager-modal-container"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="w-full max-w-md bg-white dark:bg-[#202020] rounded-2xl shadow-2xl border border-slate-200 dark:border-zinc-700/80 p-5 flex flex-col gap-4 text-slate-800 dark:text-slate-100 select-none"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-zinc-800">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-teal-500/15 text-teal-600 dark:text-teal-400 flex items-center justify-center">
                <Activity size={20} />
              </div>
              <div>
                <h3 className="text-sm font-bold">Trình quản lý Tác vụ Windows</h3>
                <p className="text-[11px] text-slate-500 dark:text-zinc-400">
                  Windows 11 Task Manager Build 22631.3007
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:bg-red-500 hover:text-white transition-colors"
            >
              <X size={15} />
            </button>
          </div>

          <div className="flex flex-col gap-3 text-xs leading-relaxed text-slate-600 dark:text-zinc-300">
            <div className="flex items-start gap-2 p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/60 border border-slate-200/60 dark:border-zinc-700/60">
              <ShieldCheck size={18} className="text-teal-500 shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold text-slate-800 dark:text-slate-100">
                  Giám sát & Quản trị Hệ thống Toàn diện
                </div>
                <div className="text-[11px] text-slate-500 dark:text-zinc-400 mt-0.5">
                  Cung cấp thông tin chi tiết về các tiến trình, hiệu suất phần cứng (CPU, RAM, Đĩa, Mạng, GPU), lịch sử ứng dụng, phiên người dùng, chi tiết tiến trình và các dịch vụ hệ điều hành.
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2 rounded-lg bg-slate-100/70 dark:bg-zinc-800/40">
                <span className="text-slate-400 block">Kiến trúc:</span>
                <span className="font-bold text-slate-700 dark:text-slate-200">x64 (64-bit Edition)</span>
              </div>
              <div className="p-2 rounded-lg bg-slate-100/70 dark:bg-zinc-800/40">
                <span className="text-slate-400 block">Bản quyền:</span>
                <span className="font-bold text-slate-700 dark:text-slate-200">Microsoft Corporation</span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 text-[11px] font-medium">
              <CheckCircle2 size={14} />
              <span>Hệ thống đang chạy ổn định trong môi trường Sandbox bảo mật.</span>
            </div>
          </div>

          {/* Footer buttons */}
          <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-zinc-800">
            <button
              onClick={() => {
                onClose();
                openApp('edge', { initialUrl: 'https://support.microsoft.com/windows' });
              }}
              className="flex items-center gap-1 text-[11px] text-sky-600 dark:text-sky-400 hover:underline"
            >
              <span>Hỗ trợ trực tuyến</span>
              <ExternalLink size={12} />
            </button>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl bg-teal-500 hover:bg-teal-600 text-white text-xs font-semibold shadow-sm transition-all"
            >
              Đóng
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
