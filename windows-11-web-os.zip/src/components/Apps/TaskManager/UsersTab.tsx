import React, { useState } from 'react';
import { User, ChevronRight, ChevronDown, LogOut, XCircle, FileText, ArrowUpDown } from 'lucide-react';
import { IconRenderer } from '../../Common/IconRenderer';
import { UserSessionData, ProcessItemData } from './types';
import { useOS } from '../../../context/OSContext';

interface UsersTabProps {
  users: UserSessionData[];
  onDisconnectUser: (userId: string) => void;
  onEndProcess: (processId: string) => void;
  onSwitchToDetails: (pid: number) => void;
}

export const UsersTab: React.FC<UsersTabProps> = ({
  users,
  onDisconnectUser,
  onEndProcess,
  onSwitchToDetails,
}) => {
  const { showContextMenu, addNotification } = useOS();
  const [expandedUsers, setExpandedUsers] = useState<Record<string, boolean>>({
    'user-current': true,
  });

  const toggleUser = (userId: string) => {
    setExpandedUsers((prev) => ({ ...prev, [userId]: !prev[userId] }));
  };

  const handleUserContextMenu = (e: React.MouseEvent, user: UserSessionData) => {
    e.preventDefault();
    e.stopPropagation();

    const items = [
      {
        id: 'user-disconnect',
        label: 'Kết thúc phiên (Ngắt kết nối)',
        icon: 'LogOut',
        onClick: () => {
          onDisconnectUser(user.id);
          addNotification('Phiên người dùng', `Đã kết thúc phiên làm việc của ${user.userName}`, 'taskmanager');
        },
      },
      {
        id: 'user-manage',
        label: 'Quản lý tài khoản',
        icon: 'User',
        onClick: () => {
          addNotification('Quản lý tài khoản', `Người dùng ${user.userName} đang có quyền Quản trị viên (Admin)`, 'taskmanager');
        },
      },
    ];

    showContextMenu(e.clientX, e.clientY, items, 'taskmanager');
  };

  const handleProcessContextMenu = (e: React.MouseEvent, proc: ProcessItemData) => {
    e.preventDefault();
    e.stopPropagation();

    const items = [
      {
        id: 'user-proc-end',
        label: 'Kết thúc tác vụ',
        icon: 'XCircle',
        onClick: () => {
          onEndProcess(proc.id);
        },
      },
      {
        id: 'user-proc-details',
        label: 'Xem chi tiết (Tab Chi tiết)',
        icon: 'FileText',
        onClick: () => {
          onSwitchToDetails(proc.pid);
        },
      },
    ];

    showContextMenu(e.clientX, e.clientY, items, 'taskmanager');
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-white dark:bg-[#1c1c1c]">
      {/* Table Header */}
      <div className="grid grid-cols-12 px-4 py-1.5 font-bold text-[11px] text-slate-500 dark:text-zinc-400 bg-slate-100 dark:bg-zinc-800/90 border-b border-slate-200 dark:border-zinc-700/80 sticky top-0 select-none">
        <div className="col-span-3">Tên người dùng / Tiến trình</div>
        <div className="col-span-1 text-center">Trạng thái</div>
        <div className="col-span-1 text-right pr-2">CPU</div>
        <div className="col-span-1 text-right pr-2">Bộ nhớ</div>
        <div className="col-span-1 text-right pr-2">Đĩa</div>
        <div className="col-span-1 text-right pr-2">Mạng</div>
        <div className="col-span-2 text-center">Thời gian đăng nhập</div>
        <div className="col-span-1 text-center">Địa chỉ</div>
        <div className="col-span-1 text-right">Phiên bản</div>
      </div>

      {/* Main Users List */}
      <div className="flex-1 overflow-y-auto">
        {users.map((user) => {
          const isExpanded = expandedUsers[user.id];

          return (
            <div key={user.id} className="flex flex-col border-b border-slate-200/80 dark:border-zinc-800">
              {/* User Row */}
              <div
                onClick={() => toggleUser(user.id)}
                onContextMenu={(e) => handleUserContextMenu(e, user)}
                className="grid grid-cols-12 items-center px-4 py-2 bg-slate-50 dark:bg-zinc-900/60 hover:bg-slate-100 dark:hover:bg-zinc-800/60 transition-colors cursor-pointer select-none font-semibold text-xs"
              >
                {/* User Name */}
                <div className="col-span-3 flex items-center gap-2 truncate pr-2">
                  {isExpanded ? (
                    <ChevronDown size={14} className="text-slate-400" />
                  ) : (
                    <ChevronRight size={14} className="text-slate-400" />
                  )}
                  <div className="w-5 h-5 rounded-full bg-sky-500/20 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0">
                    <User size={13} />
                  </div>
                  <span className="truncate text-slate-800 dark:text-slate-100">
                    {user.userName}
                  </span>
                  <span className="text-[10px] text-slate-400 font-normal">
                    ({user.processes.length})
                  </span>
                </div>

                {/* Trạng thái */}
                <div className="col-span-1 text-center text-[11px]">
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] ${
                      user.status === 'Đang hoạt động'
                        ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                        : 'bg-slate-500/15 text-slate-500'
                    }`}
                  >
                    {user.status}
                  </span>
                </div>

                {/* CPU */}
                <div className="col-span-1 text-right font-mono text-[11px] pr-2 text-sky-600 dark:text-sky-400">
                  {user.cpu.toFixed(1)}%
                </div>

                {/* Bộ nhớ */}
                <div className="col-span-1 text-right font-mono text-[11px] pr-2 text-slate-600 dark:text-zinc-300">
                  {(user.memory / 1024).toFixed(2)} GB
                </div>

                {/* Đĩa */}
                <div className="col-span-1 text-right font-mono text-[11px] pr-2 text-slate-500">
                  {user.disk.toFixed(1)} MB/s
                </div>

                {/* Mạng */}
                <div className="col-span-1 text-right font-mono text-[11px] pr-2 text-slate-500">
                  {user.network.toFixed(1)} Mbps
                </div>

                {/* Thời gian đăng nhập */}
                <div className="col-span-2 text-center text-[11px] text-slate-500">
                  {user.loginTime}
                </div>

                {/* Địa chỉ đăng nhập */}
                <div className="col-span-1 text-center font-mono text-[10px] text-slate-500">
                  {user.loginAddress}
                </div>

                {/* Phiên bản */}
                <div className="col-span-1 text-right text-[11px] text-slate-500">
                  {user.clientVersion}
                </div>
              </div>

              {/* Child Processes of this user */}
              {isExpanded && (
                <div className="divide-y divide-slate-100 dark:divide-zinc-800/40 bg-white dark:bg-[#1a1a1a]">
                  {user.processes.map((proc) => (
                    <div
                      key={proc.id}
                      onContextMenu={(e) => handleProcessContextMenu(e, proc)}
                      className="grid grid-cols-12 items-center px-4 py-1.5 text-xs hover:bg-sky-500/10 transition-colors cursor-pointer text-slate-600 dark:text-zinc-300 pl-9"
                    >
                      {/* Name */}
                      <div className="col-span-3 flex items-center gap-2 truncate pr-2">
                        <div className="w-3.5 h-3.5 flex items-center justify-center shrink-0">
                          <IconRenderer name={proc.icon || 'Activity'} size={13} />
                        </div>
                        <span className="truncate">{proc.displayName}</span>
                      </div>

                      {/* Status */}
                      <div className="col-span-1 text-center text-[10px] text-slate-400">
                        {proc.status}
                      </div>

                      {/* CPU */}
                      <div className="col-span-1 text-right font-mono text-[11px] pr-2">
                        {proc.cpu.toFixed(1)}%
                      </div>

                      {/* Memory */}
                      <div className="col-span-1 text-right font-mono text-[11px] pr-2">
                        {proc.memory.toFixed(1)} MB
                      </div>

                      {/* Disk */}
                      <div className="col-span-1 text-right font-mono text-[11px] pr-2 text-slate-400">
                        {proc.disk > 0 ? `${proc.disk.toFixed(1)} MB/s` : '0.0 MB/s'}
                      </div>

                      {/* Network */}
                      <div className="col-span-1 text-right font-mono text-[11px] pr-2 text-slate-400">
                        {proc.network > 0 ? `${proc.network.toFixed(1)} Mbps` : '0.0 Mbps'}
                      </div>

                      {/* Path/Details */}
                      <div className="col-span-3 text-[10px] truncate text-slate-400 pl-4 font-mono">
                        PID: {proc.pid} | {proc.name}
                      </div>

                      {/* Priority */}
                      <div className="col-span-1 text-right text-[10px] text-slate-400 capitalize">
                        {proc.priority}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
