import React, { useState } from 'react';
import { ArrowUpDown, Search, FileText, XCircle, RotateCw, Shield, Download, ExternalLink, Sliders } from 'lucide-react';
import { ProcessItemData, PriorityLevel } from './types';
import { useOS } from '../../../context/OSContext';

interface DetailsTabProps {
  processes: ProcessItemData[];
  selectedPid: number | null;
  onSelectPid: (pid: number | null) => void;
  onEndProcess: (id: string) => void;
  onRestartProcess: (id: string) => void;
  onSetPriority: (id: string, priority: PriorityLevel) => void;
  onToggleVirtualization: (id: string) => void;
  onExportList: () => void;
}

export const DetailsTab: React.FC<DetailsTabProps> = ({
  processes,
  selectedPid,
  onSelectPid,
  onEndProcess,
  onRestartProcess,
  onSetPriority,
  onToggleVirtualization,
  onExportList,
}) => {
  const { openApp, showContextMenu, addNotification } = useOS();
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<keyof ProcessItemData>('name');
  const [sortAsc, setSortAsc] = useState(true);

  const handleSort = (field: keyof ProcessItemData) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  const filteredProcesses = processes
    .filter((p) => {
      const term = searchTerm.toLowerCase();
      return (
        p.name.toLowerCase().includes(term) ||
        p.pid.toString().includes(term) ||
        p.userName.toLowerCase().includes(term) ||
        (p.serviceName && p.serviceName.toLowerCase().includes(term))
      );
    })
    .sort((a, b) => {
      const valA = a[sortField] ?? '';
      const valB = b[sortField] ?? '';
      if (typeof valA === 'string') {
        return sortAsc ? valA.localeCompare(valB as string) : (valB as string).localeCompare(valA);
      }
      return sortAsc ? (valA as number) - (valB as number) : (valB as number) - (valA as number);
    });

  const handleContextMenu = (e: React.MouseEvent, process: ProcessItemData) => {
    e.preventDefault();
    e.stopPropagation();
    onSelectPid(process.pid);

    const items = [
      {
        id: 'det-end-task',
        label: 'Kết thúc tác vụ',
        icon: 'XCircle',
        shortcut: 'Del',
        onClick: () => {
          onEndProcess(process.id);
        },
      },
      {
        id: 'det-end-tree',
        label: 'Kết thúc cây tiến trình (End process tree)',
        icon: 'XCircle',
        onClick: () => {
          onEndProcess(process.id);
          addNotification('Chi tiết tiến trình', `Đã kết thúc cây tiến trình của PID ${process.pid}`, 'taskmanager');
        },
      },
      { separator: true, id: 'det-sep-1', label: '' },
      {
        id: 'det-priority',
        label: 'Đặt mức ưu tiên',
        icon: 'Sliders',
        submenu: [
          {
            id: 'det-prio-realtime',
            label: 'Thời gian thực (Realtime)',
            checked: process.priority === 'realtime',
            onClick: () => onSetPriority(process.id, 'realtime'),
          },
          {
            id: 'det-prio-high',
            label: 'Cao nhất (High)',
            checked: process.priority === 'high',
            onClick: () => onSetPriority(process.id, 'high'),
          },
          {
            id: 'det-prio-above-normal',
            label: 'Cao hơn bình thường (Above Normal)',
            checked: process.priority === 'above_normal',
            onClick: () => onSetPriority(process.id, 'above_normal'),
          },
          {
            id: 'det-prio-normal',
            label: 'Bình thường (Normal)',
            checked: process.priority === 'normal',
            onClick: () => onSetPriority(process.id, 'normal'),
          },
          {
            id: 'det-prio-below-normal',
            label: 'Thấp hơn bình thường (Below Normal)',
            checked: process.priority === 'below_normal',
            onClick: () => onSetPriority(process.id, 'below_normal'),
          },
          {
            id: 'det-prio-low',
            label: 'Thấp (Low)',
            checked: process.priority === 'low',
            onClick: () => onSetPriority(process.id, 'low'),
          },
        ],
      },
      {
        id: 'det-affinity',
        label: 'Đặt mối quan hệ CPU (CPU Affinity)',
        icon: 'Cpu',
        onClick: () => {
          addNotification('Mối quan hệ CPU', `Đã gán tiến trình ${process.name} cho tất cả 16 luồng logic CPU`, 'taskmanager');
        },
      },
      {
        id: 'det-virtualization',
        label: process.uacVirtualization ? 'Tắt ảo hóa UAC' : 'Bật ảo hóa UAC',
        icon: 'Shield',
        onClick: () => {
          onToggleVirtualization(process.id);
        },
      },
      {
        id: 'det-compatibility',
        label: 'Đặt liên kết tương thích',
        icon: 'FileText',
        onClick: () => {
          addNotification('Tương thích', `Đã cấu hình tương thích cho ${process.name}`, 'taskmanager');
        },
      },
      { separator: true, id: 'det-sep-2', label: '' },
      {
        id: 'det-open-location',
        label: 'Mở vị trí tệp',
        icon: 'FolderOpen',
        onClick: () => {
          openApp('explorer', { initialPath: process.filePath || 'C:\\Windows\\System32' });
        },
      },
      {
        id: 'det-search-online',
        label: 'Tìm kiếm trực tuyến',
        icon: 'Search',
        onClick: () => {
          openApp('edge', {
            initialUrl: `https://www.bing.com/search?q=${encodeURIComponent(
              process.name + ' process details'
            )}`,
          });
        },
      },
      {
        id: 'det-properties',
        label: 'Thuộc tính',
        icon: 'Settings',
        onClick: () => {
          addNotification('Thuộc tính tệp', `Đường dẫn: ${process.filePath}\nPhiên bản: ${process.version}`, 'taskmanager');
        },
      },
    ];

    showContextMenu(e.clientX, Math.min(e.clientY, window.innerHeight - 380), items, 'taskmanager');
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-white dark:bg-[#1c1c1c]">
      {/* Top Search & Stats Bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-50 dark:bg-zinc-800/80 border-b border-slate-200 dark:border-zinc-700/80 text-xs">
        <div className="flex items-center gap-2 max-w-sm flex-1">
          <div className="relative w-full">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Tìm kiếm theo Tên, PID, Người dùng hoặc Dịch vụ..."
              className="w-full pl-8 pr-3 py-1 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-800 dark:text-slate-100 text-xs outline-none focus:ring-1 focus:ring-sky-500"
            />
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-[11px] text-slate-500 font-mono">
            Tổng: {filteredProcesses.length} tiến trình
          </span>
          <button
            onClick={onExportList}
            className="flex items-center gap-1 px-3 py-1 rounded-lg bg-slate-200/60 dark:bg-zinc-700/60 hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-700 dark:text-slate-200 transition-colors text-[11px] font-semibold"
          >
            <Download size={12} />
            <span>Xuất danh sách</span>
          </button>
        </div>
      </div>

      {/* Table Container with horizontal & vertical scroll */}
      <div className="flex-1 overflow-auto">
        <table className="w-full min-w-[1200px] border-collapse text-left text-xs select-none">
          <thead className="sticky top-0 z-20 bg-slate-100 dark:bg-zinc-800 font-bold text-[11px] text-slate-500 dark:text-zinc-400 border-b border-slate-200 dark:border-zinc-700">
            <tr>
              <th
                onClick={() => handleSort('name')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500"
              >
                <div className="flex items-center gap-1">
                  <span>Tên tiến trình</span>
                  <ArrowUpDown size={10} />
                </div>
              </th>
              <th
                onClick={() => handleSort('pid')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500 text-right"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>PID</span>
                  <ArrowUpDown size={10} />
                </div>
              </th>
              <th
                onClick={() => handleSort('status')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500 text-center"
              >
                <span>Trạng thái</span>
              </th>
              <th
                onClick={() => handleSort('userName')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500"
              >
                <span>Tên người dùng</span>
              </th>
              <th
                onClick={() => handleSort('version')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500"
              >
                <span>Phiên bản</span>
              </th>
              <th
                onClick={() => handleSort('cpu')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500 text-right"
              >
                <span>CPU</span>
              </th>
              <th
                onClick={() => handleSort('memory')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500 text-right"
              >
                <span>Bộ nhớ (MB)</span>
              </th>
              <th
                onClick={() => handleSort('priority')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500 text-center"
              >
                <span>Ưu tiên</span>
              </th>
              <th
                onClick={() => handleSort('architecture')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500 text-center"
              >
                <span>Kiến trúc</span>
              </th>
              <th
                onClick={() => handleSort('serviceName')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500"
              >
                <span>Tên dịch vụ</span>
              </th>
              <th
                onClick={() => handleSort('packageName')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500"
              >
                <span>Tên gói</span>
              </th>
              <th
                onClick={() => handleSort('filePath')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500"
              >
                <span>Đường dẫn tệp</span>
              </th>
              <th
                onClick={() => handleSort('commandLine')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500"
              >
                <span>Dòng lệnh</span>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-zinc-800/60">
            {filteredProcesses.map((proc) => {
              const isSelected = selectedPid === proc.pid;

              return (
                <tr
                  key={proc.id}
                  onClick={() => onSelectPid(proc.pid)}
                  onContextMenu={(e) => handleContextMenu(e, proc)}
                  className={`cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-sky-500/20 dark:bg-sky-500/30 text-sky-900 dark:text-sky-100 font-semibold'
                      : 'hover:bg-slate-50 dark:hover:bg-zinc-800/50 text-slate-700 dark:text-zinc-200'
                  }`}
                >
                  <td className="px-3 py-1.5 font-mono text-xs truncate max-w-[160px]">
                    {proc.name}
                  </td>
                  <td className="px-3 py-1.5 text-right font-mono text-slate-500">{proc.pid}</td>
                  <td className="px-3 py-1.5 text-center">
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded ${
                        proc.status === 'Đang chạy'
                          ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                          : 'bg-amber-500/10 text-amber-600'
                      }`}
                    >
                      {proc.status}
                    </span>
                  </td>
                  <td className="px-3 py-1.5 truncate max-w-[120px] text-slate-600 dark:text-zinc-300">
                    {proc.userName}
                  </td>
                  <td className="px-3 py-1.5 font-mono text-[11px] text-slate-500 truncate max-w-[110px]">
                    {proc.version}
                  </td>
                  <td className="px-3 py-1.5 text-right font-mono text-[11px]">
                    {proc.cpu > 0 ? (
                      <span className="text-sky-600 dark:text-sky-400 font-bold">
                        {proc.cpu.toFixed(1)}%
                      </span>
                    ) : (
                      <span className="text-slate-400">0.0%</span>
                    )}
                  </td>
                  <td className="px-3 py-1.5 text-right font-mono text-[11px]">
                    {proc.memory.toFixed(1)}
                  </td>
                  <td className="px-3 py-1.5 text-center text-[10px] capitalize text-slate-600 dark:text-zinc-300">
                    {proc.priority}
                  </td>
                  <td className="px-3 py-1.5 text-center font-mono text-[10px] text-slate-500">
                    {proc.architecture}
                  </td>
                  <td className="px-3 py-1.5 font-mono text-[11px] text-slate-500 truncate max-w-[130px]">
                    {proc.serviceName || 'N/A'}
                  </td>
                  <td className="px-3 py-1.5 text-[11px] text-slate-500 truncate max-w-[130px]">
                    {proc.packageName || 'N/A'}
                  </td>
                  <td className="px-3 py-1.5 font-mono text-[10px] text-slate-400 truncate max-w-[200px]">
                    {proc.filePath}
                  </td>
                  <td className="px-3 py-1.5 font-mono text-[10px] text-slate-400 truncate max-w-[220px]">
                    {proc.commandLine}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
