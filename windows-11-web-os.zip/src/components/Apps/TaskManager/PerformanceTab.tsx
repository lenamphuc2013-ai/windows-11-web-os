import React, { useState, useEffect, useRef } from 'react';
import { Cpu, Activity, HardDrive, Wifi, Layers, Flame, Clock, Radio, Info } from 'lucide-react';
import { PerformanceDeviceType } from './types';

interface PerformanceTabProps {
  cpuHistory: number[];
  memoryHistory: number[];
  diskHistory: number[];
  networkHistory: number[];
  gpuHistory: number[];
  summaryView: boolean;
}

export const PerformanceTab: React.FC<PerformanceTabProps> = ({
  cpuHistory,
  memoryHistory,
  diskHistory,
  networkHistory,
  gpuHistory,
  summaryView,
}) => {
  const [selectedDevice, setSelectedDevice] = useState<PerformanceDeviceType>('cpu');
  const [upTimeSeconds, setUpTimeSeconds] = useState(14820); // starts around 4h 07m

  useEffect(() => {
    const timer = setInterval(() => {
      setUpTimeSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatUpTime = (totalSecs: number) => {
    const days = Math.floor(totalSecs / 86400);
    const hours = Math.floor((totalSecs % 86400) / 3600);
    const mins = Math.floor((totalSecs % 3600) / 60);
    const secs = totalSecs % 60;
    return `${days > 0 ? `${days}:` : ''}${hours.toString().padStart(2, '0')}:${mins
      .toString()
      .padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const currentCpu = cpuHistory[cpuHistory.length - 1] || 16;
  const currentMem = memoryHistory[memoryHistory.length - 1] || 38;
  const currentDisk = diskHistory[diskHistory.length - 1] || 4;
  const currentNet = networkHistory[networkHistory.length - 1] || 2.4;
  const currentGpu = gpuHistory[gpuHistory.length - 1] || 14;

  const devices: {
    id: PerformanceDeviceType;
    name: string;
    sub: string;
    val: string;
    icon: any;
    color: string;
    history: number[];
  }[] = [
    {
      id: 'cpu',
      name: 'CPU',
      sub: 'AMD Ryzen 7 7800X3D 8-Core',
      val: `${currentCpu}% ${ (3.4 + currentCpu * 0.015).toFixed(2) } GHz`,
      icon: Cpu,
      color: '#0284c7',
      history: cpuHistory,
    },
    {
      id: 'memory',
      name: 'Bộ nhớ (Memory)',
      sub: '16.0 GB DDR5 5600MHz',
      val: `${((currentMem / 100) * 16).toFixed(1)}/16.0 GB (${currentMem}%)`,
      icon: Activity,
      color: '#9333ea',
      history: memoryHistory,
    },
    {
      id: 'disk_c',
      name: 'Đĩa 0 (C: SSD NVMe)',
      sub: 'Samsung 990 PRO 1TB',
      val: `${currentDisk}% ${ (currentDisk * 2.8).toFixed(1) } MB/s`,
      icon: HardDrive,
      color: '#16a34a',
      history: diskHistory,
    },
    {
      id: 'disk_d',
      name: 'Đĩa 1 (D: HDD Data)',
      sub: 'Seagate Barracuda 2TB',
      val: `0% 0.0 KB/s`,
      icon: HardDrive,
      color: '#ca8a04',
      history: diskHistory.map((d) => Math.max(0, Math.floor(d * 0.3))),
    },
    {
      id: 'network',
      name: 'Mạng (Wi-Fi 6 AX201)',
      sub: 'Wi-Fi 802.11ax 5GHz',
      val: `Gửi: ${(currentNet * 0.4).toFixed(1)} / Nhận: ${(currentNet * 1.8).toFixed(1)} Mbps`,
      icon: Wifi,
      color: '#ea580c',
      history: networkHistory,
    },
    {
      id: 'gpu',
      name: 'GPU 0 (NVIDIA RTX 4070)',
      sub: '12 GB GDDR6X',
      val: `${currentGpu}% (48°C)`,
      icon: Layers,
      color: '#059669',
      history: gpuHistory,
    },
  ];

  // Helper to draw SVG wave curve
  const renderSvgGraph = (data: number[], color: string, maxVal = 100) => {
    const width = 500;
    const height = 180;
    const step = width / (data.length - 1 || 1);

    const points = data
      .map((val, i) => {
        const x = i * step;
        const clamped = Math.min(maxVal, Math.max(0, val));
        const y = height - (clamped / maxVal) * (height - 10);
        return `${x},${y}`;
      })
      .join(' ');

    const areaPoints = `${points} ${width},${height} 0,${height}`;

    return (
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-44 rounded-xl bg-slate-900 overflow-hidden shadow-inner"
      >
        {/* Grid lines */}
        <line x1="0" y1="45" x2={width} y2="45" stroke="#334155" strokeDasharray="3,3" strokeWidth="1" />
        <line x1="0" y1="90" x2={width} y2="90" stroke="#334155" strokeDasharray="3,3" strokeWidth="1" />
        <line x1="0" y1="135" x2={width} y2="135" stroke="#334155" strokeDasharray="3,3" strokeWidth="1" />

        {/* Vertical grid lines */}
        {[100, 200, 300, 400].map((x) => (
          <line
            key={x}
            x1={x}
            y1="0"
            x2={x}
            y2={height}
            stroke="#1e293b"
            strokeDasharray="2,2"
            strokeWidth="1"
          />
        ))}

        {/* Area fill */}
        <polygon points={areaPoints} fill={color} fillOpacity="0.25" />

        {/* Stroke line */}
        <polyline
          points={points}
          fill="none"
          stroke={color}
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    );
  };

  const renderSelectedDetails = () => {
    switch (selectedDevice) {
      case 'cpu':
        return (
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">
                  AMD Ryzen 7 7800X3D 8-Core Processor
                </h3>
                <p className="text-xs text-slate-500 dark:text-zinc-400">
                  Kiến trúc Zen 4, 8 nhân vật lý, 16 luồng xử lý
                </p>
              </div>
              <div className="text-right font-mono">
                <span className="text-3xl font-extrabold text-sky-600 dark:text-sky-400">
                  {currentCpu}%
                </span>
                <div className="text-xs text-slate-400">
                  {(3.4 + currentCpu * 0.015).toFixed(2)} GHz
                </div>
              </div>
            </div>

            {renderSvgGraph(cpuHistory, '#0284c7', 100)}

            <div className="grid grid-cols-4 gap-3 text-xs bg-slate-50 dark:bg-zinc-800/60 p-4 rounded-xl border border-slate-200/80 dark:border-zinc-700/60">
              <div>
                <span className="text-slate-400 block">Tỷ lệ sử dụng:</span>
                <span className="font-bold text-sm">{currentCpu}%</span>
              </div>
              <div>
                <span className="text-slate-400 block">Tốc độ hiện tại:</span>
                <span className="font-bold text-sm">{(3.4 + currentCpu * 0.015).toFixed(2)} GHz</span>
              </div>
              <div>
                <span className="text-slate-400 block">Số tiến trình:</span>
                <span className="font-bold text-sm">184</span>
              </div>
              <div>
                <span className="text-slate-400 block">Luồng xử lý:</span>
                <span className="font-bold text-sm">2,490</span>
              </div>
              <div>
                <span className="text-slate-400 block">Số xử lý (Handles):</span>
                <span className="font-bold text-sm">89,420</span>
              </div>
              <div>
                <span className="text-slate-400 block">Thời gian hoạt động:</span>
                <span className="font-bold text-sm font-mono text-emerald-600 dark:text-emerald-400">
                  {formatUpTime(upTimeSeconds)}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Số nhân vật lý:</span>
                <span className="font-bold text-sm">8</span>
              </div>
              <div>
                <span className="text-slate-400 block">Bộ xử lý logic:</span>
                <span className="font-bold text-sm">16</span>
              </div>
              <div>
                <span className="text-slate-400 block">Ảo hóa:</span>
                <span className="font-bold text-sm text-emerald-600 dark:text-emerald-400">Đã bật (Enabled)</span>
              </div>
              <div>
                <span className="text-slate-400 block">Bộ đệm L1:</span>
                <span className="font-bold text-sm">512 KB</span>
              </div>
              <div>
                <span className="text-slate-400 block">Bộ đệm L2:</span>
                <span className="font-bold text-sm">8.0 MB</span>
              </div>
              <div>
                <span className="text-slate-400 block">Bộ đệm L3 (3D V-Cache):</span>
                <span className="font-bold text-sm text-sky-500">96.0 MB</span>
              </div>
            </div>
          </div>
        );

      case 'memory':
        return (
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">
                  Bộ nhớ RAM 16.0 GB DDR5
                </h3>
                <p className="text-xs text-slate-500 dark:text-zinc-400">
                  Tốc độ bus 5600 MT/s Dual-Channel
                </p>
              </div>
              <div className="text-right font-mono">
                <span className="text-3xl font-extrabold text-purple-600 dark:text-purple-400">
                  {((currentMem / 100) * 16).toFixed(1)} GB
                </span>
                <div className="text-xs text-slate-400">{currentMem}% sử dụng</div>
              </div>
            </div>

            {renderSvgGraph(memoryHistory, '#9333ea', 100)}

            <div className="grid grid-cols-3 gap-3 text-xs bg-slate-50 dark:bg-zinc-800/60 p-4 rounded-xl border border-slate-200/80 dark:border-zinc-700/60">
              <div>
                <span className="text-slate-400 block">Đang sử dụng:</span>
                <span className="font-bold text-sm">{((currentMem / 100) * 16).toFixed(1)} GB</span>
              </div>
              <div>
                <span className="text-slate-400 block">Còn trống:</span>
                <span className="font-bold text-sm">{(16.0 - (currentMem / 100) * 16).toFixed(1)} GB</span>
              </div>
              <div>
                <span className="text-slate-400 block">Đã cam kết (Committed):</span>
                <span className="font-bold text-sm">8.4 / 22.0 GB</span>
              </div>
              <div>
                <span className="text-slate-400 block">Bộ nhớ đệm (Cached):</span>
                <span className="font-bold text-sm">4.8 GB</span>
              </div>
              <div>
                <span className="text-slate-400 block">Vùng nhớ không phân trang:</span>
                <span className="font-bold text-sm">410 MB</span>
              </div>
              <div>
                <span className="text-slate-400 block">Tốc độ RAM:</span>
                <span className="font-bold text-sm">5600 MT/s</span>
              </div>
              <div>
                <span className="text-slate-400 block">Khe cắm đã dùng:</span>
                <span className="font-bold text-sm">2 / 4</span>
              </div>
              <div>
                <span className="text-slate-400 block">Hệ số dạng:</span>
                <span className="font-bold text-sm">DIMM</span>
              </div>
              <div>
                <span className="text-slate-400 block">Dành riêng cho phần cứng:</span>
                <span className="font-bold text-sm">184 MB</span>
              </div>
            </div>
          </div>
        );

      case 'disk_c':
      case 'disk_d':
        const isC = selectedDevice === 'disk_c';
        return (
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">
                  {isC ? 'Đĩa 0 (C: SSD NVMe) Samsung 990 PRO 1TB' : 'Đĩa 1 (D: HDD Data) Seagate 2TB'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-zinc-400">
                  {isC ? 'Chuẩn PCIe 4.0 x4 NVMe 2.0' : 'SATA III 6Gb/s 7200RPM'}
                </p>
              </div>
              <div className="text-right font-mono">
                <span className="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400">
                  {isC ? currentDisk : 0}%
                </span>
                <div className="text-xs text-slate-400">Thời gian hoạt động</div>
              </div>
            </div>

            {renderSvgGraph(diskHistory, isC ? '#16a34a' : '#ca8a04', 100)}

            <div className="grid grid-cols-3 gap-3 text-xs bg-slate-50 dark:bg-zinc-800/60 p-4 rounded-xl border border-slate-200/80 dark:border-zinc-700/60">
              <div>
                <span className="text-slate-400 block">Tốc độ đọc:</span>
                <span className="font-bold text-sm font-mono">
                  {isC ? `${(currentDisk * 2.4).toFixed(1)} MB/s` : '0.0 KB/s'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Tốc độ ghi:</span>
                <span className="font-bold text-sm font-mono">
                  {isC ? `${(currentDisk * 1.6).toFixed(1)} MB/s` : '0.0 KB/s'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Thời gian phản hồi:</span>
                <span className="font-bold text-sm font-mono">{isC ? '0.8 ms' : '8.2 ms'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Tổng dung lượng:</span>
                <span className="font-bold text-sm">{isC ? '931 GB (1.0 TB)' : '1863 GB (2.0 TB)'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Dung lượng còn trống:</span>
                <span className="font-bold text-sm text-emerald-600 dark:text-emerald-400">
                  {isC ? '642 GB (69%)' : '1240 GB (66%)'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Đĩa hệ thống:</span>
                <span className="font-bold text-sm">{isC ? 'Có (C: Windows)' : 'Không (Data D:)'}</span>
              </div>
            </div>
          </div>
        );

      case 'network':
        return (
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">
                  Mạng Wi-Fi (Intel Wi-Fi 6 AX201 160MHz)
                </h3>
                <p className="text-xs text-slate-500 dark:text-zinc-400">
                  Chuẩn kết nối IEEE 802.11ax băng tần 5 GHz
                </p>
              </div>
              <div className="text-right font-mono">
                <span className="text-3xl font-extrabold text-orange-600 dark:text-orange-400">
                  {(currentNet * 1.8).toFixed(1)} Mbps
                </span>
                <div className="text-xs text-slate-400">Tốc độ truyền dữ liệu</div>
              </div>
            </div>

            {renderSvgGraph(networkHistory, '#ea580c', 20)}

            <div className="grid grid-cols-3 gap-3 text-xs bg-slate-50 dark:bg-zinc-800/60 p-4 rounded-xl border border-slate-200/80 dark:border-zinc-700/60">
              <div>
                <span className="text-slate-400 block">Tốc độ gửi:</span>
                <span className="font-bold text-sm font-mono">{(currentNet * 0.4).toFixed(1)} Kbps</span>
              </div>
              <div>
                <span className="text-slate-400 block">Tốc độ nhận:</span>
                <span className="font-bold text-sm font-mono">{(currentNet * 1.8).toFixed(1)} Mbps</span>
              </div>
              <div>
                <span className="text-slate-400 block">Tên bộ điều hợp:</span>
                <span className="font-bold text-sm">Intel Wi-Fi 6 AX201</span>
              </div>
              <div>
                <span className="text-slate-400 block">Tên mạng SSID:</span>
                <span className="font-bold text-sm text-sky-500">Home_5G_HighSpeed</span>
              </div>
              <div>
                <span className="text-slate-400 block">Địa chỉ IPv4:</span>
                <span className="font-bold text-sm font-mono">192.168.1.108</span>
              </div>
              <div>
                <span className="text-slate-400 block">Địa chỉ IPv6:</span>
                <span className="font-bold text-sm font-mono">fe80::9a8b:7c6d:5e4f</span>
              </div>
              <div>
                <span className="text-slate-400 block">Loại kết nối:</span>
                <span className="font-bold text-sm">802.11ax (Wi-Fi 6)</span>
              </div>
              <div>
                <span className="text-slate-400 block">Tốc độ liên kết:</span>
                <span className="font-bold text-sm">2400/2400 (Mbps)</span>
              </div>
              <div>
                <span className="text-slate-400 block">Tín hiệu:</span>
                <span className="font-bold text-sm text-emerald-600 dark:text-emerald-400">Rất mạnh (100%)</span>
              </div>
            </div>
          </div>
        );

      case 'gpu':
        return (
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">
                  GPU 0 (NVIDIA GeForce RTX 4070)
                </h3>
                <p className="text-xs text-slate-500 dark:text-zinc-400">
                  12 GB GDDR6X VRAM, Ada Lovelace Architecture
                </p>
              </div>
              <div className="text-right font-mono">
                <span className="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400">
                  {currentGpu}%
                </span>
                <div className="text-xs text-slate-400">3D Compute Engine</div>
              </div>
            </div>

            {renderSvgGraph(gpuHistory, '#059669', 100)}

            <div className="grid grid-cols-3 gap-3 text-xs bg-slate-50 dark:bg-zinc-800/60 p-4 rounded-xl border border-slate-200/80 dark:border-zinc-700/60">
              <div>
                <span className="text-slate-400 block">Tỷ lệ dùng 3D:</span>
                <span className="font-bold text-sm">{currentGpu}%</span>
              </div>
              <div>
                <span className="text-slate-400 block">Bộ nhớ GPU chuyên dụng:</span>
                <span className="font-bold text-sm">
                  {((currentGpu / 100) * 12).toFixed(1)} / 12.0 GB GDDR6X
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Bộ nhớ GPU chia sẻ:</span>
                <span className="font-bold text-sm">0.6 / 8.0 GB</span>
              </div>
              <div>
                <span className="text-slate-400 block">Nhiệt độ GPU:</span>
                <span className="font-bold text-sm text-emerald-600 dark:text-emerald-400">48°C (Mát)</span>
              </div>
              <div>
                <span className="text-slate-400 block">Phiên bản trình điều khiển:</span>
                <span className="font-bold text-sm font-mono">551.86 (Game Ready)</span>
              </div>
              <div>
                <span className="text-slate-400 block">DirectX:</span>
                <span className="font-bold text-sm text-sky-500">DirectX 12 Ultimate</span>
              </div>
              <div>
                <span className="text-slate-400 block">Vị trí vật lý:</span>
                <span className="font-bold text-sm">Bus PCI 1, thiết bị 0</span>
              </div>
              <div>
                <span className="text-slate-400 block">Công suất tiêu thụ (TGP):</span>
                <span className="font-bold text-sm">{(45 + currentGpu * 1.4).toFixed(0)} W</span>
              </div>
              <div>
                <span className="text-slate-400 block">Tốc độ xung nhịp:</span>
                <span className="font-bold text-sm">2475 MHz</span>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-white dark:bg-[#1c1c1c]">
      {/* Split view: Left Device Selector / Right Realtime Graph & Details */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Devices Sidebar */}
        <div className="w-64 border-r border-slate-200 dark:border-zinc-800 flex flex-col overflow-y-auto bg-slate-50/50 dark:bg-zinc-900/30 p-2 gap-1.5 select-none shrink-0">
          {devices.map((dev) => {
            const isSelected = selectedDevice === dev.id;
            const Icon = dev.icon;
            return (
              <div
                key={dev.id}
                onClick={() => setSelectedDevice(dev.id)}
                className={`flex items-center gap-3 p-2.5 rounded-xl cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-sky-500/15 dark:bg-sky-500/20 border border-sky-500/40 shadow-sm'
                    : 'hover:bg-slate-200/60 dark:hover:bg-zinc-800/60 border border-transparent'
                }`}
              >
                <div
                  className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `${dev.color}20`, color: dev.color }}
                >
                  <Icon size={18} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold truncate text-slate-800 dark:text-slate-100">
                      {dev.name}
                    </span>
                  </div>
                  <div className="text-[11px] font-mono font-semibold truncate text-slate-600 dark:text-zinc-300">
                    {dev.val}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate">{dev.sub}</div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Details Panel */}
        <div className="flex-1 overflow-y-auto p-6">{renderSelectedDetails()}</div>
      </div>

      {/* Bottom Summary Bar (if enabled or default) */}
      {summaryView && (
        <div className="px-4 py-2 bg-slate-100 dark:bg-zinc-900 border-t border-slate-200 dark:border-zinc-800 flex items-center justify-between text-xs text-slate-600 dark:text-zinc-300 select-none">
          <div className="flex items-center gap-6 font-mono text-[11px]">
            <div>
              <span className="text-slate-400">CPU:</span>{' '}
              <span className="font-bold text-sky-500">{currentCpu}%</span>
            </div>
            <div>
              <span className="text-slate-400">RAM:</span>{' '}
              <span className="font-bold text-purple-500">{currentMem}%</span>
            </div>
            <div>
              <span className="text-slate-400">Đĩa:</span>{' '}
              <span className="font-bold text-emerald-500">{currentDisk}%</span>
            </div>
            <div>
              <span className="text-slate-400">Mạng:</span>{' '}
              <span className="font-bold text-orange-500">{(currentNet * 1.8).toFixed(1)} Mbps</span>
            </div>
            <div>
              <span className="text-slate-400">GPU:</span>{' '}
              <span className="font-bold text-emerald-500">{currentGpu}%</span>
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
            <Clock size={13} />
            <span>Thời gian hoạt động: {formatUpTime(upTimeSeconds)}</span>
          </div>
        </div>
      )}
    </div>
  );
};
