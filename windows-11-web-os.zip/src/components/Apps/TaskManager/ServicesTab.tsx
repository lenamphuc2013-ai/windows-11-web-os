import React, { useState } from 'react';
import { Play, Square, Pause, RotateCw, Settings2, Search, ExternalLink, ArrowUpDown, Filter, Layers } from 'lucide-react';
import { ServiceItemData, ServiceStatus } from './types';
import { useOS } from '../../../context/OSContext';

interface ServicesTabProps {
  services: ServiceItemData[];
  selectedServiceId: string | null;
  onSelectService: (id: string | null) => void;
  onUpdateServiceStatus: (id: string, status: ServiceStatus) => void;
  onOpenProperties: (service: ServiceItemData) => void;
}

export const ServicesTab: React.FC<ServicesTabProps> = ({
  services,
  selectedServiceId,
  onSelectService,
  onUpdateServiceStatus,
  onOpenProperties,
}) => {
  const { openApp, showContextMenu, addNotification } = useOS();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'running' | 'stopped'>('all');
  const [sortField, setSortField] = useState<keyof ServiceItemData>('name');
  const [sortAsc, setSortAsc] = useState(true);

  const handleSort = (field: keyof ServiceItemData) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  const filteredServices = services
    .filter((s) => {
      if (statusFilter === 'running' && s.status !== 'Đang chạy') return false;
      if (statusFilter === 'stopped' && s.status !== 'Đã dừng') return false;
      const term = searchTerm.toLowerCase();
      return (
        s.name.toLowerCase().includes(term) ||
        s.description.toLowerCase().includes(term) ||
        s.executablePath.toLowerCase().includes(term)
      );
    })
    .sort((a, b) => {
      const valA = a[sortField] ?? '';
      const valB = b[sortField] ?? '';
      if (typeof valA === 'string') {
        return sortAsc ? valA.localeCompare(valB as string) : (valB as string).localeCompare(valA);
      }
      return sortAsc ? (valA as number) - (valB as number) : (valB as number) - (valA as number);
    });

  const handleContextMenu = (e: React.MouseEvent, srv: ServiceItemData) => {
    e.preventDefault();
    e.stopPropagation();
    onSelectService(srv.id);

    const items = [
      {
        id: 'srv-start',
        label: 'Bắt đầu (Start)',
        icon: 'Play',
        disabled: srv.status === 'Đang chạy',
        onClick: () => {
          onUpdateServiceStatus(srv.id, 'Đang chạy');
          addNotification('Dịch vụ Windows', `Đã khởi động dịch vụ "${srv.name}"`, 'taskmanager');
        },
      },
      {
        id: 'srv-stop',
        label: 'Dừng (Stop)',
        icon: 'Square',
        disabled: srv.status === 'Đã dừng',
        onClick: () => {
          onUpdateServiceStatus(srv.id, 'Đã dừng');
          addNotification('Dịch vụ Windows', `Đã dừng dịch vụ "${srv.name}"`, 'taskmanager');
        },
      },
      {
        id: 'srv-pause',
        label: 'Tạm dừng (Pause)',
        icon: 'Pause',
        disabled: srv.status !== 'Đang chạy',
        onClick: () => {
          onUpdateServiceStatus(srv.id, 'Tạm dừng');
          addNotification('Dịch vụ Windows', `Đã tạm dừng dịch vụ "${srv.name}"`, 'taskmanager');
        },
      },
      {
        id: 'srv-restart',
        label: 'Khởi động lại (Restart)',
        icon: 'RotateCw',
        onClick: () => {
          onUpdateServiceStatus(srv.id, 'Đang khởi động');
          setTimeout(() => {
            onUpdateServiceStatus(srv.id, 'Đang chạy');
          }, 600);
          addNotification('Dịch vụ Windows', `Đã khởi động lại dịch vụ "${srv.name}"`, 'taskmanager');
        },
      },
      { separator: true, id: 'srv-sep-1', label: '' },
      {
        id: 'srv-open-services',
        label: 'Mở Quản lý Dịch vụ (Services MMC)',
        icon: 'Settings',
        onClick: () => {
          onOpenProperties(srv);
        },
      },
      {
        id: 'srv-properties',
        label: 'Thuộc tính...',
        icon: 'Sliders',
        onClick: () => {
          onOpenProperties(srv);
        },
      },
      {
        id: 'srv-search-online',
        label: 'Tìm kiếm trực tuyến',
        icon: 'Search',
        onClick: () => {
          openApp('edge', {
            initialUrl: `https://www.bing.com/search?q=${encodeURIComponent(
              srv.name + ' windows service'
            )}`,
          });
        },
      },
    ];

    showContextMenu(e.clientX, Math.min(e.clientY, window.innerHeight - 320), items, 'taskmanager');
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-white dark:bg-[#1c1c1c]">
      {/* Top Filter Bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-50 dark:bg-zinc-800/80 border-b border-slate-200 dark:border-zinc-700/80 text-xs">
        <div className="flex items-center gap-3 flex-1 max-w-md">
          <div className="relative w-full">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Tìm kiếm dịch vụ..."
              className="w-full pl-8 pr-3 py-1 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-800 dark:text-slate-100 text-xs outline-none focus:ring-1 focus:ring-sky-500"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-2.5 py-1 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-800 dark:text-slate-100 text-xs outline-none shrink-0"
          >
            <option value="all">Tất cả ({services.length})</option>
            <option value="running">Đang chạy</option>
            <option value="stopped">Đã dừng</option>
          </select>
        </div>

        {selectedServiceId && (
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                const srv = services.find((s) => s.id === selectedServiceId);
                if (srv) onOpenProperties(srv);
              }}
              className="flex items-center gap-1 px-3 py-1 rounded-lg bg-sky-500 hover:bg-sky-600 text-white text-xs font-semibold shadow-sm transition-all"
            >
              <Settings2 size={13} />
              <span>Thuộc tính</span>
            </button>
          </div>
        )}
      </div>

      {/* Table Container */}
      <div className="flex-1 overflow-auto">
        <table className="w-full min-w-[1100px] border-collapse text-left text-xs select-none">
          <thead className="sticky top-0 z-20 bg-slate-100 dark:bg-zinc-800 font-bold text-[11px] text-slate-500 dark:text-zinc-400 border-b border-slate-200 dark:border-zinc-700">
            <tr>
              <th
                onClick={() => handleSort('name')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500 w-44"
              >
                <div className="flex items-center gap-1">
                  <span>Tên dịch vụ</span>
                  <ArrowUpDown size={10} />
                </div>
              </th>
              <th
                onClick={() => handleSort('description')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500 w-72"
              >
                <div className="flex items-center gap-1">
                  <span>Mô tả</span>
                  <ArrowUpDown size={10} />
                </div>
              </th>
              <th
                onClick={() => handleSort('status')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500 text-center w-28"
              >
                <span>Trạng thái</span>
              </th>
              <th
                onClick={() => handleSort('startupType')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500 w-36"
              >
                <span>Loại khởi động</span>
              </th>
              <th
                onClick={() => handleSort('executablePath')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500"
              >
                <span>Tệp thực thi</span>
              </th>
              <th
                onClick={() => handleSort('logOnAs')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500 w-44"
              >
                <span>Đăng nhập như</span>
              </th>
              <th
                onClick={() => handleSort('dependencies')}
                className="px-3 py-1.5 cursor-pointer hover:text-sky-500 w-48"
              >
                <span>Nhóm phụ thuộc</span>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-zinc-800/60">
            {filteredServices.map((srv) => {
              const isSelected = selectedServiceId === srv.id;

              return (
                <tr
                  key={srv.id}
                  onClick={() => onSelectService(srv.id)}
                  onDoubleClick={() => onOpenProperties(srv)}
                  onContextMenu={(e) => handleContextMenu(e, srv)}
                  className={`cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-sky-500/20 dark:bg-sky-500/30 text-sky-900 dark:text-sky-100 font-semibold'
                      : 'hover:bg-slate-50 dark:hover:bg-zinc-800/50 text-slate-700 dark:text-zinc-200'
                  }`}
                >
                  <td className="px-3 py-2 font-mono font-bold text-xs truncate max-w-[170px] text-slate-800 dark:text-slate-100">
                    {srv.name}
                  </td>
                  <td className="px-3 py-2 text-xs truncate max-w-[280px] text-slate-600 dark:text-zinc-300">
                    {srv.description}
                  </td>
                  <td className="px-3 py-2 text-center">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded font-semibold ${
                        srv.status === 'Đang chạy'
                          ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                          : srv.status === 'Đã dừng'
                          ? 'bg-slate-200 dark:bg-zinc-700 text-slate-500'
                          : 'bg-amber-500/15 text-amber-600'
                      }`}
                    >
                      {srv.status}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-xs text-slate-600 dark:text-zinc-300">
                    {srv.startupType}
                  </td>
                  <td className="px-3 py-2 font-mono text-[10px] text-slate-400 truncate max-w-[240px]">
                    {srv.executablePath}
                  </td>
                  <td className="px-3 py-2 font-mono text-[11px] text-slate-500 truncate max-w-[170px]">
                    {srv.logOnAs}
                  </td>
                  <td className="px-3 py-2 text-[11px] text-slate-400 truncate max-w-[190px]">
                    {srv.dependencies}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
