import React, { useState } from 'react';
import { History, Filter, Trash2, Calendar, Clock, ArrowUpDown } from 'lucide-react';
import { IconRenderer } from '../../Common/IconRenderer';
import { AppHistoryItemData } from './types';
import { useOS } from '../../../context/OSContext';

interface AppHistoryTabProps {
  historyItems: AppHistoryItemData[];
  onClearHistory: () => void;
}

export const AppHistoryTab: React.FC<AppHistoryTabProps> = ({
  historyItems,
  onClearHistory,
}) => {
  const { addNotification } = useOS();
  const [timeRange, setTimeRange] = useState<'1m' | '1h' | '7d'>('1h');
  const [filterType, setFilterType] = useState<'all' | 'running' | 'closed'>('all');
  const [sortField, setSortField] = useState<keyof AppHistoryItemData>('appName');
  const [sortAsc, setSortAsc] = useState(true);

  const filteredItems = historyItems
    .filter((item) => {
      if (filterType === 'running') return item.status === 'running';
      if (filterType === 'closed') return item.status === 'closed';
      return true;
    })
    .sort((a, b) => {
      let valA = a[sortField] || '';
      let valB = b[sortField] || '';
      if (typeof valA === 'string') {
        return sortAsc ? valA.localeCompare(valB as string) : (valB as string).localeCompare(valA);
      }
      return sortAsc ? (valA as number) - (valB as number) : (valB as number) - (valA as number);
    });

  const handleSort = (field: keyof AppHistoryItemData) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-white dark:bg-[#1c1c1c]">
      {/* Top Filter & Chart Controls */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-50 dark:bg-zinc-800/80 border-b border-slate-200 dark:border-zinc-700/80 text-xs">
        <div className="flex items-center gap-3">
          {/* Time range selector */}
          <div className="flex items-center gap-1 bg-slate-200/60 dark:bg-zinc-700/60 p-0.5 rounded-lg">
            <button
              onClick={() => setTimeRange('1m')}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                timeRange === '1m'
                  ? 'bg-white dark:bg-zinc-800 text-sky-600 dark:text-sky-400 shadow-sm'
                  : 'text-slate-600 dark:text-zinc-300 hover:text-slate-900'
              }`}
            >
              1 phút
            </button>
            <button
              onClick={() => setTimeRange('1h')}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                timeRange === '1h'
                  ? 'bg-white dark:bg-zinc-800 text-sky-600 dark:text-sky-400 shadow-sm'
                  : 'text-slate-600 dark:text-zinc-300 hover:text-slate-900'
              }`}
            >
              1 giờ
            </button>
            <button
              onClick={() => setTimeRange('7d')}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                timeRange === '7d'
                  ? 'bg-white dark:bg-zinc-800 text-sky-600 dark:text-sky-400 shadow-sm'
                  : 'text-slate-600 dark:text-zinc-300 hover:text-slate-900'
              }`}
            >
              7 ngày qua
            </button>
          </div>

          {/* Filter Status */}
          <div className="flex items-center gap-1.5 ml-2">
            <Filter size={13} className="text-slate-400" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as any)}
              className="px-2.5 py-1 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-800 dark:text-slate-100 text-[11px] outline-none"
            >
              <option value="all">Tất cả ứng dụng ({historyItems.length})</option>
              <option value="running">Ứng dụng đang dùng</option>
              <option value="closed">Đã đóng</option>
            </select>
          </div>
        </div>

        {/* Clear history button */}
        <button
          onClick={() => {
            onClearHistory();
            addNotification('Lịch sử ứng dụng', 'Đã xóa toàn bộ lịch sử sử dụng tài nguyên ứng dụng', 'taskmanager');
          }}
          className="flex items-center gap-1.5 px-3 py-1 rounded-lg text-red-600 dark:text-red-400 hover:bg-red-500/10 transition-colors text-[11px] font-semibold"
        >
          <Trash2 size={13} />
          <span>Xóa lịch sử sử dụng</span>
        </button>
      </div>

      {/* Mini Visual Chart Bar for the top 4 apps */}
      <div className="px-4 py-3 bg-slate-50/50 dark:bg-zinc-900/30 border-b border-slate-200 dark:border-zinc-800 flex flex-col gap-2">
        <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500 dark:text-zinc-400">
          <span>Tiêu thụ CPU theo ứng dụng ({timeRange === '1m' ? '1 phút' : timeRange === '1h' ? '1 giờ' : '7 ngày'}):</span>
          <span className="text-[10px] text-slate-400">Dữ liệu tài nguyên thời gian thực</span>
        </div>
        <div className="w-full h-3 rounded-full bg-slate-200 dark:bg-zinc-800 overflow-hidden flex">
          <div className="bg-sky-500 h-full" style={{ width: '42%' }} title="Microsoft Edge: 42%" />
          <div className="bg-purple-500 h-full" style={{ width: '26%' }} title="Visual Studio Code / Terminal: 26%" />
          <div className="bg-emerald-500 h-full" style={{ width: '18%' }} title="File Explorer: 18%" />
          <div className="bg-amber-500 h-full" style={{ width: '14%' }} title="Khác: 14%" />
        </div>
        <div className="flex items-center gap-4 text-[10px] text-slate-500 dark:text-zinc-400">
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-sky-500" />
            <span>Microsoft Edge (42%)</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-purple-500" />
            <span>Terminal & Code (26%)</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>File Explorer (18%)</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-amber-500" />
            <span>Khác (14%)</span>
          </div>
        </div>
      </div>

      {/* Table Header */}
      <div className="grid grid-cols-12 px-4 py-1.5 font-bold text-[11px] text-slate-500 dark:text-zinc-400 bg-slate-100 dark:bg-zinc-800/90 border-b border-slate-200 dark:border-zinc-700/80 sticky top-0 select-none">
        <div
          onClick={() => handleSort('appName')}
          className="col-span-3 flex items-center gap-1 cursor-pointer hover:text-sky-500"
        >
          <span>Tên ứng dụng</span>
          <ArrowUpDown size={11} />
        </div>
        <div
          onClick={() => handleSort('runtime')}
          className="col-span-1 text-right pr-2 cursor-pointer hover:text-sky-500"
        >
          <span>Thời gian chạy</span>
        </div>
        <div
          onClick={() => handleSort('cpuTime')}
          className="col-span-1 text-right pr-2 cursor-pointer hover:text-sky-500"
        >
          <span>CPU tiêu thụ</span>
        </div>
        <div
          onClick={() => handleSort('avgMemory')}
          className="col-span-1 text-right pr-2 cursor-pointer hover:text-sky-500"
        >
          <span>Bộ nhớ TB</span>
        </div>
        <div
          onClick={() => handleSort('diskUsage')}
          className="col-span-2 text-right pr-2 cursor-pointer hover:text-sky-500"
        >
          <span>Đĩa</span>
        </div>
        <div
          onClick={() => handleSort('networkUsage')}
          className="col-span-1 text-right pr-2 cursor-pointer hover:text-sky-500"
        >
          <span>Mạng</span>
        </div>
        <div
          onClick={() => handleSort('activeDuration')}
          className="col-span-2 text-center cursor-pointer hover:text-sky-500"
        >
          <span>Thời gian hoạt động</span>
        </div>
        <div
          onClick={() => handleSort('lastOpened')}
          className="col-span-1 text-right cursor-pointer hover:text-sky-500"
        >
          <span>Lần cuối mở</span>
        </div>
      </div>

      {/* Main List */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-zinc-800/60">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            className="grid grid-cols-12 items-center px-4 py-2 text-xs hover:bg-slate-50 dark:hover:bg-zinc-800/50 transition-colors text-slate-700 dark:text-zinc-200"
          >
            {/* Tên ứng dụng */}
            <div className="col-span-3 flex items-center gap-2 truncate pr-2">
              <div className="w-4 h-4 flex items-center justify-center shrink-0">
                <IconRenderer name={item.icon || 'Activity'} size={15} />
              </div>
              <span className="font-semibold truncate">{item.appName}</span>
              {item.status === 'running' && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" title="Đang chạy" />
              )}
            </div>

            {/* Thời gian chạy */}
            <div className="col-span-1 text-right font-mono text-[11px] pr-2 text-slate-600 dark:text-zinc-400">
              {item.runtime}
            </div>

            {/* CPU tiêu thụ */}
            <div className="col-span-1 text-right font-mono text-[11px] pr-2 text-sky-600 dark:text-sky-400 font-semibold">
              {item.cpuTime}
            </div>

            {/* Bộ nhớ trung bình */}
            <div className="col-span-1 text-right font-mono text-[11px] pr-2 text-slate-600 dark:text-zinc-400">
              {item.avgMemory} MB
            </div>

            {/* Đĩa */}
            <div className="col-span-2 text-right font-mono text-[11px] pr-2 text-slate-600 dark:text-zinc-400">
              {item.diskUsage}
            </div>

            {/* Mạng */}
            <div className="col-span-1 text-right font-mono text-[11px] pr-2 text-slate-600 dark:text-zinc-400">
              {item.networkUsage}
            </div>

            {/* Thời gian hoạt động */}
            <div className="col-span-2 text-center text-[11px] text-slate-500 dark:text-zinc-400">
              {item.activeDuration}
            </div>

            {/* Lần cuối mở */}
            <div className="col-span-1 text-right text-[11px] text-slate-500 dark:text-zinc-400">
              {item.lastOpened}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
