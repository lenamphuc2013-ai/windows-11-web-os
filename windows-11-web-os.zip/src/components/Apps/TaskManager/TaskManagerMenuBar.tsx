import React, { useState, useRef, useEffect } from 'react';
import { Play, Check, ChevronRight, HelpCircle, ExternalLink, Settings, Eye, Info, X } from 'lucide-react';
import { ColumnVisibility } from './types';
import { useOS } from '../../../context/OSContext';

interface TaskManagerMenuBarProps {
  onOpenNewTask: () => void;
  onCloseApp: () => void;
  onOpenAbout: () => void;
  alwaysOnTop: boolean;
  setAlwaysOnTop: React.Dispatch<React.SetStateAction<boolean>>;
  minimizeOnClose: boolean;
  setMinimizeOnClose: React.Dispatch<React.SetStateAction<boolean>>;
  openDetailedWindow: boolean;
  setOpenDetailedWindow: React.Dispatch<React.SetStateAction<boolean>>;
  hideWhenMinimized: boolean;
  setHideWhenMinimized: React.Dispatch<React.SetStateAction<boolean>>;
  showFullPaths: boolean;
  setShowFullPaths: React.Dispatch<React.SetStateAction<boolean>>;
  summaryView: boolean;
  setSummaryView: React.Dispatch<React.SetStateAction<boolean>>;
  refreshSpeed: 'high' | 'normal' | 'low' | 'paused';
  setRefreshSpeed: (speed: 'high' | 'normal' | 'low' | 'paused') => void;
  columns: ColumnVisibility;
  setColumns: React.Dispatch<React.SetStateAction<ColumnVisibility>>;
}

export const TaskManagerMenuBar: React.FC<TaskManagerMenuBarProps> = ({
  onOpenNewTask,
  onCloseApp,
  onOpenAbout,
  alwaysOnTop,
  setAlwaysOnTop,
  minimizeOnClose,
  setMinimizeOnClose,
  openDetailedWindow,
  setOpenDetailedWindow,
  hideWhenMinimized,
  setHideWhenMinimized,
  showFullPaths,
  setShowFullPaths,
  summaryView,
  setSummaryView,
  refreshSpeed,
  setRefreshSpeed,
  columns,
  setColumns,
}) => {
  const { openApp, addNotification } = useOS();
  const [activeMenu, setActiveMenu] = useState<'file' | 'options' | 'view' | 'help' | null>(null);
  const [isColumnSubmenuOpen, setIsColumnSubmenuOpen] = useState(false);
  const menuBarRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuBarRef.current && !menuBarRef.current.contains(e.target as Node)) {
        setActiveMenu(null);
        setIsColumnSubmenuOpen(false);
      }
    };
    window.addEventListener('mousedown', handleClickOutside);
    return () => window.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div
      ref={menuBarRef}
      className="flex items-center gap-1 px-3 py-1 bg-white/70 dark:bg-[#1f1f1f]/70 border-b border-slate-200/80 dark:border-zinc-800/80 text-[11px] select-none backdrop-blur-sm relative z-30"
    >
      {/* Tệp (File) */}
      <div className="relative">
        <button
          onClick={() => setActiveMenu(activeMenu === 'file' ? null : 'file')}
          onMouseEnter={() => activeMenu && setActiveMenu('file')}
          className={`px-2.5 py-1 rounded transition-colors ${
            activeMenu === 'file'
              ? 'bg-slate-200/80 dark:bg-zinc-700/80 font-bold'
              : 'hover:bg-slate-200/50 dark:hover:bg-zinc-800/50 text-slate-700 dark:text-zinc-200'
          }`}
        >
          Tệp
        </button>

        {activeMenu === 'file' && (
          <div className="absolute left-0 top-full mt-1 w-52 bg-white dark:bg-[#252525] rounded-xl shadow-xl border border-slate-200 dark:border-zinc-700/80 p-1.5 flex flex-col gap-0.5 text-xs text-slate-800 dark:text-slate-100 z-50">
            <button
              onClick={() => {
                setActiveMenu(null);
                onOpenNewTask();
              }}
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-sky-500/10 text-left cursor-pointer"
            >
              <Play size={13} className="text-sky-500" />
              <span>Chạy tác vụ mới...</span>
            </button>
            <div className="h-px bg-slate-200 dark:bg-zinc-700 my-1" />
            <button
              onClick={() => {
                setActiveMenu(null);
                onCloseApp();
              }}
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-red-500/10 text-red-600 dark:text-red-400 text-left cursor-pointer"
            >
              <X size={13} />
              <span>Thoát</span>
            </button>
          </div>
        )}
      </div>

      {/* Tùy chọn (Options) */}
      <div className="relative">
        <button
          onClick={() => setActiveMenu(activeMenu === 'options' ? null : 'options')}
          onMouseEnter={() => activeMenu && setActiveMenu('options')}
          className={`px-2.5 py-1 rounded transition-colors ${
            activeMenu === 'options'
              ? 'bg-slate-200/80 dark:bg-zinc-700/80 font-bold'
              : 'hover:bg-slate-200/50 dark:hover:bg-zinc-800/50 text-slate-700 dark:text-zinc-200'
          }`}
        >
          Tùy chọn
        </button>

        {activeMenu === 'options' && (
          <div className="absolute left-0 top-full mt-1 w-64 bg-white dark:bg-[#252525] rounded-xl shadow-xl border border-slate-200 dark:border-zinc-700/80 p-1.5 flex flex-col gap-0.5 text-xs text-slate-800 dark:text-slate-100 z-50">
            <button
              onClick={() => {
                setAlwaysOnTop((prev) => !prev);
                addNotification('Trình quản lý Tác vụ', alwaysOnTop ? 'Đã tắt Luôn trên cùng' : 'Đã bật Luôn trên cùng', 'taskmanager');
              }}
              className="flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-sky-500/10 text-left"
            >
              <span>Luôn hiển thị trên cùng</span>
              {alwaysOnTop && <Check size={14} className="text-sky-500" />}
            </button>
            <button
              onClick={() => setMinimizeOnClose((prev) => !prev)}
              className="flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-sky-500/10 text-left"
            >
              <span>Thu nhỏ khi đóng</span>
              {minimizeOnClose && <Check size={14} className="text-sky-500" />}
            </button>
            <button
              onClick={() => setOpenDetailedWindow((prev) => !prev)}
              className="flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-sky-500/10 text-left"
            >
              <span>Mở cửa sổ chi tiết</span>
              {openDetailedWindow && <Check size={14} className="text-sky-500" />}
            </button>
            <button
              onClick={() => setHideWhenMinimized((prev) => !prev)}
              className="flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-sky-500/10 text-left"
            >
              <span>Ẩn biểu tượng khi thu nhỏ</span>
              {hideWhenMinimized && <Check size={14} className="text-sky-500" />}
            </button>
            <div className="h-px bg-slate-200 dark:bg-zinc-700 my-1" />
            <button
              onClick={() => setShowFullPaths((prev) => !prev)}
              className="flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-sky-500/10 text-left"
            >
              <span>Hiển thị tên đầy đủ đường dẫn</span>
              {showFullPaths && <Check size={14} className="text-sky-500" />}
            </button>
          </div>
        )}
      </div>

      {/* Xem (View) */}
      <div className="relative">
        <button
          onClick={() => setActiveMenu(activeMenu === 'view' ? null : 'view')}
          onMouseEnter={() => activeMenu && setActiveMenu('view')}
          className={`px-2.5 py-1 rounded transition-colors ${
            activeMenu === 'view'
              ? 'bg-slate-200/80 dark:bg-zinc-700/80 font-bold'
              : 'hover:bg-slate-200/50 dark:hover:bg-zinc-800/50 text-slate-700 dark:text-zinc-200'
          }`}
        >
          Xem
        </button>

        {activeMenu === 'view' && (
          <div className="absolute left-0 top-full mt-1 w-64 bg-white dark:bg-[#252525] rounded-xl shadow-xl border border-slate-200 dark:border-zinc-700/80 p-1.5 flex flex-col gap-0.5 text-xs text-slate-800 dark:text-slate-100 z-50">
            {/* Columns Submenu trigger */}
            <div
              className="relative"
              onMouseEnter={() => setIsColumnSubmenuOpen(true)}
              onMouseLeave={() => setIsColumnSubmenuOpen(false)}
            >
              <div className="flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-sky-500/10 cursor-pointer">
                <span>Chọn các cột hiển thị...</span>
                <ChevronRight size={13} className="text-slate-400" />
              </div>

              {isColumnSubmenuOpen && (
                <div className="absolute left-full top-0 ml-1 w-52 bg-white dark:bg-[#252525] rounded-xl shadow-xl border border-slate-200 dark:border-zinc-700/80 p-1.5 flex flex-col gap-0.5 z-50">
                  <button
                    onClick={() => setColumns((c) => ({ ...c, cpu: !c.cpu }))}
                    className="flex items-center justify-between px-2 py-1 rounded hover:bg-sky-500/10 text-left"
                  >
                    <span>CPU</span>
                    {columns.cpu && <Check size={13} className="text-sky-500" />}
                  </button>
                  <button
                    onClick={() => setColumns((c) => ({ ...c, memory: !c.memory }))}
                    className="flex items-center justify-between px-2 py-1 rounded hover:bg-sky-500/10 text-left"
                  >
                    <span>Bộ nhớ (Memory)</span>
                    {columns.memory && <Check size={13} className="text-sky-500" />}
                  </button>
                  <button
                    onClick={() => setColumns((c) => ({ ...c, disk: !c.disk }))}
                    className="flex items-center justify-between px-2 py-1 rounded hover:bg-sky-500/10 text-left"
                  >
                    <span>Đĩa (Disk)</span>
                    {columns.disk && <Check size={13} className="text-sky-500" />}
                  </button>
                  <button
                    onClick={() => setColumns((c) => ({ ...c, network: !c.network }))}
                    className="flex items-center justify-between px-2 py-1 rounded hover:bg-sky-500/10 text-left"
                  >
                    <span>Mạng (Network)</span>
                    {columns.network && <Check size={13} className="text-sky-500" />}
                  </button>
                  <button
                    onClick={() => setColumns((c) => ({ ...c, powerUsage: !c.powerUsage }))}
                    className="flex items-center justify-between px-2 py-1 rounded hover:bg-sky-500/10 text-left"
                  >
                    <span>Năng lượng (Power)</span>
                    {columns.powerUsage && <Check size={13} className="text-sky-500" />}
                  </button>
                  <button
                    onClick={() => setColumns((c) => ({ ...c, publisher: !c.publisher }))}
                    className="flex items-center justify-between px-2 py-1 rounded hover:bg-sky-500/10 text-left"
                  >
                    <span>Nhà phát triển</span>
                    {columns.publisher && <Check size={13} className="text-sky-500" />}
                  </button>
                </div>
              )}
            </div>

            <button
              onClick={() => setSummaryView((prev) => !prev)}
              className="flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-sky-500/10 text-left"
            >
              <span>Biểu đồ tóm tắt toàn hệ thống</span>
              {summaryView && <Check size={14} className="text-sky-500" />}
            </button>

            <div className="h-px bg-slate-200 dark:bg-zinc-700 my-1" />
            <div className="px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Tốc độ làm mới (Update Speed)
            </div>
            <button
              onClick={() => setRefreshSpeed('high')}
              className="flex items-center justify-between px-2.5 py-1 rounded-lg hover:bg-sky-500/10 text-left"
            >
              <span>Cao (0.5 giây)</span>
              {refreshSpeed === 'high' && <Check size={14} className="text-sky-500" />}
            </button>
            <button
              onClick={() => setRefreshSpeed('normal')}
              className="flex items-center justify-between px-2.5 py-1 rounded-lg hover:bg-sky-500/10 text-left"
            >
              <span>Bình thường (1.0 giây)</span>
              {refreshSpeed === 'normal' && <Check size={14} className="text-sky-500" />}
            </button>
            <button
              onClick={() => setRefreshSpeed('low')}
              className="flex items-center justify-between px-2.5 py-1 rounded-lg hover:bg-sky-500/10 text-left"
            >
              <span>Thấp (4.0 giây)</span>
              {refreshSpeed === 'low' && <Check size={14} className="text-sky-500" />}
            </button>
            <button
              onClick={() => setRefreshSpeed('paused')}
              className="flex items-center justify-between px-2.5 py-1 rounded-lg hover:bg-sky-500/10 text-left"
            >
              <span>Tạm dừng (Paused)</span>
              {refreshSpeed === 'paused' && <Check size={14} className="text-sky-500" />}
            </button>
          </div>
        )}
      </div>

      {/* Hỗ trợ (Help) */}
      <div className="relative">
        <button
          onClick={() => setActiveMenu(activeMenu === 'help' ? null : 'help')}
          onMouseEnter={() => activeMenu && setActiveMenu('help')}
          className={`px-2.5 py-1 rounded transition-colors ${
            activeMenu === 'help'
              ? 'bg-slate-200/80 dark:bg-zinc-700/80 font-bold'
              : 'hover:bg-slate-200/50 dark:hover:bg-zinc-800/50 text-slate-700 dark:text-zinc-200'
          }`}
        >
          Hỗ trợ
        </button>

        {activeMenu === 'help' && (
          <div className="absolute left-0 top-full mt-1 w-64 bg-white dark:bg-[#252525] rounded-xl shadow-xl border border-slate-200 dark:border-zinc-700/80 p-1.5 flex flex-col gap-0.5 text-xs text-slate-800 dark:text-slate-100 z-50">
            <button
              onClick={() => {
                setActiveMenu(null);
                onOpenAbout();
              }}
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-sky-500/10 text-left"
            >
              <Info size={14} className="text-teal-500" />
              <span>Giới thiệu Trình quản lý Tác vụ</span>
            </button>
            <button
              onClick={() => {
                setActiveMenu(null);
                onOpenAbout();
              }}
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-sky-500/10 text-left"
            >
              <Settings size={14} className="text-sky-500" />
              <span>Thông tin phiên bản</span>
            </button>
            <div className="h-px bg-slate-200 dark:bg-zinc-700 my-1" />
            <button
              onClick={() => {
                setActiveMenu(null);
                openApp('edge', { initialUrl: 'https://support.microsoft.com/windows' });
              }}
              className="flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-sky-500/10 text-left"
            >
              <div className="flex items-center gap-2">
                <HelpCircle size={14} className="text-amber-500" />
                <span>Liên kết hỗ trợ Microsoft</span>
              </div>
              <ExternalLink size={12} className="text-slate-400" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
