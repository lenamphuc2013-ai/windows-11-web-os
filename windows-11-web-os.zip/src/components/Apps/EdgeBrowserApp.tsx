import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Home,
  Search,
  Plus,
  X,
  Lock,
  Star,
  Compass,
  ExternalLink,
  Shield,
  Layers,
  Sparkles,
  Gamepad2,
  Folder,
  Code,
  Share2,
  Maximize2,
} from 'lucide-react';
import { useOS } from '../../context/OSContext';

interface Tab {
  id: string;
  title: string;
  url: string;
  contentView: 'home' | 'web' | 'search' | 'apps' | 'games';
  liveUrl?: string;
  searchQuery?: string;
  history: string[];
  historyIndex: number;
}

export const EdgeBrowserApp: React.FC = () => {
  const { fileSystem, openApp, addNotification } = useOS();
  const [tabs, setTabs] = useState<Tab[]>([
    {
      id: 'tab-1',
      title: 'Trang chủ - Microsoft Edge',
      url: 'edge://newtab',
      contentView: 'home',
      history: ['edge://newtab'],
      historyIndex: 0,
    },
  ]);
  const [activeTabId, setActiveTabId] = useState('tab-1');
  const [urlInput, setUrlInput] = useState('');
  const [searchInputValue, setSearchInputValue] = useState('');
  const [isIframeLoading, setIsIframeLoading] = useState(false);
  const [iframeKey, setIframeKey] = useState(1);

  const activeTab = tabs.find((t) => t.id === activeTabId) || tabs[0];

  // Helper to parse if string is an explicit URL vs a search query
  const parseNavigation = (input: string): { type: 'home' | 'web' | 'search' | 'apps' | 'games'; url: string; query?: string; title: string } => {
    const raw = input.trim();
    if (!raw || raw === 'edge://newtab' || raw === 'about:blank') {
      return { type: 'home', url: 'edge://newtab', title: 'Trang chủ - Microsoft Edge' };
    }
    if (raw === 'edge://apps' || raw === 'apps') {
      return { type: 'apps', url: 'edge://apps', title: 'Kho ứng dụng C:\\Apps' };
    }
    if (raw === 'edge://games' || raw === 'games') {
      return { type: 'games', url: 'edge://games', title: 'HTML5 Games' };
    }

    // Check if input looks like a valid URL or domain
    const isUrlPattern =
      /^https?:\/\//i.test(raw) ||
      /^www\./i.test(raw) ||
      (/^[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(\/.*)?$/i.test(raw) && !raw.includes(' '));

    if (isUrlPattern) {
      let finalUrl = raw;
      if (!/^https?:\/\//i.test(finalUrl)) {
        finalUrl = 'https://' + finalUrl;
      }
      try {
        const parsed = new URL(finalUrl);
        return {
          type: 'web',
          url: finalUrl,
          title: parsed.hostname || finalUrl,
        };
      } catch (e) {
        // Fallback to search
      }
    }

    // Default to search
    const query = raw.replace(/^https?:\/\/(www\.)?(bing|google|duckduckgo)\.com\/(search)?\?q=/i, '');
    const searchUrl = `https://duckduckgo.com/?q=${encodeURIComponent(query)}&kp=-1&kl=wt-wt`;
    return {
      type: 'search',
      url: `edge://search?q=${encodeURIComponent(query)}`,
      query,
      title: `${query} - Tìm kiếm Bing & DuckDuckGo`,
    };
  };

  const handleNavigate = (target: string) => {
    const { type, url, query, title } = parseNavigation(target);

    setTabs((prev) =>
      prev.map((t) => {
        if (t.id === activeTabId) {
          const newHistory = t.history.slice(0, t.historyIndex + 1);
          newHistory.push(url);
          return {
            ...t,
            url,
            title,
            contentView: type,
            liveUrl: type === 'web' ? url : type === 'search' ? `https://duckduckgo.com/?q=${encodeURIComponent(query || '')}&kp=-1&kl=wt-wt` : undefined,
            searchQuery: query,
            history: newHistory,
            historyIndex: newHistory.length - 1,
          };
        }
        return t;
      })
    );

    setUrlInput(type === 'home' ? '' : url);
    setIframeKey((k) => k + 1);
    setIsIframeLoading(type === 'web' || type === 'search');
  };

  const handleBack = () => {
    if (activeTab.historyIndex > 0) {
      const prevUrl = activeTab.history[activeTab.historyIndex - 1];
      const { type, url, query, title } = parseNavigation(prevUrl);
      setTabs((prev) =>
        prev.map((t) =>
          t.id === activeTabId
            ? {
                ...t,
                url,
                title,
                contentView: type,
                liveUrl: type === 'web' ? url : type === 'search' ? `https://duckduckgo.com/?q=${encodeURIComponent(query || '')}&kp=-1&kl=wt-wt` : undefined,
                searchQuery: query,
                historyIndex: t.historyIndex - 1,
              }
            : t
        )
      );
      setUrlInput(type === 'home' ? '' : url);
      setIframeKey((k) => k + 1);
    }
  };

  const handleForward = () => {
    if (activeTab.historyIndex < activeTab.history.length - 1) {
      const nextUrl = activeTab.history[activeTab.historyIndex + 1];
      const { type, url, query, title } = parseNavigation(nextUrl);
      setTabs((prev) =>
        prev.map((t) =>
          t.id === activeTabId
            ? {
                ...t,
                url,
                title,
                contentView: type,
                liveUrl: type === 'web' ? url : type === 'search' ? `https://duckduckgo.com/?q=${encodeURIComponent(query || '')}&kp=-1&kl=wt-wt` : undefined,
                searchQuery: query,
                historyIndex: t.historyIndex + 1,
              }
            : t
        )
      );
      setUrlInput(type === 'home' ? '' : url);
      setIframeKey((k) => k + 1);
    }
  };

  const handleReload = () => {
    setIframeKey((k) => k + 1);
    setIsIframeLoading(true);
  };

  const handleNewTab = () => {
    const newId = 'tab-' + Date.now();
    const newTab: Tab = {
      id: newId,
      title: 'Trang chủ - Microsoft Edge',
      url: 'edge://newtab',
      contentView: 'home',
      history: ['edge://newtab'],
      historyIndex: 0,
    };
    setTabs((prev) => [...prev, newTab]);
    setActiveTabId(newId);
    setUrlInput('');
  };

  const handleCloseTab = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tabs.length === 1) {
      setTabs([
        {
          id: 'tab-1',
          title: 'Trang chủ - Microsoft Edge',
          url: 'edge://newtab',
          contentView: 'home',
          history: ['edge://newtab'],
          historyIndex: 0,
        },
      ]);
      setActiveTabId('tab-1');
      setUrlInput('');
      return;
    }
    const remaining = tabs.filter((t) => t.id !== id);
    setTabs(remaining);
    if (activeTabId === id) {
      const nextTab = remaining[remaining.length - 1];
      setActiveTabId(nextTab.id);
      setUrlInput(nextTab.url === 'edge://newtab' ? '' : nextTab.url);
    }
  };

  // Pre-configured bookmarks & quick links
  const BOOKMARKS = [
    { name: 'Google', url: 'https://www.google.com', icon: '🔍' },
    { name: 'DuckDuckGo', url: 'https://duckduckgo.com', icon: '🦆' },
    { name: 'Wikipedia', url: 'https://en.wikipedia.org/wiki/Main_Page', icon: '📚' },
    { name: 'GitHub', url: 'https://github.com', icon: '🐙' },
    { name: 'VnExpress', url: 'https://vnexpress.net', icon: '📰' },
    { name: 'W3Schools', url: 'https://www.w3schools.com', icon: '💻' },
    { name: 'App C:\\Apps', url: 'edge://apps', icon: '⚡' },
    { name: 'Mini Games', url: 'edge://games', icon: '🎮' },
  ];

  const htmlApps = fileSystem.filter((f) => f.isHtmlApp || f.name.endsWith('.html'));

  return (
    <div className="flex flex-col w-full h-full bg-[#1e1e24] text-slate-100 select-none overflow-hidden font-sans">
      {/* Top Tab Strip */}
      <div className="flex items-center px-2 pt-1.5 bg-[#18181c] border-b border-white/10 gap-1 overflow-x-auto">
        {tabs.map((t) => {
          const isActive = t.id === activeTabId;
          return (
            <div
              key={t.id}
              onClick={() => {
                setActiveTabId(t.id);
                setUrlInput(t.url === 'edge://newtab' ? '' : t.url);
              }}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-t-xl text-xs max-w-[220px] min-w-[140px] cursor-pointer transition-all border-t border-x ${
                isActive
                  ? 'bg-[#2b2b36] border-white/20 text-white font-medium shadow-md'
                  : 'bg-transparent border-transparent text-slate-400 hover:bg-white/5 hover:text-slate-200'
              }`}
            >
              <Compass size={13} className="text-sky-400 shrink-0" />
              <span className="truncate flex-1">{t.title}</span>
              <button
                onClick={(e) => handleCloseTab(t.id, e)}
                className="p-0.5 rounded hover:bg-white/20 text-slate-400 hover:text-white"
                title="Đóng tab"
              >
                <X size={12} />
              </button>
            </div>
          );
        })}
        <button
          onClick={handleNewTab}
          className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors ml-1"
          title="Mở tab mới"
        >
          <Plus size={14} />
        </button>
      </div>

      {/* Navigation & Address Bar */}
      <div className="flex items-center gap-2 px-3 py-2 bg-[#23232b] border-b border-white/10">
        <div className="flex items-center gap-1 text-slate-400">
          <button
            onClick={handleBack}
            disabled={activeTab.historyIndex <= 0}
            className="p-1.5 hover:bg-white/10 rounded-lg disabled:opacity-30 disabled:hover:bg-transparent text-slate-200 transition-colors"
            title="Quay lại"
          >
            <ArrowLeft size={16} />
          </button>
          <button
            onClick={handleForward}
            disabled={activeTab.historyIndex >= activeTab.history.length - 1}
            className="p-1.5 hover:bg-white/10 rounded-lg disabled:opacity-30 disabled:hover:bg-transparent text-slate-200 transition-colors"
            title="Tiếp theo"
          >
            <ArrowRight size={16} />
          </button>
          <button
            onClick={handleReload}
            className="p-1.5 hover:bg-white/10 rounded-lg text-slate-200 transition-colors"
            title="Tải lại trang"
          >
            <RotateCw size={15} className={isIframeLoading ? 'animate-spin text-sky-400' : ''} />
          </button>
          <button
            onClick={() => handleNavigate('edge://newtab')}
            className="p-1.5 hover:bg-white/10 rounded-lg text-slate-200 transition-colors"
            title="Trang chủ"
          >
            <Home size={15} />
          </button>
        </div>

        {/* Address Input */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleNavigate(urlInput);
          }}
          className="flex-1 relative flex items-center"
        >
          <div className="absolute left-3 flex items-center gap-1.5 text-emerald-400 text-xs">
            <Lock size={12} />
          </div>
          <input
            type="text"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            placeholder="Tìm kiếm bằng Bing hoặc nhập địa chỉ web (VD: vnexpress.net, wikipedia.org, google.com...)"
            className="w-full bg-[#18181e] text-slate-100 placeholder-slate-400 text-xs pl-8 pr-20 py-1.5 rounded-full border border-white/15 focus:outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-500/30 transition-all font-sans"
          />
          <button
            type="submit"
            className="absolute right-2 px-2.5 py-0.5 bg-sky-600 hover:bg-sky-500 text-white rounded-full text-[11px] font-semibold transition-colors flex items-center gap-1"
          >
            <Search size={11} />
            <span>Đi tới</span>
          </button>
        </form>

        <div className="flex items-center gap-1 text-slate-300">
          <button
            onClick={() => addNotification('Bookmarks', `Đã lưu "${activeTab.title}" vào mục Yêu thích!`, 'edge')}
            className="p-1.5 hover:bg-white/10 rounded-lg transition-colors"
            title="Thêm vào danh sách yêu thích"
          >
            <Star size={16} />
          </button>
          {activeTab.liveUrl && (
            <a
              href={activeTab.liveUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-1.5 hover:bg-white/10 rounded-lg transition-colors text-sky-400"
              title="Mở trong cửa sổ trình duyệt mới"
            >
              <ExternalLink size={16} />
            </a>
          )}
        </div>
      </div>

      {/* Bookmarks Bar */}
      <div className="flex items-center gap-1.5 px-3 py-1 bg-[#1a1a22] border-b border-white/5 overflow-x-auto text-[11px]">
        {BOOKMARKS.map((bm, i) => (
          <button
            key={i}
            onClick={() => handleNavigate(bm.url)}
            className="flex items-center gap-1.5 px-2 py-1 rounded-md hover:bg-white/10 text-slate-300 hover:text-white transition-colors whitespace-nowrap"
          >
            <span>{bm.icon}</span>
            <span>{bm.name}</span>
          </button>
        ))}
      </div>

      {/* Main Viewport */}
      <div className="flex-1 bg-[#121217] overflow-y-auto relative">
        {/* VIEW 1: HOME PAGE */}
        {activeTab.contentView === 'home' && (
          <div className="flex flex-col items-center justify-center min-h-full p-6 text-center">
            {/* Microsoft Edge Logo and Header */}
            <div className="mb-6 flex flex-col items-center">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-sky-600 via-teal-500 to-indigo-600 flex items-center justify-center shadow-2xl mb-3">
                <Compass size={36} className="text-white" />
              </div>
              <h1 className="text-2xl font-bold text-white tracking-tight">Microsoft Edge</h1>
              <p className="text-xs text-slate-400 mt-1">Duyệt web an toàn, tìm kiếm thông tin và chạy ứng dụng HTML5 trực tiếp</p>
            </div>

            {/* Central Bing Search Bar */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (searchInputValue.trim()) {
                  handleNavigate(searchInputValue);
                }
              }}
              className="w-full max-w-xl mb-8 relative"
            >
              <div className="relative flex items-center">
                <Search size={18} className="absolute left-4 text-slate-400 pointer-events-none" />
                <input
                  type="text"
                  value={searchInputValue}
                  onChange={(e) => setSearchInputValue(e.target.value)}
                  placeholder="Tìm kiếm trên web hoặc nhập URL..."
                  className="w-full py-3.5 pl-12 pr-28 rounded-2xl bg-[#1e1e28] text-white placeholder-slate-400 text-sm border border-white/20 focus:outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-500/20 shadow-2xl transition-all"
                  autoFocus
                />
                <button
                  type="submit"
                  className="absolute right-2.5 px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-1.5"
                >
                  <Sparkles size={14} />
                  <span>Tìm kiếm</span>
                </button>
              </div>
            </form>

            {/* Quick Access Tiles */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-2xl w-full mb-8">
              {BOOKMARKS.map((bm, i) => (
                <div
                  key={i}
                  onClick={() => handleNavigate(bm.url)}
                  className="flex flex-col items-center justify-center p-3.5 bg-[#1f1f2a] hover:bg-[#282838] border border-white/10 rounded-2xl cursor-pointer transition-all hover:scale-105 shadow-md group"
                >
                  <span className="text-2xl mb-1.5">{bm.icon}</span>
                  <span className="text-xs font-medium text-slate-200 group-hover:text-sky-400 transition-colors">
                    {bm.name}
                  </span>
                </div>
              ))}
            </div>

            {/* Trending News / Quick Topics */}
            <div className="max-w-2xl w-full text-left">
              <div className="flex items-center gap-2 mb-3">
                <Sparkles size={16} className="text-sky-400" />
                <h3 className="text-sm font-semibold text-white">Tin tức nổi bật hôm nay</h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div
                  onClick={() => handleNavigate('https://en.wikipedia.org/wiki/Windows_11')}
                  className="p-3.5 bg-[#1c1c24] hover:bg-[#252530] border border-white/10 rounded-xl cursor-pointer transition-colors"
                >
                  <span className="text-[10px] text-sky-400 font-semibold uppercase tracking-wider">Công nghệ</span>
                  <h4 className="text-xs font-bold text-white mt-1">Khám phá tính năng mới trên Windows 11</h4>
                  <p className="text-[11px] text-slate-400 mt-1">Trải nghiệm Fluent Design, đa nhiệm snap layouts và bộ công cụ phục hồi WinRE.</p>
                </div>
                <div
                  onClick={() => handleNavigate('edge://apps')}
                  className="p-3.5 bg-[#1c1c24] hover:bg-[#252530] border border-white/10 rounded-xl cursor-pointer transition-colors"
                >
                  <span className="text-[10px] text-emerald-400 font-semibold uppercase tracking-wider">Ứng dụng</span>
                  <h4 className="text-xs font-bold text-white mt-1">Chạy ứng dụng HTML trực tiếp trong C:\Apps</h4>
                  <p className="text-[11px] text-slate-400 mt-1">Tải lên tệp HTML của riêng bạn để biến thành ứng dụng có biểu tượng độc lập.</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 2: LIVE WEB BROWSER / IFRAME NAVIGATION */}
        {(activeTab.contentView === 'web' || activeTab.contentView === 'search') && (
          <div className="w-full h-full flex flex-col relative">
            {/* Live Web Status Bar */}
            <div className="flex items-center justify-between px-3 py-1.5 bg-[#1a1a24] border-b border-white/10 text-xs">
              <div className="flex items-center gap-2 text-slate-300">
                <Shield size={13} className="text-emerald-400" />
                <span className="truncate max-w-md font-mono text-[11px]">{activeTab.liveUrl || activeTab.url}</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(activeTab.liveUrl || activeTab.url);
                    addNotification('Link Copied', 'Đã sao chép liên kết vào clipboard', 'edge');
                  }}
                  className="flex items-center gap-1 px-2 py-0.5 bg-white/10 hover:bg-white/20 rounded text-[11px] transition-colors"
                >
                  <Share2 size={11} />
                  <span>Sao chép Link</span>
                </button>
                {activeTab.liveUrl && (
                  <a
                    href={activeTab.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 px-2 py-0.5 bg-sky-600 hover:bg-sky-500 text-white rounded text-[11px] font-semibold transition-colors"
                  >
                    <ExternalLink size={11} />
                    <span>Mở ngoài tab mới</span>
                  </a>
                )}
              </div>
            </div>

            {/* Live iframe sandbox */}
            <iframe
              key={iframeKey}
              src={activeTab.liveUrl || (activeTab.url.startsWith('http') ? activeTab.url : undefined)}
              className="w-full flex-1 border-0 bg-white"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-downloads"
              onLoad={() => setIsIframeLoading(false)}
              title={activeTab.title}
            />
          </div>
        )}

        {/* VIEW 3: C:\Apps LOCAL DIRECTORY VIEW */}
        {activeTab.contentView === 'apps' && (
          <div className="p-6 max-w-4xl mx-auto space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-sky-600/20 text-sky-400 rounded-xl border border-sky-500/30">
                  <Folder size={24} />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">Thư viện ứng dụng HTML (C:\Apps)</h2>
                  <p className="text-xs text-slate-400">Các ứng dụng HTML5 được cài đặt sẵn và tự chạy trong Windows 11</p>
                </div>
              </div>
              <button
                onClick={() => openApp('store')}
                className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-semibold transition-colors"
              >
                Mở Microsoft Store
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {htmlApps.map((app) => (
                <div
                  key={app.id}
                  onClick={() =>
                    openApp('app-runner', {
                      filePath: app.path,
                      appName: app.appMetadata?.title || app.name,
                    })
                  }
                  className="p-4 bg-[#1f1f2a] hover:bg-[#282838] border border-white/10 rounded-2xl cursor-pointer transition-all hover:scale-[1.02] shadow-md flex items-start gap-3"
                >
                  <div className="p-2 bg-sky-500/10 text-sky-400 rounded-xl shrink-0">
                    <Code size={20} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h4 className="text-sm font-bold text-white truncate">{app.appMetadata?.title || app.name}</h4>
                    <p className="text-[11px] text-slate-400 line-clamp-2 mt-0.5">
                      {app.appMetadata?.description || 'Ứng dụng HTML5 tự chạy.'}
                    </p>
                    <span className="inline-block mt-2 text-[10px] text-emerald-400 font-mono">
                      {app.path}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* VIEW 4: GAMES VIEW */}
        {activeTab.contentView === 'games' && (
          <div className="p-6 max-w-4xl mx-auto space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-white/10">
              <div className="p-2.5 bg-purple-600/20 text-purple-400 rounded-xl border border-purple-500/30">
                <Gamepad2 size={24} />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">Kho trò chơi HTML5 Mini Games</h2>
                <p className="text-xs text-slate-400">Bấm vào bất kỳ trò chơi nào để bắt đầu ngay</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div
                onClick={() =>
                  openApp('app-runner', {
                    filePath: 'C:\\Apps\\FlappyBird.html',
                    appName: 'Flappy Bird Arcade',
                  })
                }
                className="p-4 bg-gradient-to-br from-amber-500/10 to-orange-500/5 hover:from-amber-500/20 hover:to-orange-500/10 border border-amber-500/20 rounded-2xl cursor-pointer transition-all flex items-center justify-between"
              >
                <div>
                  <h4 className="text-base font-bold text-amber-400">Flappy Bird Arcade</h4>
                  <p className="text-xs text-slate-300 mt-1">Trò chơi vượt chướng ngại vật tính điểm kinh điển.</p>
                </div>
                <span className="text-2xl">🐤</span>
              </div>

              <div
                onClick={() =>
                  openApp('app-runner', {
                    filePath: 'C:\\Apps\\2048.html',
                    appName: '2048 Cyber Edition',
                  })
                }
                className="p-4 bg-gradient-to-br from-blue-500/10 to-indigo-500/5 hover:from-blue-500/20 hover:to-indigo-500/10 border border-blue-500/20 rounded-2xl cursor-pointer transition-all flex items-center justify-between"
              >
                <div>
                  <h4 className="text-base font-bold text-sky-400">2048 Cyber Puzzle</h4>
                  <p className="text-xs text-slate-300 mt-1">Ghép các ô số đạt tới mốc 2048.</p>
                </div>
                <span className="text-2xl">🧩</span>
              </div>

              <div
                onClick={() =>
                  openApp('app-runner', {
                    filePath: 'C:\\Apps\\SpeedTyper.html',
                    appName: 'Speed Typer Pro',
                  })
                }
                className="p-4 bg-gradient-to-br from-emerald-500/10 to-teal-500/5 hover:from-emerald-500/20 hover:to-teal-500/10 border border-emerald-500/20 rounded-2xl cursor-pointer transition-all flex items-center justify-between"
              >
                <div>
                  <h4 className="text-base font-bold text-emerald-400">Speed Typer Pro</h4>
                  <p className="text-xs text-slate-300 mt-1">Kiểm tra tốc độ gõ phím WPM và độ chuẩn xác.</p>
                </div>
                <span className="text-2xl">⌨️</span>
              </div>

              <div
                onClick={() =>
                  openApp('app-runner', {
                    filePath: 'C:\\Apps\\MatrixRain.html',
                    appName: 'Matrix Rain Simulator',
                  })
                }
                className="p-4 bg-gradient-to-br from-green-500/10 to-emerald-500/5 hover:from-green-500/20 hover:to-emerald-500/10 border border-green-500/20 rounded-2xl cursor-pointer transition-all flex items-center justify-between"
              >
                <div>
                  <h4 className="text-base font-bold text-green-400">Matrix Rain Screensaver</h4>
                  <p className="text-xs text-slate-300 mt-1">Hiệu ứng mưa code kỹ thuật số tương tác.</p>
                </div>
                <span className="text-2xl">💻</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
