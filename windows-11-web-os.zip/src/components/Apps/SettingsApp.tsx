import React, { useState, useRef, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import { DEFAULT_WALLPAPERS } from '../../utils/fileSystem';
import { SUPPORTED_LANGUAGES, LanguageCode } from '../../utils/i18n';
import { loadLocalData, saveLocalData } from '../../utils/localPersistence';
import {
  Monitor,
  Palette,
  Volume2,
  HardDrive,
  Info,
  Layers,
  RotateCw,
  Check,
  Sparkles,
  LayoutGrid,
  Trash2,
  Sliders,
  ShieldCheck,
  Moon,
  Sun,
  Layout,
  Wrench,
  RotateCcw,
  Cpu,
  Languages,
  Globe,
  Clock,
  Keyboard,
  Plus,
  Upload,
  Image as ImageIcon,
  FolderOpen,
  X,
  Lock,
  Camera,
  CloudSun,
  Calendar,
  KeyRound,
  Eye,
  EyeOff,
  ArrowRight,
  Key,
  ShieldAlert,
  AlertTriangle,
  LogIn,
  CheckCircle2,
  HelpCircle,
} from 'lucide-react';

export const SPOTLIGHT_LOCK_WALLPAPERS = [
  {
    id: 'spotlight-halong',
    name: 'Vịnh Hạ Long, Việt Nam',
    url: 'https://images.unsplash.com/photo-1528127269322-539801943592?auto=format&fit=crop&w=1920&q=80',
  },
  {
    id: 'spotlight-dolomites',
    name: 'Dãy Alps Dolomites, Ý',
    url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1920&q=80',
  },
  {
    id: 'spotlight-beach',
    name: 'Hoàng hôn bờ biển nhiệt đới',
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1920&q=80',
  },
  {
    id: 'spotlight-nordic',
    name: 'Vịnh Fjord Na Uy tuyết phủ',
    url: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=1920&q=80',
  },
];

const ACCENT_COLORS = [
  '#0078d4', '#00b7c3', '#107c41', '#881798',
  '#e3008c', '#d83b01', '#ea4300', '#f7630c',
  '#6b69d6', '#038387', '#486860', '#525e54',
];

const AVAILABLE_REGIONS = [
  'Việt Nam',
  'United States',
  'Japan (日本)',
  'South Korea (대한민국)',
  'France (France)',
  'Germany (Deutschland)',
  'Taiwan (台灣)',
  'United Kingdom',
  'Canada',
  'Australia',
  'Singapore',
];

const AVAILABLE_KEYBOARDS = [
  'Tiếng Việt (Telex)',
  'Tiếng Việt (VNI)',
  'English (US - QWERTY)',
  '日本語 IME',
  '한국어 입력기',
  'Français (AZERTY)',
  'Deutsch (QWERTZ)',
  '繁體中文 (注音)',
];

interface SettingsAppProps {
  initialSection?:
    | 'personalization'
    | 'lockscreen'
    | 'system'
    | 'apps'
    | 'timeAndLanguage'
    | 'recovery'
    | 'update'
    | 'about';
}

export const SettingsApp: React.FC<SettingsAppProps> = ({ initialSection = 'personalization' }) => {
  const {
    settings,
    updateSettings,
    fileSystem,
    deleteFile,
    setIsAddAppModalOpen,
    addNotification,
    restartSystem,
    restartToWinRE,
    enterWinRE,
    triggerOOBESetup,
    setIsLockScreen,
    t,
    currentLang,
    setLanguage,
  } = useOS();

  const [activeSection, setActiveSection] = useState<
    'personalization' | 'lockscreen' | 'system' | 'apps' | 'timeAndLanguage' | 'recovery' | 'update' | 'about'
  >(initialSection);
  const [checkingUpdate, setCheckingUpdate] = useState(false);
  const [updateStatus, setUpdateStatus] = useState<string | null>(null);
  const [isDraggingOverWallpaper, setIsDraggingOverWallpaper] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const lockFileInputRef = useRef<HTMLInputElement>(null);
  const [lockPinInput, setLockPinInput] = useState(settings.lockPin || '1234');
  const [pinSavedFeedback, setPinSavedFeedback] = useState(false);
  const [showPinInSettings, setShowPinInSettings] = useState(false);

  // Security Auth Dialogs States (Windows 11 Authentic Experience)
  const [showPinModal, setShowPinModal] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinConfirmInput, setPinConfirmInput] = useState('');
  const [pinIncludeLetters, setPinIncludeLetters] = useState(false);
  const [pinError, setPinError] = useState<string | null>(null);
  const [showPinModalText, setShowPinModalText] = useState(false);

  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordConfirmInput, setPasswordConfirmInput] = useState('');
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [showPasswordModalText, setShowPasswordModalText] = useState(false);

  const [showRemoveConfirm, setShowRemoveConfirm] = useState(false);
  const [removeTargetType, setRemoveTargetType] = useState<'pin' | 'password'>('pin');

  const [customWallpapers, setCustomWallpapers] = useState<Array<{ id: string; name: string; url: string }>>(() => {
    try {
      const saved = localStorage.getItem('win11_custom_wallpapers');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Hydrate custom wallpapers from IndexedDB
  useEffect(() => {
    let active = true;
    loadLocalData<Array<{ id: string; name: string; url: string }>>('win11_custom_wallpapers').then((data) => {
      if (data && Array.isArray(data) && data.length > 0 && active) {
        setCustomWallpapers(data);
      }
    });
    return () => {
      active = false;
    };
  }, []);

  const processWallpaperFile = (file: File) => {
    if (!file || !file.type.startsWith('image/')) {
      addNotification(t.personalization, 'Vui lòng chọn một tệp hình ảnh hợp lệ (PNG, JPG, WebP, SVG, GIF)', 'system');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        const newWallpaperItem = {
          id: `custom-wp-${Date.now()}`,
          name: file.name.replace(/\.[^/.]+$/, ''),
          url: dataUrl,
        };

        const updated = [newWallpaperItem, ...customWallpapers.filter((w) => w.url !== dataUrl)].slice(0, 12);
        setCustomWallpapers(updated);
        saveLocalData('win11_custom_wallpapers', updated).catch(() => {});
        try {
          localStorage.setItem('win11_custom_wallpapers', JSON.stringify(updated));
        } catch (err) {
          // LocalStorage quota may be exceeded, but IndexedDB has saved it safely!
        }

        updateSettings({ wallpaper: dataUrl });
        addNotification(t.personalization, `${t.wallpaper}: "${file.name}"`, 'settings');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleWallpaperFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      processWallpaperFile(files[0]);
    }
    // reset input value so re-selecting same file triggers change
    if (e.target) {
      e.target.value = '';
    }
  };

  const processLockWallpaperFile = (file: File) => {
    if (!file || !file.type.startsWith('image/')) {
      addNotification('Màn hình khóa', 'Vui lòng chọn một tệp hình ảnh hợp lệ (PNG, JPG, WebP, SVG, GIF)', 'system');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        updateSettings({
          lockScreenWallpaper: dataUrl,
          lockScreenType: 'picture',
        });
        addNotification('Màn hình khóa', `Đã đổi hình nền màn hình khóa: "${file.name}"`, 'settings');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleLockWallpaperFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      processLockWallpaperFile(files[0]);
    }
    if (e.target) {
      e.target.value = '';
    }
  };

  const handleWallpaperDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOverWallpaper(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processWallpaperFile(e.dataTransfer.files[0]);
    }
  };

  const handleDeleteCustomWallpaper = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = customWallpapers.filter((w) => w.id !== id);
    setCustomWallpapers(updated);
    saveLocalData('win11_custom_wallpapers', updated).catch(() => {});
    try {
      localStorage.setItem('win11_custom_wallpapers', JSON.stringify(updated));
    } catch {}
  };

  const htmlApps = fileSystem.filter((f) => f.isHtmlApp);

  const handleCheckUpdates = () => {
    setCheckingUpdate(true);
    setUpdateStatus(null);
    setTimeout(() => {
      setCheckingUpdate(false);
      setUpdateStatus(`${t.upToDate}. ${t.lastChecked}: ${new Date().toLocaleTimeString(settings.language || 'vi')}`);
      addNotification(t.windowsUpdate, t.upToDate, 'settings');
    }, 1200);
  };

  const handleLanguageChange = (newCode: LanguageCode) => {
    const selected = SUPPORTED_LANGUAGES.find((l) => l.code === newCode);
    updateSettings({
      language: newCode,
      ...(selected ? { region: selected.region, keyboardLayout: selected.keyboard } : {}),
    });
    setLanguage(newCode);
    addNotification(
      t.settings,
      `${t.displayLanguage}: ${selected ? selected.nativeName : newCode}`,
      'settings'
    );
  };

  const currentDateFormatted = new Intl.DateTimeFormat(settings.language || 'vi', {
    dateStyle: 'full',
    timeStyle: 'medium',
  }).format(new Date());

  return (
    <div className="flex w-full h-full bg-slate-50 dark:bg-[#1a1a1a] text-slate-800 dark:text-slate-100 select-none overflow-hidden text-xs">
      {/* Settings Navigation Sidebar */}
      <div className="w-60 bg-white/70 dark:bg-[#202020]/70 border-r border-slate-200 dark:border-zinc-800 p-3 space-y-1 overflow-y-auto shrink-0">
        <div className="flex items-center gap-3 px-2 py-3 mb-2 border-b border-slate-200 dark:border-zinc-800">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-sky-500 to-indigo-600 text-white font-bold flex items-center justify-center text-sm uppercase shadow-sm">
            {(settings.userName || 'L').charAt(0)}
          </div>
          <div className="overflow-hidden">
            <div className="font-bold text-xs truncate">{settings.userName || 'lenamphuc'}</div>
            <div className="text-[10px] text-slate-400 truncate">{settings.userEmail || 'lenamphuc2013@gmail.com'}</div>
          </div>
        </div>

        <button
          onClick={() => setActiveSection('personalization')}
          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left font-medium transition-colors ${
            activeSection === 'personalization'
              ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 font-semibold'
              : 'hover:bg-slate-200 dark:hover:bg-zinc-800'
          }`}
        >
          <Palette size={16} />
          <span>{t.personalization}</span>
        </button>

        <button
          onClick={() => setActiveSection('lockscreen')}
          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left font-medium transition-colors ${
            activeSection === 'lockscreen'
              ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 font-semibold'
              : 'hover:bg-slate-200 dark:hover:bg-zinc-800'
          }`}
        >
          <Lock size={16} />
          <span>Màn hình khóa</span>
        </button>

        <button
          onClick={() => setActiveSection('system')}
          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left font-medium transition-colors ${
            activeSection === 'system'
              ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 font-semibold'
              : 'hover:bg-slate-200 dark:hover:bg-zinc-800'
          }`}
        >
          <Monitor size={16} />
          <span>{t.system}</span>
        </button>

        <button
          onClick={() => setActiveSection('apps')}
          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left font-medium transition-colors ${
            activeSection === 'apps'
              ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 font-semibold'
              : 'hover:bg-slate-200 dark:hover:bg-zinc-800'
          }`}
        >
          <LayoutGrid size={16} />
          <span className="truncate">{t.apps} ({htmlApps.length})</span>
        </button>

        {/* TIME & LANGUAGE (TIME & LANGUAGE SECTION) */}
        <button
          onClick={() => setActiveSection('timeAndLanguage')}
          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left font-medium transition-colors ${
            activeSection === 'timeAndLanguage'
              ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 font-semibold'
              : 'hover:bg-slate-200 dark:hover:bg-zinc-800'
          }`}
        >
          <Languages size={16} />
          <span className="truncate">{t.timeAndLanguage}</span>
        </button>

        <button
          onClick={() => setActiveSection('recovery')}
          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left font-medium transition-colors ${
            activeSection === 'recovery'
              ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 font-semibold'
              : 'hover:bg-slate-200 dark:hover:bg-zinc-800'
          }`}
        >
          <Wrench size={16} />
          <span>{t.recovery}</span>
        </button>

        <button
          onClick={() => setActiveSection('update')}
          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left font-medium transition-colors ${
            activeSection === 'update'
              ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 font-semibold'
              : 'hover:bg-slate-200 dark:hover:bg-zinc-800'
          }`}
        >
          <RotateCw size={16} />
          <span>{t.windowsUpdate}</span>
        </button>

        <button
          onClick={() => setActiveSection('about')}
          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left font-medium transition-colors ${
            activeSection === 'about'
              ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 font-semibold'
              : 'hover:bg-slate-200 dark:hover:bg-zinc-800'
          }`}
        >
          <Info size={16} />
          <span>{t.about}</span>
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 p-6 overflow-y-auto space-y-6">
        {/* PERSONALIZATION SECTION */}
        {activeSection === 'personalization' && (
          <div className="space-y-6 animate-win11-fade max-w-2xl">
            <div>
              <h2 className="text-xl font-bold tracking-tight">{t.personalization}</h2>
              <p className="text-slate-400 text-xs">{t.wallpaper}, {t.theme}, {t.accentColor}</p>
            </div>

            {/* Current Wallpaper Preview Hero & Drag Drop */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDraggingOverWallpaper(true);
              }}
              onDragLeave={() => setIsDraggingOverWallpaper(false)}
              onDrop={handleWallpaperDrop}
              className={`w-full h-44 rounded-2xl bg-cover bg-center shadow-lg border-2 transition-all relative overflow-hidden flex flex-col justify-between ${
                isDraggingOverWallpaper
                  ? 'border-sky-500 ring-4 ring-sky-500/30 scale-[1.01]'
                  : 'border-slate-300 dark:border-zinc-700'
              }`}
              style={{ backgroundImage: `url("${settings.wallpaper}")` }}
            >
              {isDraggingOverWallpaper && (
                <div className="absolute inset-0 bg-sky-600/70 backdrop-blur-sm flex flex-col items-center justify-center text-white z-20 animate-pulse">
                  <Upload size={36} className="mb-2" />
                  <span className="font-bold text-sm">{t.dropFilesHere}</span>
                </div>
              )}
              <div className="p-3 flex justify-end">
                <span className="px-3 py-1 bg-black/40 backdrop-blur-md rounded-full text-white text-[11px] font-semibold border border-white/20">
                  {settings.theme === 'dark' ? t.dark : t.light}
                </span>
              </div>
              <div className="bg-gradient-to-t from-black/80 via-black/40 to-transparent p-4 flex items-end justify-between">
                <div>
                  <span className="text-white font-bold text-sm block">{t.wallpaper}</span>
                  <span className="text-white/70 text-[11px]">Windows 11 Personalization</span>
                </div>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 bg-white/90 hover:bg-white text-slate-900 rounded-xl text-xs font-bold shadow-md transition-all active:scale-95"
                >
                  <Upload size={14} className="text-sky-600" />
                  <span>{t.browsePhotos}</span>
                </button>
              </div>
            </div>

            {/* Hidden File Input for Wallpaper Upload */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/png,image/jpeg,image/jpg,image/webp,image/gif,image/svg+xml"
              onChange={handleWallpaperFileInputChange}
              className="hidden"
            />

            {/* Upload Wallpaper Card */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDraggingOverWallpaper(true);
              }}
              onDragLeave={() => setIsDraggingOverWallpaper(false)}
              onDrop={handleWallpaperDrop}
              className="p-4 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 flex items-center justify-between gap-4"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-sky-500/10 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0">
                  <ImageIcon size={20} />
                </div>
                <div>
                  <div className="font-bold text-xs">{t.uploadWallpaper}</div>
                  <div className="text-slate-400 text-[11px]">
                    PNG, JPG, WEBP, SVG • Kéo thả hoặc duyệt ảnh từ máy tính
                  </div>
                </div>
              </div>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5 px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-xl text-xs font-semibold shadow-sm transition-all active:scale-95 shrink-0"
              >
                <FolderOpen size={14} />
                <span>{t.browsePhotos}</span>
              </button>
            </div>

            {/* Custom Uploaded Wallpapers Gallery (if any) */}
            {customWallpapers.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-xs">{t.customWallpapers}</label>
                  <span className="text-slate-400 text-[11px]">{customWallpapers.length} ảnh đã lưu</span>
                </div>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                  {customWallpapers.map((cwp) => (
                    <div
                      key={cwp.id}
                      onClick={() => updateSettings({ wallpaper: cwp.url })}
                      className={`group relative h-24 rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${
                        settings.wallpaper === cwp.url
                          ? 'border-sky-500 ring-2 ring-sky-500/30 scale-[1.02]'
                          : 'border-transparent hover:border-slate-400'
                      }`}
                    >
                      <img src={cwp.url} alt={cwp.name} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-between p-1.5 text-white">
                        <button
                          onClick={(e) => handleDeleteCustomWallpaper(cwp.id, e)}
                          title="Xóa hình nền này"
                          className="self-end p-1 rounded-md bg-red-500/80 hover:bg-red-600 text-white transition-colors"
                        >
                          <X size={12} />
                        </button>
                        <span className="text-[10px] font-semibold text-center truncate w-full px-1">
                          {cwp.name}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Theme Toggle (Dark / Light) */}
            <div className="p-4 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 flex items-center justify-between">
              <div>
                <div className="font-bold text-xs">{t.theme}</div>
                <div className="text-slate-400 text-[11px]">{t.dark} / {t.light}</div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => updateSettings({ theme: 'light' })}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-semibold transition-all ${
                    settings.theme === 'light'
                      ? 'bg-sky-500 text-white shadow'
                      : 'bg-slate-200 dark:bg-zinc-700'
                  }`}
                >
                  <Sun size={14} /> {t.light}
                </button>
                <button
                  onClick={() => updateSettings({ theme: 'dark' })}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-semibold transition-all ${
                    settings.theme === 'dark'
                      ? 'bg-sky-500 text-white shadow'
                      : 'bg-slate-200 dark:bg-zinc-700'
                  }`}
                >
                  <Moon size={14} /> {t.dark}
                </button>
              </div>
            </div>

            {/* Wallpapers Presets Grid */}
            <div className="space-y-2">
              <label className="font-bold text-xs">Windows 11 Themes & Presets</label>
              <div className="grid grid-cols-3 gap-3">
                {DEFAULT_WALLPAPERS.map((wp) => (
                  <div
                    key={wp.id}
                    onClick={() => updateSettings({ wallpaper: wp.url, theme: wp.theme })}
                    className={`group relative h-24 rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${
                      settings.wallpaper === wp.url
                        ? 'border-sky-500 ring-2 ring-sky-500/30 scale-[1.02]'
                        : 'border-transparent hover:border-slate-400'
                    }`}
                  >
                    <img src={wp.url} alt={wp.name} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-[11px] font-semibold text-center p-1">
                      {wp.name}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Accent Color Palette */}
            <div className="p-4 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 space-y-2">
              <div className="font-bold text-xs">{t.accentColor}</div>
              <div className="flex flex-wrap gap-2 pt-1">
                {ACCENT_COLORS.map((c) => (
                  <button
                    key={c}
                    onClick={() => updateSettings({ accentColor: c })}
                    className={`w-7 h-7 rounded-full transition-transform flex items-center justify-center ${
                      settings.accentColor === c ? 'scale-125 ring-2 ring-sky-400' : 'hover:scale-110'
                    }`}
                    style={{ backgroundColor: c }}
                  >
                    {settings.accentColor === c && <Check size={14} className="text-white drop-shadow" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Taskbar Alignment */}
            <div className="p-4 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 flex items-center justify-between">
              <div>
                <div className="font-bold text-xs">{t.taskbarAlignment}</div>
                <div className="text-slate-400 text-[11px]">{t.taskbarAlignmentDesc}</div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => updateSettings({ taskbarAlignment: 'center' })}
                  className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                    settings.taskbarAlignment === 'center'
                      ? 'bg-sky-500 text-white shadow'
                      : 'bg-slate-200 dark:bg-zinc-700'
                  }`}
                >
                  {t.center}
                </button>
                <button
                  onClick={() => updateSettings({ taskbarAlignment: 'left' })}
                  className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                    settings.taskbarAlignment === 'left'
                      ? 'bg-sky-500 text-white shadow'
                      : 'bg-slate-200 dark:bg-zinc-700'
                  }`}
                >
                  {t.left}
                </button>
              </div>
            </div>

            {/* Quick Link to Lock Screen Settings */}
            <div
              onClick={() => setActiveSection('lockscreen')}
              className="p-4 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 flex items-center justify-between gap-4 cursor-pointer hover:border-sky-500 hover:shadow-md transition-all group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                  <Lock size={20} />
                </div>
                <div>
                  <div className="font-bold text-xs group-hover:text-sky-500 transition-colors">
                    Màn hình khóa (Lock screen)
                  </div>
                  <div className="text-slate-400 text-[11px]">
                    Khởi động lại lên màn hình khóa như Windows gốc 100%, ảnh nền Spotlight, tiện ích thời tiết & mã PIN
                  </div>
                </div>
              </div>
              <ArrowRight size={16} className="text-slate-400 group-hover:text-sky-500 group-hover:translate-x-1 transition-all" />
            </div>
          </div>
        )}

        {/* LOCK SCREEN SECTION */}
        {activeSection === 'lockscreen' && (
          <div className="space-y-6 animate-win11-fade max-w-2xl">
            <input
              type="file"
              ref={lockFileInputRef}
              onChange={handleLockWallpaperFileInputChange}
              accept="image/*"
              className="hidden"
            />

            <div>
              <h2 className="text-xl font-bold tracking-tight">Màn hình khóa (Lock screen)</h2>
              <p className="text-slate-400 text-xs">
                Cá nhân hóa giao diện khóa, ảnh nền Tiêu điểm Windows, mã PIN đăng nhập và khởi động lại
              </p>
            </div>

            {/* Live Lock Screen Mockup Preview */}
            <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-zinc-700/60 shadow-lg group">
              <div
                className="w-full h-52 sm:h-64 bg-cover bg-center relative flex flex-col justify-between p-6 transition-all"
                style={{
                  backgroundImage: `url("${settings.lockScreenWallpaper || settings.wallpaper}")`,
                }}
              >
                {/* Subtle dark gradient overlay */}
                <div className="absolute inset-0 bg-black/25 backdrop-blur-[1px] pointer-events-none" />

                {/* Top preview tag */}
                <div className="relative z-10 flex items-center justify-between">
                  <span className="px-2.5 py-1 rounded-full bg-black/40 backdrop-blur-md text-white text-[10px] font-semibold border border-white/20">
                    Xem trước màn hình khóa thực tế
                  </span>
                  {settings.lockScreenType === 'spotlight' && (
                    <span className="px-2.5 py-1 rounded-full bg-black/40 backdrop-blur-md text-sky-300 text-[10px] font-semibold border border-white/20 flex items-center gap-1">
                      <Camera size={12} />
                      <span>Windows Spotlight</span>
                    </span>
                  )}
                </div>

                {/* Mock clock & widget */}
                <div className="relative z-10 text-white space-y-1">
                  <div className="text-4xl sm:text-5xl font-extralight tracking-tight drop-shadow-md">
                    10:42
                  </div>
                  <div className="text-xs font-normal text-white/90 drop-shadow">
                    Thứ Năm, 3 tháng 9
                  </div>
                  {settings.lockScreenStatusWidget !== 'none' && (
                    <div className="inline-flex items-center gap-2 mt-2 px-3 py-1.5 rounded-xl bg-black/30 backdrop-blur-md border border-white/15 text-[11px] text-white">
                      {settings.lockScreenStatusWidget === 'calendar' ? (
                        <>
                          <Calendar size={13} className="text-sky-400" />
                          <span>Hôm nay không có sự kiện nào</span>
                        </>
                      ) : (
                        <>
                          <CloudSun size={14} className="text-amber-300" />
                          <span>28°C Nắng nhẹ • Hà Nội</span>
                        </>
                      )}
                    </div>
                  )}
                </div>

                {/* Lock Test Button Overlay */}
                <div className="relative z-10 flex justify-end">
                  <button
                    onClick={() => setIsLockScreen(true)}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-white/90 hover:bg-white text-zinc-900 font-bold text-xs shadow-lg active:scale-95 transition-all"
                  >
                    <Lock size={14} />
                    <span>Khóa ngay (Win + L)</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Lock Screen Wallpaper Type Selection */}
            <div className="p-4 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-xs">Cá nhân hóa màn hình khóa của bạn</div>
                  <div className="text-slate-400 text-[11px]">
                    Chọn nguồn hình nền xuất hiện khi máy tính bị khóa hoặc khởi động
                  </div>
                </div>
              </div>

              {/* Selector pills */}
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() =>
                    updateSettings({
                      lockScreenType: 'spotlight',
                      lockScreenWallpaper: SPOTLIGHT_LOCK_WALLPAPERS[0].url,
                    })
                  }
                  className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all ${
                    settings.lockScreenType === 'spotlight'
                      ? 'bg-sky-500 text-white shadow-md'
                      : 'bg-slate-100 dark:bg-zinc-700/70 hover:bg-slate-200 dark:hover:bg-zinc-700'
                  }`}
                >
                  <Sparkles size={14} />
                  <span>Tiêu điểm của Windows (Spotlight)</span>
                </button>

                <button
                  onClick={() => updateSettings({ lockScreenType: 'picture' })}
                  className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all ${
                    settings.lockScreenType === 'picture'
                      ? 'bg-sky-500 text-white shadow-md'
                      : 'bg-slate-100 dark:bg-zinc-700/70 hover:bg-slate-200 dark:hover:bg-zinc-700'
                  }`}
                >
                  <ImageIcon size={14} />
                  <span>Hình ảnh (Picture)</span>
                </button>

                <button
                  onClick={() =>
                    updateSettings({
                      lockScreenType: 'desktop',
                      lockScreenWallpaper: settings.wallpaper,
                    })
                  }
                  className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all ${
                    settings.lockScreenType === 'desktop'
                      ? 'bg-sky-500 text-white shadow-md'
                      : 'bg-slate-100 dark:bg-zinc-700/70 hover:bg-slate-200 dark:hover:bg-zinc-700'
                  }`}
                >
                  <Monitor size={14} />
                  <span>Dùng chung hình nền Desktop</span>
                </button>
              </div>

              {/* Spotlight Preset Gallery */}
              {settings.lockScreenType === 'spotlight' && (
                <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-zinc-700/50">
                  <div className="text-[11px] font-semibold text-slate-500 dark:text-zinc-400">
                    Bộ sưu tập Tiêu điểm Windows Spotlight độ phân giải cao:
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {SPOTLIGHT_LOCK_WALLPAPERS.map((item) => (
                      <div
                        key={item.id}
                        onClick={() => updateSettings({ lockScreenWallpaper: item.url })}
                        className={`group relative h-20 rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${
                          settings.lockScreenWallpaper === item.url
                            ? 'border-sky-500 ring-2 ring-sky-500/30 scale-[1.02]'
                            : 'border-transparent hover:border-slate-400'
                        }`}
                      >
                        <img src={item.url} alt={item.name} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-1.5 text-white">
                          <span className="text-[9px] font-medium truncate drop-shadow">{item.name}</span>
                        </div>
                        {settings.lockScreenWallpaper === item.url && (
                          <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-sky-500 flex items-center justify-center shadow">
                            <Check size={12} className="text-white" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Picture Presets & Upload Button */}
              {settings.lockScreenType === 'picture' && (
                <div className="space-y-3 pt-2 border-t border-slate-100 dark:border-zinc-700/50">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-slate-500 dark:text-zinc-400">
                      Chọn ảnh hoặc tải lên ảnh từ máy tính của bạn:
                    </span>
                    <button
                      onClick={() => lockFileInputRef.current?.click()}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-500 hover:bg-sky-600 text-white rounded-xl text-xs font-semibold shadow-sm active:scale-95 transition-all"
                    >
                      <Upload size={13} />
                      <span>Duyệt ảnh từ máy</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {DEFAULT_WALLPAPERS.slice(0, 4).map((item) => (
                      <div
                        key={item.id}
                        onClick={() => updateSettings({ lockScreenWallpaper: item.url })}
                        className={`group relative h-20 rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${
                          settings.lockScreenWallpaper === item.url
                            ? 'border-sky-500 ring-2 ring-sky-500/30 scale-[1.02]'
                            : 'border-transparent hover:border-slate-400'
                        }`}
                      >
                        <img src={item.url} alt={item.name} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-1.5 text-white">
                          <span className="text-[9px] font-medium truncate drop-shadow">{item.name}</span>
                        </div>
                        {settings.lockScreenWallpaper === item.url && (
                          <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-sky-500 flex items-center justify-center shadow">
                            <Check size={12} className="text-white" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Lock Screen Status Widget */}
            <div className="p-4 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 space-y-3">
              <div>
                <div className="font-bold text-xs">Trạng thái màn hình khóa</div>
                <div className="text-slate-400 text-[11px]">
                  Chọn một ứng dụng để hiển thị thông tin trạng thái chi tiết trên màn hình khóa
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <button
                  onClick={() => updateSettings({ lockScreenStatusWidget: 'weather' })}
                  className={`p-3 rounded-xl border text-left flex flex-col gap-1.5 transition-all ${
                    settings.lockScreenStatusWidget === 'weather'
                      ? 'border-sky-500 bg-sky-500/10 ring-2 ring-sky-500/20'
                      : 'border-slate-200 dark:border-zinc-700 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <CloudSun size={18} className="text-amber-500" />
                    {settings.lockScreenStatusWidget === 'weather' && (
                      <Check size={14} className="text-sky-500" />
                    )}
                  </div>
                  <div className="font-bold text-xs">Thời tiết</div>
                  <div className="text-[10px] text-slate-400 leading-snug">
                    Nhiệt độ và dự báo thực tế
                  </div>
                </button>

                <button
                  onClick={() => updateSettings({ lockScreenStatusWidget: 'calendar' })}
                  className={`p-3 rounded-xl border text-left flex flex-col gap-1.5 transition-all ${
                    settings.lockScreenStatusWidget === 'calendar'
                      ? 'border-sky-500 bg-sky-500/10 ring-2 ring-sky-500/20'
                      : 'border-slate-200 dark:border-zinc-700 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <Calendar size={18} className="text-sky-500" />
                    {settings.lockScreenStatusWidget === 'calendar' && (
                      <Check size={14} className="text-sky-500" />
                    )}
                  </div>
                  <div className="font-bold text-xs">Lịch làm việc</div>
                  <div className="text-[10px] text-slate-400 leading-snug">
                    Sự kiện và lịch trình trong ngày
                  </div>
                </button>

                <button
                  onClick={() => updateSettings({ lockScreenStatusWidget: 'none' })}
                  className={`p-3 rounded-xl border text-left flex flex-col gap-1.5 transition-all ${
                    settings.lockScreenStatusWidget === 'none'
                      ? 'border-sky-500 bg-sky-500/10 ring-2 ring-sky-500/20'
                      : 'border-slate-200 dark:border-zinc-700 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <X size={18} className="text-slate-400" />
                    {settings.lockScreenStatusWidget === 'none' && (
                      <Check size={14} className="text-sky-500" />
                    )}
                  </div>
                  <div className="font-bold text-xs">Không có</div>
                  <div className="text-[10px] text-slate-400 leading-snug">
                    Chỉ hiển thị đồng hồ và ngày
                  </div>
                </button>
              </div>
            </div>

            {/* STARTUP & BOOT-TO-LOCK SCREEN (USER REQUEST: LIKE GENUINE WINDOWS 100%) */}
            <div className="p-5 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 space-y-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5 text-sky-600 dark:text-sky-400 font-bold text-sm">
                  <ShieldCheck size={18} />
                  <span>Bảo mật đăng nhập & Màn hình khóa (Windows 11 Chuẩn 100%)</span>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-sky-500/10 text-sky-600 dark:text-sky-400 text-[10px] font-bold border border-sky-500/20">
                  Windows 11 Sign-in Options
                </span>
              </div>

              {/* Status Banner: Explains whether Lock Screen triggers on boot */}
              {Boolean(settings.hasPin || settings.hasPassword) ? (
                <div className="p-4 bg-emerald-500/10 border border-emerald-500/25 rounded-2xl flex items-start gap-3.5 animate-win11-fade">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                    <ShieldCheck size={18} />
                  </div>
                  <div className="space-y-1 flex-1">
                    <div className="font-bold text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
                      <span>Đã thiết lập bảo mật màn hình khóa</span>
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 text-[10px] font-semibold">
                        Sẽ khóa khi khởi động
                      </span>
                    </div>
                    <p className="text-slate-600 dark:text-zinc-300 text-[11px] leading-relaxed">
                      Bạn đã đặt {settings.hasPin && settings.hasPassword ? 'mã PIN và Mật khẩu' : settings.hasPin ? 'mã PIN Windows Hello' : 'Mật khẩu'}. Khi bạn bật máy hoặc Khởi động lại (Restart), hệ thống sẽ hiển thị màn hình khóa yêu cầu xác thực trước khi vào Desktop.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-amber-500/10 border border-amber-500/25 rounded-2xl flex items-start gap-3.5 animate-win11-fade">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
                    <ShieldAlert size={18} />
                  </div>
                  <div className="space-y-1 flex-1">
                    <div className="font-bold text-xs text-amber-800 dark:text-amber-300 flex items-center gap-2">
                      <span>Chưa có mã PIN hoặc mật khẩu bảo vệ</span>
                      <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-800 dark:text-amber-300 text-[10px] font-semibold">
                        Tự động vào Desktop
                      </span>
                    </div>
                    <p className="text-slate-600 dark:text-zinc-300 text-[11px] leading-relaxed">
                      Vì bạn chưa đặt mã PIN hoặc mật khẩu, khi khởi động lại máy tính sẽ tự động đăng nhập và vào thẳng Desktop mà không dừng ở màn hình khóa (đúng chuẩn Windows 11). Hãy thiết lập mã PIN hoặc Mật khẩu bên dưới để kích hoạt màn hình khóa.
                    </p>
                    <div className="pt-2 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setPinInput('');
                          setPinConfirmInput('');
                          setPinError(null);
                          setShowPinModalText(false);
                          setShowPinModal(true);
                        }}
                        className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 active:scale-95 text-white rounded-xl text-xs font-semibold shadow transition-all cursor-pointer"
                      >
                        Thiết lập mã PIN ngay
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Windows 11 Sign-in Methods List */}
              <div className="space-y-3">
                <div className="text-[11px] font-bold text-slate-500 dark:text-zinc-400 uppercase tracking-wider">
                  Các phương thức đăng nhập
                </div>

                {/* PIN (Windows Hello) Row */}
                <div className="p-3.5 bg-slate-50 dark:bg-zinc-900/60 rounded-xl border border-slate-200 dark:border-zinc-800 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-sky-500/15 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0">
                      <KeyRound size={18} />
                    </div>
                    <div>
                      <div className="font-bold text-xs flex items-center gap-2">
                        <span>Mã PIN (Windows Hello)</span>
                        {settings.hasPin ? (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px] font-semibold">
                            Đã kích hoạt ({settings.lockPin ? '••••' : 'Chưa nhập'})
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-slate-200 dark:bg-zinc-700 text-slate-500 dark:text-zinc-400 text-[10px] font-semibold">
                            Chưa thiết lập
                          </span>
                        )}
                      </div>
                      <div className="text-slate-400 text-[11px]">
                        Đăng nhập an toàn và nhanh chóng bằng mã số cá nhân (Khuyên dùng)
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {settings.hasPin ? (
                      <>
                        <button
                          type="button"
                          onClick={() => {
                            setPinInput('');
                            setPinConfirmInput('');
                            setPinError(null);
                            setShowPinModalText(false);
                            setShowPinModal(true);
                          }}
                          className="px-3 py-1.5 bg-sky-500 hover:bg-sky-400 text-white rounded-xl text-xs font-semibold shadow active:scale-95 transition-all cursor-pointer"
                        >
                          Thay đổi mã PIN
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setRemoveTargetType('pin');
                            setShowRemoveConfirm(true);
                          }}
                          className="px-3 py-1.5 bg-slate-200 hover:bg-red-500 hover:text-white dark:bg-zinc-700 dark:hover:bg-red-600 text-slate-700 dark:text-zinc-200 rounded-xl text-xs font-semibold transition-all cursor-pointer"
                        >
                          Xóa
                        </button>
                      </>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setPinInput('');
                          setPinConfirmInput('');
                          setPinError(null);
                          setShowPinModalText(false);
                          setShowPinModal(true);
                        }}
                        className="px-4 py-1.5 bg-sky-500 hover:bg-sky-400 text-white rounded-xl text-xs font-semibold shadow active:scale-95 transition-all cursor-pointer"
                      >
                        Thiết lập
                      </button>
                    )}
                  </div>
                </div>

                {/* Password Row */}
                <div className="p-3.5 bg-slate-50 dark:bg-zinc-900/60 rounded-xl border border-slate-200 dark:border-zinc-800 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-purple-500/15 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                      <Key size={18} />
                    </div>
                    <div>
                      <div className="font-bold text-xs flex items-center gap-2">
                        <span>Mật khẩu tài khoản (Password)</span>
                        {settings.hasPassword ? (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px] font-semibold">
                            Đã thiết lập
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-slate-200 dark:bg-zinc-700 text-slate-500 dark:text-zinc-400 text-[10px] font-semibold">
                            Chưa thiết lập
                          </span>
                        )}
                      </div>
                      <div className="text-slate-400 text-[11px]">
                        Sử dụng mật khẩu máy tính truyền thống để đăng nhập
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {settings.hasPassword ? (
                      <>
                        <button
                          type="button"
                          onClick={() => {
                            setPasswordInput('');
                            setPasswordConfirmInput('');
                            setPasswordError(null);
                            setShowPasswordModalText(false);
                            setShowPasswordModal(true);
                          }}
                          className="px-3 py-1.5 bg-sky-500 hover:bg-sky-400 text-white rounded-xl text-xs font-semibold shadow active:scale-95 transition-all cursor-pointer"
                        >
                          Thay đổi
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setRemoveTargetType('password');
                            setShowRemoveConfirm(true);
                          }}
                          className="px-3 py-1.5 bg-slate-200 hover:bg-red-500 hover:text-white dark:bg-zinc-700 dark:hover:bg-red-600 text-slate-700 dark:text-zinc-200 rounded-xl text-xs font-semibold transition-all cursor-pointer"
                        >
                          Xóa
                        </button>
                      </>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setPasswordInput('');
                          setPasswordConfirmInput('');
                          setPasswordError(null);
                          setShowPasswordModalText(false);
                          setShowPasswordModal(true);
                        }}
                        className="px-4 py-1.5 bg-sky-500 hover:bg-sky-400 text-white rounded-xl text-xs font-semibold shadow active:scale-95 transition-all cursor-pointer"
                      >
                        Thêm
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Startup Rule Toggle */}
              <div className="flex items-start justify-between gap-4 p-3.5 bg-slate-50 dark:bg-zinc-900/60 rounded-xl border border-slate-200 dark:border-zinc-800">
                <div className="space-y-1">
                  <div className="font-bold text-xs flex items-center gap-2">
                    <span>Khởi động / Khởi động lại lên màn hình khóa</span>
                    <span className="px-2 py-0.5 rounded-full bg-sky-500/15 text-sky-600 dark:text-sky-400 text-[10px] font-bold">
                      Windows gốc 100%
                    </span>
                  </div>
                  <div className="text-slate-400 text-[11px] leading-relaxed">
                    Chỉ kích hoạt khi máy tính đã được đặt mã PIN hoặc Mật khẩu. Khi bật, việc bật máy hoặc Khởi động lại (Restart) sẽ dừng tại màn hình khóa trước khi vào Desktop.
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.requireLockOnStartup !== false}
                  disabled={!settings.hasPin && !settings.hasPassword}
                  onChange={(e) => {
                    updateSettings({ requireLockOnStartup: e.target.checked });
                    addNotification(
                      'Cài đặt khởi động',
                      e.target.checked
                        ? 'Đã BẬT: Khởi động lại sẽ luôn lên màn hình khóa như Windows gốc 100%.'
                        : 'Đã TẮT: Khởi động lại sẽ vào thẳng Desktop.',
                      'settings'
                    );
                  }}
                  className="w-5 h-5 accent-sky-500 cursor-pointer shrink-0 mt-1 disabled:opacity-40 disabled:cursor-not-allowed"
                />
              </div>

              {/* Show acrylic blur on sign in */}
              <div className="flex items-start justify-between gap-4 p-3.5 bg-slate-50 dark:bg-zinc-900/60 rounded-xl border border-slate-200 dark:border-zinc-800">
                <div className="space-y-1">
                  <div className="font-bold text-xs">Hiệu ứng mờ Acrylic trên màn hình đăng nhập</div>
                  <div className="text-slate-400 text-[11px]">
                    Làm mờ ảnh nền kính mờ kiểu Windows 11 Fluent Design khi chuyển sang khung nhập mã PIN hoặc mật khẩu.
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.showLockBackgroundOnSignIn !== false}
                  onChange={(e) => updateSettings({ showLockBackgroundOnSignIn: e.target.checked })}
                  className="w-5 h-5 accent-sky-500 cursor-pointer shrink-0 mt-1"
                />
              </div>

              {/* Quick Actions for Testing */}
              <div className="pt-2 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => setIsLockScreen(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white font-semibold text-xs rounded-xl shadow-md active:scale-95 transition-all cursor-pointer"
                >
                  <Lock size={14} />
                  <span>Khóa màn hình ngay (Win + L)</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    addNotification('Hệ thống', 'Đang khởi động lại hệ thống...', 'system');
                    restartSystem();
                  }}
                  className="flex items-center gap-2 px-4 py-2 bg-slate-200 dark:bg-zinc-700 hover:bg-slate-300 dark:hover:bg-zinc-600 font-semibold text-xs rounded-xl shadow active:scale-95 transition-all cursor-pointer"
                >
                  <RotateCcw size={14} />
                  <span>Khởi động lại thử nghiệm (Test Restart)</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* SYSTEM SECTION */}
        {activeSection === 'system' && (
          <div className="space-y-6 animate-win11-fade max-w-2xl">
            <div>
              <h2 className="text-xl font-bold tracking-tight">{t.system}</h2>
              <p className="text-slate-400 text-xs">{t.soundEffects}, {t.volume}, {t.brightness}</p>
            </div>

            {/* Sound Toggle & Volume */}
            <div className="p-4 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-xs">{t.soundEffects}</div>
                  <div className="text-slate-400 text-[11px]">{t.sound}</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.soundEnabled}
                  onChange={(e) => updateSettings({ soundEnabled: e.target.checked })}
                  className="w-5 h-5 accent-sky-500 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-500 text-[11px] mb-1 font-semibold">
                  <span>{t.systemVolume}</span>
                  <span>{settings.volume}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={settings.volume}
                  onChange={(e) => updateSettings({ volume: parseInt(e.target.value) })}
                  className="w-full accent-sky-500 cursor-pointer"
                />
              </div>
            </div>

            {/* Display Brightness */}
            <div className="p-4 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 space-y-2">
              <div className="flex justify-between text-slate-500 text-[11px] font-semibold">
                <span>{t.displayBrightness}</span>
                <span>{settings.brightness}%</span>
              </div>
              <input
                type="range"
                min="40"
                max="100"
                value={settings.brightness}
                onChange={(e) => updateSettings({ brightness: parseInt(e.target.value) })}
                className="w-full accent-sky-500 cursor-pointer"
              />
            </div>

            {/* Power & Boot Screen Actions */}
            <div className="p-4 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 flex items-center justify-between">
              <div>
                <div className="font-bold text-xs">{t.restart}</div>
                <div className="text-slate-400 text-[11px]">{t.gettingReady}</div>
              </div>
              <button
                onClick={restartSystem}
                className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 active:scale-95 text-white font-medium text-xs transition-all shadow-sm"
              >
                <RotateCw size={13} />
                <span>{t.restartNow}</span>
              </button>
            </div>
          </div>
        )}

        {/* INSTALLED APPS SECTION */}
        {activeSection === 'apps' && (
          <div className="space-y-6 animate-win11-fade max-w-2xl">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold tracking-tight">{t.installedHtmlApps}</h2>
                <p className="text-slate-400 text-xs">{t.installedHtmlAppsDesc}</p>
              </div>
              <button
                onClick={() => setIsAddAppModalOpen(true)}
                className="px-3.5 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl font-bold shadow-sm flex items-center gap-1.5"
              >
                <Sparkles size={14} /> {t.addNewHtmlApp}
              </button>
            </div>

            <div className="divide-y divide-slate-200 dark:divide-zinc-800 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 overflow-hidden">
              {htmlApps.length === 0 ? (
                <div className="p-6 text-center text-slate-400 text-xs">
                  {t.noNotifications}
                </div>
              ) : (
                htmlApps.map((app) => (
                  <div key={app.id} className="flex items-center justify-between p-3.5">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-600 dark:text-sky-400 flex items-center justify-center">
                        <LayoutGrid size={18} />
                      </div>
                      <div>
                        <div className="font-bold text-xs">{app.appMetadata?.title || app.name}</div>
                        <div className="text-[11px] text-slate-400 font-mono">{app.path}</div>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        if (confirm(`${t.delete} "${app.appMetadata?.title || app.name}"?`)) {
                          deleteFile(app.path);
                        }
                      }}
                      className="p-1.5 rounded-lg text-red-500 hover:bg-red-500/10 transition-colors"
                      title={t.uninstall}
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* TIME & LANGUAGE SECTION - FULLY IMPLEMENTED LOCALIZATION SWITCHER */}
        {activeSection === 'timeAndLanguage' && (
          <div className="space-y-6 animate-win11-fade max-w-2xl">
            <div>
              <h2 className="text-xl font-bold tracking-tight">{t.timeAndLanguage}</h2>
              <p className="text-slate-400 text-xs">{t.displayLanguage}, {t.countryOrRegion}, {t.keyboardLayout}</p>
            </div>

            {/* Current Display Language Selector */}
            <div className="p-5 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-sky-500/15 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0">
                  <Languages size={22} />
                </div>
                <div>
                  <div className="font-bold text-sm">{t.displayLanguage}</div>
                  <div className="text-slate-400 text-xs">
                    {t.chooseLanguage} - Windows sẽ lập tức chuyển đổi toàn bộ giao diện sang ngôn ngữ đã chọn
                  </div>
                </div>
              </div>

              {/* Language Selection Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
                {SUPPORTED_LANGUAGES.map((lang) => {
                  const isSelected = (settings.language || 'vi') === lang.code;
                  return (
                    <button
                      key={lang.code}
                      onClick={() => handleLanguageChange(lang.code)}
                      className={`flex items-center justify-between p-3 rounded-xl border text-left transition-all ${
                        isSelected
                          ? 'border-sky-500 bg-sky-500/10 shadow-sm ring-1 ring-sky-500'
                          : 'border-slate-200 dark:border-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-700/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-2xl leading-none">{lang.flag}</span>
                        <div>
                          <div className="font-bold text-xs text-slate-800 dark:text-white">
                            {lang.nativeName}
                          </div>
                          <div className="text-[10px] text-slate-400">{lang.name}</div>
                        </div>
                      </div>
                      {isSelected && <Check size={16} className="text-sky-500 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Country or Region Selector */}
            <div className="p-5 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                  <Globe size={20} />
                </div>
                <div>
                  <div className="font-bold text-xs">{t.countryOrRegion}</div>
                  <div className="text-slate-400 text-[11px]">Định dạng vị trí, múi giờ và nội dung khu vực</div>
                </div>
              </div>

              <select
                value={settings.region || 'Việt Nam'}
                onChange={(e) => updateSettings({ region: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-zinc-900 border border-slate-300 dark:border-zinc-700 text-xs font-semibold outline-none focus:ring-2 focus:ring-sky-500"
              >
                {AVAILABLE_REGIONS.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>

            {/* Keyboard Layout Selector */}
            <div className="p-5 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                  <Keyboard size={20} />
                </div>
                <div>
                  <div className="font-bold text-xs">{t.keyboardLayout}</div>
                  <div className="text-slate-400 text-[11px]">Phương thức nhập ký tự và bộ gõ</div>
                </div>
              </div>

              <select
                value={settings.keyboardLayout || 'Tiếng Việt (Telex)'}
                onChange={(e) => updateSettings({ keyboardLayout: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-zinc-900 border border-slate-300 dark:border-zinc-700 text-xs font-semibold outline-none focus:ring-2 focus:ring-sky-500"
              >
                {AVAILABLE_KEYBOARDS.map((kb) => (
                  <option key={kb} value={kb}>
                    {kb}
                  </option>
                ))}
              </select>
            </div>

            {/* Live Date & Time Preview */}
            <div className="p-5 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-purple-500/15 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                  <Clock size={20} />
                </div>
                <div>
                  <div className="font-bold text-xs">{t.dateAndTime}</div>
                  <div className="text-slate-400 text-[11px]">{t.currentFormat}</div>
                </div>
              </div>

              <div className="p-3 bg-slate-100 dark:bg-zinc-900 rounded-xl border border-slate-200 dark:border-zinc-800 flex items-center justify-between">
                <span className="text-slate-500 dark:text-slate-400 font-medium text-xs">{t.dateAndTime}:</span>
                <span className="font-bold text-xs text-sky-600 dark:text-sky-400 font-mono">
                  {currentDateFormatted}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* RECOVERY & ADVANCED STARTUP SECTION */}
        {activeSection === 'recovery' && (
          <div className="space-y-6 animate-win11-fade max-w-2xl">
            <div>
              <h2 className="text-xl font-bold tracking-tight">{t.recoveryOptions}</h2>
              <p className="text-slate-400 text-xs">{t.recoveryDesc}</p>
            </div>

            {/* Re-run OOBE First-Time Setup Card */}
            <div className="p-5 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 flex items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="font-bold text-sm flex items-center gap-2">
                  <Sparkles size={16} className="text-cyan-500" />
                  <span>Out-of-Box Experience ({t.runOOBESetup})</span>
                </div>
                <div className="text-slate-400 text-xs leading-relaxed">
                  {t.oobeReadyDesc}
                </div>
              </div>
              <button
                onClick={triggerOOBESetup}
                className="px-4 py-2 bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 active:scale-95 text-white rounded-xl font-semibold text-xs transition-all shrink-0 shadow-sm"
              >
                {t.runOOBESetup}
              </button>
            </div>

            {/* Reset This PC Card */}
            <div className="p-5 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 flex items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="font-bold text-sm flex items-center gap-2">
                  <RotateCcw size={16} className="text-sky-500" />
                  <span>{t.resetThisPC}</span>
                </div>
                <div className="text-slate-400 text-xs leading-relaxed">
                  {t.recoveryDesc}
                </div>
              </div>
              <button
                onClick={() => enterWinRE('reset-option')}
                className="px-4 py-2 bg-sky-600 hover:bg-sky-500 active:scale-95 text-white rounded-xl font-semibold text-xs transition-all shrink-0 shadow-sm"
              >
                {t.resetThisPC}
              </button>
            </div>

            {/* Advanced Startup / WinRE Card */}
            <div className="p-5 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 flex items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="font-bold text-sm flex items-center gap-2">
                  <Sparkles size={16} className="text-sky-500" />
                  <span>{t.advancedStartup}</span>
                </div>
                <div className="text-slate-400 text-xs leading-relaxed">
                  {t.advancedStartupDesc}
                </div>
              </div>
              <button
                onClick={restartToWinRE}
                className="px-4 py-2 bg-slate-200 dark:bg-zinc-700 hover:bg-slate-300 dark:hover:bg-zinc-600 active:scale-95 text-slate-800 dark:text-white rounded-xl font-semibold text-xs transition-all shrink-0 shadow-sm"
              >
                {t.restartNow}
              </button>
            </div>

            {/* Quick Access to Tools */}
            <div className="p-4 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 space-y-3">
              <div className="font-bold text-xs text-sky-500 uppercase tracking-wider">{t.quickRecoveryTools}</div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => enterWinRE('startup-repair')}
                  className="p-3 rounded-xl bg-slate-100 dark:bg-zinc-900/60 hover:bg-sky-500/10 text-left transition-colors border border-slate-200 dark:border-zinc-800"
                >
                  <div className="font-semibold text-xs text-sky-600 dark:text-sky-400">{t.startupRepair}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">{t.recoveryDesc}</div>
                </button>
                <button
                  onClick={() => enterWinRE('command-prompt')}
                  className="p-3 rounded-xl bg-slate-100 dark:bg-zinc-900/60 hover:bg-sky-500/10 text-left transition-colors border border-slate-200 dark:border-zinc-800"
                >
                  <div className="font-semibold text-xs text-sky-600 dark:text-sky-400">{t.commandPrompt}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">sfc, chkdsk, diskpart...</div>
                </button>
                <button
                  onClick={() => enterWinRE('system-restore')}
                  className="p-3 rounded-xl bg-slate-100 dark:bg-zinc-900/60 hover:bg-sky-500/10 text-left transition-colors border border-slate-200 dark:border-zinc-800"
                >
                  <div className="font-semibold text-xs text-sky-600 dark:text-sky-400">{t.systemRestore}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">{t.recoveryDesc}</div>
                </button>
                <button
                  onClick={() => enterWinRE('uefi-settings')}
                  className="p-3 rounded-xl bg-slate-100 dark:bg-zinc-900/60 hover:bg-sky-500/10 text-left transition-colors border border-slate-200 dark:border-zinc-800"
                >
                  <div className="font-semibold text-xs text-sky-600 dark:text-sky-400">{t.uefiFirmware}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">BIOS / Secure Boot</div>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* WINDOWS UPDATE SECTION */}
        {activeSection === 'update' && (
          <div className="space-y-6 animate-win11-fade max-w-2xl">
            <div className="flex items-center justify-between p-6 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-emerald-500/20 text-emerald-500 rounded-2xl">
                  <ShieldCheck size={28} />
                </div>
                <div>
                  <h3 className="font-bold text-base">{t.upToDate}</h3>
                  <p className="text-slate-400 text-xs mt-0.5">
                    {updateStatus || `${t.lastChecked}: ${new Date().toLocaleTimeString(settings.language || 'vi')}`}
                  </p>
                </div>
              </div>

              <button
                onClick={handleCheckUpdates}
                disabled={checkingUpdate}
                className="px-4 py-2 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white rounded-xl font-bold shadow-sm flex items-center gap-2"
              >
                <RotateCw size={14} className={checkingUpdate ? 'animate-spin' : ''} />
                <span>{checkingUpdate ? t.checkingUpdates : t.checkUpdates}</span>
              </button>
            </div>
          </div>
        )}

        {/* ABOUT SECTION */}
        {activeSection === 'about' && (
          <div className="space-y-6 animate-win11-fade max-w-2xl">
            <div>
              <h2 className="text-xl font-bold tracking-tight">{t.about}</h2>
              <p className="text-slate-400 text-xs">{t.deviceSpecifications} &amp; {t.windowsSpecifications}</p>
            </div>

            {/* Device Specifications Card */}
            <div className="p-4 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 space-y-3">
              <div className="font-bold text-xs text-sky-500">{t.deviceSpecifications}</div>
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <span className="text-slate-400">{t.deviceName}:</span>
                <span className="font-semibold font-mono text-sky-600 dark:text-sky-400">{settings.deviceName || 'LAPTOP-LENAMPHUC'}</span>
                <span className="text-slate-400">Manufacturer:</span>
                <span className="font-semibold text-emerald-600 dark:text-emerald-400">lenamphuc Systems</span>
                <span className="text-slate-400">{t.processor}:</span>
                <span className="font-semibold">Intel® Core™ i9-14900HX @ 5.80 GHz</span>
                <span className="text-slate-400">{t.installedRam}:</span>
                <span className="font-semibold">32.0 GB (31.8 GB usable) DDR5-6000</span>
                <span className="text-slate-400">{t.systemStorage}:</span>
                <span className="font-semibold">NVMe 1.0 TB SSD (Samsung 990 PRO)</span>
                <span className="text-slate-400">{t.countryOrRegion}:</span>
                <span className="font-semibold">{settings.region || 'Việt Nam'}</span>
                <span className="text-slate-400">{t.keyboardLayout}:</span>
                <span className="font-semibold">{settings.keyboardLayout || 'Tiếng Việt (Telex)'}</span>
                <span className="text-slate-400">{t.language}:</span>
                <span className="font-semibold">
                  {SUPPORTED_LANGUAGES.find((l) => l.code === (settings.language || 'vi'))?.nativeName || settings.language}
                </span>
              </div>
            </div>

            {/* Windows Specifications Card */}
            <div className="p-4 bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200 dark:border-zinc-700/60 space-y-3">
              <div className="font-bold text-xs text-sky-500">{t.windowsSpecifications}</div>
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <span className="text-slate-400">{t.edition}:</span>
                <span className="font-semibold">Windows 11 Pro Web OS</span>
                <span className="text-slate-400">{t.version}:</span>
                <span className="font-semibold">23H2 (Build 22631.3296)</span>
                <span className="text-slate-400">Runtime Engine:</span>
                <span className="font-semibold">React 19 + TypeScript + Vite + Tailwind</span>
                <span className="text-slate-400">App Sandbox:</span>
                <span className="font-semibold">Isolated HTML5 Executable Iframe</span>
                <span className="text-slate-400">{t.appsFolder}:</span>
                <span className="font-semibold">C:\Apps</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ===================================================================== */}
      {/* AUTH MODAL 1: WINDOWS HELLO PIN SETUP DIALOG                         */}
      {/* ===================================================================== */}
      {showPinModal && (
        <div
          onClick={() => setShowPinModal(false)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-700 rounded-2xl shadow-2xl p-6 text-slate-800 dark:text-zinc-100 space-y-4 animate-win11-fade"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-sky-500/15 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0">
                <KeyRound size={22} />
              </div>
              <div>
                <h3 className="font-bold text-sm">
                  {settings.hasPin ? 'Thay đổi mã PIN (Windows Hello)' : 'Thiết lập mã PIN (Windows Hello)'}
                </h3>
                <p className="text-[11px] text-slate-400">
                  Tạo mã PIN để bảo vệ máy tính và đăng nhập vào Windows 11
                </p>
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-600 dark:text-zinc-300">
                  Mã PIN mới
                </label>
                <div className="relative">
                  <input
                    type={showPinModalText ? 'text' : 'password'}
                    value={pinInput}
                    onChange={(e) => {
                      setPinInput(e.target.value);
                      if (pinError) setPinError(null);
                    }}
                    placeholder="Nhập mã PIN (tối thiểu 4 ký tự)"
                    className="w-full px-3 py-2 pr-10 bg-slate-50 dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 rounded-xl text-xs focus:outline-none focus:border-sky-500 font-mono"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => setShowPinModalText(!showPinModalText)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200"
                  >
                    {showPinModalText ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-600 dark:text-zinc-300">
                  Xác nhận mã PIN
                </label>
                <input
                  type={showPinModalText ? 'text' : 'password'}
                  value={pinConfirmInput}
                  onChange={(e) => {
                    setPinConfirmInput(e.target.value);
                    if (pinError) setPinError(null);
                  }}
                  placeholder="Nhập lại mã PIN để xác nhận"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 rounded-xl text-xs focus:outline-none focus:border-sky-500 font-mono"
                />
              </div>

              <label className="flex items-center gap-2 pt-1 text-[11px] text-slate-600 dark:text-zinc-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={pinIncludeLetters}
                  onChange={(e) => setPinIncludeLetters(e.target.checked)}
                  className="w-4 h-4 accent-sky-500 rounded cursor-pointer"
                />
                <span>Bao gồm chữ cái và ký hiệu</span>
              </label>

              {pinError && (
                <div className="flex items-center gap-1.5 text-xs text-red-500 font-medium pt-1 animate-win11-fade">
                  <AlertTriangle size={14} className="shrink-0" />
                  <span>{pinError}</span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-200 dark:border-zinc-800">
              <button
                type="button"
                onClick={() => setShowPinModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-zinc-300 hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors"
              >
                Hủy
              </button>
              <button
                type="button"
                onClick={() => {
                  const trimmed = pinInput.trim();
                  if (!trimmed) {
                    setPinError('Vui lòng nhập mã PIN.');
                    return;
                  }
                  if (trimmed.length < 4) {
                    setPinError('Mã PIN phải có tối thiểu 4 ký tự.');
                    return;
                  }
                  if (trimmed !== pinConfirmInput.trim()) {
                    setPinError('Mã PIN xác nhận không khớp.');
                    return;
                  }
                  updateSettings({
                    hasPin: true,
                    lockPin: trimmed,
                    requireLockPin: true,
                    requireLockOnStartup: true,
                    hasLockScreen: true,
                  });
                  setLockPinInput(trimmed);
                  setShowPinModal(false);
                  addNotification(
                    'Bảo mật Windows Hello',
                    'Đã thiết lập mã PIN thành công! Khi khởi động lại, màn hình khóa sẽ xuất hiện.',
                    'settings'
                  );
                }}
                className="px-5 py-2 rounded-xl text-xs font-semibold bg-sky-500 hover:bg-sky-400 text-white shadow-md active:scale-95 transition-all cursor-pointer"
              >
                OK (Lưu mã PIN)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* AUTH MODAL 2: PASSWORD SETUP DIALOG                                  */}
      {/* ===================================================================== */}
      {showPasswordModal && (
        <div
          onClick={() => setShowPasswordModal(false)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-700 rounded-2xl shadow-2xl p-6 text-slate-800 dark:text-zinc-100 space-y-4 animate-win11-fade"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/15 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                <Key size={22} />
              </div>
              <div>
                <h3 className="font-bold text-sm">
                  {settings.hasPassword ? 'Thay đổi mật khẩu tài khoản' : 'Tạo mật khẩu mới cho tài khoản'}
                </h3>
                <p className="text-[11px] text-slate-400">
                  Mật khẩu bảo vệ máy tính khi đăng nhập hoặc khóa màn hình
                </p>
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-600 dark:text-zinc-300">
                  Mật khẩu mới
                </label>
                <div className="relative">
                  <input
                    type={showPasswordModalText ? 'text' : 'password'}
                    value={passwordInput}
                    onChange={(e) => {
                      setPasswordInput(e.target.value);
                      if (passwordError) setPasswordError(null);
                    }}
                    placeholder="Nhập mật khẩu mới"
                    className="w-full px-3 py-2 pr-10 bg-slate-50 dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 rounded-xl text-xs focus:outline-none focus:border-sky-500"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => setShowPasswordModalText(!showPasswordModalText)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200"
                  >
                    {showPasswordModalText ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-600 dark:text-zinc-300">
                  Xác nhận mật khẩu
                </label>
                <input
                  type={showPasswordModalText ? 'text' : 'password'}
                  value={passwordConfirmInput}
                  onChange={(e) => {
                    setPasswordConfirmInput(e.target.value);
                    if (passwordError) setPasswordError(null);
                  }}
                  placeholder="Nhập lại mật khẩu để xác nhận"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 rounded-xl text-xs focus:outline-none focus:border-sky-500"
                />
              </div>

              {passwordError && (
                <div className="flex items-center gap-1.5 text-xs text-red-500 font-medium pt-1 animate-win11-fade">
                  <AlertTriangle size={14} className="shrink-0" />
                  <span>{passwordError}</span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-200 dark:border-zinc-800">
              <button
                type="button"
                onClick={() => setShowPasswordModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-zinc-300 hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors"
              >
                Hủy
              </button>
              <button
                type="button"
                onClick={() => {
                  const trimmed = passwordInput.trim();
                  if (!trimmed) {
                    setPasswordError('Vui lòng nhập mật khẩu.');
                    return;
                  }
                  if (trimmed !== passwordConfirmInput.trim()) {
                    setPasswordError('Mật khẩu xác nhận không khớp.');
                    return;
                  }
                  updateSettings({
                    hasPassword: true,
                    password: trimmed,
                    passwordHint: '',
                    requireLockOnStartup: true,
                    hasLockScreen: true,
                  });
                  setShowPasswordModal(false);
                  addNotification(
                    'Bảo mật tài khoản',
                    'Đã thiết lập mật khẩu thành công! Khi khởi động lại, màn hình khóa sẽ xuất hiện.',
                    'settings'
                  );
                }}
                className="px-5 py-2 rounded-xl text-xs font-semibold bg-sky-500 hover:bg-sky-400 text-white shadow-md active:scale-95 transition-all cursor-pointer"
              >
                Hoàn tất
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* AUTH MODAL 3: REMOVE AUTH CONFIRMATION                                */}
      {/* ===================================================================== */}
      {showRemoveConfirm && (
        <div
          onClick={() => setShowRemoveConfirm(false)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-700 rounded-2xl shadow-2xl p-6 text-slate-800 dark:text-zinc-100 space-y-4 animate-win11-fade"
          >
            <div className="flex items-center gap-3 text-red-500">
              <div className="w-10 h-10 rounded-xl bg-red-500/15 flex items-center justify-center shrink-0">
                <AlertTriangle size={22} />
              </div>
              <div>
                <h3 className="font-bold text-sm">
                  {removeTargetType === 'pin' ? 'Gỡ bỏ mã PIN?' : 'Gỡ bỏ mật khẩu?'}
                </h3>
                <p className="text-[11px] text-slate-400">
                  Xác nhận xóa bảo mật tài khoản
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-zinc-300 leading-relaxed">
              {removeTargetType === 'pin'
                ? 'Bạn có chắc chắn muốn xóa mã PIN không? Nếu không có mật khẩu khác, máy tính sẽ không hiển thị màn hình khóa khi khởi động lại mà sẽ vào thẳng Desktop như Windows 11 gốc.'
                : 'Bạn có chắc chắn muốn xóa mật khẩu không? Nếu không có mã PIN khác, máy tính sẽ tự động vào thẳng Desktop khi khởi động lại.'}
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200 dark:border-zinc-800">
              <button
                type="button"
                onClick={() => setShowRemoveConfirm(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-zinc-300 hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors"
              >
                Hủy
              </button>
              <button
                type="button"
                onClick={() => {
                  if (removeTargetType === 'pin') {
                    const willHaveNoAuth = !settings.hasPassword;
                    updateSettings({
                      hasPin: false,
                      lockPin: '',
                      requireLockPin: false,
                      ...(willHaveNoAuth ? { hasLockScreen: false, requireLockOnStartup: false } : {}),
                    });
                    addNotification(
                      'Bảo mật mã PIN',
                      willHaveNoAuth
                        ? 'Đã gỡ bỏ mã PIN. Khởi động lại sẽ tự động vào thẳng Desktop.'
                        : 'Đã gỡ bỏ mã PIN.',
                      'settings'
                    );
                  } else {
                    const willHaveNoAuth = !settings.hasPin;
                    updateSettings({
                      hasPassword: false,
                      password: '',
                      passwordHint: '',
                      ...(willHaveNoAuth ? { hasLockScreen: false, requireLockOnStartup: false } : {}),
                    });
                    addNotification(
                      'Bảo mật mật khẩu',
                      willHaveNoAuth
                        ? 'Đã gỡ bỏ mật khẩu. Khởi động lại sẽ tự động vào thẳng Desktop.'
                        : 'Đã gỡ bỏ mật khẩu.',
                      'settings'
                    );
                  }
                  setShowRemoveConfirm(false);
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-red-500 hover:bg-red-600 text-white shadow-md active:scale-95 transition-all cursor-pointer"
              >
                Xác nhận gỡ bỏ
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
