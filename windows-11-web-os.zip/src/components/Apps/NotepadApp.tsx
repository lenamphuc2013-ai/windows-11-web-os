import React, { useState, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import {
  FileText,
  Save,
  Download,
  Plus,
  Settings2,
  Check,
} from 'lucide-react';

interface NotepadAppProps {
  filePath?: string;
  fileName?: string;
  content?: string;
}

export const NotepadApp: React.FC<NotepadAppProps> = ({
  filePath,
  fileName = 'Untitled.txt',
  content = '',
}) => {
  const { fileSystem, addFile, updateFileContent, addNotification } = useOS();

  const [text, setText] = useState(content);
  const [currentPath, setCurrentPath] = useState(filePath);
  const [currentName, setCurrentName] = useState(fileName);
  const [isWordWrap, setIsWordWrap] = useState(true);
  const [fontSize, setFontSize] = useState(13);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [cursorPos, setCursorPos] = useState({ line: 1, col: 1 });

  // Sync if file content was loaded
  useEffect(() => {
    if (filePath) {
      const f = fileSystem.find((item) => item.path === filePath);
      if (f && f.content !== undefined) {
        setText(f.content);
        setCurrentName(f.name);
      }
    }
  }, [filePath, fileSystem]);

  const handleSave = () => {
    if (currentPath) {
      updateFileContent(currentPath, text);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2000);
      addNotification('File Saved', `Saved changes to ${currentName}`, 'notepad');
    } else {
      // Prompt user for save path
      const name = prompt('Nhập tên tệp tin để lưu:', currentName);
      if (!name) return;
      const targetPath = `C:\\Users\\User\\Documents\\${name}`;
      addFile({
        name,
        path: targetPath,
        isDirectory: false,
        content: text,
        size: text.length,
        icon: 'FileText',
      });
      setCurrentPath(targetPath);
      setCurrentName(name);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2000);
      addNotification('File Created', `Saved to ${targetPath}`, 'notepad');
    }
  };

  const handleDownload = () => {
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = currentName || 'document.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
    const sel = e.target.selectionStart;
    const lines = e.target.value.substring(0, sel).split('\n');
    setCursorPos({
      line: lines.length,
      col: lines[lines.length - 1].length + 1,
    });
  };

  return (
    <div className="flex flex-col w-full h-full bg-white dark:bg-[#1f1f1f] text-slate-800 dark:text-slate-100 select-none overflow-hidden text-xs">
      {/* Menu Bar */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-slate-100 dark:bg-[#272727] border-b border-slate-200 dark:border-zinc-800">
        <div className="flex items-center gap-1">
          <button
            onClick={() => {
              setText('');
              setCurrentPath(undefined);
              setCurrentName('Untitled.txt');
            }}
            className="px-2 py-1 rounded hover:bg-slate-200 dark:hover:bg-zinc-700 transition-colors"
          >
            File mới
          </button>
          <button
            onClick={handleSave}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-sky-600 hover:bg-sky-500 text-white font-semibold transition-colors"
          >
            {savedSuccess ? <Check size={13} /> : <Save size={13} />}
            <span>{savedSuccess ? 'Đã lưu' : 'Lưu'}</span>
          </button>
          <button
            onClick={handleDownload}
            className="flex items-center gap-1 px-2 py-1 rounded hover:bg-slate-200 dark:hover:bg-zinc-700 transition-colors"
          >
            <Download size={13} />
            <span>Tải .txt</span>
          </button>
          <button
            onClick={() => setIsWordWrap(!isWordWrap)}
            className={`px-2 py-1 rounded transition-colors ${
              isWordWrap ? 'bg-slate-200 dark:bg-zinc-700 font-medium' : 'hover:bg-slate-200 dark:hover:bg-zinc-700'
            }`}
          >
            Tự xuống dòng
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setFontSize((f) => Math.max(10, f - 1))}
            className="px-2 py-0.5 rounded bg-slate-200 dark:bg-zinc-700 hover:bg-slate-300 font-mono"
          >
            A-
          </button>
          <span className="font-mono text-[11px] text-slate-500">{fontSize}px</span>
          <button
            onClick={() => setFontSize((f) => Math.min(24, f + 1))}
            className="px-2 py-0.5 rounded bg-slate-200 dark:bg-zinc-700 hover:bg-slate-300 font-mono"
          >
            A+
          </button>
        </div>
      </div>

      {/* Editor Area */}
      <textarea
        value={text}
        onChange={handleTextChange}
        style={{ fontSize: `${fontSize}px` }}
        wrap={isWordWrap ? 'soft' : 'off'}
        spellCheck={false}
        className="flex-1 p-4 bg-transparent outline-none border-none resize-none font-mono text-slate-800 dark:text-slate-100 select-text leading-relaxed selection:bg-sky-500/30"
        placeholder="Gõ nội dung văn bản tại đây..."
      />

      {/* Status Bar */}
      <div className="flex items-center justify-between px-4 py-1 bg-slate-100 dark:bg-[#272727] border-t border-slate-200 dark:border-zinc-800 text-[11px] text-slate-500 dark:text-zinc-400 font-mono">
        <div className="flex items-center gap-4">
          <span>
            Ln {cursorPos.line}, Col {cursorPos.col}
          </span>
          <span>{text.length} ký tự</span>
        </div>
        <div className="flex items-center gap-4">
          <span>Windows (CRLF)</span>
          <span>UTF-8</span>
        </div>
      </div>
    </div>
  );
};
