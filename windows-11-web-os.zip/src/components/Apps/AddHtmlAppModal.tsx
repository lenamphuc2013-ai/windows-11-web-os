import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { IconRenderer } from '../Common/IconRenderer';
import {
  Upload,
  Sparkles,
  Code,
  FileCode,
  X,
  Play,
  Check,
  Gamepad2,
  Clock,
  Palette,
  Calculator,
  Compass,
  FileText,
  Activity,
  Layers,
} from 'lucide-react';

const PRESET_ICONS = [
  'Gamepad2',
  'LayoutGrid',
  'Code',
  'Sparkles',
  'Terminal',
  'Clock',
  'Palette',
  'Calculator',
  'Compass',
  'FileText',
  'Activity',
  'Globe',
  'Zap',
  'Rocket',
  'Heart',
  'Star',
  'Cpu',
  'Music',
  'Camera',
  'Box',
];

const TEMPLATE_APPS = [
  {
    name: 'Neon Counter',
    icon: 'Activity',
    category: 'utilities',
    code: `<!DOCTYPE html>
<html>
<head>
  <style>
    body { background: #0f172a; color: white; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; font-family: sans-serif; }
    h1 { font-size: 80px; color: #38bdf8; margin: 20px 0; text-shadow: 0 0 20px #38bdf8; }
    .btn-group { display: flex; gap: 12px; }
    button { padding: 12px 28px; font-size: 20px; font-weight: bold; border-radius: 10px; border: none; cursor: pointer; transition: 0.2s; }
    .inc { background: #38bdf8; color: #0f172a; }
    .dec { background: #ef4444; color: white; }
    .res { background: #334155; color: white; }
    button:hover { transform: scale(1.08); }
  </style>
</head>
<body>
  <h2>⚡ Neon Cyber Clicker</h2>
  <h1 id="count">0</h1>
  <div class="btn-group">
    <button class="dec" onclick="add(-1)">-1</button>
    <button class="res" onclick="set(0)">Reset</button>
    <button class="inc" onclick="add(1)">+1</button>
  </div>
  <script>
    let val = 0;
    function add(n) { val += n; document.getElementById('count').innerText = val; }
    function set(n) { val = n; document.getElementById('count').innerText = val; }
  </script>
</body>
</html>`,
  },
  {
    name: 'Color Palette Studio',
    icon: 'Palette',
    category: 'entertainment',
    code: `<!DOCTYPE html>
<html>
<head>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; font-family: system-ui, sans-serif; }
    body { background: #111; color: #eee; padding: 24px; text-align: center; }
    h2 { margin-bottom: 16px; color: #a855f7; }
    .palette { display: flex; height: 260px; border-radius: 16px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
    .color-block { flex: 1; display: flex; flex-direction: column; justify-content: flex-end; padding: 16px; font-weight: 700; font-family: monospace; cursor: pointer; transition: 0.2s; }
    .color-block:hover { flex: 1.4; }
    button { margin-top: 20px; padding: 12px 28px; background: #a855f7; color: white; border: none; border-radius: 8px; font-size: 16px; font-weight: bold; cursor: pointer; }
    button:hover { background: #9333ea; }
  </style>
</head>
<body>
  <h2>🎨 Live Palette Generator</h2>
  <div class="palette" id="box"></div>
  <button onclick="generate()">Generate New Palette (Space)</button>
  <script>
    function randomHex() { return '#' + Math.floor(Math.random()*16777215).toString(16).padStart(6, '0'); }
    function generate() {
      const box = document.getElementById('box');
      box.innerHTML = '';
      for(let i=0; i<5; i++) {
        const hex = randomHex();
        const d = document.createElement('div');
        d.className = 'color-block';
        d.style.backgroundColor = hex;
        d.innerText = hex.toUpperCase();
        d.onclick = () => { navigator.clipboard.writeText(hex); alert('Copied ' + hex); };
        box.appendChild(d);
      }
    }
    window.addEventListener('keydown', e => { if (e.code === 'Space') generate(); });
    generate();
  </script>
</body>
</html>`,
  },
];

export const AddHtmlAppModal: React.FC = () => {
  const { isAddAppModalOpen, setIsAddAppModalOpen, createHtmlApp, openApp } = useOS();

  const [title, setTitle] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('Gamepad2');
  const [category, setCategory] = useState('entertainment');
  const [htmlCode, setHtmlCode] = useState('');
  const [activeTab, setActiveTab] = useState<'upload' | 'code' | 'template'>('upload');
  const [dragOver, setDragOver] = useState(false);

  if (!isAddAppModalOpen) return null;

  const handleFileRead = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      setHtmlCode(content);

      // Auto-extract title from <title> tag
      const match = content.match(/<title>([^<]+)<\/title>/i);
      if (match && match[1]) {
        setTitle(match[1].trim());
      } else {
        const cleanName = file.name.replace(/\.html?$/i, '');
        setTitle(cleanName);
      }
      setActiveTab('code');
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileRead(e.dataTransfer.files[0]);
    }
  };

  const handleSubmit = (launchNow = true) => {
    if (!title.trim()) {
      alert('Vui lòng nhập tên ứng dụng!');
      return;
    }
    if (!htmlCode.trim()) {
      alert('Vui lòng cung cấp mã nguồn HTML!');
      return;
    }

    const newApp = createHtmlApp(title, selectedIcon, htmlCode, category);
    setIsAddAppModalOpen(false);

    if (launchNow) {
      openApp('app-runner', {
        filePath: newApp.path,
        appName: title,
        icon: selectedIcon,
      });
    }

    // Reset form
    setTitle('');
    setHtmlCode('');
  };

  return (
    <div
      id="add-html-app-modal-backdrop"
      className="fixed inset-0 z-[9990] flex items-center justify-center bg-black/60 backdrop-blur-md p-4 animate-win11-fade select-none"
      onClick={() => setIsAddAppModalOpen(false)}
    >
      <div
        id="add-html-app-modal-window"
        className="w-full max-w-2xl bg-white dark:bg-[#202020] text-slate-800 dark:text-slate-100 rounded-2xl shadow-2xl border border-white/20 dark:border-white/10 overflow-hidden flex flex-col max-h-[90vh] animate-win11-flyin"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-zinc-800 bg-slate-50/50 dark:bg-zinc-900/50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-sky-500/15 text-sky-600 dark:text-sky-400">
              <FileCode size={22} />
            </div>
            <div>
              <h2 className="text-base font-bold">Thêm / Tạo Ứng Dụng HTML Mới</h2>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Thêm trực tiếp vào thư mục C:\Apps & Desktop, bấm vào chạy ngay!
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsAddAppModalOpen(false)}
            className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-700 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex px-6 pt-3 border-b border-slate-200 dark:border-zinc-800 gap-4 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('upload')}
            className={`pb-2.5 border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'upload'
                ? 'border-sky-500 text-sky-600 dark:text-sky-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Upload size={14} />
            <span>Tải lên file .HTML</span>
          </button>

          <button
            onClick={() => setActiveTab('code')}
            className={`pb-2.5 border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'code'
                ? 'border-sky-500 text-sky-600 dark:text-sky-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Code size={14} />
            <span>Soạn thảo mã HTML</span>
          </button>

          <button
            onClick={() => setActiveTab('template')}
            className={`pb-2.5 border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'template'
                ? 'border-sky-500 text-sky-600 dark:text-sky-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Sparkles size={14} />
            <span>Chọn mẫu sẵn</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1 text-xs">
          {/* App Metadata Form */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-zinc-400 mb-1">
                Tên Ứng Dụng
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ví dụ: My Awesome Game"
                className="w-full px-3 py-2 bg-slate-100 dark:bg-zinc-800 rounded-lg border border-slate-300 dark:border-zinc-700 focus:outline-none focus:border-sky-500 text-xs font-medium"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-zinc-400 mb-1">
                Danh Mục
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 bg-slate-100 dark:bg-zinc-800 rounded-lg border border-slate-300 dark:border-zinc-700 focus:outline-none focus:border-sky-500 text-xs font-medium"
              >
                <option value="entertainment">Game & Giải trí</option>
                <option value="productivity">Công việc & Năng suất</option>
                <option value="utilities">Tiện ích hệ thống</option>
                <option value="custom">Tùy chỉnh cá nhân</option>
              </select>
            </div>
          </div>

          {/* Icon Selector Grid */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 dark:text-zinc-400 mb-1.5">
              Chọn Biểu Tượng (Icon)
            </label>
            <div className="flex flex-wrap gap-2 p-2 bg-slate-100/70 dark:bg-zinc-800/60 rounded-xl border border-slate-200 dark:border-zinc-700/60 max-h-24 overflow-y-auto">
              {PRESET_ICONS.map((iconName) => (
                <button
                  key={iconName}
                  type="button"
                  onClick={() => setSelectedIcon(iconName)}
                  className={`p-2 rounded-lg transition-all flex items-center justify-center ${
                    selectedIcon === iconName
                      ? 'bg-sky-500 text-white shadow-md scale-105'
                      : 'hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-600 dark:text-zinc-300'
                  }`}
                  title={iconName}
                >
                  <IconRenderer name={iconName} size={16} />
                </button>
              ))}
            </div>
          </div>

          {/* Tab 1: Upload File Drag & Drop */}
          {activeTab === 'upload' && (
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center transition-all ${
                dragOver
                  ? 'border-sky-500 bg-sky-500/10 scale-[1.01]'
                  : 'border-slate-300 dark:border-zinc-700 hover:border-slate-400 dark:hover:border-zinc-600'
              }`}
            >
              <div className="p-4 rounded-full bg-sky-500/10 text-sky-600 dark:text-sky-400 mb-3">
                <Upload size={32} />
              </div>
              <p className="font-semibold text-sm mb-1">Kéo thả file .html của bạn vào đây</p>
              <p className="text-slate-500 dark:text-zinc-400 text-xs mb-4">
                Hỗ trợ đầy đủ HTML5, CSS3, JavaScript, WebGL, Canvas
              </p>
              <label className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xl font-medium cursor-pointer transition-colors shadow-sm inline-flex items-center gap-2">
                <FileCode size={16} />
                <span>Chọn File HTML Từ Máy</span>
                <input
                  type="file"
                  accept=".html,.htm"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleFileRead(e.target.files[0]);
                    }
                  }}
                />
              </label>
            </div>
          )}

          {/* Tab 2: Code Editor */}
          {activeTab === 'code' && (
            <div className="space-y-1.5">
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-zinc-400">
                Mã Nguồn HTML (Tự động kèm CSS và JS)
              </label>
              <textarea
                value={htmlCode}
                onChange={(e) => setHtmlCode(e.target.value)}
                placeholder="<!DOCTYPE html>
<html>
<head>
  <style> body { background: #000; color: #fff; } </style>
</head>
<body>
  <h1>Hello Windows 11!</h1>
</body>
</html>"
                className="w-full h-44 p-3 bg-slate-900 text-slate-200 font-mono text-xs rounded-xl border border-slate-700 focus:outline-none focus:border-sky-500 resize-none"
                spellCheck={false}
              />
            </div>
          )}

          {/* Tab 3: Template Apps */}
          {activeTab === 'template' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {TEMPLATE_APPS.map((tpl, i) => (
                <div
                  key={i}
                  onClick={() => {
                    setTitle(tpl.name);
                    setSelectedIcon(tpl.icon);
                    setCategory(tpl.category);
                    setHtmlCode(tpl.code);
                    setActiveTab('code');
                  }}
                  className="p-4 rounded-xl border border-slate-200 dark:border-zinc-700/70 hover:border-sky-500 hover:bg-sky-500/5 cursor-pointer transition-all flex items-start gap-3"
                >
                  <div className="p-2.5 rounded-lg bg-sky-500/10 text-sky-600 dark:text-sky-400">
                    <IconRenderer name={tpl.icon} size={20} />
                  </div>
                  <div>
                    <div className="font-bold text-xs">{tpl.name}</div>
                    <div className="text-[11px] text-slate-500 dark:text-zinc-400 mt-0.5">
                      Bấm để chọn mẫu và thử nghiệm ngay
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-200 dark:border-zinc-800 bg-slate-50/50 dark:bg-zinc-900/50">
          <button
            type="button"
            onClick={() => setIsAddAppModalOpen(false)}
            className="px-4 py-2 rounded-xl text-xs font-semibold hover:bg-slate-200 dark:hover:bg-zinc-800 transition-colors"
          >
            Hủy
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleSubmit(false)}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-200 dark:bg-zinc-800 hover:bg-slate-300 dark:hover:bg-zinc-700 transition-colors"
            >
              Lưu vào C:\Apps
            </button>

            <button
              type="button"
              onClick={() => handleSubmit(true)}
              className="px-5 py-2 rounded-xl text-xs font-bold bg-sky-600 hover:bg-sky-500 text-white transition-all shadow-md flex items-center gap-1.5"
            >
              <Play size={14} />
              <span>Lưu & Chạy Ngay</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
