import React, { useState } from 'react';
import {
  Gamepad2,
  Trophy,
  Flame,
  Zap,
  Activity,
  HardDrive,
  Users,
  Play,
  Volume2,
  Tv,
  Camera,
  Cpu,
  Monitor,
} from 'lucide-react';
import { useOS } from '../../context/OSContext';

interface XboxGame {
  id: string;
  title: string;
  genre: string;
  gradient: string;
  accentColor: string;
  achievements: string;
  installed: boolean;
  gameModeSupported: boolean;
}

export const XboxApp: React.FC = () => {
  const { addNotification } = useOS();
  const [selectedGameId, setSelectedGameId] = useState('forza');
  const [gameModeActive, setGameModeActive] = useState(true);
  const [fpsOverlay, setFpsOverlay] = useState(true);
  const [hdrEnabled, setHdrEnabled] = useState(true);

  const games: XboxGame[] = [
    {
      id: 'forza',
      title: 'Forza Horizon 5',
      genre: 'Racing / Open World',
      gradient: 'from-amber-600 via-orange-800 to-stone-950',
      accentColor: '#f59e0b',
      achievements: '48 / 60 Unlocked',
      installed: true,
      gameModeSupported: true,
    },
    {
      id: 'halo',
      title: 'Halo Infinite',
      genre: 'First-Person Shooter',
      gradient: 'from-emerald-700 via-teal-900 to-slate-950',
      accentColor: '#10b981',
      achievements: '32 / 50 Unlocked',
      installed: true,
      gameModeSupported: true,
    },
    {
      id: 'flight',
      title: 'Microsoft Flight Simulator',
      genre: 'Simulation',
      gradient: 'from-sky-600 via-indigo-900 to-slate-950',
      accentColor: '#38bdf8',
      achievements: '20 / 45 Unlocked',
      installed: true,
      gameModeSupported: true,
    },
    {
      id: 'minecraft',
      title: 'Minecraft',
      genre: 'Sandbox / Survival',
      gradient: 'from-lime-600 via-emerald-900 to-zinc-950',
      accentColor: '#84cc16',
      achievements: '85 / 110 Unlocked',
      installed: true,
      gameModeSupported: true,
    },
  ];

  const currentGame = games.find((g) => g.id === selectedGameId) || games[0];

  const handleLaunchGame = (gameTitle: string) => {
    addNotification('Xbox Game Bar', `Starting ${gameTitle} with Game Mode & DirectStorage prioritized!`, 'xbox');
  };

  return (
    <div className="flex h-full bg-[#101014] text-slate-100 select-none overflow-hidden font-sans">
      {/* Left Xbox Green Navigation */}
      <div className="w-56 bg-[#16161c] p-3 border-r border-white/5 flex flex-col justify-between">
        <div className="space-y-4">
          <div className="flex items-center gap-2.5 px-3 py-2 text-emerald-400 font-bold text-sm">
            <Gamepad2 size={22} /> Xbox
          </div>

          <div className="space-y-1">
            <button className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Flame size={16} /> Game Pass
            </button>
            <button className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-white/5">
              <Trophy size={16} /> Achievements
            </button>
            <button className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-white/5">
              <Users size={16} /> Friends & Party
            </button>
          </div>

          {/* Installed Games List */}
          <div>
            <div className="px-3 py-1 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              Installed Games
            </div>
            <div className="space-y-1 mt-1">
              {games.map((g) => (
                <button
                  key={g.id}
                  onClick={() => setSelectedGameId(g.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    selectedGameId === g.id
                      ? 'bg-white/15 text-white'
                      : 'hover:bg-white/5 text-slate-400'
                  }`}
                >
                  <div className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span className="truncate">{g.title}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Live System Performance HUD Preview */}
        <div className="p-3 bg-black/40 rounded-2xl border border-white/5 space-y-2">
          <div className="flex items-center justify-between text-[11px] font-bold text-slate-400">
            <span className="flex items-center gap-1">
              <Activity size={12} className="text-emerald-400" /> Game Bar HUD
            </span>
            <span className="text-emerald-400 font-mono">144 FPS</span>
          </div>
          <div className="text-[10px] text-slate-400 space-y-1">
            <div className="flex justify-between">
              <span>GPU (RTX 4080):</span>
              <span className="text-white font-mono">54% • 58°C</span>
            </div>
            <div className="flex justify-between">
              <span>CPU:</span>
              <span className="text-white font-mono">24% • 4.8 GHz</span>
            </div>
            <div className="flex justify-between">
              <span>DirectStorage:</span>
              <span className="text-emerald-400 font-bold">Active (0.4s load)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-y-auto">
        {/* Big Game Hero Banner */}
        <div className={`relative h-64 w-full overflow-hidden bg-gradient-to-br ${currentGame.gradient} flex items-center justify-center p-8`}>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(255,255,255,0.15),transparent)] pointer-events-none" />
          <div className="absolute top-6 right-8 opacity-20 text-white">
            <Gamepad2 size={120} />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-[#101014] via-[#101014]/40 to-transparent" />

          {/* Hero text */}
          <div className="absolute bottom-6 left-8 space-y-2">
            <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold rounded-full uppercase">
              {currentGame.genre}
            </span>
            <h1 className="text-3xl font-extrabold text-white">{currentGame.title}</h1>
            <div className="flex items-center gap-4 text-xs text-slate-300">
              <span className="flex items-center gap-1">
                <Trophy size={14} className="text-amber-400" /> {currentGame.achievements}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1 text-emerald-400">
                <Zap size={14} /> Auto HDR & DirectX 12 Ultimate
              </span>
            </div>
          </div>

          {/* Launch Big Play Button */}
          <button
            onClick={() => handleLaunchGame(currentGame.title)}
            className="absolute bottom-6 right-8 px-8 py-3 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm rounded-2xl flex items-center gap-2 shadow-2xl shadow-emerald-500/30 active:scale-95 transition-all"
          >
            <Play size={18} fill="currentColor" /> Play Now
          </button>
        </div>

        {/* Windows 11 Gaming Features & Optimizations */}
        <div className="p-8 space-y-6">
          <h3 className="text-base font-bold text-slate-200">Windows 11 Gaming Performance Optimizations</h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex items-start gap-3">
              <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl">
                <Cpu size={20} />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold">Game Mode</h4>
                  <input
                    type="checkbox"
                    checked={gameModeActive}
                    onChange={() => setGameModeActive(!gameModeActive)}
                    className="accent-emerald-500 cursor-pointer"
                  />
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Prevents background updates and optimizes CPU & GPU threads for higher frame rates.
                </p>
              </div>
            </div>

            <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex items-start gap-3">
              <div className="p-2.5 bg-sky-500/10 text-sky-400 rounded-xl">
                <Monitor size={20} />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold">Auto HDR</h4>
                  <input
                    type="checkbox"
                    checked={hdrEnabled}
                    onChange={() => setHdrEnabled(!hdrEnabled)}
                    className="accent-emerald-500 cursor-pointer"
                  />
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Expands color range and contrast for stunning visual clarity.
                </p>
              </div>
            </div>

            <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex items-start gap-3">
              <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl">
                <HardDrive size={20} />
              </div>
              <div className="flex-1">
                <h4 className="text-xs font-bold">DirectStorage</h4>
                <p className="text-[11px] text-slate-400 mt-1">
                  Loads game assets directly from NVMe SSD to GPU memory without CPU bottlenecks.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
