import React, { useState, useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import { CheckCircle2, Save, HelpCircle, Monitor, Cpu, Volume2, Gamepad2, Info } from 'lucide-react';

interface DxDiagDialogProps {
  windowId?: string;
}

export function generateDxDiagReportText(): string {
  const now = new Date();
  return `------------------
System Information
------------------
      Time of this report: ${now.toLocaleString('vi-VN')}
             Machine name: DESKTOP-WIN11-OS
               Machine Id: {B4F298C1-729A-4E38-B590-E58390FA8211}
         Operating System: Windows 11 Pro 64-bit (10.0, Build 22631) (22631.ni_release.220506-1250)
                 Language: Vietnamese (Regional Setting: Vietnamese)
      System Manufacturer: Micro-Star International Co., Ltd.
             System Model: MS-7D70 (Custom Gaming / Workstation)
                     BIOS: 1.A0 (type: UEFI)
                Processor: AMD Ryzen 9 7950X 16-Core Processor (32 CPUs), ~4.5GHz
                   Memory: 32768MB RAM (32 GB DDR5 6000MHz)
      Available OS Memory: 32680MB RAM
                Page File: 4892MB used, 32100MB available
              Windows Dir: C:\\Windows
          DirectX Version: DirectX 12 Ultimate (FL 12_2)
      DX Setup Parameters: Not found
         User DPI Setting: 96 DPI (100 percent)
       System DPI Setting: 96 DPI (100 percent)
          DWM DPI Scaling: Disabled
                 Miracast: Available, with HDCP
Microsoft Graphics Hybrid: Not Supported
 DirectX Database Version: 1.5.8
           DxDiag Version: 10.00.22631.3296 64bit Unicode

------------
DxDiag Notes
------------
      Display Tab 1: No problems found.
      Display Tab 2: No problems found.
        Sound Tab 1: No problems found.
        Input Tab: No problems found.

--------------------
DirectX Debug Levels
--------------------
Direct3D:    0/4 (retail)
DirectDraw:  0/4 (retail)
DirectInput: 0/5 (retail)
DirectMusic: 0/5 (retail)
DirectPlay:  0/9 (retail)
DirectSound: 0/5 (retail)
DirectShow:  0/6 (retail)

---------------
Display Devices
---------------
           Card name: NVIDIA GeForce RTX 4090
        Manufacturer: NVIDIA
           Chip type: NVIDIA GeForce RTX 4090 (AD102)
            DAC type: Integrated RAMDAC
         Device Type: Full Display Device (1)
          Device Key: Enum\\PCI\\VEN_10DE&DEV_2684&SUBSYS_51121462&REV_A1
       Device Status: 0180200A [DN_DRIVER_LOADED|DN_STARTED|DN_DISABLEABLE|DN_NT_ENUMERATOR|DN_NT_DRIVER] 
 Device Problem Code: No Problem
 Driver Problem Code: Unknown
      Display Memory: 40924 MB
    Dedicated Memory: 24576 MB GDDR6X
       Shared Memory: 16348 MB
        Current Mode: 2560 x 1440 (32 bit) (165Hz)
         HDR Support: Supported (1000 nits Peak HDR)
            Topology: Internal Primary
         Driver Name: nvldumdx.dll,nvwgf2um.dll,nvwgf2um.dll
  Driver File Version: 31.00.0015.5186 (English)
       Driver Version: 31.0.15.5186 (GeForce Game Ready WHQL)
          Driver Date: 18/03/2026 00:00:00
        WHQL Logo'd: Yes
    WHQL Date Stamp: 18/03/2026
      Direct3D DDI: 12
   Feature Levels: 12_2, 12_1, 12_0, 11_1, 11_0, 10_1, 10_0
     Driver Model: WDDM 3.1
  Hardware Scheduling: Supported:Enabled 
DirectX Features:
  DirectDraw Acceleration: Enabled
   Direct3D Acceleration: Enabled
   AGP Texture Acceleration: Enabled

-------------
Sound Devices
-------------
            Description: Speakers / Headphones (Realtek High Definition Audio)
 Default Sound Playback: Yes
 Default Voice Playback: Yes
            Hardware ID: HDAUDIO\\FUNC_01&VEN_10EC&DEV_1220&SUBSYS_14627D70
        Manufacturer ID: 1
             Product ID: 100
                   Type: WDM
            Driver Name: RTKVHD64.sys
         Driver Version: 6.0.9239.1 (English)
            Driver Date: 12/01/2026 00:00:00
            WHQL Logo'd: Yes
               Provider: Realtek Semiconductor Corp.

---------------------
Input Devices
---------------------
      Device Name: Optical USB Gaming Mouse
         Attached: 1
      Device Type: DirectInput / HID
       Subdevices: 5 buttons, 0 axes

      Device Name: RGB Mechanical Keyboard
         Attached: 1
      Device Type: DirectInput / HID
       Subdevices: 108 keys, 0 axes

      Device Name: Xbox Wireless Controller
         Attached: 1
      Device Type: XInput / DirectInput
       Subdevices: 16 buttons, 6 axes (Triggers, Thumbsticks)
`;
}

export const DxDiagDialog: React.FC<DxDiagDialogProps> = ({ windowId }) => {
  const { closeWindow, windows, addFile, addNotification } = useOS();
  const [activeTab, setActiveTab] = useState<'system' | 'display' | 'sound' | 'input'>('system');
  const [checkWhql, setCheckWhql] = useState(true);
  const [isSavedNotice, setIsSavedNotice] = useState(false);

  const tabs: Array<{ id: 'system' | 'display' | 'sound' | 'input'; label: string; icon: any }> = [
    { id: 'system', label: 'System (Hệ thống)', icon: Cpu },
    { id: 'display', label: 'Display (Hiển thị)', icon: Monitor },
    { id: 'sound', label: 'Sound (Âm thanh)', icon: Volume2 },
    { id: 'input', label: 'Input (Nhập)', icon: Gamepad2 },
  ];

  const handleClose = () => {
    if (windowId) {
      closeWindow(windowId);
    } else {
      const dxWin = windows.find((w) => w.appId === 'dxdiag');
      if (dxWin) closeWindow(dxWin.id);
    }
  };

  const handleNextPage = () => {
    if (activeTab === 'system') setActiveTab('display');
    else if (activeTab === 'display') setActiveTab('sound');
    else if (activeTab === 'sound') setActiveTab('input');
    else setActiveTab('system');
  };

  const handleSaveAllInfo = () => {
    const report = generateDxDiagReportText();
    // Add to Desktop in FileSystem
    addFile({
      name: 'DxDiag.txt',
      path: 'C:\\Users\\User\\Desktop\\DxDiag.txt',
      isDirectory: false,
      content: report,
      size: report.length,
    });

    // Also trigger browser text file download
    try {
      const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'DxDiag.txt';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch {
      // ignore
    }

    setIsSavedNotice(true);
    addNotification(
      'DirectX Diagnostic Tool',
      'Đã lưu toàn bộ thông tin chẩn đoán DirectX vào C:\\Users\\User\\Desktop\\DxDiag.txt',
      'system'
    );
    setTimeout(() => setIsSavedNotice(false), 3000);
  };

  return (
    <div
      tabIndex={-1}
      className="w-full h-full bg-[#f3f3f3] dark:bg-[#202020] text-slate-800 dark:text-slate-100 flex flex-col justify-between select-none font-sans text-xs outline-none"
    >
      {/* Top Tabs Bar */}
      <div className="flex items-center px-3 pt-2 bg-[#e9e9e9] dark:bg-[#1a1a1a] border-b border-slate-300 dark:border-zinc-700 gap-1 overflow-x-auto">
        {tabs.map((tab) => {
          const isSelected = activeTab === tab.id;
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-t-md transition-colors border-t border-x ${
                isSelected
                  ? 'bg-[#f3f3f3] dark:bg-[#202020] border-slate-300 dark:border-zinc-700 text-slate-900 dark:text-white shadow-sm -mb-px pb-2'
                  : 'bg-transparent border-transparent text-slate-600 dark:text-zinc-400 hover:bg-slate-200/60 dark:hover:bg-zinc-800'
              }`}
            >
              <Icon size={13} className={isSelected ? 'text-[#0078d4]' : 'text-slate-500 dark:text-zinc-400'} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Tab Content */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3">
        {/* Banner introduction */}
        <div className="text-[11.5px] text-slate-600 dark:text-zinc-300 leading-relaxed bg-white/70 dark:bg-zinc-900/60 p-2.5 rounded-lg border border-slate-200 dark:border-zinc-800">
          Công cụ này báo cáo thông tin chi tiết về các thành phần và trình điều khiển DirectX được cài đặt trên hệ thống của bạn. Bạn có thể kiểm tra tính năng, chẩn đoán sự cố và lưu báo cáo.
        </div>

        {/* TAB 1: SYSTEM */}
        {activeTab === 'system' && (
          <div className="space-y-3">
            <fieldset className="border border-slate-300 dark:border-zinc-700 rounded-lg p-3 bg-white/50 dark:bg-zinc-900/40">
              <legend className="px-2 font-semibold text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1.5">
                <Cpu size={13} className="text-[#0078d4]" />
                <span>Thông tin hệ thống (System Information)</span>
              </legend>
              <div className="grid grid-cols-[170px_1fr] gap-y-1.5 gap-x-2 text-[11.5px] leading-tight pt-1">
                <span className="text-slate-500 dark:text-zinc-400">Ngày giờ hiện tại:</span>
                <span className="font-medium">{new Date().toLocaleString('vi-VN')}</span>

                <span className="text-slate-500 dark:text-zinc-400">Tên máy tính:</span>
                <span className="font-medium">DESKTOP-WIN11-OS</span>

                <span className="text-slate-500 dark:text-zinc-400">Hệ điều hành:</span>
                <span className="font-semibold text-slate-900 dark:text-white">
                  Windows 11 Pro 64-bit (10.0, Bản dựng 22631.3296)
                </span>

                <span className="text-slate-500 dark:text-zinc-400">Ngôn ngữ:</span>
                <span>Tiếng Việt (Cài đặt khu vực: Tiếng Việt)</span>

                <span className="text-slate-500 dark:text-zinc-400">Nhà sản xuất hệ thống:</span>
                <span>Micro-Star International Co., Ltd.</span>

                <span className="text-slate-500 dark:text-zinc-400">Mẫu hệ thống (Model):</span>
                <span>MS-7D70 (Gaming PC Master)</span>

                <span className="text-slate-500 dark:text-zinc-400">BIOS:</span>
                <span>1.A0 (loại: UEFI, Secure Boot Enabled)</span>

                <span className="text-slate-500 dark:text-zinc-400">Bộ xử lý (CPU):</span>
                <span className="font-semibold text-[#0078d4]">
                  AMD Ryzen 9 7950X 16-Core Processor (32 CPUs), ~4.5GHz
                </span>

                <span className="text-slate-500 dark:text-zinc-400">Bộ nhớ RAM:</span>
                <span className="font-medium">32768MB RAM (32 GB DDR5 6000MHz Dual-Channel)</span>

                <span className="text-slate-500 dark:text-zinc-400">Tệp hoán đổi (Page file):</span>
                <span>4892MB đã dùng, 32100MB khả dụng</span>

                <span className="text-slate-500 dark:text-zinc-400">Phiên bản DirectX:</span>
                <span className="font-bold text-[#0078d4]">DirectX 12 Ultimate (Feature Level 12_2)</span>
              </div>
            </fieldset>

            <div className="flex items-center gap-2 pt-1">
              <input
                type="checkbox"
                id="whql"
                checked={checkWhql}
                onChange={(e) => setCheckWhql(e.target.checked)}
                className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
              />
              <label htmlFor="whql" className="text-[11.5px] cursor-pointer text-slate-700 dark:text-zinc-300">
                Kiểm tra chữ ký số WHQL của Microsoft (Check for WHQL digital signatures)
              </label>
            </div>
          </div>
        )}

        {/* TAB 2: DISPLAY */}
        {activeTab === 'display' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {/* Box 1: Device */}
            <fieldset className="border border-slate-300 dark:border-zinc-700 rounded-lg p-3 bg-white/50 dark:bg-zinc-900/40">
              <legend className="px-2 font-semibold text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1.5">
                <Monitor size={13} className="text-[#0078d4]" />
                <span>Thiết bị hiển thị (Device)</span>
              </legend>
              <div className="grid grid-cols-[130px_1fr] gap-y-1 gap-x-2 text-[11px] leading-tight pt-1">
                <span className="text-slate-500 dark:text-zinc-400">Tên thiết bị:</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">NVIDIA GeForce RTX 4090</span>

                <span className="text-slate-500 dark:text-zinc-400">Nhà sản xuất:</span>
                <span>NVIDIA Corporation</span>

                <span className="text-slate-500 dark:text-zinc-400">Loại chip:</span>
                <span>NVIDIA GeForce RTX 4090 (AD102)</span>

                <span className="text-slate-500 dark:text-zinc-400">Loại DAC:</span>
                <span>Integrated RAMDAC</span>

                <span className="text-slate-500 dark:text-zinc-400">Bộ nhớ xấp xỉ:</span>
                <span>40924 MB</span>

                <span className="text-slate-500 dark:text-zinc-400">Bộ nhớ VRAM:</span>
                <span className="font-semibold text-slate-900 dark:text-white">24576 MB GDDR6X</span>

                <span className="text-slate-500 dark:text-zinc-400">Bộ nhớ chia sẻ:</span>
                <span>16348 MB</span>

                <span className="text-slate-500 dark:text-zinc-400">Chế độ hiển thị:</span>
                <span className="font-medium">2560 x 1440 (32 bit) (165Hz)</span>

                <span className="text-slate-500 dark:text-zinc-400">Màn hình (Monitor):</span>
                <span>ROG Swift OLED 27" (HDR 1000 nits)</span>
              </div>
            </fieldset>

            {/* Box 2: Drivers */}
            <fieldset className="border border-slate-300 dark:border-zinc-700 rounded-lg p-3 bg-white/50 dark:bg-zinc-900/40">
              <legend className="px-2 font-semibold text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1.5">
                <Info size={13} className="text-[#0078d4]" />
                <span>Trình điều khiển (Drivers)</span>
              </legend>
              <div className="grid grid-cols-[130px_1fr] gap-y-1 gap-x-2 text-[11px] leading-tight pt-1">
                <span className="text-slate-500 dark:text-zinc-400">Trình điều khiển chính:</span>
                <span className="font-mono text-[10px] truncate">nvldumdx.dll,nvwgf2um.dll</span>

                <span className="text-slate-500 dark:text-zinc-400">Phiên bản driver:</span>
                <span className="font-semibold text-slate-900 dark:text-white">31.0.15.5186 (Game Ready)</span>

                <span className="text-slate-500 dark:text-zinc-400">Ngày phát hành:</span>
                <span>18/03/2026</span>

                <span className="text-slate-500 dark:text-zinc-400">Chứng nhận WHQL:</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-semibold">Có (Yes)</span>

                <span className="text-slate-500 dark:text-zinc-400">Direct3D DDI:</span>
                <span>12</span>

                <span className="text-slate-500 dark:text-zinc-400">Feature Levels:</span>
                <span>12_2, 12_1, 12_0, 11_1, 11_0</span>

                <span className="text-slate-500 dark:text-zinc-400">Driver Model:</span>
                <span>WDDM 3.1</span>
              </div>
            </fieldset>

            {/* DirectX Features Acceleration */}
            <fieldset className="md:col-span-2 border border-slate-300 dark:border-zinc-700 rounded-lg p-3 bg-white/50 dark:bg-zinc-900/40">
              <legend className="px-2 font-semibold text-slate-800 dark:text-slate-200 text-xs">
                Tính năng tăng tốc DirectX (DirectX Features)
              </legend>
              <div className="grid grid-cols-3 gap-2 text-[11.5px]">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-emerald-500 shrink-0" />
                  <span>DirectDraw: <strong>Đã bật (Enabled)</strong></span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-emerald-500 shrink-0" />
                  <span>Direct3D: <strong>Đã bật (Enabled)</strong></span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-emerald-500 shrink-0" />
                  <span>AGP Texture: <strong>Đã bật (Enabled)</strong></span>
                </div>
              </div>
            </fieldset>

            {/* Notes */}
            <fieldset className="md:col-span-2 border border-slate-300 dark:border-zinc-700 rounded-lg p-2.5 bg-white/50 dark:bg-zinc-900/40 text-[11px] text-slate-600 dark:text-zinc-300">
              <legend className="px-2 font-semibold text-slate-800 dark:text-slate-200 text-xs">Ghi chú (Notes)</legend>
              <p>• Không tìm thấy sự cố nào (No problems found).</p>
              <p>• Tất cả các thành phần Direct3D và GPU Ray Tracing đang hoạt động bình thường ở hiệu năng cao nhất.</p>
            </fieldset>
          </div>
        )}

        {/* TAB 3: SOUND */}
        {activeTab === 'sound' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <fieldset className="border border-slate-300 dark:border-zinc-700 rounded-lg p-3 bg-white/50 dark:bg-zinc-900/40">
              <legend className="px-2 font-semibold text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1.5">
                <Volume2 size={13} className="text-[#0078d4]" />
                <span>Thiết bị âm thanh (Device)</span>
              </legend>
              <div className="grid grid-cols-[130px_1fr] gap-y-1.5 gap-x-2 text-[11px] leading-tight pt-1">
                <span className="text-slate-500 dark:text-zinc-400">Tên thiết bị:</span>
                <span className="font-semibold text-slate-900 dark:text-white">Loa / Tai nghe (Realtek HD Audio)</span>

                <span className="text-slate-500 dark:text-zinc-400">Hardware ID:</span>
                <span className="font-mono text-[10px] truncate">HDAUDIO\FUNC_01&VEN_10EC</span>

                <span className="text-slate-500 dark:text-zinc-400">Loại thiết bị:</span>
                <span>WDM Audio Device</span>

                <span className="text-slate-500 dark:text-zinc-400">Thiết bị mặc định:</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-semibold">Có (Default Playback)</span>
              </div>
            </fieldset>

            <fieldset className="border border-slate-300 dark:border-zinc-700 rounded-lg p-3 bg-white/50 dark:bg-zinc-900/40">
              <legend className="px-2 font-semibold text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1.5">
                <Info size={13} className="text-[#0078d4]" />
                <span>Trình điều khiển âm thanh (Drivers)</span>
              </legend>
              <div className="grid grid-cols-[130px_1fr] gap-y-1.5 gap-x-2 text-[11px] leading-tight pt-1">
                <span className="text-slate-500 dark:text-zinc-400">Tệp Driver:</span>
                <span className="font-mono text-[10.5px]">RTKVHD64.sys</span>

                <span className="text-slate-500 dark:text-zinc-400">Phiên bản:</span>
                <span>6.0.9239.1</span>

                <span className="text-slate-500 dark:text-zinc-400">Ngày phát hành:</span>
                <span>12/01/2026</span>

                <span className="text-slate-500 dark:text-zinc-400">Chứng nhận WHQL:</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-semibold">Có (Yes)</span>
              </div>
            </fieldset>

            <fieldset className="md:col-span-2 border border-slate-300 dark:border-zinc-700 rounded-lg p-2.5 bg-white/50 dark:bg-zinc-900/40 text-[11px] text-slate-600 dark:text-zinc-300">
              <legend className="px-2 font-semibold text-slate-800 dark:text-slate-200 text-xs">Ghi chú (Notes)</legend>
              <p>• Không tìm thấy sự cố nào (No problems found).</p>
            </fieldset>
          </div>
        )}

        {/* TAB 4: INPUT */}
        {activeTab === 'input' && (
          <div className="space-y-3">
            <fieldset className="border border-slate-300 dark:border-zinc-700 rounded-lg p-3 bg-white/50 dark:bg-zinc-900/40">
              <legend className="px-2 font-semibold text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1.5">
                <Gamepad2 size={13} className="text-[#0078d4]" />
                <span>Thiết bị DirectInput (DirectInput Devices)</span>
              </legend>
              <div className="space-y-2 text-[11.5px]">
                <div className="flex items-center justify-between p-2 rounded bg-slate-100 dark:bg-zinc-800/60">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span className="font-semibold">Chuột quang học Gaming USB (Mouse)</span>
                  </div>
                  <span className="text-slate-500 dark:text-zinc-400 text-xs">5 nút bấm (Buttons), Trạng thái: Đã kết nối</span>
                </div>

                <div className="flex items-center justify-between p-2 rounded bg-slate-100 dark:bg-zinc-800/60">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span className="font-semibold">Bàn phím cơ RGB Standard (Keyboard)</span>
                  </div>
                  <span className="text-slate-500 dark:text-zinc-400 text-xs">108 phím, Trạng thái: Đã kết nối</span>
                </div>

                <div className="flex items-center justify-between p-2 rounded bg-slate-100 dark:bg-zinc-800/60">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span className="font-semibold">Tay cầm chơi game Xbox Wireless Controller</span>
                  </div>
                  <span className="text-slate-500 dark:text-zinc-400 text-xs">16 nút, 6 trục (Axes), XInput: Đã kết nối</span>
                </div>
              </div>
            </fieldset>

            <fieldset className="border border-slate-300 dark:border-zinc-700 rounded-lg p-2.5 bg-white/50 dark:bg-zinc-900/40 text-[11px] text-slate-600 dark:text-zinc-300">
              <legend className="px-2 font-semibold text-slate-800 dark:text-slate-200 text-xs">Ghi chú (Notes)</legend>
              <p>• Không tìm thấy sự cố nào (No problems found).</p>
            </fieldset>
          </div>
        )}
      </div>

      {/* Bottom Footer Controls */}
      <div className="p-3 bg-[#e9e9e9] dark:bg-[#181818] border-t border-slate-300 dark:border-zinc-700 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-zinc-400">
          <CheckCircle2 size={14} className="text-emerald-500" />
          <span>Kiểm tra chữ ký số: Hoàn tất (100%)</span>
          {isSavedNotice && (
            <span className="ml-2 text-emerald-600 font-semibold animate-pulse">✓ Đã lưu tệp DxDiag.txt</span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => addNotification('DirectX Help', 'Truy cập tài liệu DirectX 12 Ultimate tại learn.microsoft.com/windows/win32/directx', 'info')}
            className="px-3 py-1 rounded bg-slate-200 hover:bg-slate-300 dark:bg-zinc-700 dark:hover:bg-zinc-600 text-xs font-medium transition-colors"
          >
            Trợ giúp (Help)
          </button>
          <button
            onClick={handleNextPage}
            className="px-3 py-1 rounded bg-slate-200 hover:bg-slate-300 dark:bg-zinc-700 dark:hover:bg-zinc-600 text-xs font-medium transition-colors"
          >
            Trang tiếp (Next Page)
          </button>
          <button
            onClick={handleSaveAllInfo}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-sky-600 hover:bg-sky-700 text-white text-xs font-medium transition-colors shadow-sm"
          >
            <Save size={13} />
            <span>Lưu tất cả thông tin... (Save All Information)</span>
          </button>
          <button
            onClick={handleClose}
            className="px-4 py-1 rounded bg-slate-200 hover:bg-slate-300 dark:bg-zinc-700 dark:hover:bg-zinc-600 text-xs font-medium transition-colors"
          >
            Thoát (Exit)
          </button>
        </div>
      </div>
    </div>
  );
};
