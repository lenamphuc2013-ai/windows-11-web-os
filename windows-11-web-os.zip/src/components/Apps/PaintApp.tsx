import React, { useState, useRef, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import {
  Paintbrush,
  Eraser,
  Square,
  Circle,
  Minus,
  RotateCcw,
  RotateCw,
  Trash2,
  Download,
  Save,
  Check,
} from 'lucide-react';

const COLORS = [
  '#000000', '#ffffff', '#7f7f7f', '#c3c3c3',
  '#880015', '#b97a57', '#ed1c24', '#ffaec9',
  '#ff7f27', '#ffc90e', '#fff200', '#efe4b0',
  '#22b14c', '#b5e61d', '#00a2e8', '#99d9ea',
  '#3f48cc', '#7092be', '#a349a4', '#c8bfe7',
];

export const PaintApp: React.FC = () => {
  const { addFile, addNotification } = useOS();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [tool, setTool] = useState<'brush' | 'eraser' | 'rect' | 'circle' | 'line'>('brush');
  const [color, setColor] = useState('#000000');
  const [lineWidth, setLineWidth] = useState(4);
  const [isDrawing, setIsDrawing] = useState(false);
  const [startPos, setStartPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [history, setHistory] = useState<ImageData[]>([]);
  const [historyStep, setHistoryStep] = useState(-1);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    const initial = ctx.getImageData(0, 0, canvas.width, canvas.height);
    setHistory([initial]);
    setHistoryStep(0);
  }, []);

  const saveState = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const current = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const newHistory = history.slice(0, historyStep + 1);
    newHistory.push(current);
    setHistory(newHistory);
    setHistoryStep(newHistory.length - 1);
  };

  const handleUndo = () => {
    if (historyStep > 0) {
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      if (!canvas || !ctx) return;
      const prev = history[historyStep - 1];
      ctx.putImageData(prev, 0, 0);
      setHistoryStep(historyStep - 1);
    }
  };

  const handleRedo = () => {
    if (historyStep < history.length - 1) {
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      if (!canvas || !ctx) return;
      const next = history[historyStep + 1];
      ctx.putImageData(next, 0, 0);
      setHistoryStep(historyStep + 1);
    }
  };

  const getCanvasCoords = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  };

  const startDraw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const coords = getCanvasCoords(e);
    setIsDrawing(true);
    setStartPos(coords);

    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx) return;

    ctx.beginPath();
    ctx.moveTo(coords.x, coords.y);
    ctx.strokeStyle = tool === 'eraser' ? '#ffffff' : color;
    ctx.fillStyle = color;
    ctx.lineWidth = lineWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (tool === 'brush' || tool === 'eraser') {
      ctx.lineTo(coords.x, coords.y);
      ctx.stroke();
    }
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const coords = getCanvasCoords(e);

    if (tool === 'brush' || tool === 'eraser') {
      ctx.lineTo(coords.x, coords.y);
      ctx.stroke();
    } else {
      // For shapes, restore step then draw preview
      if (history[historyStep]) {
        ctx.putImageData(history[historyStep], 0, 0);
      }
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth = lineWidth;

      if (tool === 'rect') {
        ctx.strokeRect(startPos.x, startPos.y, coords.x - startPos.x, coords.y - startPos.y);
      } else if (tool === 'circle') {
        const radius = Math.hypot(coords.x - startPos.x, coords.y - startPos.y);
        ctx.arc(startPos.x, startPos.y, radius, 0, Math.PI * 2);
        ctx.stroke();
      } else if (tool === 'line') {
        ctx.moveTo(startPos.x, startPos.y);
        ctx.lineTo(coords.x, coords.y);
        ctx.stroke();
      }
    }
  };

  const endDraw = () => {
    if (isDrawing) {
      setIsDrawing(false);
      saveState();
    }
  };

  const handleClear = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    saveState();
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `Drawing-${Date.now()}.png`;
    a.click();
  };

  const handleSaveToPictures = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL('image/png');
    const name = `Artwork-${Date.now()}.png`;
    addFile({
      name,
      path: `C:\\Users\\User\\Pictures\\${name}`,
      isDirectory: false,
      content: url,
      size: url.length,
      icon: 'Image',
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
    addNotification('Saved to Pictures', `Your drawing was saved to C:\\Users\\User\\Pictures\\${name}`, 'paint');
  };

  return (
    <div className="flex flex-col w-full h-full bg-slate-200 dark:bg-[#1a1a1a] text-slate-800 dark:text-slate-100 select-none overflow-hidden text-xs">
      {/* Ribbon Bar */}
      <div className="flex flex-wrap items-center justify-between p-2 bg-slate-100 dark:bg-[#242424] border-b border-slate-300 dark:border-zinc-800 gap-2">
        {/* Tools */}
        <div className="flex items-center gap-1 bg-white dark:bg-zinc-800 p-1 rounded-xl border border-slate-300 dark:border-zinc-700">
          <button
            onClick={() => setTool('brush')}
            className={`p-1.5 rounded-lg transition-colors ${
              tool === 'brush' ? 'bg-sky-500 text-white' : 'hover:bg-slate-200 dark:hover:bg-zinc-700'
            }`}
            title="Brush"
          >
            <Paintbrush size={16} />
          </button>
          <button
            onClick={() => setTool('eraser')}
            className={`p-1.5 rounded-lg transition-colors ${
              tool === 'eraser' ? 'bg-sky-500 text-white' : 'hover:bg-slate-200 dark:hover:bg-zinc-700'
            }`}
            title="Eraser"
          >
            <Eraser size={16} />
          </button>
          <button
            onClick={() => setTool('line')}
            className={`p-1.5 rounded-lg transition-colors ${
              tool === 'line' ? 'bg-sky-500 text-white' : 'hover:bg-slate-200 dark:hover:bg-zinc-700'
            }`}
            title="Line"
          >
            <Minus size={16} />
          </button>
          <button
            onClick={() => setTool('rect')}
            className={`p-1.5 rounded-lg transition-colors ${
              tool === 'rect' ? 'bg-sky-500 text-white' : 'hover:bg-slate-200 dark:hover:bg-zinc-700'
            }`}
            title="Rectangle"
          >
            <Square size={16} />
          </button>
          <button
            onClick={() => setTool('circle')}
            className={`p-1.5 rounded-lg transition-colors ${
              tool === 'circle' ? 'bg-sky-500 text-white' : 'hover:bg-slate-200 dark:hover:bg-zinc-700'
            }`}
            title="Circle"
          >
            <Circle size={16} />
          </button>
        </div>

        {/* Thickness selector */}
        <div className="flex items-center gap-2 bg-white dark:bg-zinc-800 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-zinc-700">
          <span className="text-[11px] text-slate-500">Size:</span>
          <div className="flex items-center gap-1.5">
            {[2, 4, 8, 16].map((sz) => (
              <button
                key={sz}
                onClick={() => setLineWidth(sz)}
                className={`w-6 h-6 rounded flex items-center justify-center transition-all ${
                  lineWidth === sz ? 'bg-sky-500 text-white' : 'hover:bg-slate-200 dark:hover:bg-zinc-700'
                }`}
              >
                <div
                  className="bg-current rounded-full"
                  style={{ width: Math.min(14, sz * 2), height: Math.min(14, sz * 2) }}
                />
              </button>
            ))}
          </div>
        </div>

        {/* Palette */}
        <div className="flex flex-wrap gap-1 max-w-[220px] bg-white dark:bg-zinc-800 p-1.5 rounded-xl border border-slate-300 dark:border-zinc-700">
          {COLORS.map((c) => (
            <button
              key={c}
              onClick={() => setColor(c)}
              className={`w-4 h-4 rounded-full border transition-transform ${
                color === c ? 'scale-125 ring-2 ring-sky-500 border-white' : 'border-black/20 hover:scale-110'
              }`}
              style={{ backgroundColor: c }}
            />
          ))}
          <input
            type="color"
            value={color}
            onChange={(e) => setColor(e.target.value)}
            className="w-4 h-4 rounded cursor-pointer border-0 p-0"
            title="Custom Color"
          />
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1">
          <button
            onClick={handleUndo}
            disabled={historyStep <= 0}
            className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-700 disabled:opacity-30"
            title="Undo"
          >
            <RotateCcw size={15} />
          </button>
          <button
            onClick={handleRedo}
            disabled={historyStep >= history.length - 1}
            className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-700 disabled:opacity-30"
            title="Redo"
          >
            <RotateCw size={15} />
          </button>
          <button
            onClick={handleClear}
            className="p-1.5 rounded-lg hover:bg-red-500/10 text-red-600 dark:text-red-400"
            title="Clear Canvas"
          >
            <Trash2 size={15} />
          </button>

          <button
            onClick={handleSaveToPictures}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold shadow-sm transition-all"
          >
            {savedSuccess ? <Check size={14} /> : <Save size={14} />}
            <span>{savedSuccess ? 'Saved' : 'Save Image'}</span>
          </button>

          <button
            onClick={handleDownload}
            className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-700"
            title="Download PNG"
          >
            <Download size={15} />
          </button>
        </div>
      </div>

      {/* Canvas Working Area */}
      <div className="flex-1 overflow-auto flex items-center justify-center p-4 bg-slate-300 dark:bg-[#111]">
        <div className="shadow-2xl rounded-lg overflow-hidden border border-slate-400 dark:border-zinc-800 bg-white">
          <canvas
            ref={canvasRef}
            width={760}
            height={480}
            onMouseDown={startDraw}
            onMouseMove={draw}
            onMouseUp={endDraw}
            onMouseLeave={endDraw}
            className="cursor-crosshair block bg-white"
          />
        </div>
      </div>
    </div>
  );
};
