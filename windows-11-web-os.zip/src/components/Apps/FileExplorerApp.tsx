import React, { useState, useRef, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import { useContextMenuTrigger } from '../../hooks/useContextMenuTrigger';
import { IconRenderer } from '../Common/IconRenderer';
import { FileSystemItem } from '../../types';
import { generateFileContextMenu } from '../../utils/fileContextMenu';
import {
  Folder,
  FolderTree,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  RotateCw,
  Search,
  Plus,
  Upload,
  LayoutGrid,
  List,
  HardDrive,
  Monitor,
  FileText,
  Image,
  Download,
  Music,
  Video,
  Disc,
  Database,
  Computer,
  ArrowRight,
  Clipboard,
  CornerUpRight,
  Shield,
  Trash2,
  Edit3,
  Copy,
  Scissors,
  Terminal,
  Pin,
  PinOff,
} from 'lucide-react';

interface FileExplorerAppProps {
  initialPath?: string;
}

export const FileExplorerApp: React.FC<FileExplorerAppProps> = ({
  initialPath = 'This PC',
}) => {
  const {
    fileSystem,
    getFilesByDirectory,
    addFile,
    deleteFile,
    renameFile,
    clipboard,
    setClipboard,
    pasteFile,
    createArchiveFile,
    createShortcutFile,
    copyFileToFolder,
    pinnedFolders,
    pinFolder,
    unpinFolder,
    openApp,
    setIsAddAppModalOpen,
    showContextMenu,
    addNotification,
    openFileProperties,
    openDefenderScan,
    openDriveProperties,
    updateSettings,
    t,
  } = useOS();

  const [currentPath, setCurrentPath] = useState(initialPath);
  const [history, setHistory] = useState<string[]>([initialPath]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const [selectedItem, setSelectedItem] = useState<FileSystemItem | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [isDragOver, setIsDragOver] = useState(false);

  // Address Bar Edit State
  const [isEditingAddress, setIsEditingAddress] = useState(false);
  const [addressInput, setAddressInput] = useState(initialPath);
  const addressInputRef = useRef<HTMLInputElement>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Keep addressInput in sync with currentPath
  useEffect(() => {
    setAddressInput(currentPath);
  }, [currentPath]);

  // When entering address bar edit mode, auto focus and select all (bôi xanh)
  useEffect(() => {
    if (isEditingAddress && addressInputRef.current) {
      addressInputRef.current.focus();
      addressInputRef.current.select();
    }
  }, [isEditingAddress]);

  // Navigate to path
  const navigateTo = (path: string) => {
    let cleanPath = path.trim();
    if (!cleanPath) return;

    // Normalization
    if (cleanPath.toLowerCase() === 'this pc' || cleanPath.toLowerCase() === 'my computer') {
      cleanPath = 'This PC';
    } else if (/^[a-zA-Z]:$/.test(cleanPath)) {
      cleanPath = cleanPath.toUpperCase();
    } else if (/^[a-zA-Z]:[\\/]$/.test(cleanPath)) {
      cleanPath = cleanPath.substring(0, 2).toUpperCase();
    } else if (cleanPath.toLowerCase() === 'desktop') {
      cleanPath = 'C:\\Users\\User\\Desktop';
    } else if (cleanPath.toLowerCase() === 'documents') {
      cleanPath = 'C:\\Users\\User\\Documents';
    } else if (cleanPath.toLowerCase() === 'downloads') {
      cleanPath = 'C:\\Users\\User\\Downloads';
    } else if (cleanPath.toLowerCase() === 'pictures') {
      cleanPath = 'C:\\Users\\User\\Pictures';
    } else if (cleanPath.toLowerCase() === 'apps' || cleanPath.toLowerCase() === 'c:\\apps') {
      cleanPath = 'C:\\Apps';
    }

    if (cleanPath === currentPath) {
      setIsEditingAddress(false);
      return;
    }

    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(cleanPath);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
    setCurrentPath(cleanPath);
    setAddressInput(cleanPath);
    setIsEditingAddress(false);
    setSelectedItem(null);
    setSearchQuery('');
  };

  const handleBack = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      const prevPath = history[historyIndex - 1];
      setCurrentPath(prevPath);
      setAddressInput(prevPath);
      setIsEditingAddress(false);
      setSelectedItem(null);
    }
  };

  const handleForward = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      const nextPath = history[historyIndex + 1];
      setCurrentPath(nextPath);
      setAddressInput(nextPath);
      setIsEditingAddress(false);
      setSelectedItem(null);
    }
  };

  const handleUp = () => {
    if (currentPath === 'This PC') return;
    if (currentPath === 'C:' || currentPath === 'D:' || currentPath === 'C:\\' || currentPath === 'D:\\') {
      navigateTo('This PC');
      return;
    }
    const lastSlash = Math.max(currentPath.lastIndexOf('\\'), currentPath.lastIndexOf('/'));
    if (lastSlash === -1 || lastSlash === 2) {
      navigateTo(currentPath.substring(0, 2));
    } else {
      navigateTo(currentPath.substring(0, lastSlash));
    }
  };

  // Get items in current directory or search results
  const isThisPC = currentPath === 'This PC';
  let items: FileSystemItem[] = [];
  if (!isThisPC) {
    if (searchQuery.trim()) {
      items = fileSystem.filter(
        (f) =>
          f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          f.appMetadata?.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    } else {
      items = getFilesByDirectory(currentPath);
    }
  }

  // Handle open file or folder
  const handleItemOpen = (item: FileSystemItem) => {
    if (item.isDirectory) {
      navigateTo(item.path);
    } else if (item.isHtmlApp || item.name.endsWith('.html') || item.name.endsWith('.htm')) {
      openApp('app-runner', {
        filePath: item.path,
        appName: item.appMetadata?.title || item.name.replace(/\.html?$/i, ''),
        icon: item.icon || 'Gamepad2',
      });
    } else if (item.name.endsWith('.txt') || item.name.endsWith('.json') || item.name.endsWith('.md')) {
      openApp('notepad', {
        filePath: item.path,
        fileName: item.name,
        content: item.content || '',
      });
    } else if (item.name.match(/\.(png|jpe?g|svg|webp|gif)$/i)) {
      openApp('photos', {
        filePath: item.path,
        fileName: item.name,
      });
    } else if (item.name.match(/\.(mp4|webm|mkv|mov|avi|ogv)$/i)) {
      openApp('videoplayer', {
        filePath: item.path,
        fileName: item.name,
        videoUrl: item.content || undefined,
      });
    }
  };

  // Create new folder
  const handleCreateFolder = () => {
    if (isThisPC) return;
    const name = prompt('Nhập tên thư mục mới:', 'New Folder');
    if (!name) return;
    const path = `${currentPath}\\${name}`;
    addFile({
      name,
      path,
      isDirectory: true,
      icon: 'Folder',
    });
  };

  // Create new text file
  const handleCreateTextFile = () => {
    if (isThisPC) return;
    const name = prompt('Nhập tên file văn bản:', 'New Document.txt');
    if (!name) return;
    const path = `${currentPath}\\${name}`;
    addFile({
      name,
      path,
      isDirectory: false,
      content: '',
      size: 0,
      icon: 'FileText',
    });
  };

  // File Upload via Input or Drag & Drop
  const processUploadFiles = (files: FileList) => {
    if (isThisPC) {
      navigateTo('C:\\Users\\User\\Downloads');
    }
    const targetDir = isThisPC ? 'C:\\Users\\User\\Downloads' : currentPath;

    Array.from(files).forEach((file) => {
      const isHtml = file.name.endsWith('.html') || file.name.endsWith('.htm');
      const isImage = /\.(png|jpe?g|svg|webp|gif|bmp|ico|avif)$/i.test(file.name) || file.type.startsWith('image/');
      const isVideo = /\.(mp4|webm|mkv|mov|avi|ogv)$/i.test(file.name) || file.type.startsWith('video/');
      const isAudio = /\.(mp3|wav|ogg|flac|m4a|aac|wma)$/i.test(file.name) || file.type.startsWith('audio/');
      const isArchive = /\.(zip|rar|7z|tar|gz|bz2)$/i.test(file.name);
      const isCode = /\.(js|ts|jsx|tsx|json|py|css|html|xml|bat|cmd|ps1|c|cpp|h|java|sql|sh)$/i.test(file.name);
      const isBinary = isImage || isVideo || isAudio || isArchive || !file.type.startsWith('text/');

      const reader = new FileReader();
      reader.onload = (e) => {
        const content = (e.target?.result as string) || '';
        const path = `${targetDir}\\${file.name}`;

        let appTitle = file.name.replace(/\.html?$/i, '');
        if (isHtml) {
          const match = content.match(/<title>([^<]+)<\/title>/i);
          if (match && match[1]) appTitle = match[1].trim();
        }

        let iconName = 'FileText';
        if (isHtml) iconName = 'Gamepad2';
        else if (isImage) iconName = 'Image';
        else if (isVideo) iconName = 'Film';
        else if (isAudio) iconName = 'Music';
        else if (isArchive) iconName = 'Archive';
        else if (file.name.match(/\.(bat|cmd|ps1)$/i)) iconName = 'Terminal';
        else if (isCode) iconName = 'FileCode';

        addFile({
          name: file.name,
          path,
          isDirectory: false,
          content,
          size: file.size,
          icon: iconName,
          isHtmlApp: isHtml,
          appMetadata: isHtml
            ? {
                title: appTitle,
                icon: 'Gamepad2',
                category: 'custom',
                description: `Ứng dụng HTML: ${appTitle}`,
              }
            : undefined,
        });

        addNotification(
          'Đã lưu cục bộ',
          `"${file.name}" đã được lưu thành công vào ${targetDir}`,
          'explorer'
        );
      };

      if (isBinary && !isHtml && !isCode) {
        reader.readAsDataURL(file);
      } else {
        reader.readAsText(file);
      }
    });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processUploadFiles(e.dataTransfer.files);
    }
  };

  // Address Bar Right-Click Context Menu
  const handleAddressBarContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    // Enable editing and select all text immediately (bôi xanh)
    setIsEditingAddress(true);
    setTimeout(() => {
      if (addressInputRef.current) {
        addressInputRef.current.focus();
        addressInputRef.current.select();
      }
    }, 20);

    showContextMenu(e.clientX, e.clientY, [
      {
        id: 'addr-undo',
        label: 'Hoàn tác (Undo)',
        icon: 'RotateCcw',
        shortcut: 'Ctrl+Z',
        onClick: () => {
          setAddressInput(currentPath);
        },
      },
      { separator: true, id: 'addr-sep-1', label: '' },
      {
        id: 'addr-cut',
        label: 'Cắt (Cut)',
        icon: 'Scissors',
        shortcut: 'Ctrl+X',
        onClick: () => {
          try {
            navigator.clipboard.writeText(addressInput);
          } catch (err) {}
          setAddressInput('');
          addNotification('Đường dẫn', 'Đã cắt đường dẫn', 'info');
        },
      },
      {
        id: 'addr-copy',
        label: 'Sao chép (Copy)',
        icon: 'Copy',
        shortcut: 'Ctrl+C',
        onClick: () => {
          try {
            navigator.clipboard.writeText(currentPath);
          } catch (err) {}
          addNotification('Sao chép đường dẫn', `Đã sao chép: "${currentPath}"`, 'explorer');
        },
      },
      {
        id: 'addr-paste',
        label: 'Dán (Paste)',
        icon: 'Clipboard',
        shortcut: 'Ctrl+V',
        onClick: async () => {
          try {
            const text = await navigator.clipboard.readText();
            if (text) {
              setAddressInput(text);
              setIsEditingAddress(true);
            }
          } catch (err) {
            const pasted = prompt('Dán đường dẫn vào đây:');
            if (pasted) {
              setAddressInput(pasted);
              setIsEditingAddress(true);
            }
          }
        },
      },
      {
        id: 'addr-delete',
        label: 'Xóa (Delete)',
        icon: 'Trash2',
        shortcut: 'Del',
        onClick: () => {
          setAddressInput('');
        },
      },
      { separator: true, id: 'addr-sep-2', label: '' },
      {
        id: 'addr-select-all',
        label: 'Chọn tất cả (Select all)',
        icon: 'CheckSquare',
        shortcut: 'Ctrl+A',
        onClick: () => {
          setIsEditingAddress(true);
          setTimeout(() => {
            addressInputRef.current?.focus();
            addressInputRef.current?.select();
          }, 20);
        },
      },
      { separator: true, id: 'addr-sep-3', label: '' },
      {
        id: 'addr-copy-text',
        label: 'Sao chép địa chỉ dưới dạng văn bản',
        icon: 'FileText',
        onClick: () => {
          try {
            navigator.clipboard.writeText(currentPath);
          } catch (err) {}
          addNotification('Sao chép địa chỉ', `Đã sao chép: "${currentPath}"`, 'explorer');
        },
      },
      {
        id: 'addr-edit-address',
        label: 'Chỉnh sửa địa chỉ',
        icon: 'Edit3',
        onClick: () => {
          setIsEditingAddress(true);
          setTimeout(() => {
            addressInputRef.current?.focus();
            addressInputRef.current?.select();
          }, 20);
        },
      },
      {
        id: 'addr-open-new',
        label: 'Mở trong cửa sổ mới',
        icon: 'ExternalLink',
        onClick: () => {
          openApp('explorer', { initialPath: currentPath });
        },
      },
    ]);
  };

  // Full Windows 11 Context Menu for ANY file or folder
  const handleItemContextMenu = (coords: { x: number; y: number }, item: FileSystemItem) => {
    // Synchronously highlight item in blue
    setSelectedItem(item);

    const contextItems = generateFileContextMenu({
      item,
      onOpen: handleItemOpen,
      onOpenNewWindow: (it) => openApp('explorer', { initialPath: it.path }),
      onDelete: (it) => {
        deleteFile(it.id);
      },
      onRename: (it) => {
        const newName = prompt(`Đổi tên "${it.name}" thành:`, it.name);
        if (newName && newName.trim() && newName.trim() !== it.name) {
          renameFile(it.id, newName.trim());
        }
      },
      onProperties: (it) => {
        openFileProperties(it);
      },
      onDefenderScan: (it) => {
        openDefenderScan(it.name);
      },
      onPinQuickAccess: (it) => {
        pinFolder(it.path);
      },
      onAddToArchive: (it, fmt) => {
        createArchiveFile(it, fmt || 'rar');
      },
      onCreateShortcut: (it) => {
        createShortcutFile(it, isThisPC ? 'C:\\Users\\User\\Desktop' : currentPath);
      },
      onSendToDesktop: (it) => {
        createShortcutFile(it, 'C:\\Users\\User\\Desktop');
      },
      onSendToDocs: (it) => {
        copyFileToFolder(it, 'C:\\Users\\User\\Documents');
      },
      onSendToZip: (it) => {
        createArchiveFile(it, 'zip');
      },
      onCopy: (it) => {
        setClipboard(it, 'copy');
        addNotification('Sao chép', `Đã chép "${it.name}" vào bộ nhớ tạm`, 'explorer');
      },
      onCut: (it) => {
        setClipboard(it, 'cut');
        addNotification('Cắt', `Đã cắt "${it.name}"`, 'explorer');
      },
      onSetAsWallpaper: (it) => {
        if (it.content) {
          updateSettings({ wallpaper: it.content });
          addNotification(t.personalize, `${t.setAsWallpaper}: "${it.name}"`, 'explorer');
        }
      },
      notify: (title, msg) => addNotification(title, msg, 'explorer'),
    });

    showContextMenu(coords.x, coords.y, contextItems, 'file', item);
  };

  // Drive Context Menu for C: or D:
  const handleDriveContextMenu = (e: React.MouseEvent, driveLetter: 'C' | 'D') => {
    e.preventDefault();
    e.stopPropagation();

    showContextMenu(e.clientX, e.clientY, [
      {
        id: `open-${driveLetter}`,
        label: 'Mở (Open)',
        icon: 'FolderOpen',
        onClick: () => navigateTo(`${driveLetter}:`),
      },
      {
        id: `open-new-${driveLetter}`,
        label: 'Mở trong cửa sổ mới',
        icon: 'ExternalLink',
        onClick: () => openApp('explorer', { initialPath: `${driveLetter}:` }),
      },
      {
        id: `pin-quick-${driveLetter}`,
        label: 'Ghim vào Truy cập nhanh',
        icon: 'Pin',
        onClick: () => pinFolder(`${driveLetter}:`),
      },
      {
        id: `defender-${driveLetter}`,
        label: 'Quét bằng Microsoft Defender...',
        icon: 'Shield',
        onClick: () => openDefenderScan(`Ổ đĩa cục bộ (${driveLetter}:)`),
      },
      { separator: true, id: `sep-1-${driveLetter}`, label: '' },
      {
        id: `bitlocker-${driveLetter}`,
        label: 'Bật BitLocker',
        icon: 'Lock',
        onClick: () => addNotification('BitLocker Drive Encryption', 'Tính năng mã hóa bảo mật ổ đĩa BitLocker đã kích hoạt.', 'security'),
      },
      {
        id: `format-${driveLetter}`,
        label: 'Định dạng (Format)...',
        icon: 'RotateCcw',
        onClick: () => {
          if (driveLetter === 'C') {
            alert('Không thể định dạng ổ đĩa chứa hệ điều hành Windows đang chạy!');
          } else {
            if (confirm('CẢNH BÁO: Định dạng sẽ xóa toàn bộ dữ liệu trên ổ D:. Bạn có chắc không?')) {
              addNotification('Format Ổ D:', 'Đã định dạng thành công ổ đĩa Data (D:)', 'system');
            }
          }
        },
      },
      { separator: true, id: `sep-2-${driveLetter}`, label: '' },
      {
        id: `paste-drive-${driveLetter}`,
        label: 'Dán (Paste)',
        icon: 'Clipboard',
        shortcut: 'Ctrl+V',
        disabled: !clipboard,
        onClick: () => pasteFile(`${driveLetter}:`),
      },
      { separator: true, id: `sep-3-${driveLetter}`, label: '' },
      {
        id: `prop-${driveLetter}`,
        label: 'Thuộc tính (Properties)',
        icon: 'Info',
        shortcut: 'Alt+Enter',
        onClick: () => openDriveProperties(driveLetter),
      },
    ]);
  };

  // Background Context Menu for Content Area
  const handleContentBackgroundContextMenu = (e: React.MouseEvent) => {
    if (isThisPC) return;
    e.preventDefault();

    showContextMenu(e.clientX, e.clientY, [
      {
        id: 'view-mode',
        label: 'Xem (View)',
        icon: 'LayoutGrid',
        submenu: [
          {
            id: 'view-grid',
            label: 'Biểu tượng lớn (Icons)',
            checked: viewMode === 'grid',
            onClick: () => setViewMode('grid'),
          },
          {
            id: 'view-list',
            label: 'Chi tiết (Details / List)',
            checked: viewMode === 'list',
            onClick: () => setViewMode('list'),
          },
        ],
      },
      {
        id: 'refresh',
        label: 'Làm mới (Refresh)',
        icon: 'RotateCw',
        shortcut: 'F5',
        onClick: () => setSelectedItem(null),
      },
      { separator: true, id: 'sep-ctx-paste', label: '' },
      {
        id: 'ctx-paste',
        label: 'Dán (Paste)',
        icon: 'Clipboard',
        shortcut: 'Ctrl+V',
        disabled: !clipboard,
        onClick: () => {
          pasteFile(currentPath);
        },
      },
      {
        id: 'ctx-paste-shortcut',
        label: 'Dán lối tắt (Paste shortcut)',
        icon: 'CornerUpRight',
        disabled: !clipboard,
        onClick: () => {
          if (clipboard?.item) {
            createShortcutFile(clipboard.item, currentPath);
          }
        },
      },
      { separator: true, id: 'sep-ctx-new', label: '' },
      {
        id: 'new-menu',
        label: 'Mới (New)',
        icon: 'Plus',
        submenu: [
          {
            id: 'new-folder',
            label: 'Thư mục mới (Folder)',
            icon: 'Folder',
            onClick: handleCreateFolder,
          },
          {
            id: 'new-file',
            label: 'Tệp văn bản mới (Text Document)',
            icon: 'FileText',
            onClick: handleCreateTextFile,
          },
          {
            id: 'new-html',
            label: 'Tạo App HTML Mới',
            icon: 'Sparkles',
            onClick: () => setIsAddAppModalOpen(true),
          },
        ],
      },
      { separator: true, id: 'sep-ctx-term', label: '' },
      {
        id: 'open-term',
        label: 'Mở trong Terminal',
        icon: 'Terminal',
        onClick: () => openApp('terminal'),
      },
    ]);
  };

  const isAppsFolder = currentPath.toLowerCase() === 'c:\\apps';

  // Windows 11 This PC default folders list
  const thisPCFolders = [
    {
      id: 'f-desktop',
      name: 'Desktop',
      path: 'C:\\Users\\User\\Desktop',
      icon: 'Monitor',
      color: 'from-blue-500 to-indigo-600',
      tag: 'Màn hình nền',
    },
    {
      id: 'f-docs',
      name: 'Documents',
      path: 'C:\\Users\\User\\Documents',
      icon: 'FileText',
      color: 'from-amber-500 to-yellow-600',
      tag: 'Tài liệu cá nhân',
    },
    {
      id: 'f-downloads',
      name: 'Downloads',
      path: 'C:\\Users\\User\\Downloads',
      icon: 'Download',
      color: 'from-emerald-500 to-teal-600',
      tag: 'Tệp tải xuống',
    },
    {
      id: 'f-music',
      name: 'Music',
      path: 'C:\\Users\\User\\Music',
      icon: 'Music',
      color: 'from-pink-500 to-rose-600',
      tag: 'Nhạc & Âm thanh',
    },
    {
      id: 'f-pics',
      name: 'Pictures',
      path: 'C:\\Users\\User\\Pictures',
      icon: 'Image',
      color: 'from-purple-500 to-violet-600',
      tag: 'Ảnh & Đồ họa',
    },
    {
      id: 'f-videos',
      name: 'Videos',
      path: 'C:\\Users\\User\\Videos',
      icon: 'Video',
      color: 'from-red-500 to-rose-600',
      tag: 'Phim & Video',
    },
    {
      id: 'f-apps',
      name: 'Apps (HTML)',
      path: 'C:\\Apps',
      icon: 'LayoutGrid',
      color: 'from-sky-500 to-cyan-600',
      tag: 'Thư mục Ứng Dụng',
    },
  ];

  // Helper to split breadcrumb paths
  const getBreadcrumbs = () => {
    if (isThisPC) {
      return [{ label: 'This PC', path: 'This PC', icon: 'Computer' }];
    }
    const crumbs: { label: string; path: string; icon?: string }[] = [
      { label: 'This PC', path: 'This PC', icon: 'Computer' },
    ];

    if (currentPath.startsWith('C:') || currentPath.startsWith('D:')) {
      const drive = currentPath.substring(0, 2);
      crumbs.push({
        label: drive === 'C:' ? 'Local Disk (C:)' : 'Data (D:)',
        path: drive,
        icon: 'HardDrive',
      });

      const rest = currentPath.substring(2).replace(/^[\\/]+/, '');
      if (rest) {
        const parts = rest.split(/[\\/]+/);
        let accPath = drive;
        parts.forEach((p) => {
          accPath += `\\${p}`;
          crumbs.push({
            label: p,
            path: accPath,
          });
        });
      }
    } else {
      crumbs.push({ label: currentPath, path: currentPath });
    }
    return crumbs;
  };

  return (
    <div
      className="h-full flex flex-col bg-white dark:bg-[#191919] text-slate-900 dark:text-slate-100 select-none overflow-hidden"
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragOver(true);
      }}
      onDragLeave={() => setIsDragOver(false)}
      onDrop={handleDrop}
    >
      {/* Hidden File Input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={(e) => e.target.files && processUploadFiles(e.target.files)}
        multiple
        className="hidden"
      />

      {/* Top Action Ribbon */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-slate-100 dark:bg-[#202020] border-b border-slate-200 dark:border-zinc-800 text-xs shrink-0">
        <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
          <button
            onClick={() => setIsAddAppModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-sky-500 hover:bg-sky-600 text-white font-medium shadow-sm transition-colors"
          >
            <Plus size={14} />
            <span>Thêm App HTML</span>
          </button>

          <button
            onClick={handleCreateFolder}
            disabled={isThisPC}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-800 transition-colors disabled:opacity-40"
          >
            <Folder size={14} className="text-amber-500" />
            <span>Thư mục mới</span>
          </button>

          <button
            onClick={handleCreateTextFile}
            disabled={isThisPC}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-800 transition-colors disabled:opacity-40"
          >
            <FileText size={14} className="text-sky-500" />
            <span>Tệp văn bản</span>
          </button>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-800 transition-colors"
          >
            <Upload size={14} className="text-emerald-500" />
            <span>Tải lên file</span>
          </button>

          {/* Paste button in toolbar */}
          <button
            onClick={() => pasteFile(isThisPC ? 'C:\\Users\\User\\Desktop' : currentPath)}
            disabled={!clipboard}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-800 transition-colors disabled:opacity-40"
            title="Dán tệp (Ctrl+V)"
          >
            <Clipboard size={14} className="text-amber-500" />
            <span>Dán</span>
          </button>
        </div>

        {/* View Mode */}
        <div className="flex items-center gap-1 bg-slate-200 dark:bg-zinc-800 p-0.5 rounded-lg border border-slate-300 dark:border-zinc-700 shrink-0">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-1 rounded ${
              viewMode === 'grid'
                ? 'bg-white dark:bg-zinc-700 shadow-sm text-sky-500 font-bold'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
            title={t.largeIcons}
          >
            <LayoutGrid size={14} />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`p-1 rounded ${
              viewMode === 'list'
                ? 'bg-white dark:bg-zinc-700 shadow-sm text-sky-500 font-bold'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
            title={t.view}
          >
            <List size={14} />
          </button>
        </div>
      </div>

      {/* Address & Navigation Bar */}
      <div className="flex items-center gap-2 px-3 py-2 bg-slate-50 dark:bg-[#1e1e1e] border-b border-slate-200 dark:border-zinc-800 text-xs shrink-0">
        <div className="flex items-center gap-1">
          <button
            onClick={handleBack}
            disabled={historyIndex === 0}
            className="p-1.5 rounded-md hover:bg-slate-200 dark:hover:bg-zinc-700 disabled:opacity-30 transition-colors"
            title="Quay lại"
          >
            <ChevronLeft size={16} />
          </button>
          <button
            onClick={handleForward}
            disabled={historyIndex >= history.length - 1}
            className="p-1.5 rounded-md hover:bg-slate-200 dark:hover:bg-zinc-700 disabled:opacity-30 transition-colors"
            title="Tiến tới"
          >
            <ChevronRight size={16} />
          </button>
          <button
            onClick={handleUp}
            disabled={isThisPC}
            className="p-1.5 rounded-md hover:bg-slate-200 dark:hover:bg-zinc-700 disabled:opacity-30 transition-colors"
            title="Lên cấp thư mục trên"
          >
            <ChevronUp size={16} />
          </button>
          <button
            onClick={() => {
              setSelectedItem(null);
              addNotification('Làm mới', 'Đã làm mới danh sách thư mục', 'explorer');
            }}
            className="p-1.5 rounded-md hover:bg-slate-200 dark:hover:bg-zinc-700 transition-colors"
            title="Làm mới (F5)"
          >
            <RotateCw size={14} />
          </button>
        </div>

        {/* Windows 11 Address Bar (Breadcrumb + Text Input with Blue Selection + Right Click Menu) */}
        <div
          onContextMenu={handleAddressBarContextMenu}
          className="flex-1 flex items-center h-8 px-2 bg-white dark:bg-zinc-900 rounded-lg border border-slate-300 dark:border-zinc-700 focus-within:border-sky-500 focus-within:ring-1 focus-within:ring-sky-500 font-sans text-xs overflow-hidden relative cursor-text group"
          onClick={() => {
            if (!isEditingAddress) {
              setIsEditingAddress(true);
            }
          }}
        >
          {isEditingAddress ? (
            <div className="w-full flex items-center gap-1.5">
              {isThisPC ? (
                <Computer size={14} className="text-sky-500 shrink-0" />
              ) : (
                <HardDrive size={13} className="text-sky-500 shrink-0" />
              )}
              <input
                ref={addressInputRef}
                type="text"
                value={addressInput}
                onChange={(e) => setAddressInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    navigateTo(addressInput);
                  } else if (e.key === 'Escape') {
                    setAddressInput(currentPath);
                    setIsEditingAddress(false);
                  }
                }}
                onBlur={() => {
                  setTimeout(() => {
                    setIsEditingAddress(false);
                  }, 150);
                }}
                className="flex-1 bg-transparent outline-none text-xs text-slate-900 dark:text-slate-100 font-sans selection:bg-blue-600 selection:text-white"
                placeholder="Nhập đường dẫn (ví dụ: C:\Windows, C:\Apps, This PC)..."
                autoFocus
              />
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  navigateTo(addressInput);
                }}
                className="p-1 hover:bg-slate-200 dark:hover:bg-zinc-700 rounded text-sky-500"
                title="Đi đến đường dẫn này"
              >
                <ArrowRight size={14} />
              </button>
            </div>
          ) : (
            <div className="w-full flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5">
              {getBreadcrumbs().map((crumb, idx, arr) => (
                <React.Fragment key={crumb.path}>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      navigateTo(crumb.path);
                    }}
                    className="flex items-center gap-1 px-1.5 py-0.5 rounded hover:bg-slate-200/80 dark:hover:bg-zinc-800 text-slate-700 dark:text-zinc-200 font-medium shrink-0 transition-colors"
                  >
                    {crumb.icon === 'Computer' && <Computer size={13} className="text-sky-500" />}
                    {crumb.icon === 'HardDrive' && <HardDrive size={13} className="text-sky-500" />}
                    <span>{crumb.label}</span>
                  </button>
                  {idx < arr.length - 1 && (
                    <ChevronRight size={12} className="text-slate-400 shrink-0" />
                  )}
                </React.Fragment>
              ))}
              {/* Empty clickable space to trigger text edit */}
              <div
                className="flex-1 min-w-[20px] h-full"
                onClick={() => setIsEditingAddress(true)}
              />
            </div>
          )}
        </div>

        {/* Search Bar */}
        <div className="w-48 sm:w-56 flex items-center px-2.5 py-1.5 bg-white dark:bg-zinc-900 rounded-lg border border-slate-300 dark:border-zinc-700 shrink-0">
          <Search size={13} className="text-slate-400 mr-2 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isThisPC ? 'Tìm kiếm trong This PC' : t.searchInFolder}
            className="w-full bg-transparent focus:outline-none text-xs text-slate-800 dark:text-slate-100"
          />
        </div>
      </div>

      {/* Main Body */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Drag Overlay indicator */}
        {isDragOver && (
          <div className="absolute inset-0 z-50 bg-sky-500/20 backdrop-blur-sm border-2 border-dashed border-sky-500 flex flex-col items-center justify-center text-sky-600 dark:text-sky-300 font-bold text-sm pointer-events-none">
            <Upload size={48} className="mb-2 animate-bounce" />
            <span>Thả file vào đây để lưu trữ</span>
          </div>
        )}

        {/* Sidebar Navigation Tree */}
        <div className="w-56 bg-slate-50/60 dark:bg-[#181818] border-r border-slate-200 dark:border-zinc-800 p-2.5 overflow-y-auto space-y-1 text-xs shrink-0">
          <div className="text-[11px] font-semibold text-slate-400 px-2 py-1 uppercase tracking-wider">
            {t.quickAccess}
          </div>

          <button
            onClick={() => navigateTo('C:\\Apps')}
            className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left transition-colors font-medium ${
              currentPath === 'C:\\Apps'
                ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400'
                : 'hover:bg-slate-200 dark:hover:bg-zinc-800'
            }`}
          >
            <LayoutGrid size={15} className="text-sky-500" />
            <span>{t.appsFolder}</span>
          </button>

          <button
            onClick={() => navigateTo('C:\\Users\\User\\Desktop')}
            className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left transition-colors ${
              currentPath === 'C:\\Users\\User\\Desktop'
                ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 font-medium'
                : 'hover:bg-slate-200 dark:hover:bg-zinc-800'
            }`}
          >
            <Monitor size={15} className="text-blue-500" />
            <span>Desktop</span>
          </button>

          <button
            onClick={() => navigateTo('C:\\Users\\User\\Documents')}
            className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left transition-colors ${
              currentPath === 'C:\\Users\\User\\Documents'
                ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 font-medium'
                : 'hover:bg-slate-200 dark:hover:bg-zinc-800'
            }`}
          >
            <FileText size={15} className="text-amber-500" />
            <span>{t.documents}</span>
          </button>

          <button
            onClick={() => navigateTo('C:\\Users\\User\\Downloads')}
            className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left transition-colors ${
              currentPath === 'C:\\Users\\User\\Downloads'
                ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 font-medium'
                : 'hover:bg-slate-200 dark:hover:bg-zinc-800'
            }`}
          >
            <Download size={15} className="text-emerald-500" />
            <span>{t.downloads}</span>
          </button>

          <button
            onClick={() => navigateTo('C:\\Users\\User\\Pictures')}
            className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left transition-colors ${
              currentPath === 'C:\\Users\\User\\Pictures'
                ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 font-medium'
                : 'hover:bg-slate-200 dark:hover:bg-zinc-800'
            }`}
          >
            <Image size={15} className="text-purple-500" />
            <span>{t.pictures}</span>
          </button>

          {/* Dynamic Pinned Folders */}
          {pinnedFolders.filter((p) => !['C:\\Apps', 'C:\\Users\\User\\Desktop', 'C:\\Users\\User\\Documents', 'C:\\Users\\User\\Downloads', 'C:\\Users\\User\\Pictures'].includes(p)).map((pinned) => (
            <div key={pinned} className="flex items-center group">
              <button
                onClick={() => navigateTo(pinned)}
                className={`flex-1 flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left transition-colors truncate ${
                  currentPath === pinned
                    ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 font-medium'
                    : 'hover:bg-slate-200 dark:hover:bg-zinc-800'
                }`}
              >
                <Pin size={13} className="text-sky-500 shrink-0" />
                <span className="truncate">{pinned.split(/[\\/]/).pop() || pinned}</span>
              </button>
              <button
                onClick={() => unpinFolder(pinned)}
                className="opacity-0 group-hover:opacity-100 p-1 hover:bg-slate-200 dark:hover:bg-zinc-700 rounded text-slate-400"
                title="Bỏ ghim"
              >
                <PinOff size={12} />
              </button>
            </div>
          ))}

          {/* This PC Section */}
          <div className="text-[11px] font-semibold text-slate-400 px-2 pt-3 pb-1 uppercase tracking-wider flex items-center justify-between">
            <span>This PC (100%)</span>
            <Computer size={12} className="text-sky-500" />
          </div>

          <button
            onClick={() => navigateTo('This PC')}
            className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left transition-colors font-medium ${
              currentPath === 'This PC'
                ? 'bg-sky-500/20 text-sky-600 dark:text-sky-400'
                : 'hover:bg-slate-200 dark:hover:bg-zinc-800'
            }`}
          >
            <Computer size={15} className="text-sky-600 dark:text-sky-400" />
            <span>This PC</span>
          </button>

          <div className="pl-3 space-y-0.5 border-l border-slate-200 dark:border-zinc-800 ml-3">
            <button
              onClick={() => navigateTo('C:')}
              onContextMenu={(e) => handleDriveContextMenu(e, 'C')}
              className={`w-full flex items-center gap-2 px-2 py-1 rounded text-left text-[11px] transition-colors ${
                currentPath.startsWith('C:') && currentPath !== 'C:\\Apps' && !currentPath.includes('Users')
                  ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 font-medium'
                  : 'hover:bg-slate-200 dark:hover:bg-zinc-800 text-slate-600 dark:text-zinc-400'
              }`}
            >
              <HardDrive size={13} className="text-sky-500" />
              <span className="truncate">Local Disk (C:)</span>
            </button>

            <button
              onClick={() => navigateTo('D:')}
              onContextMenu={(e) => handleDriveContextMenu(e, 'D')}
              className={`w-full flex items-center gap-2 px-2 py-1 rounded text-left text-[11px] transition-colors ${
                currentPath.startsWith('D:')
                  ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 font-medium'
                  : 'hover:bg-slate-200 dark:hover:bg-zinc-800 text-slate-600 dark:text-zinc-400'
              }`}
            >
              <Database size={13} className="text-emerald-500" />
              <span className="truncate">Data (D:)</span>
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div
          className="flex-1 flex flex-col p-4 overflow-y-auto"
          onClick={() => setSelectedItem(null)}
          onContextMenu={handleContentBackgroundContextMenu}
        >
          {/* ========================================================= */}
          {/* 100% WORKING "THIS PC" VIEW */}
          {/* ========================================================= */}
          {isThisPC ? (
            <div className="space-y-6">
              {/* Folders Group */}
              <div>
                <h4 className="text-xs font-bold text-slate-700 dark:text-zinc-300 mb-3 flex items-center gap-2 uppercase tracking-wider">
                  <Folder size={14} className="text-amber-500" />
                  <span>Thư mục người dùng (Folders)</span>
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-3">
                  {thisPCFolders.map((folder) => {
                    const matchedFsItem = fileSystem.find((f) => f.path.toLowerCase() === folder.path.toLowerCase()) || {
                      id: folder.id,
                      name: folder.name,
                      path: folder.path,
                      isDirectory: true,
                      owner: 'User',
                    };

                    return (
                      <div
                        key={folder.id}
                        onClick={() => navigateTo(folder.path)}
                        onContextMenu={(e) => {
                          e.preventDefault();
                          handleItemContextMenu({ x: e.clientX, y: e.clientY }, matchedFsItem);
                        }}
                        className="group flex flex-col items-center p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/40 hover:bg-sky-500/10 border border-slate-200/80 dark:border-zinc-700/60 hover:border-sky-500/40 transition-all cursor-pointer select-none text-center shadow-xs"
                      >
                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${folder.color} text-white flex items-center justify-center shadow-sm mb-2 group-hover:scale-105 transition-transform`}>
                          <IconRenderer name={folder.icon} size={24} />
                        </div>
                        <span className="text-xs font-semibold text-slate-800 dark:text-slate-100">
                          {folder.name}
                        </span>
                        <span className="text-[10px] text-slate-400 mt-0.5 truncate max-w-full">
                          {folder.tag}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Devices and Drives Group */}
              <div>
                <h4 className="text-xs font-bold text-slate-700 dark:text-zinc-300 mb-3 flex items-center gap-2 uppercase tracking-wider">
                  <HardDrive size={14} className="text-sky-500" />
                  <span>Thiết bị và ổ đĩa (Devices and drives)</span>
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Local Disk (C:) */}
                  <div
                    onClick={() => navigateTo('C:')}
                    onContextMenu={(e) => handleDriveContextMenu(e, 'C')}
                    className="flex items-center gap-4 p-4 rounded-xl bg-slate-50 dark:bg-zinc-800/50 hover:bg-sky-500/10 border border-slate-200 dark:border-zinc-700/80 hover:border-sky-500/50 transition-all cursor-pointer select-none shadow-xs group"
                  >
                    <div className="relative p-3 rounded-xl bg-gradient-to-br from-blue-500 to-sky-600 text-white shadow-md group-hover:scale-105 transition-transform shrink-0">
                      <HardDrive size={32} />
                      <span className="absolute -bottom-1 -right-1 px-1 py-0.2 bg-blue-700 text-[9px] font-black rounded text-white border border-white/20">
                        OS
                      </span>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-xs text-slate-900 dark:text-slate-100">
                          Local Disk (C:)
                        </span>
                        <span className="text-[11px] font-medium text-slate-500 dark:text-zinc-400">
                          185 GB trống / 256 GB
                        </span>
                      </div>

                      {/* Windows 11 Storage Bar */}
                      <div className="w-full h-3 bg-slate-200 dark:bg-zinc-700 rounded-full mt-2 overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-sky-500 to-blue-600 rounded-full transition-all"
                          style={{ width: '28%' }}
                        />
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
                        <span>Hệ điều hành Windows 11</span>
                        <span>Định dạng NTFS</span>
                      </div>
                    </div>
                  </div>

                  {/* Data (D:) */}
                  <div
                    onClick={() => navigateTo('D:')}
                    onContextMenu={(e) => handleDriveContextMenu(e, 'D')}
                    className="flex items-center gap-4 p-4 rounded-xl bg-slate-50 dark:bg-zinc-800/50 hover:bg-emerald-500/10 border border-slate-200 dark:border-zinc-700/80 hover:border-emerald-500/50 transition-all cursor-pointer select-none shadow-xs group"
                  >
                    <div className="relative p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-md group-hover:scale-105 transition-transform shrink-0">
                      <Database size={32} />
                      <span className="absolute -bottom-1 -right-1 px-1 py-0.2 bg-emerald-700 text-[9px] font-black rounded text-white border border-white/20">
                        DATA
                      </span>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-xs text-slate-900 dark:text-slate-100">
                          Data (D:)
                        </span>
                        <span className="text-[11px] font-medium text-slate-500 dark:text-zinc-400">
                          412 GB trống / 512 GB
                        </span>
                      </div>

                      {/* Storage Bar */}
                      <div className="w-full h-3 bg-slate-200 dark:bg-zinc-700 rounded-full mt-2 overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-emerald-500 to-teal-600 rounded-full transition-all"
                          style={{ width: '19.5%' }}
                        />
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
                        <span>Lưu trữ tài liệu và tệp đa phương tiện</span>
                        <span>Định dạng NTFS</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <>
              {/* Apps Folder Welcome Banner */}
              {isAppsFolder && (
                <div className="mb-4 p-4 rounded-2xl bg-gradient-to-r from-sky-500/15 via-blue-500/10 to-purple-500/15 border border-sky-500/30 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-3 rounded-xl bg-sky-500 text-white shadow-md">
                      <LayoutGrid size={24} />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-sky-700 dark:text-sky-300">
                        Thư mục Ứng Dụng HTML (C:\Apps)
                      </h3>
                      <p className="text-xs text-slate-600 dark:text-zinc-300 mt-0.5">
                        Kéo thả file <b>.html</b> từ máy tính vào đây hoặc bấm nút "Thêm App HTML" để chạy ngay!
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setIsAddAppModalOpen(true)}
                    className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl text-xs transition-all shadow-sm shrink-0 flex items-center gap-1.5"
                  >
                    <Plus size={15} />
                    <span>Thêm App Mới</span>
                  </button>
                </div>
              )}

              {/* Empty Folder State */}
              {items.length === 0 && (
                <div className="flex-1 flex flex-col items-center justify-center text-slate-400 py-12">
                  <FolderTree size={48} className="opacity-30 mb-3" />
                  <p className="text-sm font-semibold">Thư mục này hiện đang trống</p>
                  <p className="text-xs mt-1">Kéo thả file vào đây hoặc bấm chuột phải để tạo mới</p>
                </div>
              )}

              {/* Grid View Mode */}
              {viewMode === 'grid' && (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
                  {items.map((item) => (
                    <FileExplorerGridItem
                      key={item.id}
                      item={item}
                      isSelected={selectedItem?.id === item.id}
                      onSelect={() => setSelectedItem(item)}
                      onOpen={() => handleItemOpen(item)}
                      onContextMenuTrigger={(coords) => handleItemContextMenu(coords, item)}
                    />
                  ))}
                </div>
              )}

              {/* List View Mode */}
              {viewMode === 'list' && (
                <div className="divide-y divide-slate-200 dark:divide-zinc-800 text-xs">
                  <div className="grid grid-cols-12 py-2 px-3 text-slate-400 font-semibold text-[11px]">
                    <div className="col-span-6">Tên</div>
                    <div className="col-span-3">Loại</div>
                    <div className="col-span-3 text-right">Kích thước</div>
                  </div>

                  {items.map((item) => (
                    <FileExplorerListItem
                      key={item.id}
                      item={item}
                      isSelected={selectedItem?.id === item.id}
                      onSelect={() => setSelectedItem(item)}
                      onOpen={() => handleItemOpen(item)}
                      onContextMenuTrigger={(coords) => handleItemContextMenu(coords, item)}
                    />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Status Bar */}
      <div className="flex items-center justify-between px-4 py-1.5 bg-slate-100 dark:bg-[#202020] border-t border-slate-200 dark:border-zinc-800 text-[11px] text-slate-500 dark:text-zinc-400">
        <div>{isThisPC ? 'This PC — 2 Ổ đĩa, 7 Thư mục' : `${items.length} mục trong thư mục`}</div>
        <div>
          {selectedItem
            ? `Đã chọn: ${selectedItem.name} ${
                selectedItem.size !== undefined ? `(${(selectedItem.size / 1024).toFixed(1)} KB)` : ''
              }`
            : ''}
        </div>
      </div>
    </div>
  );
};

// Sub-component for Grid Item
interface FileItemProps {
  item: FileSystemItem;
  isSelected: boolean;
  onSelect: () => void;
  onOpen: () => void;
  onContextMenuTrigger: (coords: { x: number; y: number }) => void;
}

const FileExplorerGridItem: React.FC<FileItemProps> = ({
  item,
  isSelected,
  onSelect,
  onOpen,
  onContextMenuTrigger,
}) => {
  const isHtml = item.isHtmlApp || item.name.endsWith('.html') || item.name.endsWith('.htm');
  const displayName = item.appMetadata?.title || item.name;
  const lastTapTimeRef = React.useRef<number>(0);

  const { touchProps, isTriggeredRef } = useContextMenuTrigger({
    onTrigger: (coords) => {
      onSelect();
      onContextMenuTrigger(coords);
    },
  });

  const handleClick = (e: React.MouseEvent | React.TouchEvent) => {
    e.stopPropagation();
    if (isTriggeredRef.current) return;

    const now = Date.now();
    const timeSinceLastTap = now - lastTapTimeRef.current;
    lastTapTimeRef.current = now;

    if (timeSinceLastTap < 400 || isSelected) {
      onOpen();
    } else {
      onSelect();
    }
  };

  return (
    <div
      {...touchProps}
      onClick={handleClick}
      onDoubleClick={(e) => {
        e.stopPropagation();
        onOpen();
      }}
      className={`flex flex-col items-center p-3 rounded-xl cursor-pointer transition-all border touch-manipulation select-none active:scale-95 ${
        isSelected
          ? 'bg-sky-500/20 border-sky-500/50 shadow-sm'
          : 'border-transparent hover:bg-slate-200/60 dark:hover:bg-zinc-800/60'
      }`}
    >
      <div className="relative p-2 rounded-xl mb-1 flex items-center justify-center pointer-events-none">
        {item.isDirectory ? (
          <Folder size={42} className="text-amber-500 fill-amber-500/30" />
        ) : isHtml ? (
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-sky-500 to-indigo-600 text-white flex items-center justify-center shadow-md">
            <IconRenderer name={item.icon || 'Gamepad2'} size={24} />
          </div>
        ) : (item.icon === 'Image' || /\.(gif|png|jpe?g|webp|svg|bmp|ico|avif)$/i.test(item.name)) && item.content ? (
          <div className="w-11 h-11 rounded-lg overflow-hidden border border-slate-300 dark:border-zinc-700 shadow-sm bg-black/10 flex items-center justify-center relative">
            <img src={item.content} alt={item.name} className="w-full h-full object-cover" />
            {item.name.toLowerCase().endsWith('.gif') && (
              <span className="absolute bottom-0 right-0 bg-purple-600 text-white text-[8px] font-bold px-1 rounded-tl leading-none">
                GIF
              </span>
            )}
          </div>
        ) : (
          <IconRenderer name={item.icon || 'FileText'} size={40} className="text-sky-500" />
        )}

        {isHtml && (
          <span className="absolute -bottom-1 -right-1 px-1 py-0.2 bg-emerald-500 text-white text-[9px] font-bold rounded shadow">
            HTML
          </span>
        )}
      </div>

      <span
        className="text-xs text-center font-medium line-clamp-2 break-all max-w-full px-1 pointer-events-none"
        title={displayName}
      >
        {displayName}
      </span>

      {item.size !== undefined && (
        <span className="text-[10px] text-slate-400 mt-0.5 pointer-events-none">
          {(item.size / 1024).toFixed(1)} KB
        </span>
      )}
    </div>
  );
};

// Sub-component for List Item
const FileExplorerListItem: React.FC<FileItemProps> = ({
  item,
  isSelected,
  onSelect,
  onOpen,
  onContextMenuTrigger,
}) => {
  const isHtml = item.isHtmlApp || item.name.endsWith('.html') || item.name.endsWith('.htm');
  const displayName = item.appMetadata?.title || item.name;
  const lastTapTimeRef = React.useRef<number>(0);

  const { touchProps, isTriggeredRef } = useContextMenuTrigger({
    onTrigger: (coords) => {
      onSelect();
      onContextMenuTrigger(coords);
    },
  });

  const handleClick = (e: React.MouseEvent | React.TouchEvent) => {
    e.stopPropagation();
    if (isTriggeredRef.current) return;

    const now = Date.now();
    const timeSinceLastTap = now - lastTapTimeRef.current;
    lastTapTimeRef.current = now;

    if (timeSinceLastTap < 400 || isSelected) {
      onOpen();
    } else {
      onSelect();
    }
  };

  return (
    <div
      {...touchProps}
      onClick={handleClick}
      onDoubleClick={(e) => {
        e.stopPropagation();
        onOpen();
      }}
      className={`grid grid-cols-12 items-center py-2 px-3 rounded-lg cursor-pointer transition-colors touch-manipulation select-none ${
        isSelected
          ? 'bg-sky-500/20 text-sky-600 dark:text-sky-400 font-semibold'
          : 'hover:bg-slate-100 dark:hover:bg-zinc-800/60'
      }`}
    >
      <div className="col-span-6 flex items-center gap-2.5 truncate pointer-events-none">
        {item.isDirectory ? (
          <Folder size={18} className="text-amber-500" />
        ) : isHtml ? (
          <div className="p-1 rounded bg-sky-500 text-white">
            <IconRenderer name={item.icon || 'Gamepad2'} size={14} />
          </div>
        ) : (
          <IconRenderer name={item.icon || 'FileText'} size={18} className="text-sky-500" />
        )}
        <span className="truncate">{displayName}</span>
      </div>

      <div className="col-span-3 text-slate-500 dark:text-zinc-400 pointer-events-none">
        {item.isDirectory ? 'Thư mục' : isHtml ? 'Ứng dụng HTML' : 'Tệp văn bản'}
      </div>

      <div className="col-span-3 text-right text-slate-400 font-mono text-[11px] pointer-events-none">
        {item.size !== undefined ? `${(item.size / 1024).toFixed(1)} KB` : '--'}
      </div>
    </div>
  );
};
