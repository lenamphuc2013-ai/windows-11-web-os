import React, { useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';

interface WinverDialogProps {
  windowId?: string;
}

export const WinverDialog: React.FC<WinverDialogProps> = ({ windowId }) => {
  const { closeWindow, windows } = useOS();
  const okButtonRef = useRef<HTMLButtonElement>(null);
  const isMountedRef = useRef(false);

  const handleClose = () => {
    if (windowId) {
      closeWindow(windowId);
    } else {
      const winverWin = windows.find((w) => w.appId === 'winver');
      if (winverWin) closeWindow(winverWin.id);
    }
  };

  useEffect(() => {
    // Small delay before enabling keyboard shortcut closing to prevent catching initial Enter from terminal/run
    const timer = setTimeout(() => {
      isMountedRef.current = true;
      okButtonRef.current?.focus();
    }, 150);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isMountedRef.current) return;
      if (e.key === 'Escape') {
        e.preventDefault();
        handleClose();
      } else if ((e.key === 'Enter' || e.key === ' ') && document.activeElement === okButtonRef.current) {
        e.preventDefault();
        handleClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [windowId, windows]);

  return (
    <div
      tabIndex={-1}
      className="w-full h-full bg-[#fbfbfb] dark:bg-[#202020] text-slate-800 dark:text-slate-100 flex flex-col justify-between p-6 select-none font-sans text-xs leading-relaxed outline-none"
    >
      {/* Top Banner / Logo & Product Title */}
      <div className="space-y-4">
        <div className="flex items-center gap-5 pt-1">
          {/* Windows 11 Official 4-square Logo */}
          <div className="w-14 h-14 shrink-0 grid grid-cols-2 gap-1.5 p-1 bg-transparent">
            <div className="bg-[#0078d4] rounded-[2px] shadow-sm" />
            <div className="bg-[#0078d4] rounded-[2px] shadow-sm" />
            <div className="bg-[#0078d4] rounded-[2px] shadow-sm" />
            <div className="bg-[#0078d4] rounded-[2px] shadow-sm" />
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-light tracking-tight text-slate-900 dark:text-white">Windows</span>
              <span className="text-3xl font-bold tracking-tight text-[#0078d4]">11</span>
              <span className="text-sm font-normal text-slate-500 dark:text-zinc-400 ml-1">Pro</span>
            </div>
            <p className="text-[11.5px] text-slate-500 dark:text-zinc-400 mt-0.5">
              Hệ điều hành Microsoft Windows 11 Pro
            </p>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-slate-300/80 dark:bg-white/10 w-full" />

        {/* System & Build Information */}
        <div className="space-y-2.5 text-[11.5px] text-slate-700 dark:text-slate-200">
          <p className="font-bold text-slate-900 dark:text-white text-[12px]">
            Microsoft Windows
          </p>
          <p>
            Phiên bản 23H2 (Bản dựng HĐH 22631.3296)
          </p>
          <p className="text-slate-500 dark:text-zinc-400 text-[11px]">
            © Microsoft Corporation. Bảo lưu mọi quyền (All rights reserved).
          </p>
          <p className="text-[11px] leading-normal text-slate-600 dark:text-zinc-300 pt-1">
            Hệ điều hành Windows 11 Pro và giao diện người dùng của nó được bảo vệ bởi nhãn hiệu thương mại và các quyền sở hữu trí tuệ đang chờ cấp bằng sáng chế hoặc hiện có tại Hoa Kỳ và các quốc gia/khu vực khác.
          </p>
        </div>

        {/* Licensing Information */}
        <div className="pt-2.5 border-t border-slate-200 dark:border-white/10 space-y-1.5 text-[11px]">
          <p className="text-slate-600 dark:text-zinc-300">
            Sản phẩm này được cấp phép theo Điều khoản Cấp phép Phần mềm Microsoft cho:
          </p>
          <div className="pl-3 py-1 space-y-0.5 font-medium text-slate-800 dark:text-slate-100">
            <p>Người dùng (User): <span className="font-semibold text-[#0078d4]">User</span></p>
            <p className="text-slate-500 dark:text-zinc-400 text-[10.5px]">Tổ chức (Organization): Microsoft Corporation / Personal Device</p>
          </div>
        </div>
      </div>

      {/* Bottom Actions (OK button) */}
      <div className="flex justify-end pt-3 border-t border-slate-200 dark:border-white/10">
        <button
          ref={okButtonRef}
          onClick={handleClose}
          className="min-w-[96px] px-5 py-1.5 rounded-md bg-[#0067c0] hover:bg-[#0078d4] active:bg-[#005a9e] text-white font-medium text-xs shadow-sm hover:shadow transition-all focus:outline-none focus:ring-2 focus:ring-[#0078d4]/50 cursor-pointer"
        >
          OK
        </button>
      </div>
    </div>
  );
};
