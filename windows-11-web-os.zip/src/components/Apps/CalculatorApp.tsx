import React, { useState } from 'react';
import { History, Delete, RotateCcw } from 'lucide-react';

export const CalculatorApp: React.FC = () => {
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');
  const [history, setHistory] = useState<{ eq: string; res: string }[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [newNumber, setNewNumber] = useState(true);

  const handleDigit = (d: string) => {
    if (newNumber || display === '0') {
      setDisplay(d);
      setNewNumber(false);
    } else {
      setDisplay(display + d);
    }
  };

  const handleDecimal = () => {
    if (newNumber) {
      setDisplay('0.');
      setNewNumber(false);
    } else if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const handleOperator = (op: string) => {
    setEquation(`${display} ${op} `);
    setNewNumber(true);
  };

  const handleCalculate = () => {
    if (!equation) return;
    try {
      const fullEq = equation + display;
      // Sanitize equation
      const sanitized = fullEq.replace(/×/g, '*').replace(/÷/g, '/');
      // eslint-disable-next-line no-eval
      const result = Function(`'use strict'; return (${sanitized})`)();
      const resStr = String(Number(result.toFixed(8)));

      setHistory((prev) => [{ eq: fullEq, res: resStr }, ...prev.slice(0, 15)]);
      setDisplay(resStr);
      setEquation('');
      setNewNumber(true);
    } catch (e) {
      setDisplay('Error');
      setNewNumber(true);
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setEquation('');
    setNewNumber(true);
  };

  const handleBackspace = () => {
    if (newNumber || display.length <= 1) {
      setDisplay('0');
      setNewNumber(true);
    } else {
      setDisplay(display.slice(0, -1));
    }
  };

  const handleUnary = (type: 'sqrt' | 'sqr' | 'inv' | 'neg' | 'percent') => {
    const val = parseFloat(display);
    if (isNaN(val)) return;
    let res = val;
    switch (type) {
      case 'sqrt':
        res = Math.sqrt(val);
        break;
      case 'sqr':
        res = val * val;
        break;
      case 'inv':
        res = 1 / val;
        break;
      case 'neg':
        res = -val;
        break;
      case 'percent':
        res = val / 100;
        break;
    }
    setDisplay(String(Number(res.toFixed(8))));
    setNewNumber(true);
  };

  return (
    <div className="flex flex-col w-full h-full bg-[#f3f3f3] dark:bg-[#202020] text-slate-800 dark:text-slate-100 select-none overflow-hidden text-xs">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-slate-200 dark:border-zinc-800">
        <span className="font-bold text-sm">Standard</span>
        <button
          onClick={() => setShowHistory(!showHistory)}
          className={`p-1.5 rounded-lg transition-colors ${
            showHistory ? 'bg-sky-500/20 text-sky-500' : 'hover:bg-slate-200 dark:hover:bg-zinc-700'
          }`}
          title="History"
        >
          <History size={16} />
        </button>
      </div>

      {/* Screen Display */}
      <div className="p-4 text-right flex flex-col justify-end bg-white/40 dark:bg-black/20 min-h-[90px]">
        <div className="text-slate-400 font-mono text-xs h-4 overflow-hidden">{equation}</div>
        <div className="text-3xl font-extrabold tracking-tight truncate font-mono text-slate-900 dark:text-white">
          {display}
        </div>
      </div>

      {/* Keypad or History */}
      {showHistory ? (
        <div className="flex-1 p-3 overflow-y-auto space-y-2">
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 pb-1 border-b border-slate-200 dark:border-zinc-800">
            <span>Calculation History</span>
            <button
              onClick={() => setHistory([])}
              className="text-red-500 hover:underline"
            >
              Clear
            </button>
          </div>
          {history.length === 0 ? (
            <div className="text-center text-slate-400 py-8 text-xs italic">There's no history yet</div>
          ) : (
            history.map((h, i) => (
              <div
                key={i}
                onClick={() => {
                  setDisplay(h.res);
                  setNewNumber(true);
                }}
                className="p-2 rounded-lg bg-white dark:bg-zinc-800/60 hover:bg-slate-100 dark:hover:bg-zinc-700/60 cursor-pointer text-right border border-slate-200 dark:border-zinc-700/40"
              >
                <div className="text-slate-400 font-mono text-[11px]">{h.eq} =</div>
                <div className="font-bold text-sm text-sky-600 dark:text-sky-400 font-mono">
                  {h.res}
                </div>
              </div>
            ))
          )}
        </div>
      ) : (
        <div className="flex-1 p-2 grid grid-cols-4 gap-1.5 font-semibold text-sm">
          {/* Row 1 */}
          <button
            onClick={() => handleUnary('percent')}
            className="p-2.5 rounded-lg bg-slate-200/70 dark:bg-zinc-800/80 hover:bg-slate-300 dark:hover:bg-zinc-700 active:scale-95 transition-all text-xs"
          >
            %
          </button>
          <button
            onClick={() => setDisplay('0')}
            className="p-2.5 rounded-lg bg-slate-200/70 dark:bg-zinc-800/80 hover:bg-slate-300 dark:hover:bg-zinc-700 active:scale-95 transition-all text-xs"
          >
            CE
          </button>
          <button
            onClick={handleClear}
            className="p-2.5 rounded-lg bg-slate-200/70 dark:bg-zinc-800/80 hover:bg-slate-300 dark:hover:bg-zinc-700 active:scale-95 transition-all text-xs"
          >
            C
          </button>
          <button
            onClick={handleBackspace}
            className="p-2.5 rounded-lg bg-slate-200/70 dark:bg-zinc-800/80 hover:bg-slate-300 dark:hover:bg-zinc-700 active:scale-95 transition-all flex items-center justify-center"
          >
            <Delete size={15} />
          </button>

          {/* Row 2 */}
          <button
            onClick={() => handleUnary('inv')}
            className="p-2.5 rounded-lg bg-slate-200/70 dark:bg-zinc-800/80 hover:bg-slate-300 dark:hover:bg-zinc-700 active:scale-95 transition-all text-xs"
          >
            1/x
          </button>
          <button
            onClick={() => handleUnary('sqr')}
            className="p-2.5 rounded-lg bg-slate-200/70 dark:bg-zinc-800/80 hover:bg-slate-300 dark:hover:bg-zinc-700 active:scale-95 transition-all text-xs"
          >
            x²
          </button>
          <button
            onClick={() => handleUnary('sqrt')}
            className="p-2.5 rounded-lg bg-slate-200/70 dark:bg-zinc-800/80 hover:bg-slate-300 dark:hover:bg-zinc-700 active:scale-95 transition-all text-xs"
          >
            √x
          </button>
          <button
            onClick={() => handleOperator('/')}
            className="p-2.5 rounded-lg bg-slate-200/70 dark:bg-zinc-800/80 hover:bg-slate-300 dark:hover:bg-zinc-700 active:scale-95 transition-all text-base"
          >
            ÷
          </button>

          {/* Digits 7 8 9 * */}
          <button
            onClick={() => handleDigit('7')}
            className="p-2.5 rounded-lg bg-white dark:bg-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-600 active:scale-95 transition-all shadow-sm"
          >
            7
          </button>
          <button
            onClick={() => handleDigit('8')}
            className="p-2.5 rounded-lg bg-white dark:bg-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-600 active:scale-95 transition-all shadow-sm"
          >
            8
          </button>
          <button
            onClick={() => handleDigit('9')}
            className="p-2.5 rounded-lg bg-white dark:bg-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-600 active:scale-95 transition-all shadow-sm"
          >
            9
          </button>
          <button
            onClick={() => handleOperator('*')}
            className="p-2.5 rounded-lg bg-slate-200/70 dark:bg-zinc-800/80 hover:bg-slate-300 dark:hover:bg-zinc-700 active:scale-95 transition-all text-base"
          >
            ×
          </button>

          {/* Digits 4 5 6 - */}
          <button
            onClick={() => handleDigit('4')}
            className="p-2.5 rounded-lg bg-white dark:bg-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-600 active:scale-95 transition-all shadow-sm"
          >
            4
          </button>
          <button
            onClick={() => handleDigit('5')}
            className="p-2.5 rounded-lg bg-white dark:bg-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-600 active:scale-95 transition-all shadow-sm"
          >
            5
          </button>
          <button
            onClick={() => handleDigit('6')}
            className="p-2.5 rounded-lg bg-white dark:bg-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-600 active:scale-95 transition-all shadow-sm"
          >
            6
          </button>
          <button
            onClick={() => handleOperator('-')}
            className="p-2.5 rounded-lg bg-slate-200/70 dark:bg-zinc-800/80 hover:bg-slate-300 dark:hover:bg-zinc-700 active:scale-95 transition-all text-base"
          >
            −
          </button>

          {/* Digits 1 2 3 + */}
          <button
            onClick={() => handleDigit('1')}
            className="p-2.5 rounded-lg bg-white dark:bg-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-600 active:scale-95 transition-all shadow-sm"
          >
            1
          </button>
          <button
            onClick={() => handleDigit('2')}
            className="p-2.5 rounded-lg bg-white dark:bg-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-600 active:scale-95 transition-all shadow-sm"
          >
            2
          </button>
          <button
            onClick={() => handleDigit('3')}
            className="p-2.5 rounded-lg bg-white dark:bg-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-600 active:scale-95 transition-all shadow-sm"
          >
            3
          </button>
          <button
            onClick={() => handleOperator('+')}
            className="p-2.5 rounded-lg bg-slate-200/70 dark:bg-zinc-800/80 hover:bg-slate-300 dark:hover:bg-zinc-700 active:scale-95 transition-all text-base"
          >
            +
          </button>

          {/* Row 5: +/- 0 . = */}
          <button
            onClick={() => handleUnary('neg')}
            className="p-2.5 rounded-lg bg-white dark:bg-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-600 active:scale-95 transition-all text-xs"
          >
            ⁺⁄₋
          </button>
          <button
            onClick={() => handleDigit('0')}
            className="p-2.5 rounded-lg bg-white dark:bg-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-600 active:scale-95 transition-all shadow-sm"
          >
            0
          </button>
          <button
            onClick={handleDecimal}
            className="p-2.5 rounded-lg bg-white dark:bg-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-600 active:scale-95 transition-all text-base"
          >
            .
          </button>
          <button
            onClick={handleCalculate}
            className="p-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-bold active:scale-95 transition-all text-base shadow"
          >
            =
          </button>
        </div>
      )}
    </div>
  );
};
