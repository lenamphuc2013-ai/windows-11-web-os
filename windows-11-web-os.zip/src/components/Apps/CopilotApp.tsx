import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { Sparkles, Send, Play, Check, Download, Bot, User } from 'lucide-react';

interface CopilotMessage {
  id: string;
  sender: 'user' | 'copilot';
  text: string;
  generatedApp?: {
    title: string;
    icon: string;
    code: string;
    category: string;
  };
}

export const CopilotApp: React.FC = () => {
  const { createHtmlApp, openApp, updateSettings, addNotification } = useOS();

  const [messages, setMessages] = useState<CopilotMessage[]>([
    {
      id: 'init-1',
      sender: 'copilot',
      text: 'Xin chào! Tôi là Windows Copilot. Tôi có thể giúp bạn tạo ứng dụng HTML mới, giải đáp thắc mắc về Windows 11, đổi hình nền hoặc viết mã theo yêu cầu!',
    },
  ]);
  const [inputVal, setInputVal] = useState('');
  const [installedApps, setInstalledApps] = useState<string[]>([]);

  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || inputVal).trim();
    if (!query) return;

    const userMsg: CopilotMessage = {
      id: 'u-' + Date.now(),
      sender: 'user',
      text: query,
    };
    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputVal('');
    setIsLoading(true);

    try {
      // Try Node.js server API
      const res = await fetch('/api/copilot/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: query }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.reply || data.generatedApp) {
          const copilotMsg: CopilotMessage = {
            id: 'c-' + Date.now(),
            sender: 'copilot',
            text: data.reply,
            generatedApp: data.generatedApp || undefined,
          };
          setMessages((prev) => [...prev, copilotMsg]);
          setIsLoading(false);
          return;
        }
      }
    } catch (e) {
      console.warn('Server Copilot API call failed, using built-in engine:', e);
    }

    // Built-in responsive Copilot engine fallback
    setTimeout(() => {
      let replyText = 'Tôi có thể hỗ trợ bạn điều đó!';
      let generatedApp: CopilotMessage['generatedApp'] = undefined;

      const lower = query.toLowerCase();

      if (lower.includes('game') || lower.includes('trò chơi') || lower.includes('space') || lower.includes('bắn súng')) {
        replyText = 'Tôi đã tạo xong cho bạn một mini game Space Defender bằng HTML5 Canvas và CSS. Bạn có thể bấm "Cài đặt & Chạy" ngay dưới đây!';
        generatedApp = {
          title: 'Space Defender',
          icon: 'Rocket',
          category: 'entertainment',
          code: `<!DOCTYPE html>
<html>
<head>
  <title>Space Defender</title>
  <style>
    body { background:#000; color:#fff; display:flex; flex-direction:column; align-items:center; justify-content:center; height:100vh; font-family:sans-serif; margin:0; overflow:hidden; }
    canvas { background:#050510; border:2px solid #38bdf8; border-radius:12px; }
  </style>
</head>
<body>
  <div style="font-size:18px; margin-bottom:8px; font-weight:bold; color:#38bdf8;">🚀 Space Defender | Score: <span id="s">0</span></div>
  <canvas id="c" width="400" height="500"></canvas>
  <script>
    const cv = document.getElementById('c'); const ctx = cv.getContext('2d');
    let ship = { x: 180, y: 440, w: 30, h: 30 };
    let bullets = [], enemies = [], score = 0;
    window.onmousemove = e => { const r = cv.getBoundingClientRect(); ship.x = e.clientX - r.left - 15; };
    window.onclick = () => { bullets.push({ x: ship.x + 13, y: ship.y, vy: -7 }); };
    setInterval(() => { enemies.push({ x: Math.random()*360, y: -20, vy: 2 }); }, 800);
    function loop() {
      ctx.fillStyle = '#050510'; ctx.fillRect(0,0,400,500);
      // Ship
      ctx.fillStyle = '#38bdf8'; ctx.beginPath(); ctx.moveTo(ship.x+15, ship.y); ctx.lineTo(ship.x, ship.y+30); ctx.lineTo(ship.x+30, ship.y+30); ctx.fill();
      // Bullets
      ctx.fillStyle = '#facc15';
      for(let i=bullets.length-1; i>=0; i--) {
        bullets[i].y += bullets[i].vy; ctx.fillRect(bullets[i].x, bullets[i].y, 4, 10);
        if(bullets[i].y < 0) bullets.splice(i, 1);
      }
      // Enemies
      for(let i=enemies.length-1; i>=0; i--) {
        let e = enemies[i]; e.y += e.vy;
        ctx.fillStyle = '#ef4444'; ctx.fillRect(e.x, e.y, 25, 25);
        for(let j=bullets.length-1; j>=0; j--) {
          let b = bullets[j];
          if(b.x > e.x && b.x < e.x+25 && b.y > e.y && b.y < e.y+25) {
            enemies.splice(i, 1); bullets.splice(j, 1);
            score += 10; document.getElementById('s').innerText = score; break;
          }
        }
      }
      requestAnimationFrame(loop);
    }
    loop();
  </script>
</body>
</html>`,
        };
      } else if (lower.includes('stopwatch') || lower.includes('đồng hồ') || lower.includes('timer')) {
        replyText = 'Đây là ứng dụng Đồng hồ bấm giờ & Đếm ngược (Stopwatch Studio) siêu đẹp cho bạn!';
        generatedApp = {
          title: 'Stopwatch Studio',
          icon: 'Clock',
          category: 'productivity',
          code: `<!DOCTYPE html>
<html>
<head>
  <style>
    body { background:#0f172a; color:#fff; display:flex; flex-direction:column; align-items:center; justify-content:center; height:100vh; font-family:sans-serif; }
    h1 { font-size:64px; font-mono:tabular-nums; color:#38bdf8; margin:16px 0; }
    button { padding:10px 24px; font-size:16px; font-weight:bold; border-radius:10px; border:none; cursor:pointer; margin:4px; }
  </style>
</head>
<body>
  <h2>⏱️ Stopwatch Win11</h2>
  <h1 id="d">00:00.00</h1>
  <div>
    <button style="background:#22c55e; color:#000;" onclick="start()">Start</button>
    <button style="background:#ef4444; color:#fff;" onclick="stop()">Stop</button>
    <button style="background:#334155; color:#fff;" onclick="reset()">Reset</button>
  </div>
  <script>
    let t=0, iv=null;
    function fmt(ms) {
      const s = Math.floor(ms/100)%60; const m = Math.floor(ms/6000); const cs = ms%100;
      return String(m).padStart(2,'0')+':'+String(s).padStart(2,'0')+'.'+String(cs).padStart(2,'0');
    }
    function start() { if(!iv) iv=setInterval(()=>{ t++; document.getElementById('d').innerText=fmt(t); }, 10); }
    function stop() { clearInterval(iv); iv=null; }
    function reset() { stop(); t=0; document.getElementById('d').innerText='00:00.00'; }
  </script>
</body>
</html>`,
        };
      } else if (lower.includes('dark') || lower.includes('tối') || lower.includes('theme')) {
        updateSettings({ theme: 'dark' });
        replyText = 'Đã chuyển đổi giao diện Windows 11 sang Dark Mode!';
      } else {
        replyText = `Cảm ơn bạn! Bạn có thể kéo thả bất kỳ file .html nào vào thư mục C:\\Apps hoặc gõ lệnh trong Terminal để trải nghiệm các tính năng mạnh mẽ của Windows 11.`;
      }

      const copilotMsg: CopilotMessage = {
        id: 'c-' + Date.now(),
        sender: 'copilot',
        text: replyText,
        generatedApp,
      };
      setMessages((prev) => [...prev, copilotMsg]);
      setIsLoading(false);
    }, 600);
  };

  const handleInstallApp = (app: NonNullable<CopilotMessage['generatedApp']>) => {
    const newFile = createHtmlApp(app.title, app.icon, app.code, app.category);
    setInstalledApps((prev) => [...prev, app.title]);
    openApp('app-runner', {
      filePath: newFile.path,
      appName: app.title,
    });
  };

  return (
    <div className="flex flex-col w-full h-full bg-slate-100 dark:bg-[#181818] text-slate-800 dark:text-slate-100 select-none overflow-hidden text-xs">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 bg-white dark:bg-[#222] border-b border-slate-200 dark:border-zinc-800 shadow-sm">
        <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-sky-400 text-white flex items-center justify-center shadow">
          <Sparkles size={18} />
        </div>
        <div>
          <h2 className="font-bold text-sm">Copilot Assistant</h2>
          <p className="text-[11px] text-slate-400">AI companion in Windows 11</p>
        </div>
      </div>

      {/* Chat Messages Log */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3.5 select-text">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex gap-2.5 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {m.sender === 'copilot' && (
              <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0">
                <Bot size={15} />
              </div>
            )}

            <div
              className={`p-3.5 rounded-2xl max-w-[85%] leading-relaxed ${
                m.sender === 'user'
                  ? 'bg-sky-600 text-white rounded-br-none shadow-sm'
                  : 'bg-white dark:bg-zinc-800 text-slate-800 dark:text-slate-100 rounded-bl-none border border-slate-200 dark:border-zinc-700/60 shadow-sm'
              }`}
            >
              <p>{m.text}</p>

              {/* Generated App Action Card */}
              {m.generatedApp && (
                <div className="mt-3 p-3 rounded-xl bg-slate-50 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-700 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-sky-500 text-white flex items-center justify-center font-bold">
                      🚀
                    </div>
                    <div>
                      <div className="font-bold text-xs">{m.generatedApp.title}</div>
                      <div className="text-[10px] text-slate-400">Tự động cài vào C:\Apps</div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleInstallApp(m.generatedApp!)}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all shadow flex items-center gap-1 shrink-0"
                  >
                    <Play size={12} />
                    <span>Cài đặt & Chạy</span>
                  </button>
                </div>
              )}
            </div>

            {m.sender === 'user' && (
              <div className="w-7 h-7 rounded-lg bg-sky-500/20 text-sky-600 flex items-center justify-center shrink-0">
                <User size={15} />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Suggested Prompts */}
      <div className="px-4 py-2 flex gap-1.5 overflow-x-auto">
        {[
          'Tạo game bắn súng HTML',
          'Tạo app đồng hồ đếm ngược',
          'Đổi giao diện Dark Mode',
        ].map((s, i) => (
          <button
            key={i}
            onClick={() => handleSend(s)}
            className="px-2.5 py-1 rounded-full bg-white dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 text-slate-600 dark:text-zinc-300 hover:border-sky-500 text-[11px] whitespace-nowrap transition-colors"
          >
            {s}
          </button>
        ))}
      </div>

      {/* Input Box */}
      <div className="p-3 bg-white dark:bg-[#222] border-t border-slate-200 dark:border-zinc-800">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2 bg-slate-100 dark:bg-zinc-800 px-3 py-2 rounded-2xl border border-slate-300 dark:border-zinc-700 focus-within:border-indigo-500"
        >
          <input
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            placeholder="Hỏi Copilot hoặc yêu cầu viết ứng dụng HTML..."
            className="flex-1 bg-transparent outline-none text-xs text-slate-800 dark:text-slate-100"
          />
          <button
            type="submit"
            disabled={!inputVal.trim()}
            className="p-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-30 text-white transition-colors"
          >
            <Send size={14} />
          </button>
        </form>
      </div>
    </div>
  );
};
