import React, { useState, useEffect } from 'react';
import {
  Shield,
  ShieldCheck,
  ShieldAlert,
  Lock,
  Wifi,
  Activity,
  HardDrive,
  UserCheck,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Play,
  FileText,
  Sliders,
} from 'lucide-react';
import { useOS } from '../../context/OSContext';

export const WindowsSecurityApp: React.FC = () => {
  const { addNotification } = useOS();
  const [activeTab, setActiveTab] = useState<'home' | 'virus' | 'firewall' | 'health'>('home');
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scannedFilesCount, setScannedFilesCount] = useState(0);
  const [lastScanTime, setLastScanTime] = useState('Today, 10:45 AM');
  const [realtimeProtection, setRealtimeProtection] = useState(true);
  const [cloudProtection, setCloudProtection] = useState(true);
  const [firewallPublic, setFirewallPublic] = useState(true);
  const [firewallPrivate, setFirewallPrivate] = useState(true);

  const startScan = (type: 'quick' | 'full') => {
    setIsScanning(true);
    setScanProgress(0);
    setScannedFilesCount(0);

    const total = type === 'quick' ? 1420 : 8930;
    const interval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsScanning(false);
          setLastScanTime('Just now');
          addNotification('Scan Completed', `Windows Defender found 0 threats. ${total} files scanned.`, 'security');
          return 100;
        }
        const next = prev + (type === 'quick' ? 8 : 4);
        setScannedFilesCount(Math.floor((next / 100) * total));
        return next > 100 ? 100 : next;
      });
    }, 200);
  };

  return (
    <div className="flex h-full bg-[#f3f3f3] dark:bg-[#202020] text-slate-800 dark:text-slate-100 select-none overflow-hidden font-sans">
      {/* Sidebar Navigation */}
      <div className="w-56 bg-slate-200/50 dark:bg-black/20 p-3 border-r border-black/5 dark:border-white/5 flex flex-col gap-1">
        <div className="px-3 py-2 text-xs font-bold text-slate-500 uppercase tracking-wider">
          Windows Security
        </div>

        <button
          onClick={() => setActiveTab('home')}
          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'home'
              ? 'bg-white dark:bg-white/15 text-sky-600 dark:text-sky-400 shadow-sm'
              : 'hover:bg-white/40 dark:hover:bg-white/5 text-slate-600 dark:text-slate-300'
          }`}
        >
          <ShieldCheck size={16} /> Security at a glance
        </button>

        <button
          onClick={() => setActiveTab('virus')}
          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'virus'
              ? 'bg-white dark:bg-white/15 text-sky-600 dark:text-sky-400 shadow-sm'
              : 'hover:bg-white/40 dark:hover:bg-white/5 text-slate-600 dark:text-slate-300'
          }`}
        >
          <Shield size={16} /> Virus & threat protection
        </button>

        <button
          onClick={() => setActiveTab('firewall')}
          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'firewall'
              ? 'bg-white dark:bg-white/15 text-sky-600 dark:text-sky-400 shadow-sm'
              : 'hover:bg-white/40 dark:hover:bg-white/5 text-slate-600 dark:text-slate-300'
          }`}
        >
          <Wifi size={16} /> Firewall & network
        </button>

        <button
          onClick={() => setActiveTab('health')}
          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'health'
              ? 'bg-white dark:bg-white/15 text-sky-600 dark:text-sky-400 shadow-sm'
              : 'hover:bg-white/40 dark:hover:bg-white/5 text-slate-600 dark:text-slate-300'
          }`}
        >
          <Activity size={16} /> Device performance & health
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 p-6 overflow-y-auto">
        {/* Home Tab */}
        {activeTab === 'home' && (
          <div className="max-w-3xl mx-auto flex flex-col gap-6">
            <div className="flex items-center gap-4 p-5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20">
              <div className="w-12 h-12 rounded-full bg-emerald-500 flex items-center justify-center text-white shadow-md">
                <CheckCircle2 size={28} />
              </div>
              <div>
                <h2 className="text-base font-bold text-emerald-800 dark:text-emerald-300">
                  No actions needed
                </h2>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                  Your device is being protected in real-time by Microsoft Defender Antivirus.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div
                onClick={() => setActiveTab('virus')}
                className="p-4 rounded-xl bg-white dark:bg-white/5 border border-black/5 dark:border-white/10 hover:shadow-md cursor-pointer transition-all flex items-start gap-3.5"
              >
                <div className="p-2.5 rounded-lg bg-sky-500/10 text-sky-500 mt-0.5">
                  <Shield size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-semibold">Virus & threat protection</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Last scan: {lastScanTime}. 0 threats found.
                  </p>
                  <span className="inline-flex items-center gap-1 text-[11px] text-emerald-500 font-semibold mt-2">
                    <CheckCircle2 size={12} /> Protected
                  </span>
                </div>
              </div>

              <div
                onClick={() => setActiveTab('firewall')}
                className="p-4 rounded-xl bg-white dark:bg-white/5 border border-black/5 dark:border-white/10 hover:shadow-md cursor-pointer transition-all flex items-start gap-3.5"
              >
                <div className="p-2.5 rounded-lg bg-indigo-500/10 text-indigo-500 mt-0.5">
                  <Wifi size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-semibold">Firewall & network protection</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Domain, Private and Public networks are protected.
                  </p>
                  <span className="inline-flex items-center gap-1 text-[11px] text-emerald-500 font-semibold mt-2">
                    <CheckCircle2 size={12} /> Active
                  </span>
                </div>
              </div>

              <div
                onClick={() => setActiveTab('health')}
                className="p-4 rounded-xl bg-white dark:bg-white/5 border border-black/5 dark:border-white/10 hover:shadow-md cursor-pointer transition-all flex items-start gap-3.5"
              >
                <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-500 mt-0.5">
                  <Activity size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-semibold">Device performance & health</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Storage capacity, battery life, and apps health check.
                  </p>
                  <span className="inline-flex items-center gap-1 text-[11px] text-emerald-500 font-semibold mt-2">
                    <CheckCircle2 size={12} /> Good condition
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-white dark:bg-white/5 border border-black/5 dark:border-white/10 flex items-start gap-3.5">
                <div className="p-2.5 rounded-lg bg-purple-500/10 text-purple-500 mt-0.5">
                  <Lock size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-semibold">Account protection</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Windows Hello authentication & Microsoft account security.
                  </p>
                  <span className="inline-flex items-center gap-1 text-[11px] text-emerald-500 font-semibold mt-2">
                    <CheckCircle2 size={12} /> Enabled
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Virus & Threat Protection Tab */}
        {activeTab === 'virus' && (
          <div className="max-w-2xl mx-auto flex flex-col gap-6">
            <div className="p-6 rounded-2xl bg-white dark:bg-white/5 border border-black/5 dark:border-white/10 shadow-sm">
              <h2 className="text-lg font-bold mb-1">Current threats</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
                No current threats. Last scan: {lastScanTime}
              </p>

              {isScanning ? (
                <div className="space-y-3 p-4 bg-sky-500/10 rounded-xl border border-sky-500/20">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-sky-600 dark:text-sky-400">Scanning files...</span>
                    <span>{scanProgress}%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-200 dark:bg-zinc-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-sky-500 transition-all duration-200"
                      style={{ width: `${scanProgress}%` }}
                    />
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Scanned: <span className="font-mono font-bold">{scannedFilesCount}</span> files
                  </p>
                </div>
              ) : (
                <div className="flex gap-3">
                  <button
                    onClick={() => startScan('quick')}
                    className="flex items-center gap-2 px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-xl text-xs font-semibold shadow transition-all active:scale-95"
                  >
                    <Play size={14} /> Quick scan
                  </button>
                  <button
                    onClick={() => startScan('full')}
                    className="px-4 py-2 bg-slate-200 dark:bg-zinc-800 hover:bg-slate-300 dark:hover:bg-zinc-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-semibold transition-all"
                  >
                    Full scan
                  </button>
                </div>
              )}
            </div>

            {/* Protection Settings */}
            <div className="p-6 rounded-2xl bg-white dark:bg-white/5 border border-black/5 dark:border-white/10 shadow-sm space-y-4">
              <h3 className="text-sm font-bold">Virus & threat protection settings</h3>

              <div className="flex items-center justify-between py-2 border-b border-black/5 dark:border-white/5">
                <div>
                  <div className="text-xs font-semibold">Real-time protection</div>
                  <div className="text-[11px] text-slate-400">
                    Locates and stops malware from installing or running.
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={realtimeProtection}
                  onChange={() => setRealtimeProtection(!realtimeProtection)}
                  className="w-5 h-5 accent-sky-500 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between py-2">
                <div>
                  <div className="text-xs font-semibold">Cloud-delivered protection</div>
                  <div className="text-[11px] text-slate-400">
                    Provides increased protection with cloud security intelligence.
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={cloudProtection}
                  onChange={() => setCloudProtection(!cloudProtection)}
                  className="w-5 h-5 accent-sky-500 cursor-pointer"
                />
              </div>
            </div>
          </div>
        )}

        {/* Firewall Tab */}
        {activeTab === 'firewall' && (
          <div className="max-w-2xl mx-auto flex flex-col gap-4">
            <div className="p-5 rounded-2xl bg-white dark:bg-white/5 border border-black/5 dark:border-white/10 shadow-sm flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold">Domain network</h3>
                <p className="text-xs text-slate-400 mt-0.5">Firewall is active and blocking unauthorized inbound traffic.</p>
              </div>
              <span className="text-xs font-bold text-emerald-500 bg-emerald-500/10 px-2.5 py-1 rounded-full">
                Active
              </span>
            </div>

            <div className="p-5 rounded-2xl bg-white dark:bg-white/5 border border-black/5 dark:border-white/10 shadow-sm flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold">Private network</h3>
                <p className="text-xs text-slate-400 mt-0.5">Firewall protection for your home or work Wi-Fi network.</p>
              </div>
              <input
                type="checkbox"
                checked={firewallPrivate}
                onChange={() => setFirewallPrivate(!firewallPrivate)}
                className="w-5 h-5 accent-sky-500 cursor-pointer"
              />
            </div>

            <div className="p-5 rounded-2xl bg-white dark:bg-white/5 border border-black/5 dark:border-white/10 shadow-sm flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold">Public network</h3>
                <p className="text-xs text-slate-400 mt-0.5">Firewall protection when connecting at cafes, airports, or hotels.</p>
              </div>
              <input
                type="checkbox"
                checked={firewallPublic}
                onChange={() => setFirewallPublic(!firewallPublic)}
                className="w-5 h-5 accent-sky-500 cursor-pointer"
              />
            </div>
          </div>
        )}

        {/* Device Health Tab */}
        {activeTab === 'health' && (
          <div className="max-w-2xl mx-auto space-y-3">
            <div className="p-4 rounded-xl bg-white dark:bg-white/5 border border-black/5 dark:border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <HardDrive size={20} className="text-sky-500" />
                <div>
                  <div className="text-xs font-bold">Storage capacity</div>
                  <div className="text-[11px] text-slate-400">128 GB free out of 512 GB (NVMe SSD)</div>
                </div>
              </div>
              <CheckCircle2 size={16} className="text-emerald-500" />
            </div>

            <div className="p-4 rounded-xl bg-white dark:bg-white/5 border border-black/5 dark:border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Activity size={20} className="text-emerald-500" />
                <div>
                  <div className="text-xs font-bold">Battery life & power</div>
                  <div className="text-[11px] text-slate-400">Optimized power profile enabled</div>
                </div>
              </div>
              <CheckCircle2 size={16} className="text-emerald-500" />
            </div>

            <div className="p-4 rounded-xl bg-white dark:bg-white/5 border border-black/5 dark:border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <ShieldCheck size={20} className="text-purple-500" />
                <div>
                  <div className="text-xs font-bold">Smart App Control</div>
                  <div className="text-[11px] text-slate-400">Blocking untrusted malicious executables</div>
                </div>
              </div>
              <CheckCircle2 size={16} className="text-emerald-500" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
