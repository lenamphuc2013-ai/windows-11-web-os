import React, { useState, useRef, useEffect } from 'react';
import { Camera, Video, RefreshCw, Sparkles, Image, Download, Check } from 'lucide-react';
import { useOS } from '../../context/OSContext';

export const CameraApp: React.FC = () => {
  const { addNotification, addFile } = useOS();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [hasCamera, setHasCamera] = useState<boolean>(true);
  const [filter, setFilter] = useState<string>('none');
  const [capturedPhotos, setCapturedPhotos] = useState<string[]>([]);
  const [isCapturing, setIsCapturing] = useState<boolean>(false);
  const [stream, setStream] = useState<MediaStream | null>(null);

  // Initialize Camera Stream
  useEffect(() => {
    let currentStream: MediaStream | null = null;
    navigator.mediaDevices
      ?.getUserMedia({ video: true, audio: false })
      .then((s) => {
        currentStream = s;
        setStream(s);
        if (videoRef.current) {
          videoRef.current.srcObject = s;
        }
      })
      .catch((err) => {
        console.warn('Camera not accessible, falling back to simulated preview', err);
        setHasCamera(false);
      });

    return () => {
      if (currentStream) {
        currentStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const takePhoto = () => {
    setIsCapturing(true);
    setTimeout(() => setIsCapturing(false), 200);

    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (canvas && video && hasCamera) {
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Apply filter to canvas
        if (filter === 'grayscale') ctx.filter = 'grayscale(100%)';
        else if (filter === 'sepia') ctx.filter = 'sepia(100%)';
        else if (filter === 'invert') ctx.filter = 'invert(100%)';
        else if (filter === 'blur') ctx.filter = 'blur(4px)';
        else ctx.filter = 'none';

        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/png');
        setCapturedPhotos((prev) => [dataUrl, ...prev]);

        // Save to virtual filesystem in Pictures
        const fileName = `Photo_${new Date().toISOString().slice(0, 10)}_${Date.now().toString().slice(-4)}.png`;
        addFile({
          name: fileName,
          path: `C:\\Users\\User\\Pictures\\${fileName}`,
          isDirectory: false,
          content: dataUrl,
          icon: 'Image',
          size: Math.floor(dataUrl.length * 0.75),
        });

        addNotification('Photo Captured', `Saved ${fileName} to Pictures folder.`, 'camera');
      }
    } else {
      // Mock photo generation
      const mockCanvas = document.createElement('canvas');
      mockCanvas.width = 640;
      mockCanvas.height = 480;
      const ctx = mockCanvas.getContext('2d');
      if (ctx) {
        const gradient = ctx.createLinearGradient(0, 0, 640, 480);
        gradient.addColorStop(0, '#0284c7');
        gradient.addColorStop(1, '#6366f1');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 640, 480);
        ctx.fillStyle = '#fff';
        ctx.font = '24px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('Windows 11 Camera Capture', 320, 240);
        ctx.font = '16px sans-serif';
        ctx.fillText(new Date().toLocaleString(), 320, 280);

        const dataUrl = mockCanvas.toDataURL('image/png');
        setCapturedPhotos((prev) => [dataUrl, ...prev]);

        const fileName = `Snapshot_${Date.now().toString().slice(-4)}.png`;
        addFile({
          name: fileName,
          path: `C:\\Users\\User\\Pictures\\${fileName}`,
          isDirectory: false,
          content: dataUrl,
          icon: 'Image',
          size: 1024 * 12,
        });

        addNotification('Snapshot Saved', `Saved to Pictures directory.`, 'camera');
      }
    }
  };

  const filterStyles: Record<string, string> = {
    none: '',
    grayscale: 'grayscale',
    sepia: 'sepia',
    invert: 'invert',
    warm: 'hue-rotate-30 saturate-150',
    cool: 'hue-rotate-180 saturate-125',
  };

  return (
    <div className="flex flex-col h-full bg-[#111] text-slate-100 select-none overflow-hidden font-sans">
      {/* Hidden processing canvas */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Main Viewfinder Stage */}
      <div className="relative flex-1 bg-black flex items-center justify-center overflow-hidden">
        {isCapturing && (
          <div className="absolute inset-0 bg-white z-40 animate-out fade-out duration-200" />
        )}

        {hasCamera ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className={`w-full h-full object-cover transform -scale-x-100 ${filterStyles[filter] || ''}`}
          />
        ) : (
          <div className="flex flex-col items-center justify-center p-8 text-center gap-3">
            <div className="w-20 h-20 rounded-full bg-zinc-800 flex items-center justify-center text-slate-400">
              <Camera size={36} />
            </div>
            <p className="text-sm font-medium text-slate-300">Camera preview simulation ready</p>
            <span className="text-xs text-slate-500">
              Webcam permission is optional. Tap the shutter to capture a photo!
            </span>
          </div>
        )}

        {/* Viewfinder Target Guidelines */}
        <div className="absolute inset-12 border border-white/10 rounded-2xl pointer-events-none flex items-center justify-center">
          <div className="w-12 h-12 border-2 border-white/30 rounded-full" />
        </div>

        {/* Filter Quick Selector */}
        <div className="absolute top-4 left-4 flex items-center gap-1.5 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/10 z-20">
          <Sparkles size={14} className="text-amber-400" />
          <span className="text-xs font-semibold mr-1">Filter:</span>
          {['none', 'grayscale', 'sepia', 'warm', 'cool'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-2 py-0.5 rounded text-[11px] uppercase tracking-wide font-bold transition-all ${
                filter === f ? 'bg-sky-500 text-white' : 'hover:bg-white/20 text-slate-300'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Bottom Shutter & Gallery Bar */}
      <div className="h-24 bg-zinc-950/90 backdrop-blur-xl border-t border-white/10 px-6 flex items-center justify-between z-20">
        {/* Recent Photo Gallery preview */}
        <div className="flex items-center gap-2 min-w-[120px]">
          {capturedPhotos.length > 0 ? (
            <div className="flex items-center gap-2">
              <img
                src={capturedPhotos[0]}
                alt="Recent"
                className="w-12 h-12 rounded-lg object-cover border border-white/30 shadow-md"
              />
              <span className="text-xs text-slate-400">{capturedPhotos.length} photos</span>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <Image size={18} />
              <span>No photos yet</span>
            </div>
          )}
        </div>

        {/* Shutter Button */}
        <div className="flex items-center justify-center">
          <button
            onClick={takePhoto}
            className="w-16 h-16 rounded-full border-4 border-white flex items-center justify-center p-1 hover:scale-105 active:scale-95 transition-all shadow-2xl group"
            title="Take Photo"
          >
            <div className="w-full h-full bg-white group-hover:bg-sky-400 rounded-full transition-colors" />
          </button>
        </div>

        {/* Mode switch */}
        <div className="flex items-center gap-3 min-w-[120px] justify-end">
          <button
            onClick={() => setFilter('none')}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-slate-300 transition-colors"
            title="Reset Filters"
          >
            <RefreshCw size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};
