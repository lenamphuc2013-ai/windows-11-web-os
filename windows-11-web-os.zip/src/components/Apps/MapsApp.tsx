import React, { useState } from 'react';
import {
  MapPin,
  Search,
  RotateCcw,
  ExternalLink,
  Map as MapIcon,
} from 'lucide-react';

const DEFAULT_MAP_URL =
  'https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d251033.95512041674!2d105.05639289999999!3d10.547403450000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1svi!2s!4v1788428124726!5m2!1svi!2s';

export const MapsApp: React.FC = () => {
  const [mapUrl, setMapUrl] = useState(DEFAULT_MAP_URL);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentLabel, setCurrentLabel] = useState('Bản đồ vệ tinh / Địa lý (Việt Nam)');
  const [key, setKey] = useState(0); // For reloading iframe

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = searchQuery.trim();
    if (!query) {
      setMapUrl(DEFAULT_MAP_URL);
      setCurrentLabel('Bản đồ mặc định');
      return;
    }
    // Google Maps query embed format
    const searchUrl = `https://maps.google.com/maps?q=${encodeURIComponent(query)}&t=&z=13&ie=UTF8&iwloc=&output=embed`;
    setMapUrl(searchUrl);
    setCurrentLabel(query);
    setKey((prev) => prev + 1);
  };

  const handleReset = () => {
    setSearchQuery('');
    setMapUrl(DEFAULT_MAP_URL);
    setCurrentLabel('Bản đồ vệ tinh / Địa lý (Việt Nam)');
    setKey((prev) => prev + 1);
  };

  return (
    <div className="flex flex-col h-full w-full relative bg-slate-900 text-slate-100 select-none overflow-hidden font-sans">
      {/* Top Header / Search Navigation Bar */}
      <div className="h-11 px-3 bg-slate-900/90 backdrop-blur-md border-b border-white/10 flex items-center justify-between gap-3 z-20 shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0">
            <MapIcon size={16} />
          </div>
          <span className="font-semibold text-xs hidden sm:inline text-white">Google Maps</span>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="flex-1 max-w-md relative flex items-center">
          <Search size={14} className="absolute left-3 text-slate-400 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Tìm kiếm địa điểm, thành phố trên Google Maps..."
            className="w-full h-7 pl-8 pr-16 bg-slate-800/80 border border-white/10 rounded-lg text-xs text-white placeholder-slate-400 focus:outline-none focus:border-sky-500 transition-all"
          />
          <button
            type="submit"
            className="absolute right-1 px-2 py-0.5 bg-sky-500 hover:bg-sky-400 text-white rounded text-[11px] font-medium transition-all"
          >
            Tìm
          </button>
        </form>

        {/* Actions */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={handleReset}
            title="Trở về bản đồ gốc"
            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 border border-white/10 rounded-lg text-xs flex items-center gap-1.5 transition-all"
          >
            <RotateCcw size={13} />
            <span className="hidden md:inline text-[11px]">Mặc định</span>
          </button>
          <a
            href="https://www.google.com/maps"
            target="_blank"
            rel="noopener noreferrer"
            title="Mở Google Maps trên trình duyệt"
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-white/10 rounded-lg transition-all"
          >
            <ExternalLink size={14} />
          </a>
        </div>
      </div>

      {/* Embedded Google Maps iFrame */}
      <div className="flex-1 w-full h-full relative bg-slate-950 overflow-hidden">
        <iframe
          key={key}
          src={mapUrl}
          title="Google Maps"
          className="w-full h-full border-0"
          style={{ border: 0 }}
          allowFullScreen
          loading="lazy"
          referrerPolicy="strict-origin-when-cross-origin"
        />

        {/* Location Info Pill */}
        <div className="absolute bottom-3 left-3 px-3 py-1.5 bg-slate-900/85 backdrop-blur-md rounded-xl border border-white/15 flex items-center gap-2 shadow-xl pointer-events-none text-xs">
          <MapPin size={13} className="text-red-400 shrink-0" />
          <span className="text-[11px] text-white/90 font-medium truncate max-w-[240px]">
            {currentLabel}
          </span>
        </div>
      </div>
    </div>
  );
};

