import React, { useState, useRef } from 'react';
import { Scissors, Camera, Clock, Save, Copy, RotateCcw, Pen, Highlighter, Eraser, Check } from 'lucide-react';
import { useOS } from '../../context/OSContext';

export const SnippingToolApp: React.FC = () => {
  const { addNotification, addFile } = useOS();
  const [mode, setMode] = useState<'rect' | 'window' | 'fullscreen'>('rect');
  const [delay, setDelay] = useState<number>(0);
  const [snipImage, setSnipImage] = useState<string | null>(null);
  const [tool, setTool] = useState<'pen' | 'highlighter' | 'eraser'>('pen');
  const [penColor, setPenColor] = useState<string>('#ef4444');
  const [copied, setCopied] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isDrawingRef = useRef<boolean>(false);

  const startSnip = () => {
    addNotification('Snipping Tool', `Taking snip in ${delay}s...`, 'snippingtool');
    setTimeout(() => {
      // Capture simulated screen snapshot
      const canvas = document.createElement('canvas');
      canvas.width = 800;
      canvas.height = 500;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Desktop mock rendering
        const grad = ctx.createLinearGradient(0, 0, 800, 500);
        grad.addColorStop(0, '#0f172a');
        grad.addColorStop(1, '#1e293b');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 800, 500);

        // Draw simulated windows
        ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.lineWidth = 2;
        ctx.roundRect(80, 60, 640, 360, 16);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#fff';
        ctx.font = 'bold 22px system-ui';
        ctx.fillText('Windows 11 Screen Capture', 120, 140);
        ctx.font = '14px system-ui';
        ctx.fillStyle = '#94a3b8';
        ctx.fillText(`Captured at ${new Date().toLocaleTimeString()} - Mode: ${mode}`, 120, 180);

        const dataUrl = canvas.toDataURL('image/png');
        setSnipImage(dataUrl);

        // Load into annotation canvas
        setTimeout(() => {
          const annotCanvas = canvasRef.current;
          if (annotCanvas) {
            const aCtx = annotCanvas.getContext('2d');
            const img = new Image();
            img.onload = () => {
              annotCanvas.width = 800;
              annotCanvas.height = 500;
              aCtx?.drawImage(img, 0, 0);
            };
            img.src = dataUrl;
          }
        }, 100);
      }
    }, delay * 1000);
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    isDrawingRef.current = true;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.beginPath();
    ctx.moveTo(
      ((e.clientX - rect.left) / rect.width) * canvas.width,
      ((e.clientY - rect.top) / rect.height) * canvas.height
    );
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.lineWidth = tool === 'highlighter' ? 14 : tool === 'eraser' ? 20 : 3;
    ctx.lineCap = 'round';
    ctx.strokeStyle =
      tool === 'highlighter'
        ? 'rgba(250, 204, 21, 0.4)'
        : tool === 'eraser'
        ? '#0f172a'
        : penColor;

    ctx.lineTo(
      ((e.clientX - rect.left) / rect.width) * canvas.width,
      ((e.clientY - rect.top) / rect.height) * canvas.height
    );
    ctx.stroke();
  };

  const handleMouseUp = () => {
    isDrawingRef.current = false;
  };

  const handleSave = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    const fileName = `Snip_${new Date().toISOString().slice(0, 10)}_${Date.now().toString().slice(-4)}.png`;
    addFile({
      name: fileName,
      path: `C:\\Users\\User\\Pictures\\${fileName}`,
      isDirectory: false,
      content: dataUrl,
      icon: 'Image',
      size: Math.floor(dataUrl.length * 0.75),
    });
    addNotification('Snip Saved', `Saved ${fileName} to Pictures.`, 'snippingtool');
  };

  const handleCopy = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    addNotification('Copied', 'Snip image copied to clipboard buffer.', 'snippingtool');
  };

  return (
    <div className="flex flex-col h-full bg-[#f3f3f3] dark:bg-[#202020] text-slate-800 dark:text-slate-100 select-none overflow-hidden font-sans">
      {/* Top Toolbar */}
      <div className="h-12 bg-white/70 dark:bg-zinc-900/70 backdrop-blur border-b border-black/5 dark:border-white/5 px-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {/* New Snip Button */}
          <button
            onClick={startSnip}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-500 hover:bg-sky-600 active:scale-95 text-white rounded-lg text-xs font-semibold shadow transition-all"
          >
            <Scissors size={14} /> New Snip
          </button>

          {/* Delay selector */}
          <div className="flex items-center gap-1 bg-slate-200/60 dark:bg-white/5 px-2.5 py-1.5 rounded-lg text-xs">
            <Clock size={13} className="text-slate-400" />
            <select
              value={delay}
              onChange={(e) => setDelay(Number(e.target.value))}
              className="bg-transparent focus:outline-none text-xs font-medium cursor-pointer"
            >
              <option value={0}>No delay</option>
              <option value={3}>Snip in 3s</option>
              <option value={5}>Snip in 5s</option>
              <option value={10}>Snip in 10s</option>
            </select>
          </div>
        </div>

        {/* Editing Tools (Enabled after snip) */}
        {snipImage && (
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-slate-200/60 dark:bg-white/5 p-1 rounded-lg">
              <button
                onClick={() => setTool('pen')}
                className={`p-1.5 rounded-md transition-colors ${
                  tool === 'pen' ? 'bg-white dark:bg-white/20 shadow-sm text-sky-500' : 'text-slate-400'
                }`}
                title="Pen"
              >
                <Pen size={14} />
              </button>
              <button
                onClick={() => setTool('highlighter')}
                className={`p-1.5 rounded-md transition-colors ${
                  tool === 'highlighter' ? 'bg-white dark:bg-white/20 shadow-sm text-amber-500' : 'text-slate-400'
                }`}
                title="Highlighter"
              >
                <Highlighter size={14} />
              </button>
              <button
                onClick={() => setTool('eraser')}
                className={`p-1.5 rounded-md transition-colors ${
                  tool === 'eraser' ? 'bg-white dark:bg-white/20 shadow-sm text-red-500' : 'text-slate-400'
                }`}
                title="Eraser"
              >
                <Eraser size={14} />
              </button>
            </div>

            {/* Colors */}
            <div className="flex items-center gap-1">
              {['#ef4444', '#3b82f6', '#10b981', '#ffffff'].map((c) => (
                <button
                  key={c}
                  onClick={() => setPenColor(c)}
                  className={`w-5 h-5 rounded-full border-2 transition-transform ${
                    penColor === c ? 'scale-110 border-sky-400 shadow' : 'border-transparent'
                  }`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>

            <div className="h-4 w-px bg-slate-300 dark:bg-zinc-700 mx-1" />

            <button
              onClick={handleCopy}
              className="flex items-center gap-1 px-2.5 py-1 bg-slate-200/60 dark:bg-white/10 hover:bg-slate-300 dark:hover:bg-white/20 rounded-lg text-xs font-semibold transition-colors"
            >
              {copied ? <Check size={13} className="text-emerald-500" /> : <Copy size={13} />}
              {copied ? 'Copied' : 'Copy'}
            </button>

            <button
              onClick={handleSave}
              className="flex items-center gap-1 px-2.5 py-1 bg-sky-500 hover:bg-sky-600 text-white rounded-lg text-xs font-semibold shadow transition-colors"
            >
              <Save size={13} /> Save
            </button>
          </div>
        )}
      </div>

      {/* Main Canvas Viewport */}
      <div className="flex-1 flex items-center justify-center p-4 overflow-auto bg-slate-100 dark:bg-[#181818]">
        {snipImage ? (
          <div className="relative border border-black/10 dark:border-white/10 rounded-xl shadow-2xl overflow-hidden bg-black max-w-full max-h-full">
            <canvas
              ref={canvasRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              className="cursor-crosshair max-w-full max-h-[70vh] block"
            />
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center text-center p-8 gap-4 max-w-sm">
            <div className="w-16 h-16 rounded-2xl bg-sky-500/10 text-sky-500 flex items-center justify-center shadow-inner">
              <Scissors size={32} />
            </div>
            <div>
              <h3 className="font-bold text-base">Snipping Tool</h3>
              <p className="text-xs text-slate-400 mt-1">
                Press "New Snip" to capture a region of your desktop and annotate it with pens and highlighters.
              </p>
            </div>
            <button
              onClick={startSnip}
              className="px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white font-semibold text-xs rounded-xl shadow-md transition-all"
            >
              Take a Snip
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
