import React, { useState, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import { DEFAULT_WALLPAPERS } from '../../utils/fileSystem';
import {
  ZoomIn,
  ZoomOut,
  RotateCw,
  Image as ImageIcon,
  Monitor,
  Check,
  UploadCloud,
} from 'lucide-react';

interface PhotosAppProps {
  filePath?: string;
  fileName?: string;
}

export const PhotosApp: React.FC<PhotosAppProps> = ({ filePath, fileName }) => {
  const { fileSystem, addFile, updateSettings, addNotification } = useOS();
  const [isDragOver, setIsDragOver] = useState(false);

  // Find images in file system + wallpapers
  const savedImages = fileSystem.filter((f) =>
    f.name.match(/\.(png|jpe?g|svg|webp|gif|bmp|ico|avif)$/i)
  );

  // If specific filePath or fileName is provided, ensure it is in the list
  const specificFile = fileSystem.find(
    (f) =>
      (filePath && f.path.toLowerCase() === filePath.toLowerCase()) ||
      (fileName && f.name.toLowerCase() === fileName.toLowerCase())
  );

  const allPictures = [
    ...(specificFile && !savedImages.some((f) => f.path === specificFile.path)
      ? [{ name: specificFile.name, url: specificFile.content || '', path: specificFile.path }]
      : []),
    ...savedImages.map((f) => ({ name: f.name, url: f.content || '', path: f.path })),
    ...DEFAULT_WALLPAPERS.map((w) => ({ name: w.name, url: w.url, path: '' })),
  ];

  const findInitialIndex = () => {
    if (fileName) {
      const idx = allPictures.findIndex(
        (p) => p.name.toLowerCase() === fileName.toLowerCase()
      );
      if (idx !== -1) return idx;
    }
    if (filePath) {
      const idx = allPictures.findIndex(
        (p) => p.path && p.path.toLowerCase() === filePath.toLowerCase()
      );
      if (idx !== -1) return idx;
    }
    return 0;
  };

  const [selectedIdx, setSelectedIdx] = useState<number>(findInitialIndex);
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [setSuccess, setSetSuccess] = useState(false);

  // Update selected photo if props change
  useEffect(() => {
    const idx = findInitialIndex();
    setSelectedIdx(idx);
    setZoom(1);
    setRotation(0);
  }, [filePath, fileName]);

  const activePic = allPictures[selectedIdx] || allPictures[0];
  const isGif = activePic?.name?.toLowerCase().endsWith('.gif') || activePic?.url?.startsWith('data:image/gif');

  const handleSetWallpaper = () => {
    if (!activePic || !activePic.url) return;
    updateSettings({ wallpaper: activePic.url });
    setSetSuccess(true);
    setTimeout(() => setSetSuccess(false), 2000);
    addNotification('Hình nền Desktop', `Đã đặt "${activePic.name}" làm hình nền Desktop!`, 'photos');
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const files: File[] = Array.from(e.dataTransfer.files);
      files.forEach((file: File) => {
        if (file.type.startsWith('image/') || /\.(gif|png|jpe?g|webp|svg|bmp)$/i.test(file.name)) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const dataUrl = event.target?.result as string;
            const path = `C:\\Users\\User\\Pictures\\${file.name}`;
            addFile({
              name: file.name,
              path,
              isDirectory: false,
              content: dataUrl,
              size: file.size,
              icon: 'Image',
            });
            addNotification('Ảnh đã lưu', `Đã lưu ảnh "${file.name}" cục bộ vào Pictures`, 'photos');
          };
          reader.readAsDataURL(file);
        }
      });
    }
  };

  return (
    <div
      className="flex flex-col w-full h-full bg-[#1e1e1e] text-slate-100 select-none overflow-hidden text-xs relative"
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragOver(true);
      }}
      onDragLeave={() => setIsDragOver(false)}
      onDrop={handleDrop}
    >
      {/* Drag & Drop Overlay */}
      {isDragOver && (
        <div className="absolute inset-0 z-50 bg-sky-600/30 backdrop-blur-sm border-2 border-dashed border-sky-400 flex flex-col items-center justify-center pointer-events-none">
          <UploadCloud size={48} className="text-white animate-bounce mb-2" />
          <p className="text-sm font-semibold text-white">Thả hình ảnh hoặc GIF vào đây để lưu cục bộ</p>
        </div>
      )}

      {/* Top Controls */}
      <div className="flex items-center justify-between px-4 py-2 bg-[#252525] border-b border-white/10">
        <div className="flex items-center gap-2">
          <ImageIcon size={16} className="text-amber-400" />
          <span className="font-bold truncate max-w-xs">{activePic?.name || 'Trình xem ảnh & GIF'}</span>
          {isGif && (
            <span className="px-1.5 py-0.5 bg-purple-600 text-white font-bold text-[10px] rounded">
              GIF Động
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setZoom((z) => Math.max(0.5, z - 0.2))}
            className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
            title="Zoom out"
          >
            <ZoomOut size={15} />
          </button>
          <span className="font-mono text-[11px] text-slate-400">{Math.round(zoom * 100)}%</span>
          <button
            onClick={() => setZoom((z) => Math.min(3, z + 0.2))}
            className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
            title="Zoom in"
          >
            <ZoomIn size={15} />
          </button>
          <button
            onClick={() => setRotation((r) => (r + 90) % 360)}
            className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
            title="Rotate"
          >
            <RotateCw size={15} />
          </button>

          <div className="h-4 border-r border-white/20 mx-1" />

          <button
            onClick={handleSetWallpaper}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold transition-all shadow-sm"
          >
            {setSuccess ? <Check size={14} /> : <Monitor size={14} />}
            <span>{setSuccess ? 'Applied!' : 'Set as background'}</span>
          </button>
        </div>
      </div>

      {/* Main Image Stage */}
      <div className="flex-1 flex items-center justify-center p-6 overflow-hidden bg-black/40 relative">
        {activePic ? (
          <img
            src={activePic.url}
            alt={activePic.name}
            style={{
              transform: `scale(${zoom}) rotate(${rotation}deg)`,
              transition: 'transform 0.2s cubic-bezier(0.1, 0.9, 0.2, 1)',
            }}
            className="max-h-full max-w-full object-contain rounded-lg shadow-2xl"
          />
        ) : (
          <div className="text-slate-500">No image loaded</div>
        )}
      </div>

      {/* Bottom Thumbnail Filmstrip */}
      <div className="h-20 bg-[#181818] border-t border-white/10 p-2 flex items-center gap-2 overflow-x-auto">
        {allPictures.map((pic, idx) => (
          <div
            key={idx}
            onClick={() => {
              setSelectedIdx(idx);
              setZoom(1);
              setRotation(0);
            }}
            className={`h-16 w-24 rounded-lg overflow-hidden shrink-0 cursor-pointer border-2 transition-all relative ${
              selectedIdx === idx ? 'border-sky-500 scale-105' : 'border-transparent opacity-60 hover:opacity-100'
            }`}
          >
            <img src={pic.url} alt={pic.name} className="w-full h-full object-cover" />
            {(pic.name.toLowerCase().endsWith('.gif') || pic.url.startsWith('data:image/gif')) && (
              <span className="absolute bottom-0 right-0 px-1 py-0.2 bg-purple-600/90 text-white text-[8px] font-bold rounded-tl">
                GIF
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
