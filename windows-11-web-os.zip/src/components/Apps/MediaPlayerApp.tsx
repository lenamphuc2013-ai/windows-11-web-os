import React, { useState, useRef, useEffect } from 'react';
import {
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  Music,
  ListMusic,
  Repeat,
  Shuffle,
  FolderOpen,
  Sparkles,
} from 'lucide-react';
import { useOS } from '../../context/OSContext';

interface Track {
  id: string;
  title: string;
  artist: string;
  duration: string;
  durationSec: number;
  coverSvg: string;
  chordProgression: number[];
  type: 'audio' | 'video';
  fileDataUrl?: string;
}

const DEFAULT_TRACKS: Track[] = [
  {
    id: '1',
    title: 'Windows 11 Ambient Suite',
    artist: 'Fluent Audio Engine',
    duration: '3:45',
    durationSec: 225,
    chordProgression: [261.63, 329.63, 392.0, 523.25, 440.0], // C4 - E4 - G4 - C5 - A4
    coverSvg: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400'><defs><radialGradient id='g1' cx='50%' cy='50%' r='60%'><stop offset='0%' stop-color='%2338bdf8'/><stop offset='50%' stop-color='%231d4ed8'/><stop offset='100%' stop-color='%230f172a'/></radialGradient></defs><rect width='400' height='400' fill='url(%23g1)'/><circle cx='200' cy='200' r='110' fill='none' stroke='%23ffffff' stroke-width='4' opacity='0.4'/><circle cx='200' cy='200' r='60' fill='%2360a5fa' opacity='0.3'/><circle cx='200' cy='200' r='20' fill='%23ffffff' opacity='0.8'/></svg>`,
    type: 'audio',
  },
  {
    id: '2',
    title: 'Neon Horizon Chillhop',
    artist: 'Mica Synthesis',
    duration: '4:12',
    durationSec: 252,
    chordProgression: [220.0, 277.18, 329.63, 440.0, 369.99], // A3 - C#4 - E4 - A4 - F#4
    coverSvg: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400'><defs><radialGradient id='g2' cx='50%' cy='50%' r='60%'><stop offset='0%' stop-color='%23ec4899'/><stop offset='50%' stop-color='%237e22ce'/><stop offset='100%' stop-color='%2309090b'/></radialGradient></defs><rect width='400' height='400' fill='url(%23g2)'/><polygon points='200,80 320,280 80,280' fill='none' stroke='%23f472b6' stroke-width='4' opacity='0.6'/><circle cx='200' cy='200' r='30' fill='%23fb7185' opacity='0.5'/></svg>`,
    type: 'audio',
  },
  {
    id: '3',
    title: 'Lofi Cyber Garden',
    artist: 'Aero Chords',
    duration: '2:58',
    durationSec: 178,
    chordProgression: [349.23, 440.0, 523.25, 659.25, 392.0], // F4 - A4 - C5 - E5 - G4
    coverSvg: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400'><defs><radialGradient id='g3' cx='50%' cy='50%' r='60%'><stop offset='0%' stop-color='%2334d399'/><stop offset='50%' stop-color='%230f766e'/><stop offset='100%' stop-color='%23042f2e'/></radialGradient></defs><rect width='400' height='400' fill='url(%23g3)'/><rect x='100' y='100' width='200' height='200' rx='30' fill='none' stroke='%23a7f3d0' stroke-width='4' opacity='0.5' transform='rotate(45 200 200)'/><circle cx='200' cy='200' r='25' fill='%236ee7b7'/></svg>`,
    type: 'audio',
  },
];

export const MediaPlayerApp: React.FC = () => {
  const { addNotification } = useOS();
  const [tracks, setTracks] = useState<Track[]>(DEFAULT_TRACKS);
  const [currentTrackIndex, setCurrentTrackIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [volume, setVolume] = useState<number>(80);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [visualizerBars, setVisualizerBars] = useState<number[]>(Array(24).fill(20));

  const audioCtxRef = useRef<AudioContext | null>(null);
  const synthNodesRef = useRef<{ osc1?: OscillatorNode; osc2?: OscillatorNode; gain?: GainNode; filter?: BiquadFilterNode } | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const htmlAudioRef = useRef<HTMLAudioElement | null>(null);

  const currentTrack = tracks[currentTrackIndex] || tracks[0];

  // Stop synthetic audio
  const stopSynth = () => {
    if (synthNodesRef.current) {
      try {
        synthNodesRef.current.gain?.gain.setTargetAtTime(0.0001, audioCtxRef.current?.currentTime || 0, 0.05);
        setTimeout(() => {
          synthNodesRef.current?.osc1?.stop();
          synthNodesRef.current?.osc2?.stop();
          synthNodesRef.current?.osc1?.disconnect();
          synthNodesRef.current?.osc2?.disconnect();
          synthNodesRef.current = null;
        }, 80);
      } catch (e) {
        // ignore
      }
    }
  };

  // Play synthetic chords via Web Audio API
  const startSynth = (track: Track) => {
    stopSynth();
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!audioCtxRef.current) {
        audioCtxRef.current = new AudioContextClass();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      const baseFreq = track.chordProgression[0] || 261.63;
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(baseFreq, ctx.currentTime);

      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(baseFreq * 1.5, ctx.currentTime);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(900, ctx.currentTime);

      const targetVol = isMuted ? 0 : (volume / 100) * 0.18;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(Math.max(0.0001, targetVol), ctx.currentTime + 0.3);

      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc1.start();
      osc2.start();

      synthNodesRef.current = { osc1, osc2, gain, filter };
    } catch (e) {
      // AudioContext unavailable or autoplay restricted
    }
  };

  // Update volume live
  useEffect(() => {
    if (synthNodesRef.current?.gain && audioCtxRef.current) {
      const targetVol = isMuted ? 0 : (volume / 100) * 0.18;
      synthNodesRef.current.gain.gain.setTargetAtTime(targetVol, audioCtxRef.current.currentTime, 0.05);
    }
    if (htmlAudioRef.current) {
      htmlAudioRef.current.volume = isMuted ? 0 : volume / 100;
    }
  }, [volume, isMuted]);

  // Playback timer & visualizer
  useEffect(() => {
    if (isPlaying) {
      if (currentTrack.fileDataUrl) {
        htmlAudioRef.current?.play().catch(() => {});
      } else {
        startSynth(currentTrack);
      }

      intervalRef.current = setInterval(() => {
        setCurrentTime((prev) => {
          const next = prev + 1;
          if (next >= currentTrack.durationSec) {
            nextTrack();
            return 0;
          }
          return next;
        });

        // Rotate note frequency subtly
        if (synthNodesRef.current?.osc1 && synthNodesRef.current?.osc2 && audioCtxRef.current) {
          const chords = currentTrack.chordProgression;
          const noteIndex = Math.floor(Date.now() / 2400) % chords.length;
          const note = chords[noteIndex];
          synthNodesRef.current.osc1.frequency.setTargetAtTime(note, audioCtxRef.current.currentTime, 0.2);
          synthNodesRef.current.osc2.frequency.setTargetAtTime(note * 1.5, audioCtxRef.current.currentTime, 0.2);
        }

        setVisualizerBars(
          Array(24)
            .fill(0)
            .map(() => Math.floor(Math.random() * 80) + 20)
        );
      }, 1000);
    } else {
      stopSynth();
      if (htmlAudioRef.current) {
        htmlAudioRef.current.pause();
      }
      if (intervalRef.current) clearInterval(intervalRef.current);
      setVisualizerBars(Array(24).fill(15));
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      stopSynth();
    };
  }, [isPlaying, currentTrackIndex]);

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const nextTrack = () => {
    stopSynth();
    setCurrentTrackIndex((prev) => (prev + 1) % tracks.length);
    setCurrentTime(0);
    setIsPlaying(true);
  };

  const prevTrack = () => {
    stopSynth();
    setCurrentTrackIndex((prev) => (prev - 1 + tracks.length) % tracks.length);
    setCurrentTime(0);
    setIsPlaying(true);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files[0];
    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target?.result as string;
      const newTrack: Track = {
        id: 'user-' + Date.now(),
        title: file.name.replace(/\.[^/.]+$/, ''),
        artist: 'Local Media File',
        duration: '3:00',
        durationSec: 180,
        chordProgression: [293.66, 369.99, 440.0, 587.33],
        coverSvg: DEFAULT_TRACKS[0].coverSvg,
        type: 'audio',
        fileDataUrl: dataUrl,
      };
      setTracks((prev) => [newTrack, ...prev]);
      setCurrentTrackIndex(0);
      setCurrentTime(0);
      setIsPlaying(true);
      addNotification('Media Player', `Đã nạp bài hát: ${file.name}`, 'media');
    };
    reader.readAsDataURL(file);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const progressPercent = Math.min(100, (currentTime / Math.max(1, currentTrack.durationSec)) * 100);

  return (
    <div className="relative flex flex-col h-full bg-[#0e0e14] text-slate-100 select-none overflow-hidden font-sans">
      {/* Hidden local audio element for user uploaded files */}
      {currentTrack.fileDataUrl && (
        <audio
          ref={htmlAudioRef}
          src={currentTrack.fileDataUrl}
          onEnded={nextTrack}
          onTimeUpdate={() => {
            if (htmlAudioRef.current) {
              setCurrentTime(Math.floor(htmlAudioRef.current.currentTime));
            }
          }}
        />
      )}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileUpload}
        accept="audio/*,video/*"
        className="hidden"
      />

      {/* Main Content Area */}
      <div className="relative flex-1 flex flex-col md:flex-row items-center p-6 gap-8 overflow-y-auto z-10 justify-center">
        {/* Album Art & Vinyl Disc */}
        <div className="flex flex-col items-center gap-4">
          <div className="relative group">
            {/* Spinning Vinyl Effect */}
            <div
              className={`w-44 h-44 sm:w-52 sm:h-52 rounded-full bg-zinc-900 border-4 border-zinc-700 shadow-2xl flex items-center justify-center relative overflow-hidden transition-transform duration-500 ${
                isPlaying ? 'animate-spin [animation-duration:8s]' : ''
              }`}
            >
              <div className="absolute inset-0 bg-[radial-gradient(circle,transparent_40%,rgba(255,255,255,0.05)_45%,transparent_50%)]" />
              <img
                src={currentTrack.coverSvg}
                alt={currentTrack.title}
                className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover border-2 border-white/20 shadow-inner"
              />
              <div className="w-6 h-6 rounded-full bg-[#111] border-2 border-white/40 absolute" />
            </div>
          </div>

          <div className="text-center">
            <h2 className="text-base sm:text-lg font-bold truncate max-w-xs">{currentTrack.title}</h2>
            <p className="text-xs text-slate-400 mt-0.5">{currentTrack.artist}</p>
          </div>

          {/* Audio Visualizer Waves */}
          <div className="flex items-end justify-center gap-1 h-10 w-full max-w-xs px-4">
            {visualizerBars.map((height, i) => (
              <div
                key={i}
                className="flex-1 bg-gradient-to-t from-sky-500 to-indigo-400 rounded-t transition-all duration-150"
                style={{ height: `${height}%` }}
              />
            ))}
          </div>
        </div>

        {/* Playlist Queue */}
        <div className="w-full max-w-md bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-4 flex flex-col h-72">
          <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-2">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
              <ListMusic size={16} className="text-sky-400" />
              <span>Danh sách phát (Offline Synthesizer)</span>
            </div>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1 text-[11px] bg-white/10 hover:bg-white/20 px-2 py-1 rounded-lg text-sky-300 transition-colors"
            >
              <FolderOpen size={12} />
              <span>Mở tệp máy tính</span>
            </button>
          </div>

          <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
            {tracks.map((t, idx) => {
              const isSelected = idx === currentTrackIndex;
              return (
                <div
                  key={t.id}
                  onClick={() => {
                    stopSynth();
                    setCurrentTrackIndex(idx);
                    setCurrentTime(0);
                    setIsPlaying(true);
                  }}
                  className={`flex items-center justify-between p-2.5 rounded-xl cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-sky-500/30 border border-sky-500/50 text-white font-semibold'
                      : 'hover:bg-white/5 text-slate-300 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3 truncate">
                    <img src={t.coverSvg} alt={t.title} className="w-8 h-8 rounded-lg object-cover" />
                    <div className="truncate">
                      <div className="text-xs truncate">{t.title}</div>
                      <div className="text-[10px] text-slate-400 truncate">{t.artist}</div>
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">{t.duration}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Bottom Controls Player Bar */}
      <div className="relative z-10 h-20 bg-black/70 backdrop-blur-xl border-t border-white/10 px-6 flex items-center justify-between">
        {/* Track info small */}
        <div className="flex items-center gap-3 w-1/4 min-w-[120px] truncate">
          <img src={currentTrack.coverSvg} alt={currentTrack.title} className="w-10 h-10 rounded-lg object-cover" />
          <div className="truncate hidden sm:block">
            <div className="text-xs font-semibold truncate">{currentTrack.title}</div>
            <div className="text-[10px] text-slate-400 truncate">{currentTrack.artist}</div>
          </div>
        </div>

        {/* Center Playback Controls */}
        <div className="flex flex-col items-center gap-1.5 w-2/4 max-w-md">
          <div className="flex items-center gap-4">
            <button className="text-slate-400 hover:text-white transition-colors">
              <Shuffle size={14} />
            </button>
            <button onClick={prevTrack} className="text-slate-200 hover:text-white transition-colors">
              <SkipBack size={18} />
            </button>
            <button
              onClick={togglePlay}
              className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-lg"
            >
              {isPlaying ? <Pause size={18} /> : <Play size={18} className="ml-0.5" />}
            </button>
            <button onClick={nextTrack} className="text-slate-200 hover:text-white transition-colors">
              <SkipForward size={18} />
            </button>
            <button className="text-slate-400 hover:text-white transition-colors">
              <Repeat size={14} />
            </button>
          </div>

          {/* Progress Bar */}
          <div className="w-full flex items-center gap-2">
            <span className="text-[10px] text-slate-400 font-mono">{formatTime(currentTime)}</span>
            <div
              className="flex-1 h-1.5 bg-white/20 rounded-full cursor-pointer relative group"
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const pos = (e.clientX - rect.left) / rect.width;
                const newSecs = Math.floor(pos * currentTrack.durationSec);
                setCurrentTime(newSecs);
                if (htmlAudioRef.current) {
                  htmlAudioRef.current.currentTime = newSecs;
                }
              }}
            >
              <div
                className="h-full bg-sky-400 rounded-full relative"
                style={{ width: `${progressPercent}%` }}
              >
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2.5 h-2.5 bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow" />
              </div>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">{currentTrack.duration}</span>
          </div>
        </div>

        {/* Volume Controls */}
        <div className="flex items-center justify-end gap-2 w-1/4">
          <button
            onClick={() => setIsMuted(!isMuted)}
            className="text-slate-300 hover:text-white"
          >
            {isMuted || volume === 0 ? <VolumeX size={16} /> : <Volume2 size={16} />}
          </button>
          <input
            type="range"
            min="0"
            max="100"
            value={isMuted ? 0 : volume}
            onChange={(e) => {
              const val = Number(e.target.value);
              setVolume(val);
              setIsMuted(false);
            }}
            className="w-16 sm:w-20 accent-sky-400 h-1 bg-white/20 rounded-lg appearance-none cursor-pointer"
          />
        </div>
      </div>
    </div>
  );
};
