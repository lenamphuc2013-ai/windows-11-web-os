import React, { useState } from 'react';
import { CloudSun, Sun, CloudRain, Wind, Droplets, Compass, Eye, Thermometer, MapPin, Search } from 'lucide-react';

interface CityWeather {
  city: string;
  country: string;
  temp: number;
  condition: string;
  high: number;
  low: number;
  humidity: number;
  windSpeed: number;
  uvIndex: number;
  airQuality: string;
  hourly: { time: string; temp: number; icon: string }[];
  daily: { day: string; condition: string; high: number; low: number }[];
}

const CITIES: Record<string, CityWeather> = {
  'Hà Nội': {
    city: 'Hà Nội',
    country: 'Vietnam',
    temp: 29,
    condition: 'Partly Cloudy',
    high: 33,
    low: 26,
    humidity: 78,
    windSpeed: 14,
    uvIndex: 7,
    airQuality: 'Moderate (AQI 68)',
    hourly: [
      { time: 'Now', temp: 29, icon: 'CloudSun' },
      { time: '12:00', temp: 32, icon: 'Sun' },
      { time: '15:00', temp: 33, icon: 'Sun' },
      { time: '18:00', temp: 30, icon: 'CloudSun' },
      { time: '21:00', temp: 28, icon: 'CloudRain' },
      { time: '00:00', temp: 27, icon: 'CloudSun' },
    ],
    daily: [
      { day: 'Today', condition: 'Partly Cloudy', high: 33, low: 26 },
      { day: 'Thu', condition: 'Sunny', high: 34, low: 27 },
      { day: 'Fri', condition: 'Scattered Showers', high: 31, low: 25 },
      { day: 'Sat', condition: 'Thunderstorm', high: 29, low: 24 },
      { day: 'Sun', condition: 'Sunny', high: 32, low: 25 },
      { day: 'Mon', condition: 'Partly Cloudy', high: 33, low: 26 },
      { day: 'Tue', condition: 'Clear', high: 34, low: 26 },
    ],
  },
  'TP. Hồ Chí Minh': {
    city: 'TP. Hồ Chí Minh',
    country: 'Vietnam',
    temp: 31,
    condition: 'Sunny & Warm',
    high: 35,
    low: 27,
    humidity: 72,
    windSpeed: 16,
    uvIndex: 9,
    airQuality: 'Good (AQI 45)',
    hourly: [
      { time: 'Now', temp: 31, icon: 'Sun' },
      { time: '13:00', temp: 34, icon: 'Sun' },
      { time: '16:00', temp: 33, icon: 'CloudSun' },
      { time: '19:00', temp: 30, icon: 'CloudSun' },
      { time: '22:00', temp: 28, icon: 'CloudSun' },
      { time: '01:00', temp: 27, icon: 'CloudSun' },
    ],
    daily: [
      { day: 'Today', condition: 'Sunny & Warm', high: 35, low: 27 },
      { day: 'Thu', condition: 'Sunny', high: 35, low: 27 },
      { day: 'Fri', condition: 'Afternoon Rain', high: 32, low: 26 },
      { day: 'Sat', condition: 'Scattered Showers', high: 32, low: 25 },
      { day: 'Sun', condition: 'Sunny', high: 34, low: 26 },
      { day: 'Mon', condition: 'Partly Cloudy', high: 34, low: 26 },
      { day: 'Tue', condition: 'Sunny', high: 35, low: 27 },
    ],
  },
  'Tokyo': {
    city: 'Tokyo',
    country: 'Japan',
    temp: 18,
    condition: 'Clear Sky',
    high: 22,
    low: 14,
    humidity: 55,
    windSpeed: 12,
    uvIndex: 5,
    airQuality: 'Excellent (AQI 22)',
    hourly: [
      { time: 'Now', temp: 18, icon: 'Sun' },
      { time: '14:00', temp: 21, icon: 'Sun' },
      { time: '17:00', temp: 19, icon: 'Sun' },
      { time: '20:00', temp: 16, icon: 'CloudSun' },
      { time: '23:00', temp: 15, icon: 'CloudSun' },
      { time: '02:00', temp: 14, icon: 'CloudSun' },
    ],
    daily: [
      { day: 'Today', condition: 'Clear Sky', high: 22, low: 14 },
      { day: 'Thu', condition: 'Sunny', high: 23, low: 15 },
      { day: 'Fri', condition: 'Cloudy', high: 20, low: 13 },
      { day: 'Sat', condition: 'Rain', high: 17, low: 12 },
      { day: 'Sun', condition: 'Sunny', high: 21, low: 14 },
      { day: 'Mon', condition: 'Clear', high: 22, low: 14 },
      { day: 'Tue', condition: 'Sunny', high: 23, low: 15 },
    ],
  },
};

export const WeatherApp: React.FC = () => {
  const [selectedCity, setSelectedCity] = useState<string>('Hà Nội');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const weather = CITIES[selectedCity] || CITIES['Hà Nội'];

  return (
    <div className="relative flex flex-col h-full bg-gradient-to-br from-sky-600 via-sky-700 to-indigo-900 text-white select-none overflow-y-auto font-sans p-6">
      {/* Search & Location Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-6 z-10">
        <div className="flex items-center gap-2">
          <MapPin size={20} className="text-sky-300" />
          <h1 className="text-xl font-bold">{weather.city}</h1>
          <span className="text-xs px-2 py-0.5 bg-white/20 rounded-full">{weather.country}</span>
        </div>

        {/* Quick city switcher */}
        <div className="flex items-center gap-1.5 bg-black/20 backdrop-blur-md p-1 rounded-xl border border-white/10">
          {Object.keys(CITIES).map((c) => (
            <button
              key={c}
              onClick={() => setSelectedCity(c)}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                selectedCity === c ? 'bg-white text-slate-900 shadow' : 'hover:bg-white/10 text-white'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      {/* Hero Temperature & Condition */}
      <div className="flex flex-col sm:flex-row items-center justify-between p-6 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl shadow-xl mb-6">
        <div className="flex items-center gap-6">
          <CloudSun size={72} className="text-amber-300 drop-shadow-md" />
          <div>
            <div className="text-6xl font-light font-mono tracking-tight">{weather.temp}°</div>
            <div className="text-lg font-medium text-sky-100">{weather.condition}</div>
            <div className="text-xs text-sky-200 mt-0.5">
              H: {weather.high}° &nbsp;|&nbsp; L: {weather.low}°
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-4 sm:mt-0 text-xs">
          <div className="flex items-center gap-2 bg-black/20 p-2.5 rounded-xl">
            <Droplets size={16} className="text-sky-300" />
            <div>
              <div className="text-sky-200 text-[10px]">Humidity</div>
              <div className="font-bold">{weather.humidity}%</div>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-black/20 p-2.5 rounded-xl">
            <Wind size={16} className="text-sky-300" />
            <div>
              <div className="text-sky-200 text-[10px]">Wind</div>
              <div className="font-bold">{weather.windSpeed} km/h</div>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-black/20 p-2.5 rounded-xl">
            <Sun size={16} className="text-amber-300" />
            <div>
              <div className="text-sky-200 text-[10px]">UV Index</div>
              <div className="font-bold">{weather.uvIndex} (High)</div>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-black/20 p-2.5 rounded-xl">
            <Eye size={16} className="text-emerald-300" />
            <div>
              <div className="text-sky-200 text-[10px]">Air Quality</div>
              <div className="font-bold text-[11px] truncate">{weather.airQuality}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Hourly Forecast */}
      <div className="p-4 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl shadow-md mb-6">
        <h3 className="text-xs font-bold text-sky-200 uppercase tracking-wider mb-3">Hourly Forecast</h3>
        <div className="grid grid-cols-6 gap-2 text-center">
          {weather.hourly.map((h, i) => (
            <div key={i} className="flex flex-col items-center gap-2 p-2 rounded-xl hover:bg-white/10 transition-colors">
              <span className="text-xs text-sky-200">{h.time}</span>
              <CloudSun size={22} className="text-amber-300" />
              <span className="text-sm font-bold font-mono">{h.temp}°</span>
            </div>
          ))}
        </div>
      </div>

      {/* 7-Day Forecast */}
      <div className="p-4 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl shadow-md">
        <h3 className="text-xs font-bold text-sky-200 uppercase tracking-wider mb-3">7-Day Forecast</h3>
        <div className="space-y-2">
          {weather.daily.map((d, i) => (
            <div key={i} className="flex items-center justify-between py-2 px-3 rounded-xl hover:bg-white/5 transition-colors">
              <span className="w-20 text-xs font-semibold">{d.day}</span>
              <div className="flex items-center gap-2 flex-1 px-4">
                <CloudSun size={16} className="text-amber-300" />
                <span className="text-xs text-sky-100">{d.condition}</span>
              </div>
              <div className="flex items-center gap-3 text-xs font-mono">
                <span className="font-bold">{d.high}°</span>
                <div className="w-16 h-1.5 bg-white/20 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-400 rounded-full" style={{ width: '70%' }} />
                </div>
                <span className="text-sky-300">{d.low}°</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
