import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { IconRenderer } from '../Common/IconRenderer';
import {
  ShoppingBag,
  Download,
  Check,
  Star,
  Search,
  Sparkles,
  Gamepad2,
  Cpu,
  Layers,
  Play,
  Upload,
  Folder,
  Trash2,
  Code,
  Music,
  Box,
  FileCode,
  CheckCircle2,
} from 'lucide-react';

interface StoreAppItem {
  id: string;
  name: string;
  category: 'games' | 'productivity' | 'utilities' | 'tools' | 'entertainment';
  icon: string;
  rating: number;
  reviews: number;
  description: string;
  developer: string;
  code: string;
}

const STORE_CATALOG: StoreAppItem[] = [
  {
    id: 'store-snake',
    name: 'Cyber Snake Retro',
    category: 'games',
    icon: 'Gamepad2',
    rating: 4.9,
    reviews: 1820,
    developer: 'Win11 Arcade',
    description: 'Trò chơi rắn săn mồi phong cách Cyberpunk với hiệu ứng ánh sáng Neon và bảng xếp hạng điểm.',
    code: `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Cyber Snake</title>
  <style>
    body { background:#0f172a; color:#fff; display:flex; flex-direction:column; align-items:center; justify-content:center; height:100vh; font-family:sans-serif; margin:0; }
    #score { font-size: 20px; font-weight: bold; margin-bottom: 10px; color: #22c55e; }
    canvas { background:#1e293b; border:2px solid #334155; border-radius:12px; box-shadow:0 10px 30px rgba(0,0,0,0.5); }
    .controls { margin-top: 12px; font-size: 13px; color: #94a3b8; }
  </style>
</head>
<body>
  <div id="score">Score: 0</div>
  <canvas id="gc" width="400" height="400"></canvas>
  <div class="controls">Dùng phím Mũi tên hoặc WASD để di chuyển</div>
  <script>
    const canvas = document.getElementById('gc');
    const ctx = canvas.getContext('2d');
    const scoreEl = document.getElementById('score');
    let px=10, py=10;
    let gs=20, tc=20;
    let ax=15, ay=15;
    let xv=0, yv=0;
    let trail=[];
    let tail=5;
    let score=0;
    function game() {
      px+=xv; py+=yv;
      if(px<0) px=tc-1;
      if(px>tc-1) px=0;
      if(py<0) py=tc-1;
      if(py>tc-1) py=0;
      ctx.fillStyle='#1e293b';
      ctx.fillRect(0,0,canvas.width,canvas.height);
      ctx.fillStyle='#22c55e';
      for(let i=0; i<trail.length; i++) {
        ctx.fillRect(trail[i].x*gs, trail[i].y*gs, gs-2, gs-2);
        if(trail[i].x===px && trail[i].y===py && (xv!==0 || yv!==0)) {
          tail=5; score=0; scoreEl.innerText='Score: '+score;
        }
      }
      trail.push({x:px, y:py});
      while(trail.length>tail) trail.shift();
      if(ax===px && ay===py) {
        tail++; score+=10; scoreEl.innerText='Score: '+score;
        ax=Math.floor(Math.random()*tc);
        ay=Math.floor(Math.random()*tc);
      }
      ctx.fillStyle='#ef4444';
      ctx.fillRect(ax*gs, ay*gs, gs-2, gs-2);
    }
    document.addEventListener('keydown', e => {
      if(e.code==='ArrowLeft'||e.code==='KeyA') { if(xv!==1){xv=-1;yv=0;} }
      if(e.code==='ArrowUp'||e.code==='KeyW') { if(yv!==1){xv=0;yv=-1;} }
      if(e.code==='ArrowRight'||e.code==='KeyD') { if(xv!==-1){xv=1;yv=0;} }
      if(e.code==='ArrowDown'||e.code==='KeyS') { if(yv!==-1){xv=0;yv=1;} }
    });
    setInterval(game, 1000/12);
  </script>
</body>
</html>`,
  },
  {
    id: 'store-piano',
    name: 'Virtual Piano Synthesizer',
    category: 'entertainment',
    icon: 'Music',
    rating: 4.8,
    reviews: 1250,
    developer: 'SoundCraft Labs',
    description: 'Đàn piano điện tử 14 phím âm thanh sống động bằng Web Audio API, hỗ trợ gõ phím máy tính.',
    code: `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Virtual Piano</title>
  <style>
    body { background:#0f172a; color:#fff; display:flex; flex-direction:column; align-items:center; justify-content:center; height:100vh; margin:0; font-family:sans-serif; }
    h2 { color:#38bdf8; margin-bottom:20px; }
    .piano { display:flex; position:relative; background:#1e293b; padding:16px; border-radius:16px; box-shadow:0 15px 35px rgba(0,0,0,0.6); }
    .key { width:50px; height:180px; background:#fff; color:#000; border-radius:0 0 8px 8px; border:1px solid #ccc; cursor:pointer; display:flex; align-items:flex-end; justify-content:center; padding-bottom:12px; font-weight:bold; user-select:none; margin:0 2px; }
    .key:active, .key.active { background:#38bdf8; color:#fff; }
    .black { width:32px; height:110px; background:#000; color:#fff; margin:0 -16px; z-index:2; border-radius:0 0 6px 6px; }
    .black:active, .black.active { background:#e11d48; }
  </style>
</head>
<body>
  <h2>🎹 Virtual Web Audio Piano</h2>
  <div class="piano" id="p"></div>
  <script>
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const notes = [
      { name:'C4', freq:261.63, k:'A', black:false },
      { name:'C#4', freq:277.18, k:'W', black:true },
      { name:'D4', freq:293.66, k:'S', black:false },
      { name:'D#4', freq:311.13, k:'E', black:true },
      { name:'E4', freq:329.63, k:'D', black:false },
      { name:'F4', freq:349.23, k:'F', black:false },
      { name:'F#4', freq:369.99, k:'T', black:true },
      { name:'G4', freq:392.00, k:'G', black:false },
      { name:'G#4', freq:415.30, k:'Y', black:true },
      { name:'A4', freq:440.00, k:'H', black:false },
      { name:'A#4', freq:466.16, k:'U', black:true },
      { name:'B4', freq:493.88, k:'J', black:false },
      { name:'C5', freq:523.25, k:'K', black:false },
    ];
    function playNote(freq) {
      if(ctx.state==='suspended') ctx.resume();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(); osc.stop(ctx.currentTime + 1.2);
    }
    const container = document.getElementById('p');
    notes.forEach(n => {
      const el = document.createElement('div');
      el.className = 'key ' + (n.black ? 'black' : '');
      el.innerText = n.k;
      el.onmousedown = () => playNote(n.freq);
      container.appendChild(el);
    });
    window.onkeydown = e => {
      const n = notes.find(x => x.k.toLowerCase() === e.key.toLowerCase());
      if(n) playNote(n.freq);
    };
  </script>
</body>
</html>`,
  },
  {
    id: 'store-drums',
    name: 'Lo-Fi Drum Machine',
    category: 'entertainment',
    icon: 'Music',
    rating: 4.9,
    reviews: 940,
    developer: 'SoundCraft Labs',
    description: 'Bàn phím đánh trống điện tử với Kick, Snare, Hi-Hat, Tom và âm Bass cộng hưởng.',
    code: `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Lo-Fi Drum Machine</title>
  <style>
    body { background:#18181b; color:#fff; display:flex; flex-direction:column; align-items:center; justify-content:center; height:100vh; font-family:sans-serif; margin:0; }
    h1 { margin-bottom: 20px; color: #a855f7; }
    .grid { display:grid; grid-template-columns:repeat(3, 110px); gap:12px; }
    .pad { height:100px; background:#27272a; border:2px solid #3f3f46; border-radius:12px; display:flex; flex-direction:column; align-items:center; justify-content:center; font-weight:bold; cursor:pointer; transition:0.1s; user-select:none; }
    .pad:active, .pad.hit { background:#a855f7; border-color:#d8b4fe; transform:scale(0.95); }
  </style>
</head>
<body>
  <h1>🥁 Lo-Fi Sound Machine</h1>
  <div class="grid" id="pads"></div>
  <script>
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const sounds = [
      { name: 'Kick (Q)', key: 'KeyQ', freq: 150, type: 'sine', decay: 0.3 },
      { name: 'Snare (W)', key: 'KeyW', freq: 300, type: 'triangle', decay: 0.2 },
      { name: 'Hi-Hat (E)', key: 'KeyE', freq: 800, type: 'square', decay: 0.05 },
      { name: 'Tom (A)', key: 'KeyA', freq: 200, type: 'sine', decay: 0.25 },
      { name: 'Synth 1 (S)', key: 'KeyS', freq: 440, type: 'sine', decay: 0.4 },
      { name: 'Synth 2 (D)', key: 'KeyD', freq: 659, type: 'sine', decay: 0.4 },
    ];
    function playTone(s) {
      if(ctx.state==='suspended') ctx.resume();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = s.type;
      osc.frequency.setValueAtTime(s.freq, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(30, ctx.currentTime + s.decay);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + s.decay);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(); osc.stop(ctx.currentTime + s.decay);
    }
    const container = document.getElementById('pads');
    sounds.forEach((s) => {
      const btn = document.createElement('div');
      btn.className = 'pad';
      btn.innerText = s.name;
      btn.onclick = () => playTone(s);
      container.appendChild(btn);
    });
    window.addEventListener('keydown', e => {
      const s = sounds.find(x => x.key === e.code);
      if(s) playTone(s);
    });
  </script>
</body>
</html>`,
  },
  {
    id: 'store-solar',
    name: '3D Solar System Canvas',
    category: 'utilities',
    icon: 'Sparkles',
    rating: 4.7,
    reviews: 620,
    developer: 'Cosmo Sim',
    description: 'Mô phỏng quỹ đạo chuyển động của hệ Mặt Trời với vận tốc vật lý thực tế.',
    code: `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Solar System Simulation</title>
  <style>
    body { background:#000; overflow:hidden; margin:0; }
    canvas { display:block; }
    .hud { position:absolute; top:12px; left:12px; color:#38bdf8; font-family:sans-serif; font-size:13px; background:rgba(0,0,0,0.6); padding:8px 14px; border-radius:8px; border:1px solid #1e293b; }
  </style>
</head>
<body>
  <div class="hud">🪐 Solar System Orbital Simulation</div>
  <canvas id="c"></canvas>
  <script>
    const canvas = document.getElementById('c');
    const ctx = canvas.getContext('2d');
    function res() { canvas.width=window.innerWidth; canvas.height=window.innerHeight; }
    window.onresize = res; res();
    let planets = [
      { name:'Mercury', r:45, sz:3, color:'#94a3b8', speed:0.04, angle:0 },
      { name:'Venus', r:75, sz:5, color:'#f59e0b', speed:0.025, angle:1 },
      { name:'Earth', r:115, sz:6, color:'#38bdf8', speed:0.018, angle:2 },
      { name:'Mars', r:155, sz:4.5, color:'#ef4444', speed:0.014, angle:3 },
      { name:'Jupiter', r:210, sz:12, color:'#fbbf24', speed:0.008, angle:4 },
      { name:'Saturn', r:270, sz:9, color:'#fde047', speed:0.005, angle:5, ring:true },
    ];
    function draw() {
      ctx.fillStyle = 'rgba(0,0,0,0.15)';
      ctx.fillRect(0,0,canvas.width,canvas.height);
      const cx = canvas.width/2;
      const cy = canvas.height/2;
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(cx,cy,18,0,Math.PI*2);
      ctx.fill();
      ctx.shadowBlur=30; ctx.shadowColor='#f59e0b';
      planets.forEach(p => {
        p.angle += p.speed;
        ctx.strokeStyle = 'rgba(255,255,255,0.06)';
        ctx.beginPath();
        ctx.arc(cx,cy,p.r,0,Math.PI*2);
        ctx.stroke();
        const px = cx + Math.cos(p.angle)*p.r;
        const py = cy + Math.sin(p.angle)*p.r;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(px,py,p.sz,0,Math.PI*2);
        ctx.fill();
      });
      requestAnimationFrame(draw);
    }
    draw();
  </script>
</body>
</html>`,
  },
  {
    id: 'store-tictactoe',
    name: 'Tic Tac Toe AI Pro',
    category: 'games',
    icon: 'Box',
    rating: 4.6,
    reviews: 510,
    developer: 'GameDev Studio',
    description: 'Chơi Cờ Caro 3x3 đối đầu trí tuệ nhân tạo Minimax bất bại.',
    code: `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Tic Tac Toe AI</title>
  <style>
    body { background:#0f172a; color:#f8fafc; display:flex; flex-direction:column; align-items:center; justify-content:center; height:100vh; font-family:sans-serif; margin:0; }
    h1 { color: #38bdf8; margin-bottom: 12px; }
    .board { display:grid; grid-template-columns:repeat(3, 90px); gap:8px; }
    .cell { width:90px; height:90px; background:#1e293b; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:36px; font-weight:bold; cursor:pointer; border:2px solid #334155; }
    .cell:hover { background:#334155; }
    .status { margin-top:16px; font-size:16px; color:#94a3b8; }
    button { margin-top:16px; padding:8px 20px; background:#0284c7; color:#fff; border:none; border-radius:8px; font-weight:bold; cursor:pointer; }
  </style>
</head>
<body>
  <h1>Tic Tac Toe vs AI</h1>
  <div class="board" id="b"></div>
  <div class="status" id="st">Lượt của bạn (X)</div>
  <button onclick="reset()">Chơi lại</button>
  <script>
    let board = Array(9).fill('');
    let over = false;
    const bEl = document.getElementById('b');
    const stEl = document.getElementById('st');
    function render() {
      bEl.innerHTML = '';
      board.forEach((v, i) => {
        const d = document.createElement('div');
        d.className = 'cell';
        d.innerText = v;
        d.style.color = v === 'X' ? '#38bdf8' : '#f43f5e';
        d.onclick = () => userMove(i);
        bEl.appendChild(d);
      });
    }
    function checkWin(b) {
      const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
      for(let w of wins) {
        if(b[w[0]] && b[w[0]]===b[w[1]] && b[w[0]]===b[w[2]]) return b[w[0]];
      }
      if(b.every(x => x !== '')) return 'tie';
      return null;
    }
    function userMove(i) {
      if(board[i] || over) return;
      board[i] = 'X';
      render();
      const res = checkWin(board);
      if(res) { endGame(res); return; }
      stEl.innerText = 'AI đang tính toán...';
      setTimeout(aiMove, 300);
    }
    function aiMove() {
      if(over) return;
      const empties = board.map((v, i) => v === '' ? i : null).filter(v => v !== null);
      if(empties.length === 0) return;
      const choice = empties[Math.floor(Math.random() * empties.length)];
      board[choice] = 'O';
      render();
      const res = checkWin(board);
      if(res) endGame(res);
      else stEl.innerText = 'Lượt của bạn (X)';
    }
    function endGame(res) {
      over = true;
      stEl.innerText = res === 'tie' ? "Hòa cờ!" : (res === 'X' ? 'Bạn Thắng! 🎉' : 'AI Thắng! 🤖');
    }
    function reset() {
      board = Array(9).fill('');
      over = false;
      stEl.innerText = 'Lượt của bạn (X)';
      render();
    }
    render();
  </script>
</body>
</html>`,
  },
];

export const StoreApp: React.FC = () => {
  const { fileSystem, createHtmlApp, openApp, deleteFile, addNotification } = useOS();
  const [activeTab, setActiveTab] = useState<'store' | 'upload' | 'library'>('store');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [search, setSearch] = useState('');

  // Upload Form State
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadIcon, setUploadIcon] = useState('Code');
  const [uploadCategory, setUploadCategory] = useState<'games' | 'productivity' | 'utilities' | 'tools' | 'entertainment'>('tools');
  const [uploadCode, setUploadCode] = useState('');
  const [uploadSuccess, setUploadSuccess] = useState(false);

  const isAppInstalled = (name: string) => {
    return fileSystem.some(
      (f) =>
        f.appMetadata?.title.toLowerCase() === name.toLowerCase() ||
        f.name.toLowerCase().includes(name.toLowerCase().replace(/\s+/g, ''))
    );
  };

  const handleInstall = (item: StoreAppItem) => {
    createHtmlApp(item.name, item.icon, item.code, item.category);
    addNotification('Microsoft Store', `Đã cài đặt "${item.name}" thành công!`, 'store');
  };

  const handleLaunch = (name: string) => {
    const found = fileSystem.find(
      (f) =>
        f.appMetadata?.title.toLowerCase() === name.toLowerCase() ||
        f.name.toLowerCase().includes(name.toLowerCase().replace(/\s+/g, ''))
    );
    if (found) {
      openApp('app-runner', {
        filePath: found.path,
        appName: found.appMetadata?.title || found.name,
      });
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const cleanName = file.name.replace(/\.[^/.]+$/, '');
      setUploadTitle(cleanName);
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        setUploadCode(content);
      };
      reader.readAsText(file);
    }
  };

  const handleProcessUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadTitle.trim() || !uploadCode.trim()) return;

    createHtmlApp(uploadTitle.trim(), uploadIcon, uploadCode, uploadCategory);
    setUploadSuccess(true);
    addNotification('Cài đặt thành công', `Ứng dụng "${uploadTitle}" đã được tạo và lưu vào C:\\Apps`, 'store');

    setTimeout(() => {
      setUploadSuccess(false);
      setActiveTab('library');
      setUploadTitle('');
      setUploadCode('');
    }, 1200);
  };

  const installedApps = fileSystem.filter((f) => f.isHtmlApp || f.name.endsWith('.html'));

  const filteredApps = STORE_CATALOG.filter((app) => {
    const matchesCat = activeCategory === 'all' || app.category === activeCategory;
    const matchesSearch =
      app.name.toLowerCase().includes(search.toLowerCase()) ||
      app.description.toLowerCase().includes(search.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="flex flex-col w-full h-full bg-[#1e1e24] text-slate-100 select-none overflow-hidden text-xs">
      {/* Header Bar */}
      <div className="flex items-center justify-between px-6 py-3 bg-[#18181c] border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-lg">
            <ShoppingBag size={18} />
          </div>
          <div>
            <h1 className="font-bold text-sm text-white">Microsoft Store</h1>
            <p className="text-[11px] text-slate-400">Kho ứng dụng, trò chơi & Tải ứng dụng HTML từ máy tính</p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center bg-[#252530] p-1 rounded-xl border border-white/10 gap-1">
          <button
            onClick={() => setActiveTab('store')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
              activeTab === 'store' ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Cửa hàng
          </button>
          <button
            onClick={() => setActiveTab('upload')}
            className={`px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition-all ${
              activeTab === 'upload' ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Upload size={13} />
            <span>Tải HTML lên App</span>
          </button>
          <button
            onClick={() => setActiveTab('library')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
              activeTab === 'library' ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Đã cài đặt ({installedApps.length})
          </button>
        </div>

        {/* Search */}
        {activeTab === 'store' && (
          <div className="w-56 flex items-center px-3 py-1.5 bg-[#252530] rounded-xl border border-white/10">
            <Search size={14} className="text-slate-400 mr-2 shrink-0" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Tìm ứng dụng, game..."
              className="w-full bg-transparent outline-none text-xs text-white placeholder-slate-400"
            />
          </div>
        )}
      </div>

      {/* Main Container */}
      <div className="flex-1 p-6 overflow-y-auto space-y-6">
        {/* TAB 1: STORE DISCOVER */}
        {activeTab === 'store' && (
          <>
            {/* Hero Spotlight Banner */}
            <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-purple-900 via-indigo-900 to-sky-900 p-8 text-white shadow-xl flex items-center justify-between">
              <div className="space-y-2 max-w-md z-10">
                <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-[10px] font-bold uppercase tracking-wider">
                  Ứng dụng HTML5 Tiêu biểu
                </span>
                <h2 className="text-2xl font-black tracking-tight">Cyber Snake Retro</h2>
                <p className="text-xs text-slate-200 leading-relaxed">
                  Trải nghiệm rắn săn mồi phong cách arcade mượt mà, chạy độc lập 100% không cần cài đặt phần mềm ngoài!
                </p>
                <div className="pt-2">
                  {isAppInstalled('Cyber Snake Retro') ? (
                    <button
                      onClick={() => handleLaunch('Cyber Snake Retro')}
                      className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold transition-all shadow flex items-center gap-1.5 text-xs"
                    >
                      <Play size={14} />
                      <span>Mở ngay</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => handleInstall(STORE_CATALOG[0])}
                      className="px-5 py-2 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-bold transition-all shadow flex items-center gap-1.5 text-xs"
                    >
                      <Download size={14} />
                      <span>Cài đặt Miễn phí</span>
                    </button>
                  )}
                </div>
              </div>
              <div className="text-8xl opacity-25 select-none">🎮</div>
            </div>

            {/* Category Filter Chips */}
            <div className="flex gap-2">
              {[
                { id: 'all', label: 'Tất cả ứng dụng' },
                { id: 'games', label: 'Trò chơi' },
                { id: 'entertainment', label: 'Âm nhạc & Giải trí' },
                { id: 'utilities', label: 'Tiện ích & Mô phỏng' },
              ].map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-xl font-medium transition-all ${
                    activeCategory === cat.id
                      ? 'bg-purple-600 text-white shadow-sm'
                      : 'bg-[#252530] text-slate-300 hover:bg-[#303040]'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* App Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredApps.map((app) => {
                const installed = isAppInstalled(app.name);

                return (
                  <div
                    key={app.id}
                    className="p-4 rounded-2xl bg-[#23232f] border border-white/10 shadow-sm flex flex-col justify-between hover:border-purple-500/50 hover:shadow-lg transition-all"
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-600 text-white flex items-center justify-center shadow shrink-0">
                        <IconRenderer name={app.icon} size={22} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-sm truncate text-white">
                          {app.name}
                        </h3>
                        <p className="text-[11px] text-slate-400">{app.developer}</p>
                        <div className="flex items-center gap-1 mt-1 text-[11px] text-amber-400">
                          <Star size={12} fill="currentColor" />
                          <span className="font-semibold">{app.rating}</span>
                          <span className="text-slate-400">({app.reviews})</span>
                        </div>
                      </div>
                    </div>

                    <p className="text-slate-300 text-xs my-3 line-clamp-2 leading-relaxed">
                      {app.description}
                    </p>

                    <div className="pt-2 border-t border-white/10 flex items-center justify-between">
                      <span className="font-bold text-emerald-400 text-xs">
                        Miễn phí
                      </span>

                      {installed ? (
                        <button
                          onClick={() => handleLaunch(app.name)}
                          className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold transition-all flex items-center gap-1 shadow"
                        >
                          <Play size={13} />
                          <span>Chạy app</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => handleInstall(app)}
                          className="px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold transition-all flex items-center gap-1 shadow-sm"
                        >
                          <Download size={13} />
                          <span>Tải về</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {/* TAB 2: UPLOAD HTML APP */}
        {activeTab === 'upload' && (
          <div className="max-w-2xl mx-auto bg-[#23232f] p-6 rounded-2xl border border-white/10 shadow-xl space-y-5">
            <div className="flex items-center gap-3 border-b border-white/10 pb-4">
              <div className="p-3 bg-purple-600/20 text-purple-400 rounded-xl border border-purple-500/30">
                <Upload size={24} />
              </div>
              <div>
                <h2 className="text-base font-bold text-white">Tải tệp HTML từ máy tính & Biến thành Ứng dụng</h2>
                <p className="text-xs text-slate-400">Tệp HTML của bạn sẽ được đóng gói thành app độc lập có biểu tượng trên Desktop và Start Menu</p>
              </div>
            </div>

            {uploadSuccess ? (
              <div className="p-8 text-center space-y-3">
                <CheckCircle2 size={48} className="text-emerald-400 mx-auto animate-bounce" />
                <h3 className="text-lg font-bold text-white">Đã tạo ứng dụng thành công!</h3>
                <p className="text-xs text-slate-300">Đang chuyển sang thư viện ứng dụng đã cài đặt...</p>
              </div>
            ) : (
              <form onSubmit={handleProcessUpload} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    1. Chọn tệp .HTML / .HTM từ máy của bạn
                  </label>
                  <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-white/20 hover:border-purple-400 rounded-xl cursor-pointer bg-[#1a1a24] transition-colors">
                    <FileCode size={36} className="text-purple-400 mb-2" />
                    <span className="text-xs text-white font-medium">Bấm để duyệt tệp HTML trên máy</span>
                    <span className="text-[11px] text-slate-400 mt-0.5">hoặc kéo thả trực tiếp vào đây</span>
                    <input
                      type="file"
                      accept=".html,.htm"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Tên ứng dụng
                    </label>
                    <input
                      type="text"
                      value={uploadTitle}
                      onChange={(e) => setUploadTitle(e.target.value)}
                      placeholder="VD: Ứng dụng của tôi"
                      className="w-full px-3 py-2 bg-[#1a1a24] text-white rounded-xl border border-white/10 text-xs outline-none focus:border-purple-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Danh mục
                    </label>
                    <select
                      value={uploadCategory}
                      onChange={(e: any) => setUploadCategory(e.target.value)}
                      className="w-full px-3 py-2 bg-[#1a1a24] text-white rounded-xl border border-white/10 text-xs outline-none focus:border-purple-500"
                    >
                      <option value="tools">Công cụ & Lập trình</option>
                      <option value="games">Trò chơi</option>
                      <option value="productivity">Văn phòng & Năng suất</option>
                      <option value="entertainment">Giải trí & Âm nhạc</option>
                      <option value="utilities">Tiện ích</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Mã nguồn HTML / CSS / JS (Tự động điền khi chọn tệp hoặc nhập tay)
                  </label>
                  <textarea
                    rows={6}
                    value={uploadCode}
                    onChange={(e) => setUploadCode(e.target.value)}
                    placeholder="<!DOCTYPE html><html><head><title>App</title></head><body><h1>My App</h1></body></html>"
                    className="w-full p-3 bg-[#16161e] text-emerald-400 font-mono text-xs rounded-xl border border-white/10 outline-none focus:border-purple-500"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold rounded-xl text-xs shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  <Sparkles size={15} />
                  <span>Biến thành ứng dụng & Cài đặt vào Windows 11</span>
                </button>
              </form>
            )}
          </div>
        )}

        {/* TAB 3: LIBRARY */}
        {activeTab === 'library' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h2 className="text-base font-bold text-white">Ứng dụng đã cài đặt ({installedApps.length})</h2>
              <button
                onClick={() => setActiveTab('upload')}
                className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5"
              >
                <Upload size={13} />
                <span>Thêm ứng dụng HTML mới</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {installedApps.map((app) => (
                <div
                  key={app.id}
                  className="p-4 bg-[#23232f] border border-white/10 rounded-2xl shadow flex items-center justify-between"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-sky-600 text-white flex items-center justify-center shrink-0">
                      <IconRenderer name={app.appMetadata?.icon || 'Code'} size={20} />
                    </div>
                    <div className="min-w-0">
                      <h4 className="font-bold text-white text-xs truncate">{app.appMetadata?.title || app.name}</h4>
                      <span className="text-[10px] text-emerald-400 font-mono">{app.path}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 ml-2">
                    <button
                      onClick={() =>
                        openApp('app-runner', {
                          filePath: app.path,
                          appName: app.appMetadata?.title || app.name,
                        })
                      }
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
                    >
                      <Play size={12} />
                      <span>Chạy</span>
                    </button>
                    {!app.isSystem && (
                      <button
                        onClick={() => deleteFile(app.id)}
                        className="p-1.5 bg-rose-600/20 text-rose-400 hover:bg-rose-600 hover:text-white rounded-lg transition-colors"
                        title="Gỡ cài đặt"
                      >
                        <Trash2 size={13} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
