import React, { useState, useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import {
  RotateCw,
  Code,
  Terminal,
  Maximize2,
  Download,
  ExternalLink,
  Smartphone,
  Monitor,
  Tablet,
  Save,
  Check,
} from 'lucide-react';

interface HtmlAppRunnerProps {
  initialHtml?: string;
  code?: string;
  filePath?: string;
  appName?: string;
}

export const HtmlAppRunner: React.FC<HtmlAppRunnerProps> = ({
  initialHtml = '',
  code: directCode,
  filePath,
  appName = 'HTML Application',
}) => {
  const { fileSystem, updateFileContent, addNotification } = useOS();

  // Find file from file system if path provided
  const targetFile = filePath ? fileSystem.find((f) => f.path === filePath) : null;
  const currentContent = targetFile?.content ?? directCode ?? initialHtml;

  const [code, setCode] = useState(currentContent);
  const [isEditing, setIsEditing] = useState(false);
  const [showConsole, setShowConsole] = useState(false);
  const [logs, setLogs] = useState<{ type: 'log' | 'warn' | 'error'; message: string; time: string }[]>([]);
  const [viewportMode, setViewportMode] = useState<'fill' | 'mobile' | 'tablet'>('fill');
  const [reloadKey, setReloadKey] = useState(0);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Sync state if external file updates
  useEffect(() => {
    if (targetFile?.content !== undefined) {
      setCode(targetFile.content);
    }
  }, [targetFile?.content]);

  // Handle messages / logs from the iframe
  useEffect(() => {
    const handleMessage = (e: MessageEvent) => {
      if (e.data && e.data.__win11_app_log) {
        const { type, message } = e.data.__win11_app_log;
        const now = new Date().toLocaleTimeString();
        setLogs((prev) => [...prev.slice(-100), { type, message, time: now }]);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  // Injected wrapper to capture console and handle local storage sandbox
  const injectedCode = `
    <!DOCTYPE html>
    <html>
    <head>
      <script>
        (function() {
          const oldLog = console.log;
          const oldWarn = console.warn;
          const oldError = console.error;
          function post(type, args) {
            try {
              const msg = Array.from(args).map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ');
              window.parent.postMessage({ __win11_app_log: { type, message: msg } }, '*');
            } catch(e){}
          }
          console.log = function() { post('log', arguments); oldLog.apply(console, arguments); };
          console.warn = function() { post('warn', arguments); oldWarn.apply(console, arguments); };
          console.error = function() { post('error', arguments); oldError.apply(console, arguments); };
          window.onerror = function(msg, url, line) {
            post('error', ['Error: ' + msg + ' at line ' + line]);
          };
        })();
      </script>
    </head>
    <body>
      ${code}
    </body>
    </html>
  `;

  const handleSave = () => {
    if (filePath) {
      updateFileContent(filePath, code);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2000);
      addNotification('App Saved', `${appName} was updated successfully!`, 'appsfolder');
    }
    setReloadKey((k) => k + 1);
  };

  const handleDownload = () => {
    const blob = new Blob([code], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = (filePath ? filePath.split('\\').pop() : `${appName}.html`) || 'app.html';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleOpenInNewTab = () => {
    const blob = new Blob([code], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  };

  return (
    <div className="flex flex-col w-full h-full bg-slate-900 text-slate-100 overflow-hidden select-none">
      {/* Top App Bar Controls */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-slate-800/90 dark:bg-[#1a1a1a]/95 border-b border-white/10 text-xs gap-2">
        <div className="flex items-center gap-1.5">
          <button
            id="btn-reload-html"
            onClick={() => setReloadKey((k) => k + 1)}
            title="Reload Application"
            className="p-1.5 rounded-md hover:bg-white/10 active:scale-95 transition-colors text-slate-300 hover:text-white"
          >
            <RotateCw size={14} />
          </button>

          <div className="h-3.5 border-r border-white/15 mx-1" />

          {/* Viewport switcher */}
          <div className="flex items-center bg-black/30 rounded-lg p-0.5 border border-white/10">
            <button
              onClick={() => setViewportMode('fill')}
              className={`p-1 rounded ${viewportMode === 'fill' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'}`}
              title="Full Window View"
            >
              <Monitor size={13} />
            </button>
            <button
              onClick={() => setViewportMode('tablet')}
              className={`p-1 rounded ${viewportMode === 'tablet' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'}`}
              title="Tablet View (768px)"
            >
              <Tablet size={13} />
            </button>
            <button
              onClick={() => setViewportMode('mobile')}
              className={`p-1 rounded ${viewportMode === 'mobile' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'}`}
              title="Mobile View (375px)"
            >
              <Smartphone size={13} />
            </button>
          </div>
        </div>

        {/* Action controls */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsEditing(!isEditing)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium transition-colors ${
              isEditing ? 'bg-sky-600 text-white' : 'bg-white/10 hover:bg-white/15 text-slate-200'
            }`}
          >
            <Code size={13} />
            <span>{isEditing ? 'Hide Code' : 'Edit Code'}</span>
          </button>

          <button
            onClick={() => setShowConsole(!showConsole)}
            className={`flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium transition-colors ${
              showConsole ? 'bg-purple-600 text-white' : 'bg-white/10 hover:bg-white/15 text-slate-300'
            }`}
          >
            <Terminal size={13} />
            <span>Console</span>
            {logs.length > 0 && (
              <span className="ml-1 px-1 bg-white/20 rounded-full text-[10px]">
                {logs.length}
              </span>
            )}
          </button>

          <button
            onClick={handleDownload}
            title="Download HTML File"
            className="p-1.5 rounded-md hover:bg-white/10 text-slate-300 hover:text-white"
          >
            <Download size={14} />
          </button>

          <button
            onClick={handleOpenInNewTab}
            title="Open in Browser Tab"
            className="p-1.5 rounded-md hover:bg-white/10 text-slate-300 hover:text-white"
          >
            <ExternalLink size={14} />
          </button>
        </div>
      </div>

      {/* Main Body: Runner + Optional Live Code Editor */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Iframe App Container */}
        <div
          className={`flex-1 h-full bg-slate-950 flex items-center justify-center overflow-auto p-1 transition-all ${
            isEditing ? 'w-1/2' : 'w-full'
          }`}
        >
          <div
            className={`h-full bg-white transition-all overflow-hidden rounded shadow-2xl border border-slate-800 ${
              viewportMode === 'fill'
                ? 'w-full'
                : viewportMode === 'tablet'
                ? 'w-[768px] max-w-full my-auto'
                : 'w-[375px] max-w-full my-auto'
            }`}
          >
            <iframe
              key={reloadKey}
              ref={iframeRef}
              srcDoc={injectedCode}
              title={appName}
              sandbox="allow-scripts allow-modals allow-forms allow-same-origin"
              className="w-full h-full border-0 bg-white"
            />
          </div>
        </div>

        {/* Live Code Editor Drawer */}
        {isEditing && (
          <div className="w-1/2 h-full flex flex-col bg-[#181818] border-l border-white/10 select-text animate-win11-fade">
            <div className="flex items-center justify-between px-3 py-1.5 bg-[#252525] border-b border-white/10 text-xs">
              <span className="font-mono text-amber-400 font-semibold flex items-center gap-1.5">
                <Code size={13} />
                HTML / CSS / JS Live Editor
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleSave}
                  className="flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-medium text-xs transition-colors"
                >
                  {savedSuccess ? <Check size={13} /> : <Save size={13} />}
                  <span>{savedSuccess ? 'Saved!' : 'Save & Run'}</span>
                </button>
              </div>
            </div>

            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="flex-1 p-3 bg-[#1e1e1e] text-slate-200 font-mono text-xs resize-none outline-none border-none leading-relaxed selection:bg-sky-600/40"
              spellCheck={false}
              placeholder="Enter full HTML, CSS (<style>) and JS (<script>) code here..."
            />
          </div>
        )}
      </div>

      {/* Embedded Console Drawer */}
      {showConsole && (
        <div className="h-36 bg-[#121212] border-t border-white/10 flex flex-col font-mono text-xs select-text">
          <div className="flex items-center justify-between px-3 py-1 bg-[#1a1a1a] border-b border-white/10 text-[11px] text-slate-400">
            <span className="flex items-center gap-1">
              <Terminal size={12} /> App Console Output
            </span>
            <button
              onClick={() => setLogs([])}
              className="hover:text-white px-2 py-0.5 rounded bg-white/5"
            >
              Clear
            </button>
          </div>
          <div className="flex-1 p-2 overflow-y-auto space-y-1">
            {logs.length === 0 ? (
              <div className="text-slate-500 italic text-[11px]">No console logs yet.</div>
            ) : (
              logs.map((l, i) => (
                <div
                  key={i}
                  className={`flex items-start gap-2 text-[11px] ${
                    l.type === 'error'
                      ? 'text-red-400'
                      : l.type === 'warn'
                      ? 'text-amber-300'
                      : 'text-slate-300'
                  }`}
                >
                  <span className="text-slate-500 text-[10px] shrink-0">[{l.time}]</span>
                  <span className="break-all whitespace-pre-wrap">{l.message}</span>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
