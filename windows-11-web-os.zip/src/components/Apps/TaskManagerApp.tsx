import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useOS } from '../../context/OSContext';
import { getLocalizedAppName } from '../../utils/appRegistry';
import {
  Activity,
  Cpu,
  HardDrive,
  Wifi,
  Layers,
  XCircle,
  Play,
  Minus,
  Shield,
  RefreshCw,
  Sliders,
  Users as UsersIcon,
  History,
  FileText,
  Settings2,
} from 'lucide-react';
import {
  TaskManagerTab,
  ProcessItemData,
  AppHistoryItemData,
  UserSessionData,
  ServiceItemData,
  PriorityLevel,
  ColumnVisibility,
  ServiceStatus,
} from './TaskManager/types';
import { TaskManagerMenuBar } from './TaskManager/TaskManagerMenuBar';
import { ProcessesTab } from './TaskManager/ProcessesTab';
import { PerformanceTab } from './TaskManager/PerformanceTab';
import { AppHistoryTab } from './TaskManager/AppHistoryTab';
import { UsersTab } from './TaskManager/UsersTab';
import { DetailsTab } from './TaskManager/DetailsTab';
import { ServicesTab } from './TaskManager/ServicesTab';
import { NewTaskModal } from './TaskManager/NewTaskModal';
import { ServicePropertiesModal } from './TaskManager/ServicePropertiesModal';
import { AboutTaskManagerModal } from './TaskManager/AboutTaskManagerModal';

const INITIAL_SERVICES: ServiceItemData[] = [
  {
    id: 'srv-wuauserv',
    name: 'wuauserv',
    description: 'Windows Update Service',
    status: 'Đang chạy',
    startupType: 'Tự động (trễ)',
    executablePath: 'C:\\Windows\\System32\\svchost.exe -k netsvcs -p',
    logOnAs: 'NT AUTHORITY\\LocalSystem',
    dependencies: 'RPCSS, DcomLaunch',
    pid: 1044,
  },
  {
    id: 'srv-windefend',
    name: 'WinDefend',
    description: 'Dịch vụ Chống vi-rút của Microsoft Defender',
    status: 'Đang chạy',
    startupType: 'Tự động',
    executablePath: 'C:\\ProgramData\\Microsoft\\Windows Defender\\Platform\\MsMpEng.exe',
    logOnAs: 'NT AUTHORITY\\LocalSystem',
    dependencies: 'RPCSS',
    pid: 2160,
  },
  {
    id: 'srv-spooler',
    name: 'Spooler',
    description: 'Dịch vụ Bộ đệm Máy in (Print Spooler)',
    status: 'Đang chạy',
    startupType: 'Tự động',
    executablePath: 'C:\\Windows\\System32\\spoolsv.exe',
    logOnAs: 'LocalSystem',
    dependencies: 'RPCSS, HTTP',
    pid: 1820,
  },
  {
    id: 'srv-eventlog',
    name: 'EventLog',
    description: 'Nhật ký sự kiện Windows (Windows Event Log)',
    status: 'Đang chạy',
    startupType: 'Tự động',
    executablePath: 'C:\\Windows\\System32\\svchost.exe -k LocalServiceNetworkRestricted',
    logOnAs: 'NT AUTHORITY\\LocalService',
    dependencies: 'RPCSS',
    pid: 940,
  },
  {
    id: 'srv-themes',
    name: 'Themes',
    description: 'Dịch vụ Giao diện Trực quan & Chủ đề Windows',
    status: 'Đang chạy',
    startupType: 'Tự động',
    executablePath: 'C:\\Windows\\System32\\svchost.exe -k netsvcs',
    logOnAs: 'LocalSystem',
    dependencies: 'RPCSS',
    pid: 1204,
  },
  {
    id: 'srv-audiosrv',
    name: 'AudioSrv',
    description: 'Windows Audio Core Endpoint Service',
    status: 'Đang chạy',
    startupType: 'Tự động',
    executablePath: 'C:\\Windows\\System32\\svchost.exe -k LocalServiceNetworkRestricted',
    logOnAs: 'NT AUTHORITY\\LocalService',
    dependencies: 'AudioEndpointBuilder, RpcSs',
    pid: 1532,
  },
  {
    id: 'srv-wsearch',
    name: 'WSearch',
    description: 'Windows Search Indexer Engine',
    status: 'Đang chạy',
    startupType: 'Tự động (trễ)',
    executablePath: 'C:\\Windows\\System32\\SearchIndexer.exe /subproc',
    logOnAs: 'NT AUTHORITY\\LocalSystem',
    dependencies: 'RPCSS',
    pid: 3108,
  },
  {
    id: 'srv-bits',
    name: 'BITS',
    description: 'Background Intelligent Transfer Service',
    status: 'Đang chạy',
    startupType: 'Thủ công',
    executablePath: 'C:\\Windows\\System32\\svchost.exe -k netsvcs',
    logOnAs: 'NT AUTHORITY\\LocalSystem',
    dependencies: 'RPCSS',
    pid: 2492,
  },
  {
    id: 'srv-cryptsvc',
    name: 'CryptSvc',
    description: 'Dịch vụ Mật mã (Cryptographic Services)',
    status: 'Đang chạy',
    startupType: 'Tự động',
    executablePath: 'C:\\Windows\\System32\\svchost.exe -k NetworkService',
    logOnAs: 'NT AUTHORITY\\NetworkService',
    dependencies: 'RPCSS',
    pid: 1610,
  },
  {
    id: 'srv-lanman',
    name: 'LanmanWorkstation',
    description: 'Trạm làm việc Máy khách Mạng SMB',
    status: 'Đang chạy',
    startupType: 'Tự động',
    executablePath: 'C:\\Windows\\System32\\svchost.exe -k NetworkService',
    logOnAs: 'NT AUTHORITY\\NetworkService',
    dependencies: 'bowser, mrxsmb10, nsi',
    pid: 1420,
  },
  {
    id: 'srv-bluetooth',
    name: 'bthserv',
    description: 'Dịch vụ Hỗ trợ Thiết bị Bluetooth',
    status: 'Đã dừng',
    startupType: 'Thủ công',
    executablePath: 'C:\\Windows\\System32\\svchost.exe -k bthsvcs',
    logOnAs: 'NT AUTHORITY\\LocalService',
    dependencies: 'RPCSS',
  },
  {
    id: 'srv-sysmain',
    name: 'SysMain',
    description: 'Duy trì & Cải thiện Hiệu năng Ứng dụng SuperFetch',
    status: 'Đang chạy',
    startupType: 'Tự động',
    executablePath: 'C:\\Windows\\System32\\svchost.exe -k sysmain',
    logOnAs: 'NT AUTHORITY\\LocalSystem',
    dependencies: 'RPCSS',
    pid: 1740,
  },
];

const INITIAL_APP_HISTORY: AppHistoryItemData[] = [
  {
    id: 'hist-edge',
    appName: 'Microsoft Edge',
    icon: 'Edge',
    runtime: '04:12:35',
    cpuTime: '38m 20s',
    avgMemory: 412,
    diskUsage: '240.5 MB',
    networkUsage: '1.2 GB',
    activeDuration: '2 ngày 8 giờ',
    lastOpened: 'Hôm nay 09:30',
    status: 'running',
  },
  {
    id: 'hist-terminal',
    appName: 'Windows Terminal / PowerShell',
    icon: 'Terminal',
    runtime: '02:45:10',
    cpuTime: '14m 12s',
    avgMemory: 128,
    diskUsage: '85.4 MB',
    networkUsage: '45.2 MB',
    activeDuration: '1 ngày 4 giờ',
    lastOpened: 'Hôm nay 10:15',
    status: 'running',
  },
  {
    id: 'hist-explorer',
    appName: 'File Explorer',
    icon: 'Folder',
    runtime: '06:30:00',
    cpuTime: '08m 45s',
    avgMemory: 96,
    diskUsage: '512.0 MB',
    networkUsage: '12.4 MB',
    activeDuration: '3 ngày',
    lastOpened: 'Hôm nay 08:00',
    status: 'running',
  },
  {
    id: 'hist-calc',
    appName: 'Máy tính (Calculator)',
    icon: 'Calculator',
    runtime: '00:15:20',
    cpuTime: '00m 18s',
    avgMemory: 42,
    diskUsage: '4.2 MB',
    networkUsage: '0.0 MB',
    activeDuration: '4 giờ',
    lastOpened: 'Hôm qua 16:45',
    status: 'closed',
  },
  {
    id: 'hist-notepad',
    appName: 'Notepad',
    icon: 'FileText',
    runtime: '01:10:05',
    cpuTime: '01m 02s',
    avgMemory: 38,
    diskUsage: '12.0 MB',
    networkUsage: '0.0 MB',
    activeDuration: '1 ngày',
    lastOpened: 'Hôm nay 11:20',
    status: 'closed',
  },
  {
    id: 'hist-paint',
    appName: 'Paint',
    icon: 'Image',
    runtime: '00:45:00',
    cpuTime: '05m 30s',
    avgMemory: 110,
    diskUsage: '34.8 MB',
    networkUsage: '0.0 MB',
    activeDuration: '6 giờ',
    lastOpened: '2 ngày trước',
    status: 'closed',
  },
  {
    id: 'hist-security',
    appName: 'Windows Security',
    icon: 'Shield',
    runtime: '08:00:00',
    cpuTime: '12m 40s',
    avgMemory: 84,
    diskUsage: '145.0 MB',
    networkUsage: '65.0 MB',
    activeDuration: '3 ngày',
    lastOpened: 'Hôm nay 07:00',
    status: 'running',
  },
];

export const TaskManagerApp: React.FC = () => {
  const { windows, closeWindow, minimizeWindow, openApp, addNotification, addFile, t } = useOS();

  // Active Tab State (Exact 6 tabs order)
  const [activeTab, setActiveTab] = useState<TaskManagerTab>('processes');

  // Selected states
  const [selectedProcessId, setSelectedProcessId] = useState<string | null>(null);
  const [selectedPid, setSelectedPid] = useState<number | null>(null);
  const [selectedServiceId, setSelectedServiceId] = useState<string | null>(null);

  // Modals
  const [isNewTaskOpen, setIsNewTaskOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [activeServiceForProps, setActiveServiceForProps] = useState<ServiceItemData | null>(null);

  // Options & Views
  const [alwaysOnTop, setAlwaysOnTop] = useState(false);
  const [minimizeOnClose, setMinimizeOnClose] = useState(false);
  const [openDetailedWindow, setOpenDetailedWindow] = useState(false);
  const [hideWhenMinimized, setHideWhenMinimized] = useState(false);
  const [showFullPaths, setShowFullPaths] = useState(false);
  const [summaryView, setSummaryView] = useState(true);
  const [refreshSpeed, setRefreshSpeed] = useState<'high' | 'normal' | 'low' | 'paused'>('normal');

  // Columns visibility
  const [columns, setColumns] = useState<ColumnVisibility>({
    status: true,
    cpu: true,
    memory: true,
    disk: true,
    network: true,
    powerUsage: true,
    publisher: true,
    pid: true,
    userName: true,
    version: true,
    filePath: true,
    commandLine: true,
    priority: true,
    architecture: true,
  });

  // Services State
  const [services, setServices] = useState<ServiceItemData[]>(INITIAL_SERVICES);

  // App History State
  const [appHistory, setAppHistory] = useState<AppHistoryItemData[]>(INITIAL_APP_HISTORY);

  // Custom Renames & Overrides
  const [processOverrides, setProcessOverrides] = useState<
    Record<string, { name?: string; priority?: PriorityLevel; uac?: boolean; killed?: boolean }>
  >({});

  // Performance history states (60 data points each)
  const [cpuHistory, setCpuHistory] = useState<number[]>(() =>
    Array.from({ length: 30 }, () => Math.floor(Math.random() * 12) + 10)
  );
  const [memoryHistory, setMemoryHistory] = useState<number[]>(() =>
    Array.from({ length: 30 }, () => Math.floor(Math.random() * 6) + 38)
  );
  const [diskHistory, setDiskHistory] = useState<number[]>(() =>
    Array.from({ length: 30 }, () => Math.floor(Math.random() * 8) + 2)
  );
  const [networkHistory, setNetworkHistory] = useState<number[]>(() =>
    Array.from({ length: 30 }, () => parseFloat((Math.random() * 3 + 1).toFixed(1)))
  );
  const [gpuHistory, setGpuHistory] = useState<number[]>(() =>
    Array.from({ length: 30 }, () => Math.floor(Math.random() * 10) + 12)
  );

  // Real-time telemetry ticker based on refreshSpeed
  useEffect(() => {
    if (refreshSpeed === 'paused') return;
    const intervalMs =
      refreshSpeed === 'high' ? 500 : refreshSpeed === 'normal' ? 1000 : 4000;

    const interval = setInterval(() => {
      setCpuHistory((prev) => [
        ...prev.slice(1),
        Math.floor(Math.random() * 15) + (windows.length > 2 ? 18 : 10),
      ]);
      setMemoryHistory((prev) => [
        ...prev.slice(1),
        Math.min(92, Math.floor(Math.random() * 4) + 36 + windows.length * 2),
      ]);
      setDiskHistory((prev) => [
        ...prev.slice(1),
        Math.floor(Math.random() * 6) + 1,
      ]);
      setNetworkHistory((prev) => [
        ...prev.slice(1),
        parseFloat((Math.random() * 3.5 + 0.8).toFixed(1)),
      ]);
      setGpuHistory((prev) => [
        ...prev.slice(1),
        Math.floor(Math.random() * 8) + 10,
      ]);
    }, intervalMs);

    return () => clearInterval(interval);
  }, [refreshSpeed, windows.length]);

  // Generate All Processes List
  const allProcesses: ProcessItemData[] = useMemo(() => {
    const list: ProcessItemData[] = [];

    // 1. Interactive Apps from OS Windows
    windows.forEach((win, index) => {
      const pid = 3000 + index * 48;
      const override = processOverrides[win.id];
      if (override?.killed) return;

      const appName =
        win.customData?.appName ||
        (win.appId ? getLocalizedAppName(win.appId, t) : win.title) ||
        win.title;

      list.push({
        id: win.id,
        name: `${(win.appId || 'app').toLowerCase()}.exe`,
        displayName: override?.name || appName,
        group: 'apps',
        status: win.isMinimized ? 'Tạm dừng' : 'Đang chạy',
        cpu: win.isMinimized ? 0.0 : parseFloat((Math.random() * 2.8 + 0.6).toFixed(1)),
        memory: 64 + (index % 5) * 45 + Math.floor(Math.random() * 12),
        disk: parseFloat((Math.random() * 0.4).toFixed(1)),
        network: parseFloat((Math.random() * 0.8).toFixed(1)),
        powerUsage: win.isMinimized ? 'Rất thấp' : 'Trung bình',
        publisher: 'Microsoft Corporation',
        pid: pid,
        userName: 'User (Lenamphuc)',
        version: '11.0.22631.3007',
        filePath: `C:\\Program Files\\WindowsApps\\${win.appId || 'App'}.exe`,
        commandLine: `"C:\\Program Files\\WindowsApps\\${win.appId || 'App'}.exe" -Embedding`,
        priority: override?.priority || 'normal',
        architecture: '64-bit',
        serviceName: undefined,
        packageName: `Microsoft.${win.appId || 'App'}_8wekyb3d8bbwe`,
        uacVirtualization: override?.uac ?? false,
        windowId: win.id,
        icon: win.icon,
      });
    });

    // 2. Background Processes
    const bgList: Array<Omit<ProcessItemData, 'id' | 'priority' | 'uacVirtualization'>> = [
      {
        name: 'explorer.exe',
        displayName: 'Windows Explorer (File Explorer)',
        group: 'background',
        status: 'Đang chạy',
        cpu: 0.4,
        memory: 84.5,
        disk: 0.1,
        network: 0.0,
        powerUsage: 'Rất thấp',
        publisher: 'Microsoft Corporation',
        pid: 1480,
        userName: 'User (Lenamphuc)',
        version: '11.0.22631.3007',
        filePath: 'C:\\Windows\\explorer.exe',
        commandLine: 'C:\\Windows\\explorer.exe',
        architecture: '64-bit',
        icon: 'Folder',
      },
      {
        name: 'dwm.exe',
        displayName: 'Desktop Window Manager (DWM Core)',
        group: 'background',
        status: 'Đang chạy',
        cpu: 1.2,
        memory: 118.2,
        disk: 0.0,
        network: 0.0,
        powerUsage: 'Thấp',
        publisher: 'Microsoft Corporation',
        pid: 864,
        userName: 'DWM-1',
        version: '11.0.22631.3007',
        filePath: 'C:\\Windows\\System32\\dwm.exe',
        commandLine: 'dwm.exe',
        architecture: '64-bit',
        icon: 'Layers',
      },
      {
        name: 'audiodg.exe',
        displayName: 'Windows Audio Device Graph Isolation',
        group: 'background',
        status: 'Đang chạy',
        cpu: 0.2,
        memory: 24.6,
        disk: 0.0,
        network: 0.0,
        powerUsage: 'Rất thấp',
        publisher: 'Microsoft Corporation',
        pid: 2012,
        userName: 'LOCAL SERVICE',
        version: '11.0.22631.3007',
        filePath: 'C:\\Windows\\System32\\audiodg.exe',
        commandLine: 'C:\\Windows\\system32\\audiodg.exe 0x3d0',
        architecture: '64-bit',
        icon: 'Volume2',
      },
      {
        name: 'MsMpEng.exe',
        displayName: 'Antimalware Service Executable',
        group: 'background',
        status: 'Đang chạy',
        cpu: 0.8,
        memory: 142.0,
        disk: 0.6,
        network: 0.0,
        powerUsage: 'Thấp',
        publisher: 'Microsoft Corporation',
        pid: 2160,
        userName: 'SYSTEM',
        version: '4.18.24010.12',
        filePath: 'C:\\ProgramData\\Microsoft\\Windows Defender\\Platform\\MsMpEng.exe',
        commandLine: '"C:\\ProgramData\\Microsoft\\Windows Defender\\Platform\\MsMpEng.exe"',
        architecture: '64-bit',
        serviceName: 'WinDefend',
        icon: 'Shield',
      },
      {
        name: 'RuntimeBroker.exe',
        displayName: 'Runtime Broker Background Host',
        group: 'background',
        status: 'Đang chạy',
        cpu: 0.1,
        memory: 32.4,
        disk: 0.0,
        network: 0.0,
        powerUsage: 'Rất thấp',
        publisher: 'Microsoft Corporation',
        pid: 3416,
        userName: 'User (Lenamphuc)',
        version: '11.0.22631.3007',
        filePath: 'C:\\Windows\\System32\\RuntimeBroker.exe',
        commandLine: 'C:\\Windows\\System32\\RuntimeBroker.exe -Embedding',
        architecture: '64-bit',
        icon: 'Activity',
      },
      {
        name: 'SearchHost.exe',
        displayName: 'Windows Search Protocol Host',
        group: 'background',
        status: 'Đang chạy',
        cpu: 0.3,
        memory: 68.0,
        disk: 0.2,
        network: 0.0,
        powerUsage: 'Rất thấp',
        publisher: 'Microsoft Corporation',
        pid: 4120,
        userName: 'User (Lenamphuc)',
        version: '11.0.22631.3007',
        filePath: 'C:\\Windows\\SystemApps\\MicrosoftWindows.Client.CBS_cw5n1h2txyewy\\SearchHost.exe',
        commandLine: 'SearchHost.exe -ServerName:SearchHost.Server',
        architecture: '64-bit',
        icon: 'Search',
      },
    ];

    bgList.forEach((bg) => {
      const id = `bg-${bg.pid}`;
      const override = processOverrides[id];
      if (override?.killed) return;

      list.push({
        ...bg,
        id,
        displayName: override?.name || bg.displayName,
        priority: override?.priority || 'normal',
        uacVirtualization: override?.uac ?? false,
      });
    });

    // 3. Windows System Processes
    const winList: Array<Omit<ProcessItemData, 'id' | 'priority' | 'uacVirtualization'>> = [
      {
        name: 'smss.exe',
        displayName: 'Session Manager Subsystem',
        group: 'windows',
        status: 'Đang chạy',
        cpu: 0.0,
        memory: 1.4,
        disk: 0.0,
        network: 0.0,
        powerUsage: 'Rất thấp',
        publisher: 'Microsoft Corporation',
        pid: 4,
        userName: 'SYSTEM',
        version: '11.0.22631.3007',
        filePath: 'C:\\Windows\\System32\\smss.exe',
        commandLine: '\\SystemRoot\\System32\\smss.exe',
        architecture: '64-bit',
        icon: 'ShieldAlert',
      },
      {
        name: 'csrss.exe',
        displayName: 'Client Server Runtime Process',
        group: 'windows',
        status: 'Đang chạy',
        cpu: 0.1,
        memory: 6.2,
        disk: 0.0,
        network: 0.0,
        powerUsage: 'Rất thấp',
        publisher: 'Microsoft Corporation',
        pid: 580,
        userName: 'SYSTEM',
        version: '11.0.22631.3007',
        filePath: 'C:\\Windows\\System32\\csrss.exe',
        commandLine: '%SystemRoot%\\system32\\csrss.exe ObjectDirectory=\\Windows SharedSection=1024,20480,768',
        architecture: '64-bit',
        icon: 'Activity',
      },
      {
        name: 'wininit.exe',
        displayName: 'Windows Start-Up Application',
        group: 'windows',
        status: 'Đang chạy',
        cpu: 0.0,
        memory: 4.8,
        disk: 0.0,
        network: 0.0,
        powerUsage: 'Rất thấp',
        publisher: 'Microsoft Corporation',
        pid: 652,
        userName: 'SYSTEM',
        version: '11.0.22631.3007',
        filePath: 'C:\\Windows\\System32\\wininit.exe',
        commandLine: 'wininit.exe',
        architecture: '64-bit',
        icon: 'Play',
      },
      {
        name: 'services.exe',
        displayName: 'Services and Controller App',
        group: 'windows',
        status: 'Đang chạy',
        cpu: 0.1,
        memory: 12.8,
        disk: 0.0,
        network: 0.0,
        powerUsage: 'Rất thấp',
        publisher: 'Microsoft Corporation',
        pid: 724,
        userName: 'SYSTEM',
        version: '11.0.22631.3007',
        filePath: 'C:\\Windows\\System32\\services.exe',
        commandLine: 'C:\\Windows\\system32\\services.exe',
        architecture: '64-bit',
        icon: 'Settings',
      },
      {
        name: 'lsass.exe',
        displayName: 'Local Security Authority Process',
        group: 'windows',
        status: 'Đang chạy',
        cpu: 0.2,
        memory: 28.5,
        disk: 0.0,
        network: 0.0,
        powerUsage: 'Rất thấp',
        publisher: 'Microsoft Corporation',
        pid: 740,
        userName: 'SYSTEM',
        version: '11.0.22631.3007',
        filePath: 'C:\\Windows\\System32\\lsass.exe',
        commandLine: 'C:\\Windows\\system32\\lsass.exe',
        architecture: '64-bit',
        icon: 'Shield',
      },
      {
        name: 'svchost.exe',
        displayName: 'Host Process for Windows Services (svchost)',
        group: 'windows',
        status: 'Đang chạy',
        cpu: 0.3,
        memory: 42.0,
        disk: 0.1,
        network: 0.0,
        powerUsage: 'Rất thấp',
        publisher: 'Microsoft Corporation',
        pid: 940,
        userName: 'LOCAL SERVICE',
        version: '11.0.22631.3007',
        filePath: 'C:\\Windows\\System32\\svchost.exe',
        commandLine: 'C:\\Windows\\system32\\svchost.exe -k LocalService',
        architecture: '64-bit',
        serviceName: 'EventLog',
        icon: 'Layers',
      },
    ];

    winList.forEach((win) => {
      const id = `win-${win.pid}`;
      const override = processOverrides[id];
      if (override?.killed) return;

      list.push({
        ...win,
        id,
        displayName: override?.name || win.displayName,
        priority: override?.priority || 'normal',
        uacVirtualization: override?.uac ?? false,
      });
    });

    return list;
  }, [windows, processOverrides, t]);

  // Generate User Sessions with their child processes
  const userSessions: UserSessionData[] = useMemo(() => {
    const userProcs = allProcesses.filter((p) => p.userName.includes('User'));
    const systemProcs = allProcesses.filter((p) => !p.userName.includes('User'));

    const userCpu = userProcs.reduce((acc, p) => acc + p.cpu, 0);
    const userMem = userProcs.reduce((acc, p) => acc + p.memory, 0);
    const userDisk = userProcs.reduce((acc, p) => acc + p.disk, 0);
    const userNet = userProcs.reduce((acc, p) => acc + p.network, 0);

    const sysCpu = systemProcs.reduce((acc, p) => acc + p.cpu, 0);
    const sysMem = systemProcs.reduce((acc, p) => acc + p.memory, 0);
    const sysDisk = systemProcs.reduce((acc, p) => acc + p.disk, 0);
    const sysNet = systemProcs.reduce((acc, p) => acc + p.network, 0);

    return [
      {
        id: 'user-current',
        userName: 'User (Lenamphuc)',
        status: 'Đang hoạt động',
        cpu: parseFloat(userCpu.toFixed(1)),
        memory: Math.round(userMem),
        disk: parseFloat(userDisk.toFixed(1)),
        network: parseFloat(userNet.toFixed(1)),
        loginTime: 'Hôm nay, 08:30:14',
        loginAddress: 'Console (Cục bộ)',
        clientVersion: 'Windows 11 v10.0.22631',
        processes: userProcs,
      },
      {
        id: 'user-system',
        userName: 'SYSTEM & Network Services',
        status: 'Đang hoạt động',
        cpu: parseFloat(sysCpu.toFixed(1)),
        memory: Math.round(sysMem),
        disk: parseFloat(sysDisk.toFixed(1)),
        network: parseFloat(sysNet.toFixed(1)),
        loginTime: 'Khởi động hệ thống',
        loginAddress: '127.0.0.1 (Localhost)',
        clientVersion: 'NT Core Kernel',
        processes: systemProcs,
      },
    ];
  }, [allProcesses]);

  // Actions on processes
  const handleEndProcess = useCallback(
    (id: string) => {
      const proc = allProcesses.find((p) => p.id === id);
      if (!proc) return;

      if (proc.windowId) {
        closeWindow(proc.windowId);
      } else {
        setProcessOverrides((prev) => ({
          ...prev,
          [id]: { ...prev[id], killed: true },
        }));
      }

      addNotification(
        'Trình quản lý Tác vụ',
        `Đã kết thúc tác vụ "${proc.displayName}" (PID: ${proc.pid})`,
        'taskmanager'
      );
      if (selectedProcessId === id) setSelectedProcessId(null);
    },
    [allProcesses, closeWindow, addNotification, selectedProcessId]
  );

  const handleRestartProcess = useCallback(
    (id: string) => {
      const proc = allProcesses.find((p) => p.id === id);
      if (!proc) return;

      addNotification('Trình quản lý Tác vụ', `Đang khởi động lại "${proc.displayName}"...`, 'taskmanager');

      if (proc.windowId) {
        const win = windows.find((w) => w.id === proc.windowId);
        if (win && win.appId) {
          closeWindow(win.id);
          setTimeout(() => {
            openApp(win.appId);
          }, 300);
        }
      }
    },
    [allProcesses, windows, closeWindow, openApp, addNotification]
  );

  const handleSetPriority = useCallback(
    (id: string, priority: PriorityLevel) => {
      setProcessOverrides((prev) => ({
        ...prev,
        [id]: { ...prev[id], priority },
      }));
      addNotification('Trình quản lý Tác vụ', `Đã đặt mức ưu tiên thành "${priority}"`, 'taskmanager');
    },
    [addNotification]
  );

  const handleRenameProcess = useCallback(
    (id: string, newName: string) => {
      setProcessOverrides((prev) => ({
        ...prev,
        [id]: { ...prev[id], name: newName },
      }));
      addNotification('Trình quản lý Tác vụ', `Đã đổi tên hiển thị tiến trình thành "${newName}"`, 'taskmanager');
    },
    [addNotification]
  );

  const handleToggleVirtualization = useCallback(
    (id: string) => {
      const current = processOverrides[id]?.uac ?? false;
      setProcessOverrides((prev) => ({
        ...prev,
        [id]: { ...prev[id], uac: !current },
      }));
      addNotification('Ảo hóa UAC', `Đã ${!current ? 'bật' : 'tắt'} ảo hóa UAC cho tiến trình`, 'taskmanager');
    },
    [processOverrides, addNotification]
  );

  const handleSwitchToDetails = useCallback((pid: number) => {
    setActiveTab('details');
    setSelectedPid(pid);
  }, []);

  const handleExportList = useCallback(() => {
    const csvContent =
      'Image Name,PID,Session Name,Session#,Mem Usage,Status\n' +
      allProcesses
        .map(
          (p) =>
            `"${p.name}","${p.pid}","${p.userName}","1","${p.memory.toFixed(1)} MB","${p.status}"`
        )
        .join('\n');

    addFile({
      name: 'Tasklist.csv',
      path: 'C:\\Users\\User\\Documents\\Tasklist.csv',
      type: 'file',
      extension: 'csv',
      content: csvContent,
      size: `${(csvContent.length / 1024).toFixed(1)} KB`,
    });

    addNotification(
      'Xuất danh sách tiến trình',
      'Đã lưu tệp Tasklist.csv vào thư mục C:\\Users\\User\\Documents',
      'taskmanager'
    );
  }, [allProcesses, addFile, addNotification]);

  const handleUpdateServiceStatus = (id: string, status: ServiceStatus) => {
    setServices((prev) =>
      prev.map((s) => (s.id === id ? { ...s, status } : s))
    );
  };

  const handleUpdateService = (updated: ServiceItemData) => {
    setServices((prev) =>
      prev.map((s) => (s.id === updated.id ? updated : s))
    );
  };

  // Find the TaskManager window ID to handle close / minimize
  const currentTaskMgrWin = windows.find((w) => w.appId === 'taskmanager');

  return (
    <div
      id="task-manager-app"
      className="flex flex-col w-full h-full bg-slate-50 dark:bg-[#191919] text-slate-800 dark:text-slate-100 select-none overflow-hidden text-xs"
    >
      {/* 1. TOP MENU BAR */}
      <TaskManagerMenuBar
        onOpenNewTask={() => setIsNewTaskOpen(true)}
        onCloseApp={() => {
          if (currentTaskMgrWin) closeWindow(currentTaskMgrWin.id);
        }}
        onOpenAbout={() => setIsAboutOpen(true)}
        alwaysOnTop={alwaysOnTop}
        setAlwaysOnTop={setAlwaysOnTop}
        minimizeOnClose={minimizeOnClose}
        setMinimizeOnClose={setMinimizeOnClose}
        openDetailedWindow={openDetailedWindow}
        setOpenDetailedWindow={setOpenDetailedWindow}
        hideWhenMinimized={hideWhenMinimized}
        setHideWhenMinimized={setHideWhenMinimized}
        showFullPaths={showFullPaths}
        setShowFullPaths={setShowFullPaths}
        summaryView={summaryView}
        setSummaryView={setSummaryView}
        refreshSpeed={refreshSpeed}
        setRefreshSpeed={setRefreshSpeed}
        columns={columns}
        setColumns={setColumns}
      />

      {/* 2. TAB BAR (6 tabs in exact order) */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-white/90 dark:bg-[#202020]/90 border-b border-slate-200 dark:border-zinc-800">
        <div className="flex items-center gap-1 overflow-x-auto">
          {/* Tab 1: Tiến trình */}
          <button
            onClick={() => setActiveTab('processes')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all text-xs shrink-0 ${
              activeTab === 'processes'
                ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30'
                : 'hover:bg-slate-100 dark:hover:bg-zinc-800 text-slate-600 dark:text-zinc-300'
            }`}
          >
            <Activity size={14} />
            <span>Tiến trình</span>
          </button>

          {/* Tab 2: Hiệu suất */}
          <button
            onClick={() => setActiveTab('performance')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all text-xs shrink-0 ${
              activeTab === 'performance'
                ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30'
                : 'hover:bg-slate-100 dark:hover:bg-zinc-800 text-slate-600 dark:text-zinc-300'
            }`}
          >
            <Cpu size={14} />
            <span>Hiệu suất</span>
          </button>

          {/* Tab 3: Lịch sử ứng dụng */}
          <button
            onClick={() => setActiveTab('app_history')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all text-xs shrink-0 ${
              activeTab === 'app_history'
                ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30'
                : 'hover:bg-slate-100 dark:hover:bg-zinc-800 text-slate-600 dark:text-zinc-300'
            }`}
          >
            <History size={14} />
            <span>Lịch sử ứng dụng</span>
          </button>

          {/* Tab 4: Người dùng */}
          <button
            onClick={() => setActiveTab('users')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all text-xs shrink-0 ${
              activeTab === 'users'
                ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30'
                : 'hover:bg-slate-100 dark:hover:bg-zinc-800 text-slate-600 dark:text-zinc-300'
            }`}
          >
            <UsersIcon size={14} />
            <span>Người dùng</span>
          </button>

          {/* Tab 5: Chi tiết */}
          <button
            onClick={() => setActiveTab('details')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all text-xs shrink-0 ${
              activeTab === 'details'
                ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30'
                : 'hover:bg-slate-100 dark:hover:bg-zinc-800 text-slate-600 dark:text-zinc-300'
            }`}
          >
            <FileText size={14} />
            <span>Chi tiết</span>
          </button>

          {/* Tab 6: Dịch vụ */}
          <button
            onClick={() => setActiveTab('services')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all text-xs shrink-0 ${
              activeTab === 'services'
                ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30'
                : 'hover:bg-slate-100 dark:hover:bg-zinc-800 text-slate-600 dark:text-zinc-300'
            }`}
          >
            <Settings2 size={14} />
            <span>Dịch vụ</span>
          </button>
        </div>

        {/* Quick Process End Task shortcut button on top right */}
        {selectedProcessId && activeTab === 'processes' && (
          <button
            onClick={() => handleEndProcess(selectedProcessId)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold shadow-sm transition-all text-xs shrink-0"
          >
            <XCircle size={14} />
            <span>Kết thúc tác vụ</span>
          </button>
        )}
      </div>

      {/* 3. MAIN TAB CONTENT */}
      <div className="flex-1 overflow-hidden flex flex-col">
        {activeTab === 'processes' && (
          <ProcessesTab
            processes={allProcesses}
            selectedProcessId={selectedProcessId}
            onSelectProcess={setSelectedProcessId}
            onEndProcess={handleEndProcess}
            onRestartProcess={handleRestartProcess}
            onSetPriority={handleSetPriority}
            onRenameProcess={handleRenameProcess}
            onSwitchToDetails={handleSwitchToDetails}
            onExportList={handleExportList}
            columns={columns}
            showFullPaths={showFullPaths}
          />
        )}

        {activeTab === 'performance' && (
          <PerformanceTab
            cpuHistory={cpuHistory}
            memoryHistory={memoryHistory}
            diskHistory={diskHistory}
            networkHistory={networkHistory}
            gpuHistory={gpuHistory}
            summaryView={summaryView}
          />
        )}

        {activeTab === 'app_history' && (
          <AppHistoryTab
            historyItems={appHistory}
            onClearHistory={() => setAppHistory([])}
          />
        )}

        {activeTab === 'users' && (
          <UsersTab
            users={userSessions}
            onDisconnectUser={(uid) => {
              addNotification('Người dùng', 'Đã ngắt kết nối phiên', 'taskmanager');
            }}
            onEndProcess={handleEndProcess}
            onSwitchToDetails={handleSwitchToDetails}
          />
        )}

        {activeTab === 'details' && (
          <DetailsTab
            processes={allProcesses}
            selectedPid={selectedPid}
            onSelectPid={setSelectedPid}
            onEndProcess={handleEndProcess}
            onRestartProcess={handleRestartProcess}
            onSetPriority={handleSetPriority}
            onToggleVirtualization={handleToggleVirtualization}
            onExportList={handleExportList}
          />
        )}

        {activeTab === 'services' && (
          <ServicesTab
            services={services}
            selectedServiceId={selectedServiceId}
            onSelectService={setSelectedServiceId}
            onUpdateServiceStatus={handleUpdateServiceStatus}
            onOpenProperties={(srv) => setActiveServiceForProps(srv)}
          />
        )}
      </div>

      {/* 4. BOTTOM ACTION BAR */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-100 dark:bg-[#222] border-t border-slate-200 dark:border-zinc-800 select-none">
        <div className="flex items-center gap-2">
          {/* Tác vụ mới... */}
          <button
            onClick={() => setIsNewTaskOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-700 text-slate-700 dark:text-slate-200 font-semibold text-xs transition-all shadow-sm active:scale-95"
          >
            <Play size={13} className="text-sky-500" />
            <span>Tác vụ mới...</span>
          </button>

          {/* Mở trang Bảo mật Windows */}
          <button
            onClick={() => openApp('security')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-700 text-slate-700 dark:text-slate-200 font-semibold text-xs transition-all shadow-sm active:scale-95"
          >
            <Shield size={13} className="text-teal-500" />
            <span>Mở trang Bảo mật Windows</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          {/* Thu nhỏ */}
          <button
            onClick={() => {
              if (currentTaskMgrWin) minimizeWindow(currentTaskMgrWin.id);
            }}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-700 text-slate-700 dark:text-slate-200 font-medium text-xs transition-all"
          >
            <Minus size={13} />
            <span>Thu nhỏ</span>
          </button>

          {/* Kết thúc tác vụ */}
          <button
            onClick={() => {
              if (selectedProcessId) {
                handleEndProcess(selectedProcessId);
              } else if (selectedPid) {
                const target = allProcesses.find((p) => p.pid === selectedPid);
                if (target) handleEndProcess(target.id);
              } else {
                addNotification(
                  'Trình quản lý Tác vụ',
                  'Vui lòng chọn một tiến trình trong danh sách để kết thúc tác vụ.',
                  'taskmanager'
                );
              }
            }}
            disabled={!selectedProcessId && !selectedPid}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white font-bold text-xs shadow-sm transition-all active:scale-95"
          >
            <XCircle size={14} />
            <span>Kết thúc tác vụ</span>
          </button>
        </div>
      </div>

      {/* MODALS */}
      <NewTaskModal isOpen={isNewTaskOpen} onClose={() => setIsNewTaskOpen(false)} />

      <AboutTaskManagerModal isOpen={isAboutOpen} onClose={() => setIsAboutOpen(false)} />

      <ServicePropertiesModal
        service={activeServiceForProps}
        isOpen={!!activeServiceForProps}
        onClose={() => setActiveServiceForProps(null)}
        onUpdateService={handleUpdateService}
      />
    </div>
  );
};
