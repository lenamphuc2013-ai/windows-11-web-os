import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import {
  CONTROL_PANEL_CATEGORIES,
  CONTROL_PANEL_ITEMS,
  ControlPanelCategory,
  ControlPanelItem,
} from '../../utils/controlPanelData';
import {
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  RotateCw,
  Search,
  Shield,
  ShieldCheck,
  Cpu,
  Clock,
  Languages,
  UserCheck,
  HardDrive,
  Globe,
  Speaker,
  BatteryCharging,
  Monitor,
  Palette,
  Package,
  Lock,
  Type,
  Mic,
  Keyboard,
  Mouse,
  Hand,
  PlayCircle,
  FolderTree,
  FolderSync,
  Globe2,
  Phone,
  MonitorUp,
  Activity,
  Wrench,
  Gamepad2,
  Camera,
  Check,
  ChevronRight,
  SlidersHorizontal,
  Volume2,
  Sliders,
  Sparkles,
  ExternalLink,
  Info,
  Layers,
  FileText,
  VolumeX,
  Play,
  Square,
  RefreshCw,
  AlertCircle,
  Folder,
  FolderOpen,
} from 'lucide-react';

export interface ControlPanelAppProps {
  initialPage?: string;
  initialCpl?: string;
  isAdmin?: boolean;
}

export const ControlPanelApp: React.FC<ControlPanelAppProps> = ({
  initialPage,
  initialCpl,
  isAdmin: propIsAdmin,
}) => {
  const {
    settings,
    updateSettings,
    addNotification,
    openApp,
    t,
    currentLang,
    fileSystem,
  } = useOS();

  // Navigation state
  const [viewMode, setViewMode] = useState<'category' | 'large_icons' | 'small_icons'>('category');
  const [activeCategory, setActiveCategory] = useState<ControlPanelCategory | null>(null);
  const [activeItem, setActiveItem] = useState<ControlPanelItem | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAdmin, setIsAdmin] = useState(Boolean(propIsAdmin));

  // History stack for Back/Forward navigation
  const [history, setHistory] = useState<
    Array<{
      category: ControlPanelCategory | null;
      item: ControlPanelItem | null;
      search: string;
    }>
  >([{ category: null, item: null, search: '' }]);
  const [historyIndex, setHistoryIndex] = useState(0);

  // Initialize or update from props
  useEffect(() => {
    if (propIsAdmin) {
      setIsAdmin(true);
    }
    if (initialPage || initialCpl) {
      const pageKey = (initialPage || '').toLowerCase().replace(/["']/g, '');
      const cplKey = (initialCpl || '').toLowerCase().replace(/["']/g, '');

      const found = CONTROL_PANEL_ITEMS.find(
        (it) =>
          it.canonicalName.toLowerCase() === pageKey ||
          it.id.toLowerCase() === pageKey ||
          (it.cpl && it.cpl.toLowerCase() === (cplKey || pageKey)) ||
          pageKey.endsWith('.' + it.id.toLowerCase().replace('microsoft.', '')) ||
          it.name.toLowerCase() === pageKey
      );

      if (found) {
        navigateToItem(found, false);
      }
    }
  }, [initialPage, initialCpl, propIsAdmin]);

  const navigateToItem = (item: ControlPanelItem, recordHistory = true) => {
    setActiveItem(item);
    setActiveCategory(null);
    setSearchQuery('');
    if (recordHistory) {
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push({ category: null, item, search: '' });
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    }
  };

  const navigateToCategory = (cat: ControlPanelCategory, recordHistory = true) => {
    setActiveCategory(cat);
    setActiveItem(null);
    setSearchQuery('');
    if (recordHistory) {
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push({ category: cat, item: null, search: '' });
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    }
  };

  const navigateToRoot = (recordHistory = true) => {
    setActiveCategory(null);
    setActiveItem(null);
    setSearchQuery('');
    if (recordHistory) {
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push({ category: null, item: null, search: '' });
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    }
  };

  const handleBack = () => {
    if (historyIndex > 0) {
      const newIdx = historyIndex - 1;
      const target = history[newIdx];
      setHistoryIndex(newIdx);
      setActiveCategory(target.category);
      setActiveItem(target.item);
      setSearchQuery(target.search);
    }
  };

  const handleForward = () => {
    if (historyIndex < history.length - 1) {
      const newIdx = historyIndex + 1;
      const target = history[newIdx];
      setHistoryIndex(newIdx);
      setActiveCategory(target.category);
      setActiveItem(target.item);
      setSearchQuery(target.search);
    }
  };

  const handleUp = () => {
    if (activeItem) {
      if (activeCategory) {
        setActiveItem(null);
      } else {
        navigateToRoot();
      }
    } else if (activeCategory) {
      navigateToRoot();
    }
  };

  // Filtered items based on search or category
  const filteredItems = useMemo(() => {
    let list = CONTROL_PANEL_ITEMS;

    if (activeCategory) {
      list = list.filter((it) => it.category === activeCategory);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (it) =>
          it.name.toLowerCase().includes(q) ||
          it.vietnameseName.toLowerCase().includes(q) ||
          it.canonicalName.toLowerCase().includes(q) ||
          (it.cpl && it.cpl.toLowerCase().includes(q)) ||
          it.description.toLowerCase().includes(q) ||
          it.vietnameseDescription.toLowerCase().includes(q) ||
          it.keywords.some((k) => k.toLowerCase().includes(q))
      );
    }

    return [...list].sort((a, b) => a.name.localeCompare(b.name));
  }, [activeCategory, searchQuery]);

  // Helper to render Lucide icon safely
  const renderItemIcon = (iconName: string, size = 20, className = '') => {
    switch (iconName) {
      case 'Cpu':
        return <Cpu size={size} className={className} />;
      case 'Clock':
        return <Clock size={size} className={className} />;
      case 'Languages':
        return <Languages size={size} className={className} />;
      case 'UserCheck':
        return <UserCheck size={size} className={className} />;
      case 'HardDrive':
        return <HardDrive size={size} className={className} />;
      case 'Globe':
        return <Globe size={size} className={className} />;
      case 'Globe2':
        return <Globe2 size={size} className={className} />;
      case 'Speaker':
        return <Speaker size={size} className={className} />;
      case 'BatteryCharging':
        return <BatteryCharging size={size} className={className} />;
      case 'Monitor':
        return <Monitor size={size} className={className} />;
      case 'Palette':
        return <Palette size={size} className={className} />;
      case 'Package':
        return <Package size={size} className={className} />;
      case 'Lock':
        return <Lock size={size} className={className} />;
      case 'Type':
        return <Type size={size} className={className} />;
      case 'Mic':
        return <Mic size={size} className={className} />;
      case 'Keyboard':
        return <Keyboard size={size} className={className} />;
      case 'Mouse':
        return <Mouse size={size} className={className} />;
      case 'Hand':
        return <Hand size={size} className={className} />;
      case 'PlayCircle':
        return <PlayCircle size={size} className={className} />;
      case 'FolderTree':
        return <FolderTree size={size} className={className} />;
      case 'Search':
        return <Search size={size} className={className} />;
      case 'Phone':
        return <Phone size={size} className={className} />;
      case 'MonitorUp':
        return <MonitorUp size={size} className={className} />;
      case 'ShieldCheck':
        return <ShieldCheck size={size} className={className} />;
      case 'Shield':
        return <Shield size={size} className={className} />;
      case 'Activity':
        return <Activity size={size} className={className} />;
      case 'Wrench':
        return <Wrench size={size} className={className} />;
      case 'FolderSync':
        return <FolderSync size={size} className={className} />;
      case 'Gamepad2':
        return <Gamepad2 size={size} className={className} />;
      case 'Camera':
        return <Camera size={size} className={className} />;
      case 'RotateCw':
        return <RotateCw size={size} className={className} />;
      default:
        return <SlidersHorizontal size={size} className={className} />;
    }
  };

  // Breadcrumb segments
  const breadcrumbs = useMemo(() => {
    const crumbs = [
      {
        label: currentLang === 'vi' ? 'Bảng Điều khiển' : 'Control Panel',
        onClick: () => navigateToRoot(),
      },
    ];

    if (activeCategory) {
      const catObj = CONTROL_PANEL_CATEGORIES.find((c) => c.id === activeCategory);
      if (catObj) {
        crumbs.push({
          label: currentLang === 'vi' ? catObj.vietnameseName : catObj.name,
          onClick: () => {
            setActiveItem(null);
          },
        });
      }
    } else if (viewMode !== 'category' && !activeItem) {
      crumbs.push({
        label: currentLang === 'vi' ? 'Tất cả các mục' : 'All Control Panel Items',
        onClick: () => {},
      });
    }

    if (activeItem) {
      crumbs.push({
        label: currentLang === 'vi' ? activeItem.vietnameseName : activeItem.name,
        onClick: () => {},
      });
    }

    return crumbs;
  }, [activeCategory, activeItem, viewMode, currentLang]);

  return (
    <div className="flex flex-col w-full h-full bg-[#f8f9fa] dark:bg-[#1f1f1f] text-slate-800 dark:text-slate-100 select-none overflow-hidden font-sans">
      {/* Top Windows 11 Explorer / Control Panel Toolbar */}
      <div className="flex items-center justify-between gap-2 px-3 py-2 border-b border-slate-200 dark:border-zinc-800 bg-[#f3f3f3] dark:bg-[#252525] shrink-0">
        {/* Navigation buttons */}
        <div className="flex items-center gap-1">
          <button
            onClick={handleBack}
            disabled={historyIndex <= 0}
            title="Back"
            className="p-1.5 rounded hover:bg-slate-300/60 dark:hover:bg-zinc-700/60 disabled:opacity-30 disabled:hover:bg-transparent transition-colors text-slate-600 dark:text-slate-300"
          >
            <ArrowLeft size={16} />
          </button>
          <button
            onClick={handleForward}
            disabled={historyIndex >= history.length - 1}
            title="Forward"
            className="p-1.5 rounded hover:bg-slate-300/60 dark:hover:bg-zinc-700/60 disabled:opacity-30 disabled:hover:bg-transparent transition-colors text-slate-600 dark:text-slate-300"
          >
            <ArrowRight size={16} />
          </button>
          <button
            onClick={handleUp}
            disabled={!activeCategory && !activeItem}
            title="Up to Control Panel"
            className="p-1.5 rounded hover:bg-slate-300/60 dark:hover:bg-zinc-700/60 disabled:opacity-30 disabled:hover:bg-transparent transition-colors text-slate-600 dark:text-slate-300"
          >
            <ArrowUp size={16} />
          </button>
        </div>

        {/* Address Bar / Breadcrumbs */}
        <div className="flex-1 flex items-center h-8 px-2.5 bg-white dark:bg-[#1c1c1c] border border-slate-300 dark:border-zinc-700 rounded-md shadow-xs overflow-hidden text-xs">
          <SlidersHorizontal size={14} className="text-[#0078D4] mr-2 shrink-0" />
          <div className="flex items-center gap-1 overflow-x-auto whitespace-nowrap scrollbar-none flex-1">
            {breadcrumbs.map((crumb, idx) => (
              <React.Fragment key={idx}>
                {idx > 0 && (
                  <ChevronRight size={13} className="text-slate-400 dark:text-zinc-500 shrink-0" />
                )}
                <button
                  onClick={crumb.onClick}
                  className={`hover:underline cursor-pointer truncate max-w-[200px] ${
                    idx === breadcrumbs.length - 1
                      ? 'font-semibold text-slate-900 dark:text-white'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {crumb.label}
                </button>
              </React.Fragment>
            ))}
          </div>

          <button
            onClick={() => {
              addNotification(
                'Control Panel',
                'Đã làm mới các mục và dịch vụ trong Bảng Điều khiển',
                'system'
              );
            }}
            title="Refresh"
            className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors ml-1 shrink-0"
          >
            <RotateCw size={13} />
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative flex items-center w-52 sm:w-64 h-8 bg-white dark:bg-[#1c1c1c] border border-slate-300 dark:border-zinc-700 rounded-md shadow-xs px-2.5">
          <Search size={14} className="text-slate-400 mr-2 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              currentLang === 'vi' ? 'Tìm kiếm trong Bảng Điều khiển' : 'Search Control Panel'
            }
            className="w-full bg-transparent border-none outline-none text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-400"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="text-xs text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Sub-bar / View By & Administrator Badge */}
      <div className="flex items-center justify-between px-4 py-1.5 bg-[#f0f0f0] dark:bg-[#202020] border-b border-slate-200 dark:border-zinc-800 text-xs text-slate-600 dark:text-slate-400 shrink-0">
        <div className="flex items-center gap-2">
          {isAdmin && (
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-amber-500/10 dark:bg-amber-500/20 text-amber-700 dark:text-amber-400 border border-amber-300/40 dark:border-amber-600/40 text-[11px] font-medium">
              <Shield size={12} className="text-amber-600 dark:text-amber-400" />
              {currentLang === 'vi' ? 'Quyền Quản trị viên' : 'Administrator'}
            </span>
          )}
          <span className="text-slate-500 text-[11px]">
            {activeItem
              ? `${activeItem.name} (${activeItem.canonicalName}${
                  activeItem.cpl ? ` • ${activeItem.cpl}` : ''
                })`
              : `${filteredItems.length} ${currentLang === 'vi' ? 'mục' : 'items'}`}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-500">{currentLang === 'vi' ? 'Xem theo:' : 'View by:'}</span>
          <select
            value={viewMode}
            onChange={(e) => {
              const newMode = e.target.value as 'category' | 'large_icons' | 'small_icons';
              setViewMode(newMode);
              if (activeItem) {
                setActiveItem(null);
              }
            }}
            className="bg-white dark:bg-[#2b2b2b] border border-slate-300 dark:border-zinc-700 rounded px-2 py-0.5 text-xs text-slate-800 dark:text-slate-200 outline-none cursor-pointer"
          >
            <option value="category">
              {currentLang === 'vi' ? 'Thể loại' : 'Category'}
            </option>
            <option value="large_icons">
              {currentLang === 'vi' ? 'Biểu tượng lớn' : 'Large icons'}
            </option>
            <option value="small_icons">
              {currentLang === 'vi' ? 'Biểu tượng nhỏ' : 'Small icons'}
            </option>
          </select>
        </div>
      </div>

      {/* Main Content Viewport */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6">
        {/* VIEW 1: ACTIVE DETAILED ITEM APPLET */}
        {activeItem ? (
          <ControlPanelAppletDetail
            item={activeItem}
            isAdmin={isAdmin}
            onBack={() => setActiveItem(null)}
            onNavigate={(name) => {
              const found = CONTROL_PANEL_ITEMS.find(
                (it) => it.canonicalName === name || it.cpl === name || it.id === name
              );
              if (found) navigateToItem(found);
            }}
          />
        ) : searchQuery.trim() || viewMode !== 'category' || activeCategory ? (
          /* VIEW 2: ICON GRID (All Items, Category Items, or Search Results) */
          <div>
            {activeCategory && (
              <div className="mb-4 pb-2 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
                    {currentLang === 'vi'
                      ? CONTROL_PANEL_CATEGORIES.find((c) => c.id === activeCategory)?.vietnameseName
                      : CONTROL_PANEL_CATEGORIES.find((c) => c.id === activeCategory)?.name}
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {CONTROL_PANEL_CATEGORIES.find((c) => c.id === activeCategory)?.description}
                  </p>
                </div>
                <button
                  onClick={() => setActiveCategory(null)}
                  className="text-xs text-[#0078D4] hover:underline cursor-pointer"
                >
                  {currentLang === 'vi' ? '← Xem tất cả thể loại' : '← All categories'}
                </button>
              </div>
            )}

            {filteredItems.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center text-slate-500">
                <Search size={40} className="text-slate-300 dark:text-zinc-600 mb-3" />
                <p className="text-sm font-medium">
                  {currentLang === 'vi'
                    ? `Không tìm thấy mục nào khớp với "${searchQuery}"`
                    : `No items match "${searchQuery}"`}
                </p>
                <button
                  onClick={() => setSearchQuery('')}
                  className="mt-3 text-xs text-[#0078D4] hover:underline cursor-pointer"
                >
                  {currentLang === 'vi' ? 'Xóa tìm kiếm' : 'Clear search'}
                </button>
              </div>
            ) : viewMode === 'large_icons' || searchQuery.trim() || activeCategory ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {filteredItems.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => navigateToItem(item)}
                    className="flex items-start gap-3 p-3 rounded-lg bg-white dark:bg-[#272727] hover:bg-sky-50/70 dark:hover:bg-zinc-800 border border-slate-200/80 dark:border-zinc-700/60 hover:border-sky-300 dark:hover:border-sky-500/50 shadow-2xs transition-all cursor-pointer group"
                  >
                    <div className="p-2 rounded-md bg-slate-100 dark:bg-zinc-800 group-hover:bg-[#0078D4]/10 text-[#0078D4] shrink-0 transition-colors">
                      {renderItemIcon(item.icon, 22)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-xs font-semibold text-slate-800 dark:text-slate-100 group-hover:text-[#0078D4] truncate">
                          {currentLang === 'vi' ? item.vietnameseName : item.name}
                        </span>
                        {item.cpl && (
                          <span className="text-[10px] font-mono text-slate-400 dark:text-zinc-500 px-1 py-0.5 rounded bg-slate-100 dark:bg-zinc-800 shrink-0">
                            {item.cpl}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 mt-0.5 leading-relaxed">
                        {currentLang === 'vi' ? item.vietnameseDescription : item.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              /* Small icons view */
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-1.5">
                {filteredItems.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => navigateToItem(item)}
                    className="flex items-center gap-2.5 px-2.5 py-1.5 rounded hover:bg-sky-100/60 dark:hover:bg-zinc-800 text-slate-700 dark:text-slate-200 cursor-pointer transition-colors group"
                  >
                    <div className="text-[#0078D4] shrink-0">
                      {renderItemIcon(item.icon, 16)}
                    </div>
                    <span className="text-xs truncate group-hover:text-[#0078D4] font-medium">
                      {currentLang === 'vi' ? item.vietnameseName : item.name}
                    </span>
                    {item.cpl && (
                      <span className="ml-auto text-[10px] text-slate-400 font-mono">
                        {item.cpl}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          /* VIEW 3: CLASSIC 8 CATEGORIES VIEW */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {CONTROL_PANEL_CATEGORIES.map((cat) => (
              <div key={cat.id} className="flex items-start gap-4">
                <div
                  onClick={() => navigateToCategory(cat.id)}
                  className="p-3.5 rounded-xl bg-sky-500/10 dark:bg-sky-500/20 text-[#0078D4] shrink-0 cursor-pointer hover:scale-105 transition-transform"
                >
                  {renderItemIcon(cat.icon, 32)}
                </div>

                <div className="flex-1">
                  <button
                    onClick={() => navigateToCategory(cat.id)}
                    className="text-sm font-semibold text-[#0078D4] hover:underline text-left cursor-pointer"
                  >
                    {currentLang === 'vi' ? cat.vietnameseName : cat.name}
                  </button>

                  <ul className="mt-1.5 space-y-1">
                    {cat.tasks.map((task, idx) => (
                      <li key={idx}>
                        <button
                          onClick={() => {
                            const found = CONTROL_PANEL_ITEMS.find(
                              (it) =>
                                it.canonicalName === task.targetItem ||
                                it.id === task.targetItem ||
                                it.cpl === task.targetItem
                            );
                            if (found) {
                              navigateToItem(found);
                            }
                          }}
                          className="text-xs text-slate-600 dark:text-slate-300 hover:text-[#0078D4] hover:underline text-left cursor-pointer transition-colors"
                        >
                          {currentLang === 'vi' ? task.vietnameseLabel : task.label}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Classic Windows 11 Status Bar */}
      <div className="flex items-center justify-between px-3 py-1 bg-[#f3f3f3] dark:bg-[#202020] border-t border-slate-200 dark:border-zinc-800 text-[11px] text-slate-500 dark:text-slate-400 shrink-0">
        <span>Microsoft Windows 11 Control Panel (control.exe)</span>
        <span>Version 10.0.22631.3296</span>
      </div>
    </div>
  );
};

/* ========================================================================= */
/* SUB-COMPONENT: DETAILED INTERACTIVE CONTROL PANEL APPLET VIEWS            */
/* ========================================================================= */

interface ControlPanelAppletDetailProps {
  item: ControlPanelItem;
  isAdmin: boolean;
  onBack: () => void;
  onNavigate: (name: string) => void;
}

const ControlPanelAppletDetail: React.FC<ControlPanelAppletDetailProps> = ({
  item,
  isAdmin,
  onBack,
  onNavigate,
}) => {
  const { addNotification, settings, updateSettings } = useOS();
  const [activeTab, setActiveTab] = useState('general');

  // Interactive states for specific applets
  // 1. Mouse applet
  const [doubleClickSpeed, setDoubleClickSpeed] = useState(50);
  const [pointerSpeed, setPointerSpeed] = useState(6);
  const [isFolderOpen, setIsFolderOpen] = useState(false);
  const [switchButtons, setSwitchButtons] = useState(false);

  // 2. Date and Time applet live clock
  const [currentTime, setCurrentTime] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // 3. Sound applet
  const [selectedPlayback, setSelectedPlayback] = useState('speakers');
  const [soundVolume, setSoundVolume] = useState(75);

  // 4. Power options
  const [powerPlan, setPowerPlan] = useState<'balanced' | 'high' | 'saver'>('balanced');

  // 5. Programs and features list
  const [programsList, setProgramsList] = useState([
    { name: 'Google Chrome', publisher: 'Google LLC', date: '15/02/2026', size: '215 MB', version: '131.0.6778.86' },
    { name: 'Microsoft Edge', publisher: 'Microsoft Corporation', date: '20/01/2026', size: '342 MB', version: '131.0.2903.70' },
    { name: 'Visual Studio Code', publisher: 'Microsoft Corporation', date: '08/02/2026', size: '380 MB', version: '1.95.3' },
    { name: 'Node.js JavaScript Runtime', publisher: 'OpenJS Foundation', date: '12/01/2026', size: '85.4 MB', version: '20.18.0' },
    { name: 'Python 3.12 64-bit', publisher: 'Python Software Foundation', date: '05/01/2026', size: '120 MB', version: '3.12.7' },
    { name: 'Steam Client Bootstrapper', publisher: 'Valve Corporation', date: '10/02/2026', size: '280 MB', version: '2.10.91' },
    { name: '7-Zip 24.08 (x64 edition)', publisher: 'Igor Pavlov', date: '01/01/2026', size: '4.5 MB', version: '24.08' },
    { name: 'VLC media player', publisher: 'VideoLAN', date: '25/01/2026', size: '145 MB', version: '3.0.21' },
  ]);
  const [selectedProgram, setSelectedProgram] = useState<string | null>(null);

  // 6. Text to speech preview
  const [ttsText, setTtsText] = useState(
    'Xin chào! Bạn đang sử dụng hệ điều hành Windows 11 với Bảng Điều khiển Control Panel.'
  );
  const [ttsSpeed, setTtsSpeed] = useState(1);

  // 7. Keyboard repeat test
  const [keyboardRepeatDelay, setKeyboardRepeatDelay] = useState(3);
  const [keyboardRepeatRate, setKeyboardRepeatRate] = useState(25);

  // Render specific applet content
  const renderAppletContent = () => {
    switch (item.canonicalName) {
      // -------------------------------------------------------------
      // 1. SYSTEM (sysdm.cpl / Microsoft.System)
      // -------------------------------------------------------------
      case 'Microsoft.System':
        return (
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-white dark:bg-[#252525] border border-slate-200 dark:border-zinc-800 shadow-2xs">
              <div className="flex items-center gap-3 mb-4">
                <Cpu size={28} className="text-[#0078D4]" />
                <div>
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                    Windows 11 Pro
                  </h3>
                  <p className="text-xs text-slate-500">Phiên bản 23H2 (OS Build 22631.3296)</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-2.5 rounded bg-slate-50 dark:bg-zinc-800/60">
                  <span className="text-slate-400 block mb-0.5">Vi xử lý (Processor):</span>
                  <span className="font-medium text-slate-800 dark:text-slate-200">
                    AMD Ryzen 9 7950X 16-Core Processor 4.50 GHz
                  </span>
                </div>
                <div className="p-2.5 rounded bg-slate-50 dark:bg-zinc-800/60">
                  <span className="text-slate-400 block mb-0.5">Bộ nhớ RAM (Installed RAM):</span>
                  <span className="font-medium text-slate-800 dark:text-slate-200">
                    32.0 GB (31.8 GB usable) DDR5-6000
                  </span>
                </div>
                <div className="p-2.5 rounded bg-slate-50 dark:bg-zinc-800/60">
                  <span className="text-slate-400 block mb-0.5">Loại hệ thống (System type):</span>
                  <span className="font-medium text-slate-800 dark:text-slate-200">
                    Hệ điều hành 64-bit, vi xử lý dựa trên x64
                  </span>
                </div>
                <div className="p-2.5 rounded bg-slate-50 dark:bg-zinc-800/60">
                  <span className="text-slate-400 block mb-0.5">Mã thiết bị (Device ID):</span>
                  <span className="font-mono text-slate-800 dark:text-slate-200">
                    E8A341B2-749C-4A2D-A91B-245C68EF293A
                  </span>
                </div>
                <div className="p-2.5 rounded bg-slate-50 dark:bg-zinc-800/60">
                  <span className="text-slate-400 block mb-0.5">Tên máy tính (Computer name):</span>
                  <span className="font-medium text-slate-800 dark:text-slate-200">
                    DESKTOP-WIN11-OS
                  </span>
                </div>
                <div className="p-2.5 rounded bg-slate-50 dark:bg-zinc-800/60">
                  <span className="text-slate-400 block mb-0.5">Nhóm làm việc (Workgroup):</span>
                  <span className="font-medium text-slate-800 dark:text-slate-200">WORKGROUP</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-slate-200 dark:border-zinc-800">
                <button
                  onClick={() => onNavigate('Microsoft.DeviceManager')}
                  className="px-3 py-1.5 rounded text-xs bg-[#0078D4] text-white hover:bg-[#006cbd] cursor-pointer"
                >
                  Trình quản lý Thiết bị (Device Manager)
                </button>
                <button
                  onClick={() =>
                    addNotification('System Properties', 'Đang cấu hình cài đặt nâng cao...', 'system')
                  }
                  className="px-3 py-1.5 rounded text-xs bg-slate-200 dark:bg-zinc-700 text-slate-800 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-zinc-600 cursor-pointer"
                >
                  Cài đặt hệ thống nâng cao
                </button>
                <button
                  onClick={() =>
                    addNotification('Windows 11', 'Bản quyền Windows đã được kích hoạt kỹ thuật số hợp lệ.', 'shield')
                  }
                  className="px-3 py-1.5 rounded text-xs bg-slate-200 dark:bg-zinc-700 text-slate-800 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-zinc-600 cursor-pointer"
                >
                  Kiểm tra bản quyền
                </button>
              </div>
            </div>
          </div>
        );

      // -------------------------------------------------------------
      // 2. PROGRAMS AND FEATURES (appwiz.cpl / Microsoft.ProgramsAndFeatures)
      // -------------------------------------------------------------
      case 'Microsoft.ProgramsAndFeatures':
        return (
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-2 p-2 bg-slate-100 dark:bg-zinc-800/80 rounded-md border border-slate-200 dark:border-zinc-700 text-xs">
              <span className="text-slate-600 dark:text-slate-300">
                Để gỡ cài đặt một chương trình, hãy chọn chương trình đó rồi nhấp vào "Gỡ cài đặt".
              </span>
              <button
                disabled={!selectedProgram}
                onClick={() => {
                  if (selectedProgram) {
                    setProgramsList((prev) => prev.filter((p) => p.name !== selectedProgram));
                    addNotification(
                      'Programs and Features',
                      `Đã gỡ cài đặt thành công: ${selectedProgram}`,
                      'system'
                    );
                    setSelectedProgram(null);
                  }
                }}
                className="px-3 py-1 bg-rose-600 hover:bg-rose-700 disabled:opacity-40 text-white rounded text-xs font-medium cursor-pointer transition-colors"
              >
                Gỡ cài đặt (Uninstall)
              </button>
            </div>

            <div className="bg-white dark:bg-[#252525] border border-slate-200 dark:border-zinc-800 rounded-lg shadow-2xs overflow-hidden">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 dark:bg-zinc-800 border-b border-slate-200 dark:border-zinc-700 text-slate-500 dark:text-slate-400">
                    <th className="p-2.5 font-semibold">Tên ứng dụng</th>
                    <th className="p-2.5 font-semibold">Nhà phát hành</th>
                    <th className="p-2.5 font-semibold">Ngày cài đặt</th>
                    <th className="p-2.5 font-semibold">Kích thước</th>
                    <th className="p-2.5 font-semibold">Phiên bản</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-zinc-800">
                  {programsList.map((prog) => {
                    const isSelected = selectedProgram === prog.name;
                    return (
                      <tr
                        key={prog.name}
                        onClick={() => setSelectedProgram(prog.name)}
                        className={`cursor-pointer transition-colors ${
                          isSelected
                            ? 'bg-sky-100 dark:bg-sky-950/60 text-sky-900 dark:text-sky-200'
                            : 'hover:bg-slate-50 dark:hover:bg-zinc-800/60'
                        }`}
                      >
                        <td className="p-2.5 font-medium flex items-center gap-2">
                          <Package size={14} className="text-[#0078D4]" />
                          {prog.name}
                        </td>
                        <td className="p-2.5 text-slate-500 dark:text-slate-400">
                          {prog.publisher}
                        </td>
                        <td className="p-2.5 text-slate-500 dark:text-slate-400">{prog.date}</td>
                        <td className="p-2.5 text-slate-500 dark:text-slate-400">{prog.size}</td>
                        <td className="p-2.5 text-slate-500 dark:text-slate-400 font-mono text-[11px]">
                          {prog.version}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        );

      // -------------------------------------------------------------
      // 3. DATE AND TIME (timedate.cpl / Microsoft.DateAndTime)
      // -------------------------------------------------------------
      case 'Microsoft.DateAndTime': {
        const hours = currentTime.getHours();
        const minutes = currentTime.getMinutes();
        const seconds = currentTime.getSeconds();
        const secDeg = seconds * 6;
        const minDeg = minutes * 6 + seconds * 0.1;
        const hrDeg = (hours % 12) * 30 + minutes * 0.5;

        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 rounded-lg bg-white dark:bg-[#252525] border border-slate-200 dark:border-zinc-800 shadow-2xs flex flex-col items-center">
              <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
                Đồng hồ hệ thống (Analog Clock)
              </h3>

              {/* SVG Analog Clock */}
              <div className="relative w-44 h-44 rounded-full border-4 border-slate-300 dark:border-zinc-700 bg-white dark:bg-[#1a1a1a] shadow-inner flex items-center justify-center">
                {[...Array(12)].map((_, i) => (
                  <div
                    key={i}
                    className="absolute w-0.5 h-2 bg-slate-400 dark:bg-zinc-500"
                    style={{
                      transform: `rotate(${i * 30}deg) translateY(-80px)`,
                    }}
                  />
                ))}

                {/* Hour hand */}
                <div
                  className="absolute w-1.5 h-12 bg-slate-800 dark:bg-white rounded-full origin-bottom"
                  style={{
                    transform: `translateY(-50%) rotate(${hrDeg}deg)`,
                  }}
                />

                {/* Minute hand */}
                <div
                  className="absolute w-1 h-16 bg-slate-600 dark:bg-slate-300 rounded-full origin-bottom"
                  style={{
                    transform: `translateY(-50%) rotate(${minDeg}deg)`,
                  }}
                />

                {/* Second hand */}
                <div
                  className="absolute w-0.5 h-20 bg-red-500 origin-bottom"
                  style={{
                    transform: `translateY(-50%) rotate(${secDeg}deg)`,
                  }}
                />

                {/* Pin center */}
                <div className="absolute w-3 h-3 rounded-full bg-red-600" />
              </div>

              <div className="mt-4 text-center">
                <div className="text-2xl font-mono font-bold text-slate-800 dark:text-white">
                  {currentTime.toLocaleTimeString()}
                </div>
                <div className="text-xs text-slate-500 mt-1">
                  {currentTime.toLocaleDateString(undefined, {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </div>
              </div>
            </div>

            <div className="p-5 rounded-lg bg-white dark:bg-[#252525] border border-slate-200 dark:border-zinc-800 shadow-2xs space-y-4 text-xs">
              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-200 block mb-1">
                  Múi giờ hiện tại (Time Zone)
                </label>
                <select className="w-full bg-slate-50 dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 rounded p-2 outline-none">
                  <option>(UTC+07:00) Bangkok, Hanoi, Jakarta</option>
                  <option>(UTC+08:00) Beijing, Singapore, Taipei</option>
                  <option>(UTC+09:00) Tokyo, Seoul, Osaka</option>
                  <option>(UTC+00:00) UTC / London</option>
                  <option>(UTC-05:00) Eastern Time (US & Canada)</option>
                  <option>(UTC-08:00) Pacific Time (US & Canada)</option>
                </select>
              </div>

              <div className="p-3 bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 rounded">
                <span className="font-medium text-sky-900 dark:text-sky-200 block mb-1">
                  Đồng bộ hóa giờ Internet (Internet Time)
                </span>
                <p className="text-[11px] text-sky-700 dark:text-sky-300 mb-2">
                  Máy tính này đã được cấu hình tự động đồng bộ thời gian với máy chủ time.windows.com.
                </p>
                <button
                  onClick={() => {
                    setCurrentTime(new Date());
                    addNotification(
                      'Date and Time',
                      'Đồng bộ hóa thành công với time.windows.com',
                      'system'
                    );
                  }}
                  className="px-3 py-1 bg-[#0078D4] hover:bg-[#006cbd] text-white rounded font-medium cursor-pointer"
                >
                  Cập nhật ngay bây giờ (Update now)
                </button>
              </div>
            </div>
          </div>
        );
      }

      // -------------------------------------------------------------
      // 4. MOUSE (main.cpl / mouse.cpl / Microsoft.Mouse)
      // -------------------------------------------------------------
      case 'Microsoft.Mouse':
        return (
          <div className="space-y-4 max-w-xl">
            <div className="p-4 rounded-lg bg-white dark:bg-[#252525] border border-slate-200 dark:border-zinc-800 shadow-2xs space-y-4 text-xs">
              <div>
                <h4 className="font-semibold text-slate-800 dark:text-slate-200 mb-2">
                  Cấu hình nút chuột (Button configuration)
                </h4>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={switchButtons}
                    onChange={(e) => setSwitchButtons(e.target.checked)}
                    className="rounded text-[#0078D4]"
                  />
                  <span>Chuyển đổi nút chính và nút phụ (Switch primary and secondary buttons)</span>
                </label>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-zinc-800">
                <h4 className="font-semibold text-slate-800 dark:text-slate-200 mb-2">
                  Tốc độ nhấp đúp (Double-click speed)
                </h4>
                <div className="flex items-center gap-3">
                  <span className="text-slate-400">Chậm</span>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    value={doubleClickSpeed}
                    onChange={(e) => setDoubleClickSpeed(Number(e.target.value))}
                    className="flex-1 accent-[#0078D4]"
                  />
                  <span className="text-slate-400">Nhanh</span>
                </div>

                <div className="flex items-center gap-3 mt-3 p-3 bg-slate-50 dark:bg-zinc-800 rounded">
                  <div
                    onDoubleClick={() => setIsFolderOpen(!isFolderOpen)}
                    className="cursor-pointer text-amber-500 hover:scale-110 transition-transform p-1"
                    title="Nhấp đúp chuột vào thư mục này để kiểm tra tốc độ"
                  >
                    {isFolderOpen ? <FolderOpen size={36} /> : <Folder size={36} />}
                  </div>
                  <div>
                    <span className="font-medium text-slate-700 dark:text-slate-200 block">
                      Thư mục thử nghiệm tốc độ
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {isFolderOpen ? 'Thư mục đang MỞ (Open)' : 'Thư mục đang ĐÓNG (Closed)'} - Nhấp
                      đúp để đổi trạng thái.
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-zinc-800">
                <h4 className="font-semibold text-slate-800 dark:text-slate-200 mb-2">
                  Tốc độ con trỏ chuột (Pointer speed)
                </h4>
                <div className="flex items-center gap-3">
                  <span className="text-slate-400">1</span>
                  <input
                    type="range"
                    min="1"
                    max="11"
                    value={pointerSpeed}
                    onChange={(e) => setPointerSpeed(Number(e.target.value))}
                    className="flex-1 accent-[#0078D4]"
                  />
                  <span className="text-slate-400">11</span>
                </div>
                <label className="flex items-center gap-2 mt-2 cursor-pointer">
                  <input type="checkbox" defaultChecked className="rounded text-[#0078D4]" />
                  <span>Nâng cao độ chính xác con trỏ (Enhance pointer precision)</span>
                </label>
              </div>
            </div>
          </div>
        );

      // -------------------------------------------------------------
      // 5. SOUND (mmsys.cpl / Microsoft.Sound)
      // -------------------------------------------------------------
      case 'Microsoft.Sound':
        return (
          <div className="space-y-4 max-w-xl">
            <div className="p-4 rounded-lg bg-white dark:bg-[#252525] border border-slate-200 dark:border-zinc-800 shadow-2xs space-y-4 text-xs">
              <h4 className="font-semibold text-slate-800 dark:text-slate-200">
                Thiết bị phát âm thanh (Playback Devices)
              </h4>

              <div className="space-y-2">
                {[
                  {
                    id: 'speakers',
                    name: 'Speakers (Realtek High Definition Audio)',
                    isDefault: true,
                    status: 'Default Device',
                  },
                  {
                    id: 'headphones',
                    name: 'Headphones (Realtek High Definition Audio)',
                    isDefault: false,
                    status: 'Ready',
                  },
                  {
                    id: 'hdmi',
                    name: 'Digital Audio (NVIDIA High Definition Audio)',
                    isDefault: false,
                    status: 'Ready',
                  },
                ].map((dev) => (
                  <div
                    key={dev.id}
                    onClick={() => setSelectedPlayback(dev.id)}
                    className={`flex items-center justify-between p-3 rounded-md border cursor-pointer transition-colors ${
                      selectedPlayback === dev.id
                        ? 'bg-sky-50 dark:bg-sky-950/40 border-[#0078D4]'
                        : 'border-slate-200 dark:border-zinc-700 hover:bg-slate-50 dark:hover:bg-zinc-800'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Speaker size={22} className="text-[#0078D4]" />
                      <div>
                        <div className="font-medium text-slate-800 dark:text-slate-200">
                          {dev.name}
                        </div>
                        <div className="text-[11px] text-slate-400">{dev.status}</div>
                      </div>
                    </div>
                    {dev.isDefault && (
                      <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 text-[11px] font-medium">
                        <Check size={14} /> Mặc định
                      </span>
                    )}
                  </div>
                ))}
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-zinc-800">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">
                    Âm lượng chính (Master Volume)
                  </span>
                  <span className="font-mono text-slate-500">{soundVolume}%</span>
                </div>
                <div className="flex items-center gap-3">
                  <Volume2 size={16} className="text-[#0078D4]" />
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={soundVolume}
                    onChange={(e) => setSoundVolume(Number(e.target.value))}
                    className="flex-1 accent-[#0078D4]"
                  />
                  <button
                    onClick={() => {
                      addNotification('Sound Test', 'Đang phát âm thanh kiểm tra loa...', 'media');
                    }}
                    className="px-3 py-1 bg-[#0078D4] hover:bg-[#006cbd] text-white rounded text-xs cursor-pointer font-medium"
                  >
                    Kiểm tra (Test)
                  </button>
                </div>
              </div>
            </div>
          </div>
        );

      // -------------------------------------------------------------
      // 6. POWER OPTIONS (powercfg.cpl / Microsoft.PowerOptions)
      // -------------------------------------------------------------
      case 'Microsoft.PowerOptions':
        return (
          <div className="space-y-4 max-w-xl text-xs">
            <div className="p-4 rounded-lg bg-white dark:bg-[#252525] border border-slate-200 dark:border-zinc-800 shadow-2xs space-y-3">
              <h4 className="font-semibold text-slate-800 dark:text-slate-200">
                Gói nguồn điện ưu tiên (Preferred Plans)
              </h4>

              <div className="space-y-2">
                {[
                  {
                    id: 'balanced',
                    title: 'Balanced (Khuyên dùng)',
                    desc: 'Tự động cân bằng giữa hiệu suất và mức tiêu thụ điện năng trên phần cứng.',
                  },
                  {
                    id: 'high',
                    title: 'High Performance (Hiệu suất cao)',
                    desc: 'Ưu tiên tối đa hiệu năng xử lý của CPU và GPU, có thể tiêu tốn nhiều điện năng hơn.',
                  },
                  {
                    id: 'saver',
                    title: 'Power Saver (Tiết kiệm điện)',
                    desc: 'Tiết kiệm năng lượng bằng cách giảm xung nhịp máy tính và giảm độ sáng màn hình.',
                  },
                ].map((plan) => (
                  <label
                    key={plan.id}
                    className={`flex items-start gap-3 p-3 rounded-md border cursor-pointer transition-colors ${
                      powerPlan === plan.id
                        ? 'bg-sky-50 dark:bg-sky-950/40 border-[#0078D4]'
                        : 'border-slate-200 dark:border-zinc-700 hover:bg-slate-50 dark:hover:bg-zinc-800'
                    }`}
                  >
                    <input
                      type="radio"
                      name="powerPlan"
                      checked={powerPlan === plan.id}
                      onChange={() => setPowerPlan(plan.id as any)}
                      className="mt-1 accent-[#0078D4]"
                    />
                    <div>
                      <span className="font-medium text-slate-800 dark:text-slate-200 block">
                        {plan.title}
                      </span>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400">
                        {plan.desc}
                      </span>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </div>
        );

      // -------------------------------------------------------------
      // 7. FIREWALL (firewall.cpl / Microsoft.Firewall)
      // -------------------------------------------------------------
      case 'Microsoft.Firewall':
        return (
          <div className="space-y-4 max-w-xl text-xs">
            <div className="p-4 rounded-lg bg-white dark:bg-[#252525] border border-slate-200 dark:border-zinc-800 shadow-2xs space-y-3">
              <div className="flex items-center gap-3 text-emerald-600 dark:text-emerald-400">
                <ShieldCheck size={28} />
                <div>
                  <h4 className="font-semibold text-sm text-slate-900 dark:text-white">
                    Tường lửa Windows Defender đang BẬT
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Máy tính của bạn đang được bảo vệ chống lại các truy cập trái phép qua mạng.
                  </p>
                </div>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-zinc-800/80 rounded border border-slate-200 dark:border-zinc-700 space-y-1.5 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">Mạng riêng tư (Private networks):</span>
                  <span className="font-semibold text-emerald-600">Đã kết nối & Bảo vệ</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Mạng công cộng (Public networks):</span>
                  <span className="font-semibold text-slate-600 dark:text-slate-300">Không kết nối</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Quy tắc chặn kết nối vào:</span>
                  <span className="font-medium">Chặn tất cả ứng dụng chưa khai báo</span>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() =>
                    addNotification('Firewall', 'Tất cả quy tắc tường lửa đã được cập nhật.', 'shield')
                  }
                  className="px-3 py-1.5 bg-[#0078D4] hover:bg-[#006cbd] text-white rounded font-medium cursor-pointer"
                >
                  Cho phép ứng dụng qua tường lửa
                </button>
                <button
                  onClick={() =>
                    addNotification('Firewall', 'Đã khôi phục quy tắc tường lửa về mặc định.', 'system')
                  }
                  className="px-3 py-1.5 bg-slate-200 dark:bg-zinc-700 hover:bg-slate-300 dark:hover:bg-zinc-600 text-slate-800 dark:text-slate-200 rounded font-medium cursor-pointer"
                >
                  Khôi phục mặc định
                </button>
              </div>
            </div>
          </div>
        );

      // -------------------------------------------------------------
      // 8. DEVICE MANAGER (hdwwiz.cpl / Microsoft.DeviceManager)
      // -------------------------------------------------------------
      case 'Microsoft.DeviceManager':
        return (
          <div className="space-y-3 max-w-2xl text-xs">
            <div className="p-4 rounded-lg bg-white dark:bg-[#252525] border border-slate-200 dark:border-zinc-800 shadow-2xs">
              <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-200 dark:border-zinc-800 font-semibold text-slate-800 dark:text-slate-200">
                <Monitor size={16} className="text-[#0078D4]" />
                <span>DESKTOP-WIN11-OS (Phần cứng máy tính)</span>
              </div>

              <div className="space-y-1.5">
                {[
                  { cat: 'Audio inputs and outputs', items: ['Microphone (Realtek Audio)', 'Speakers (Realtek Audio)'] },
                  { cat: 'Cameras', items: ['Integrated HD Webcam 1080p'] },
                  { cat: 'Disk drives', items: ['Samsung SSD 990 PRO 512GB (NVMe PCIe 4.0)', 'Crucial P3 Plus 1TB (NVMe)'] },
                  { cat: 'Display adapters', items: ['NVIDIA GeForce RTX 4080 (16GB GDDR6X)', 'AMD Radeon Graphics (Integrated)'] },
                  { cat: 'Keyboards', items: ['Standard PS/2 Keyboard', 'HID Keyboard Device'] },
                  { cat: 'Mice and other pointing devices', items: ['HID-compliant optical mouse'] },
                  { cat: 'Monitors', items: ['Generic PnP Monitor (3840x2160 @ 144Hz HDR)'] },
                  { cat: 'Network adapters', items: ['Intel(R) Wi-Fi 6E AX211 160MHz', 'Realtek Gaming 2.5GbE Family Controller'] },
                  { cat: 'Processors', items: ['AMD Ryzen 9 7950X 16-Core Processor (32 Threads)'] },
                  { cat: 'Universal Serial Bus controllers', items: ['AMD USB 3.2 Gen 2x2 eXtensible Host Controller', 'USB Root Hub (USB 3.0)'] },
                ].map((group, idx) => (
                  <details key={idx} className="group/d">
                    <summary className="cursor-pointer p-1.5 rounded hover:bg-slate-100 dark:hover:bg-zinc-800 font-medium text-slate-700 dark:text-slate-300 flex items-center justify-between">
                      <span>▸ {group.cat}</span>
                      <span className="text-[10px] text-slate-400 font-normal">
                        ({group.items.length} thiết bị)
                      </span>
                    </summary>
                    <div className="pl-6 py-1 space-y-1">
                      {group.items.map((it, i) => (
                        <div
                          key={i}
                          className="flex items-center gap-2 p-1 text-[11px] text-slate-600 dark:text-slate-400 hover:text-[#0078D4]"
                        >
                          <HardDrive size={12} className="text-[#0078D4]" />
                          <span>{it}</span>
                          <span className="ml-auto text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                            Hoạt động tốt
                          </span>
                        </div>
                      ))}
                    </div>
                  </details>
                ))}
              </div>
            </div>
          </div>
        );

      // -------------------------------------------------------------
      // 9. FONTS (Microsoft.Fonts)
      // -------------------------------------------------------------
      case 'Microsoft.Fonts':
        return (
          <div className="space-y-4 text-xs">
            <div className="p-4 rounded-lg bg-white dark:bg-[#252525] border border-slate-200 dark:border-zinc-800 shadow-2xs">
              <h4 className="font-semibold text-slate-800 dark:text-slate-200 mb-2">
                Danh mục Phông chữ Hệ thống (Installed System Fonts)
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {[
                  'Segoe UI',
                  'Arial',
                  'Times New Roman',
                  'Calibri',
                  'Consolas',
                  'Courier New',
                  'Georgia',
                  'Trebuchet MS',
                  'Tahoma',
                  'Verdana',
                  'Roboto',
                  'Fira Code',
                ].map((font) => (
                  <div
                    key={font}
                    className="p-3 rounded border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800/60"
                  >
                    <div className="font-semibold text-slate-800 dark:text-slate-200 mb-1">{font}</div>
                    <div
                      className="text-slate-600 dark:text-slate-300 text-sm truncate"
                      style={{ fontFamily: font }}
                    >
                      The quick brown fox jumps over the lazy dog
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      // -------------------------------------------------------------
      // 10. TEXT TO SPEECH (Microsoft.TextToSpeech)
      // -------------------------------------------------------------
      case 'Microsoft.TextToSpeech':
        return (
          <div className="space-y-4 max-w-xl text-xs">
            <div className="p-4 rounded-lg bg-white dark:bg-[#252525] border border-slate-200 dark:border-zinc-800 shadow-2xs space-y-3">
              <h4 className="font-semibold text-slate-800 dark:text-slate-200">
                Nhận dạng Giọng nói & Đọc văn bản (Text to Speech)
              </h4>

              <div>
                <label className="text-slate-500 block mb-1">Công cụ giọng đọc (Voice selection):</label>
                <select className="w-full bg-slate-50 dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 rounded p-2 outline-none">
                  <option>Microsoft David Desktop - English (United States)</option>
                  <option>Microsoft Zira Desktop - English (United States)</option>
                  <option>Microsoft Mark Desktop - English (United States)</option>
                  <option>Vietnamese Natural Speech Engine</option>
                </select>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-slate-500">Tốc độ đọc (Voice Speed):</span>
                  <span className="font-mono">{ttsSpeed}x</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={ttsSpeed}
                  onChange={(e) => setTtsSpeed(Number(e.target.value))}
                  className="w-full accent-[#0078D4]"
                />
              </div>

              <div>
                <label className="text-slate-500 block mb-1">Văn bản xem trước (Sample Text):</label>
                <textarea
                  value={ttsText}
                  onChange={(e) => setTtsText(e.target.value)}
                  rows={3}
                  className="w-full p-2 bg-slate-50 dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 rounded outline-none"
                />
              </div>

              <button
                onClick={() => {
                  if ('speechSynthesis' in window) {
                    window.speechSynthesis.cancel();
                    const utterance = new SpeechSynthesisUtterance(ttsText);
                    utterance.rate = ttsSpeed;
                    window.speechSynthesis.speak(utterance);
                  } else {
                    addNotification('Text to Speech', 'Đang phát âm thanh giọng đọc...', 'media');
                  }
                }}
                className="px-4 py-2 bg-[#0078D4] hover:bg-[#006cbd] text-white rounded font-medium cursor-pointer flex items-center gap-2"
              >
                <Play size={14} /> Thử giọng đọc (Preview Voice)
              </button>
            </div>
          </div>
        );

      // -------------------------------------------------------------
      // DEFAULT FALLBACK FOR OTHER CPL / APPLET ITEMS
      // -------------------------------------------------------------
      default:
        return (
          <div className="space-y-4 max-w-xl text-xs">
            <div className="p-5 rounded-lg bg-white dark:bg-[#252525] border border-slate-200 dark:border-zinc-800 shadow-2xs space-y-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-lg bg-sky-500/10 text-[#0078D4]">
                  {item.icon === 'Lock' ? (
                    <Lock size={24} />
                  ) : item.icon === 'Globe' ? (
                    <Globe size={24} />
                  ) : item.icon === 'Activity' ? (
                    <Activity size={24} />
                  ) : (
                    <SlidersHorizontal size={24} />
                  )}
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                    {item.name}
                  </h3>
                  <p className="text-slate-500 font-mono text-[11px]">
                    {item.canonicalName}
                    {item.cpl ? ` • ${item.cpl}` : ''}
                  </p>
                </div>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-zinc-800/80 rounded border border-slate-200 dark:border-zinc-700">
                <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                  {item.vietnameseDescription}
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-zinc-800">
                  <span className="text-slate-400">Trạng thái mô-đun:</span>
                  <span className="text-emerald-600 font-medium">Sẵn sàng (Active)</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-zinc-800">
                  <span className="text-slate-400">Nhóm thể loại:</span>
                  <span className="text-slate-700 dark:text-slate-300 capitalize">
                    {item.category.replace('_', ' ')}
                  </span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-slate-400">Quyền thực thi:</span>
                  <span className="text-slate-700 dark:text-slate-300">
                    {isAdmin ? 'Quản trị viên (Elevated)' : 'Người dùng tiêu chuẩn'}
                  </span>
                </div>
              </div>

              <div className="pt-3 flex gap-2">
                <button
                  onClick={() =>
                    addNotification(
                      item.name,
                      `Đã áp dụng các cấu hình cho ${item.name} thành công.`,
                      'system'
                    )
                  }
                  className="px-4 py-1.5 bg-[#0078D4] hover:bg-[#006cbd] text-white rounded font-medium cursor-pointer"
                >
                  Áp dụng thiết lập (Apply)
                </button>
                <button
                  onClick={onBack}
                  className="px-4 py-1.5 bg-slate-200 dark:bg-zinc-700 hover:bg-slate-300 dark:hover:bg-zinc-600 text-slate-800 dark:text-slate-200 rounded font-medium cursor-pointer"
                >
                  Đóng (Close)
                </button>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      {/* Applet Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-zinc-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-600 dark:text-slate-300 cursor-pointer"
            title="Quay lại danh sách"
          >
            <ArrowLeft size={18} />
          </button>
          <div>
            <h2 className="text-base font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              {item.name}
              {item.cpl && (
                <span className="text-xs font-mono font-normal text-slate-400 bg-slate-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded">
                  {item.cpl}
                </span>
              )}
            </h2>
            <p className="text-xs text-slate-500">{item.description}</p>
          </div>
        </div>

        {isAdmin && (
          <span className="flex items-center gap-1 text-xs text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 px-2 py-1 rounded border border-amber-200 dark:border-amber-800 font-medium">
            <Shield size={13} /> Administrator
          </span>
        )}
      </div>

      {/* Render the specific applet */}
      {renderAppletContent()}
    </div>
  );
};
