import React, { useState, useEffect } from 'react';
import { Clock, Bell, Timer as TimerIcon, Play, Pause, RotateCcw, Plus, Trash2, Globe, Flame } from 'lucide-react';
import { useOS } from '../../context/OSContext';

export const ClockApp: React.FC = () => {
  const { addNotification } = useOS();
  const [activeTab, setActiveTab] = useState<'clock' | 'alarm' | 'stopwatch' | 'timer'>('clock');

  // Local & World Time
  const [currentTime, setCurrentTime] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Stopwatch state
  const [stopwatchTime, setStopwatchTime] = useState(0);
  const [isStopwatchRunning, setIsStopwatchRunning] = useState(false);
  const [laps, setLaps] = useState<number[]>([]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isStopwatchRunning) {
      interval = setInterval(() => {
        setStopwatchTime((prev) => prev + 10);
      }, 10);
    }
    return () => clearInterval(interval);
  }, [isStopwatchRunning]);

  // Timer state
  const [timerSeconds, setTimerSeconds] = useState(300); // 5 min default
  const [timerInitial, setTimerInitial] = useState(300);
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => {
          if (prev <= 1) {
            setIsTimerRunning(false);
            addNotification('Timer Finished!', 'Your timer has ended.', 'clock');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerSeconds, addNotification]);

  // Alarms
  const [alarms, setAlarms] = useState<{ id: string; time: string; label: string; active: boolean }[]>([
    { id: '1', time: '07:00', label: 'Morning Alarm', active: true },
    { id: '2', time: '14:30', label: 'Meeting', active: false },
  ]);

  const formatStopwatch = (ms: number) => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    const hundredths = Math.floor((ms % 1000) / 10);
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(hundredths).padStart(2, '0')}`;
  };

  const formatTimer = (totalSec: number) => {
    const hours = Math.floor(totalSec / 3600);
    const minutes = Math.floor((totalSec % 3600) / 60);
    const seconds = totalSec % 60;
    if (hours > 0) {
      return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  };

  const worldCities = [
    { city: 'Hà Nội / TP.HCM', offset: 7, country: 'Vietnam' },
    { city: 'Tokyo', offset: 9, country: 'Japan' },
    { city: 'London', offset: 0, country: 'United Kingdom' },
    { city: 'New York', offset: -5, country: 'USA' },
    { city: 'Sydney', offset: 11, country: 'Australia' },
  ];

  return (
    <div className="flex h-full bg-[#f3f3f3] dark:bg-[#202020] text-slate-800 dark:text-slate-100 select-none overflow-hidden font-sans">
      {/* Sidebar Navigation */}
      <div className="w-48 bg-slate-200/50 dark:bg-black/20 p-3 border-r border-black/5 dark:border-white/5 flex flex-col gap-1">
        <div className="px-3 py-2 text-xs font-bold text-slate-500 uppercase tracking-wider">
          Clock & Focus
        </div>

        <button
          onClick={() => setActiveTab('clock')}
          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'clock'
              ? 'bg-white dark:bg-white/15 text-sky-600 dark:text-sky-400 shadow-sm'
              : 'hover:bg-white/40 dark:hover:bg-white/5 text-slate-600 dark:text-slate-300'
          }`}
        >
          <Clock size={16} /> World Clock
        </button>

        <button
          onClick={() => setActiveTab('alarm')}
          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'alarm'
              ? 'bg-white dark:bg-white/15 text-sky-600 dark:text-sky-400 shadow-sm'
              : 'hover:bg-white/40 dark:hover:bg-white/5 text-slate-600 dark:text-slate-300'
          }`}
        >
          <Bell size={16} /> Alarm
        </button>

        <button
          onClick={() => setActiveTab('stopwatch')}
          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'stopwatch'
              ? 'bg-white dark:bg-white/15 text-sky-600 dark:text-sky-400 shadow-sm'
              : 'hover:bg-white/40 dark:hover:bg-white/5 text-slate-600 dark:text-slate-300'
          }`}
        >
          <RotateCcw size={16} /> Stopwatch
        </button>

        <button
          onClick={() => setActiveTab('timer')}
          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'timer'
              ? 'bg-white dark:bg-white/15 text-sky-600 dark:text-sky-400 shadow-sm'
              : 'hover:bg-white/40 dark:hover:bg-white/5 text-slate-600 dark:text-slate-300'
          }`}
        >
          <TimerIcon size={16} /> Timer
        </button>
      </div>

      {/* Main Content View */}
      <div className="flex-1 p-6 overflow-y-auto">
        {/* World Clock Tab */}
        {activeTab === 'clock' && (
          <div className="flex flex-col gap-6 max-w-2xl mx-auto">
            {/* Hero Main Clock */}
            <div className="p-8 rounded-2xl bg-white/70 dark:bg-white/5 border border-black/5 dark:border-white/10 shadow-sm text-center relative overflow-hidden backdrop-blur-md">
              <div className="absolute top-0 right-0 w-64 h-64 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="text-6xl font-light tracking-tight font-mono text-slate-900 dark:text-white mb-2">
                {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </div>
              <div className="text-sm font-medium text-slate-500 dark:text-slate-400">
                {currentTime.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
              </div>
              <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 bg-sky-500/15 text-sky-600 dark:text-sky-400 rounded-full text-xs font-semibold">
                <Globe size={13} /> Local Time (GMT+7)
              </div>
            </div>

            {/* World Cities List */}
            <div>
              <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-3">World Times</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {worldCities.map((item, i) => {
                  const utc = currentTime.getTime() + currentTime.getTimezoneOffset() * 60000;
                  const cityDate = new Date(utc + 3600000 * item.offset);
                  return (
                    <div
                      key={i}
                      className="p-4 rounded-xl bg-white dark:bg-zinc-800/60 border border-black/5 dark:border-white/10 shadow-sm flex items-center justify-between"
                    >
                      <div>
                        <div className="font-semibold text-sm">{item.city}</div>
                        <div className="text-xs text-slate-400">{item.country}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-mono font-bold text-sky-500">
                          {cityDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {cityDate.getDate() !== currentTime.getDate() ? (cityDate.getDate() > currentTime.getDate() ? '+1 day' : '-1 day') : 'Today'}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Alarm Tab */}
        {activeTab === 'alarm' && (
          <div className="max-w-xl mx-auto flex flex-col gap-4">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-lg font-bold">Alarms</h2>
              <button
                onClick={() => {
                  const newAlarm = {
                    id: 'alarm-' + Date.now(),
                    time: '08:00',
                    label: 'New Alarm',
                    active: true,
                  };
                  setAlarms([...alarms, newAlarm]);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-500 hover:bg-sky-600 text-white rounded-lg text-xs font-semibold shadow"
              >
                <Plus size={14} /> Add Alarm
              </button>
            </div>

            <div className="space-y-2">
              {alarms.map((alarm) => (
                <div
                  key={alarm.id}
                  className="p-4 rounded-xl bg-white dark:bg-zinc-800/70 border border-black/5 dark:border-white/10 shadow-sm flex items-center justify-between"
                >
                  <div>
                    <input
                      type="time"
                      value={alarm.time}
                      onChange={(e) => {
                        setAlarms(alarms.map((a) => (a.id === alarm.id ? { ...a, time: e.target.value } : a)));
                      }}
                      className="text-3xl font-mono font-light bg-transparent focus:outline-none border-b border-transparent focus:border-sky-500"
                    />
                    <input
                      type="text"
                      value={alarm.label}
                      onChange={(e) => {
                        setAlarms(alarms.map((a) => (a.id === alarm.id ? { ...a, label: e.target.value } : a)));
                      }}
                      className="block text-xs text-slate-500 dark:text-slate-400 bg-transparent mt-1 focus:outline-none"
                    />
                  </div>

                  <div className="flex items-center gap-3">
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={alarm.active}
                        onChange={() => {
                          setAlarms(alarms.map((a) => (a.id === alarm.id ? { ...a, active: !a.active } : a)));
                        }}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-sky-500" />
                    </label>

                    <button
                      onClick={() => setAlarms(alarms.filter((a) => a.id !== alarm.id))}
                      className="p-2 hover:bg-red-500/10 text-slate-400 hover:text-red-500 rounded-lg transition-colors"
                      title="Delete"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Stopwatch Tab */}
        {activeTab === 'stopwatch' && (
          <div className="max-w-md mx-auto flex flex-col items-center justify-center pt-8">
            <div className="relative w-64 h-64 rounded-full border-4 border-slate-300 dark:border-zinc-700 flex flex-col items-center justify-center bg-white/60 dark:bg-zinc-900/60 backdrop-blur shadow-xl mb-6">
              <div className="text-4xl font-mono font-bold text-slate-900 dark:text-white">
                {formatStopwatch(stopwatchTime)}
              </div>
              <div className="text-xs text-slate-400 mt-1">STOPWATCH</div>
            </div>

            <div className="flex items-center gap-4 mb-6">
              <button
                onClick={() => setIsStopwatchRunning(!isStopwatchRunning)}
                className={`w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-transform active:scale-95 text-white ${
                  isStopwatchRunning ? 'bg-amber-500 hover:bg-amber-600' : 'bg-sky-500 hover:bg-sky-600'
                }`}
              >
                {isStopwatchRunning ? <Pause size={22} /> : <Play size={22} className="ml-1" />}
              </button>

              <button
                onClick={() => {
                  if (isStopwatchRunning) {
                    setLaps([stopwatchTime, ...laps]);
                  } else {
                    setStopwatchTime(0);
                    setLaps([]);
                  }
                }}
                className="w-12 h-12 rounded-full bg-slate-200 dark:bg-zinc-800 hover:bg-slate-300 dark:hover:bg-zinc-700 flex items-center justify-center text-slate-700 dark:text-slate-300 shadow transition-colors"
              >
                {isStopwatchRunning ? <Flame size={18} /> : <RotateCcw size={18} />}
              </button>
            </div>

            {laps.length > 0 && (
              <div className="w-full max-h-48 overflow-y-auto space-y-1 bg-white/50 dark:bg-zinc-900/50 p-3 rounded-xl border border-black/5 dark:border-white/5">
                {laps.map((lap, idx) => (
                  <div key={idx} className="flex justify-between text-xs py-1 px-2 font-mono">
                    <span className="text-slate-400">Lap {laps.length - idx}</span>
                    <span className="font-semibold text-sky-500">{formatStopwatch(lap)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Timer Tab */}
        {activeTab === 'timer' && (
          <div className="max-w-md mx-auto flex flex-col items-center justify-center pt-8">
            <div className="relative w-64 h-64 rounded-full border-4 border-sky-500/30 flex flex-col items-center justify-center bg-white/60 dark:bg-zinc-900/60 backdrop-blur shadow-xl mb-6">
              <div className="text-4xl font-mono font-bold text-slate-900 dark:text-white">
                {formatTimer(timerSeconds)}
              </div>
              <div className="text-xs text-slate-400 mt-1">
                {isTimerRunning ? 'COUNTDOWN RUNNING' : 'TIMER READY'}
              </div>
            </div>

            {/* Preset Buttons */}
            <div className="flex items-center gap-2 mb-6">
              {[60, 300, 600, 1500].map((sec) => (
                <button
                  key={sec}
                  onClick={() => {
                    setIsTimerRunning(false);
                    setTimerSeconds(sec);
                    setTimerInitial(sec);
                  }}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-200 dark:bg-zinc-800 hover:bg-sky-500 hover:text-white transition-colors"
                >
                  {sec / 60} min
                </button>
              ))}
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={() => setIsTimerRunning(!isTimerRunning)}
                className={`w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-transform active:scale-95 text-white ${
                  isTimerRunning ? 'bg-amber-500 hover:bg-amber-600' : 'bg-sky-500 hover:bg-sky-600'
                }`}
              >
                {isTimerRunning ? <Pause size={22} /> : <Play size={22} className="ml-1" />}
              </button>

              <button
                onClick={() => {
                  setIsTimerRunning(false);
                  setTimerSeconds(timerInitial);
                }}
                className="w-12 h-12 rounded-full bg-slate-200 dark:bg-zinc-800 hover:bg-slate-300 dark:hover:bg-zinc-700 flex items-center justify-center text-slate-700 dark:text-slate-300 shadow transition-colors"
              >
                <RotateCcw size={18} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
