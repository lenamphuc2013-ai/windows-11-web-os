import React, { useState, useEffect, useMemo } from 'react';
import {
  Play,
  Code2,
  Tv,
  RotateCcw,
  ExternalLink,
  ClipboardPaste,
  Trash2,
  Check,
  AlertCircle,
  Sparkles,
  ArrowRight,
  Info,
} from 'lucide-react';

// Sample embed code to let users test instantly
const SAMPLE_IFRAME_CODE = `<iframe width="560" height="315" src="https://www.youtube.com/embed/jfKfPfyJRdk" title="Lofi hip hop radio - beats to relax/study to" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`;

const STORAGE_KEY = 'win11_youtube_saved_embed';

export const YouTubeApp: React.FC = () => {
  // Active Tab: 'input' (Tab 1) | 'player' (Tab 2)
  const [activeTab, setActiveTab] = useState<'input' | 'player'>('input');
  const [embedInput, setEmbedInput] = useState<string>(() => {
    try {
      return localStorage.getItem(STORAGE_KEY) || '';
    } catch {
      return '';
    }
  });
  const [appliedCode, setAppliedCode] = useState<string>(() => {
    try {
      return localStorage.getItem(STORAGE_KEY) || '';
    } catch {
      return '';
    }
  });

  const [copyFeedback, setCopyFeedback] = useState(false);
  const [inputError, setInputError] = useState<string | null>(null);
  const [playerKey, setPlayerKey] = useState(0);

  // Parse embed input to extract clean embed URL
  const parsedVideoInfo = useMemo(() => {
    const raw = (appliedCode || '').trim();
    if (!raw) return null;

    // 1. Try extracting src from <iframe> tag
    const iframeSrcMatch = raw.match(/<iframe[^>]*\ssrc=["']([^"']+)["'][^>]*>/i);
    if (iframeSrcMatch && iframeSrcMatch[1]) {
      let src = iframeSrcMatch[1];
      // Ensure protocol
      if (src.startsWith('//')) src = 'https:' + src;
      return {
        type: 'iframe' as const,
        embedUrl: src,
        rawHtml: raw,
      };
    }

    // 2. Try matching youtube watch URL (e.g. youtube.com/watch?v=VIDEO_ID)
    const watchMatch = raw.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i);
    if (watchMatch && watchMatch[1]) {
      const videoId = watchMatch[1];
      return {
        type: 'url' as const,
        embedUrl: `https://www.youtube.com/embed/${videoId}?autoplay=1`,
        videoId,
      };
    }

    // 3. Direct embed URL or arbitrary URL
    if (raw.startsWith('http://') || raw.startsWith('https://')) {
      return {
        type: 'direct' as const,
        embedUrl: raw,
      };
    }

    return null;
  }, [appliedCode]);

  // Handle clicking "Xem Video"
  const handleWatchVideo = () => {
    const trimmed = embedInput.trim();
    if (!trimmed) {
      setInputError('Vui lòng dán mã iframe YouTube hoặc link video vào ô trước khi xem.');
      return;
    }

    setInputError(null);
    setAppliedCode(trimmed);
    try {
      localStorage.setItem(STORAGE_KEY, trimmed);
    } catch {}

    // Switch to Tab 2: Xem Video
    setActiveTab('player');
    setPlayerKey((prev) => prev + 1);
  };

  // Paste from clipboard
  const handlePasteFromClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setEmbedInput(text);
        setInputError(null);
        setCopyFeedback(true);
        setTimeout(() => setCopyFeedback(false), 2000);
      }
    } catch {
      setInputError('Không thể truy cập khay nhớ tạm. Vui lòng nhấn Ctrl+V để dán trực tiếp vào ô.');
    }
  };

  // Use sample code
  const handleUseSample = () => {
    setEmbedInput(SAMPLE_IFRAME_CODE);
    setInputError(null);
  };

  // Clear input
  const handleClear = () => {
    setEmbedInput('');
    setInputError(null);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#0f0f0f] text-slate-100 select-none overflow-hidden font-sans">
      {/* Top Application Header / Navigation Tabs */}
      <div className="h-11 px-3 bg-[#181818] border-b border-white/10 flex items-center justify-between shrink-0 z-20">
        {/* Left: YouTube Brand Logo */}
        <div className="flex items-center gap-2 mr-2">
          <div className="w-7 h-7 rounded-lg bg-[#ff0000] flex items-center justify-center shadow-md">
            <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white">
              <path d="M9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
            </svg>
          </div>
          <span className="font-bold text-sm tracking-tight text-white hidden sm:inline">YouTube</span>
        </div>

        {/* Center: 2 Clear Tabs */}
        <div className="flex items-center bg-[#272727] p-1 rounded-xl border border-white/5">
          {/* TAB 1: NHẬP MÃ IFRAME */}
          <button
            type="button"
            onClick={() => setActiveTab('input')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'input'
                ? 'bg-[#ff0000] text-white shadow-sm font-semibold'
                : 'text-zinc-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Code2 size={14} />
            <span>Tab 1: Nhập mã iframe</span>
          </button>

          {/* TAB 2: XEM VIDEO */}
          <button
            type="button"
            onClick={() => {
              if (!appliedCode.trim() && embedInput.trim()) {
                handleWatchVideo();
              } else {
                setActiveTab('player');
              }
            }}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'player'
                ? 'bg-[#ff0000] text-white shadow-sm font-semibold'
                : 'text-zinc-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Play size={14} />
            <span>Tab 2: Xem Video</span>
            {parsedVideoInfo && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse ml-0.5" />
            )}
          </button>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-1.5">
          {activeTab === 'player' && (
            <button
              type="button"
              onClick={() => setPlayerKey((k) => k + 1)}
              title="Tải lại video"
              className="p-1.5 hover:bg-white/10 text-zinc-300 hover:text-white rounded-lg transition-colors"
            >
              <RotateCcw size={14} />
            </button>
          )}
          {parsedVideoInfo?.embedUrl && (
            <a
              href={parsedVideoInfo.embedUrl}
              target="_blank"
              rel="noopener noreferrer"
              title="Mở video trong tab trình duyệt mới"
              className="p-1.5 hover:bg-white/10 text-zinc-300 hover:text-white rounded-lg transition-colors"
            >
              <ExternalLink size={14} />
            </a>
          )}
        </div>
      </div>

      {/* Main Tab Viewport */}
      <div className="flex-1 w-full h-full relative overflow-hidden bg-[#0f0f0f]">
        {/* ========================================================= */}
        {/* TAB 1: NHẬP MÃ IFRAME */}
        {/* ========================================================= */}
        {activeTab === 'input' && (
          <div className="h-full w-full overflow-y-auto p-4 sm:p-6 flex flex-col justify-between max-w-4xl mx-auto">
            <div className="space-y-4">
              {/* Header Title & Subtitle */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/10">
                <div>
                  <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                    <Code2 className="text-[#ff0000]" size={20} />
                    Nhập mã nhúng iframe YouTube
                  </h2>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    Hỗ trợ dán toàn bộ thẻ <code className="text-zinc-300 bg-white/10 px-1 py-0.5 rounded">&lt;iframe&gt;</code> hoặc link video YouTube thông thường
                  </p>
                </div>

                {/* Helper action buttons */}
                <div className="flex items-center gap-2 self-start sm:self-auto">
                  <button
                    type="button"
                    onClick={handlePasteFromClipboard}
                    className="px-2.5 py-1.5 bg-[#272727] hover:bg-[#383838] active:scale-95 text-zinc-200 rounded-lg text-xs font-medium flex items-center gap-1.5 border border-white/10 transition-all"
                  >
                    <ClipboardPaste size={13} />
                    <span>{copyFeedback ? 'Đã dán!' : 'Dán từ clipboard'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleUseSample}
                    className="px-2.5 py-1.5 bg-[#272727] hover:bg-[#383838] active:scale-95 text-amber-300 hover:text-amber-200 rounded-lg text-xs font-medium flex items-center gap-1.5 border border-white/10 transition-all"
                    title="Điền mã iframe mẫu để thử nghiệm nhanh"
                  >
                    <Sparkles size={13} />
                    <span>Mã mẫu</span>
                  </button>

                  {embedInput && (
                    <button
                      type="button"
                      onClick={handleClear}
                      className="p-1.5 bg-[#272727] hover:bg-red-500/20 text-zinc-400 hover:text-red-400 rounded-lg text-xs border border-white/10 transition-all"
                      title="Xóa trắng"
                    >
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
              </div>

              {/* Ô to trống để người dùng DÁN mã iframe YouTube vào */}
              <div className="space-y-2">
                <div className="relative">
                  <textarea
                    value={embedInput}
                    onChange={(e) => {
                      setEmbedInput(e.target.value);
                      if (inputError) setInputError(null);
                    }}
                    placeholder={`Dán toàn bộ mã <iframe> nhúng từ YouTube vào đây...\n\nVí dụ:\n<iframe width="560" height="315" src="https://www.youtube.com/embed/jfKfPfyJRdk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>\n\n(Hoặc dán trực tiếp đường link https://www.youtube.com/watch?v=...)`}
                    rows={8}
                    className="w-full p-3.5 bg-[#1e1e1e] border border-white/15 focus:border-[#ff0000] rounded-xl text-xs sm:text-sm font-mono text-zinc-100 placeholder-zinc-500 outline-none transition-all resize-y shadow-inner leading-relaxed"
                  />
                  {embedInput && (
                    <div className="absolute bottom-3 right-3 text-[11px] text-zinc-400 bg-black/60 px-2 py-0.5 rounded-md backdrop-blur-sm pointer-events-none">
                      {embedInput.length} ký tự
                    </div>
                  )}
                </div>

                {/* Error message if any */}
                {inputError && (
                  <div className="flex items-center gap-2 text-xs text-rose-400 bg-rose-500/10 border border-rose-500/20 px-3 py-2 rounded-lg animate-in fade-in">
                    <AlertCircle size={14} className="shrink-0" />
                    <span>{inputError}</span>
                  </div>
                )}
              </div>

              {/* Action Bar: Nút "Xem Video" & Hướng dẫn nhỏ */}
              <div className="bg-[#181818] p-4 rounded-xl border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
                {/* Hướng dẫn nhỏ theo yêu cầu */}
                <div className="flex items-center gap-2 text-xs text-zinc-300">
                  <div className="w-5 h-5 rounded-full bg-[#ff0000]/20 text-[#ff0000] flex items-center justify-center shrink-0 font-bold text-[11px]">
                    i
                  </div>
                  <span className="font-medium">
                    Dán mã nhúng YouTube vào đây → bấm Xem
                  </span>
                </div>

                {/* Nút "Xem Video" */}
                <button
                  type="button"
                  onClick={handleWatchVideo}
                  className="w-full sm:w-auto px-6 py-2.5 bg-[#ff0000] hover:bg-[#d90000] active:scale-95 text-white font-semibold rounded-xl text-sm shadow-md hover:shadow-red-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Play size={16} fill="currentColor" />
                  <span>Xem Video</span>
                  <ArrowRight size={14} />
                </button>
              </div>

              {/* Quick instructions card */}
              <div className="p-3.5 bg-white/5 rounded-xl border border-white/5 text-xs text-zinc-400 space-y-1.5">
                <div className="font-semibold text-zinc-300 flex items-center gap-1.5">
                  <Info size={13} className="text-sky-400" />
                  Cách lấy mã nhúng từ YouTube:
                </div>
                <ol className="list-decimal list-inside space-y-1 text-[11px] leading-relaxed pl-1 text-zinc-400">
                  <li>Mở video bạn muốn xem trên YouTube</li>
                  <li>Bấm vào nút <strong className="text-zinc-200 font-medium">"Chia sẻ" (Share)</strong> bên dưới video</li>
                  <li>Chọn mục <strong className="text-zinc-200 font-medium">"Nhúng" (Embed)</strong> và sao chép toàn bộ đoạn mã trong ô</li>
                  <li>Dán mã đó vào ô trên và bấm nút <strong className="text-[#ff4d4d] font-semibold">"Xem Video"</strong></li>
                </ol>
              </div>
            </div>

            {/* Bottom status */}
            {appliedCode && (
              <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-zinc-400">
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <Check size={12} />
                  Đã lưu mã video trước đó
                </span>
                <button
                  type="button"
                  onClick={() => setActiveTab('player')}
                  className="text-sky-400 hover:underline flex items-center gap-1"
                >
                  <span>Chuyển sang Tab 2 để xem</span>
                  <ArrowRight size={11} />
                </button>
              </div>
            )}
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 2: XEM VIDEO */}
        {/* ========================================================= */}
        {activeTab === 'player' && (
          <div className="h-full w-full flex flex-col relative bg-black">
            {parsedVideoInfo?.embedUrl ? (
              <div className="flex-1 w-full h-full relative flex items-center justify-center overflow-hidden">
                {/* YouTube Video iframe with full permissions */}
                <iframe
                  key={playerKey}
                  src={parsedVideoInfo.embedUrl}
                  title="YouTube video player"
                  className="w-full h-full border-0"
                  style={{ border: 0 }}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                  loading="eager"
                  referrerPolicy="strict-origin-when-cross-origin"
                />

                {/* Floating Bottom Quick Bar */}
                <div className="absolute top-3 right-3 flex items-center gap-2 z-30 opacity-40 hover:opacity-100 transition-opacity">
                  <button
                    type="button"
                    onClick={() => setActiveTab('input')}
                    className="px-2.5 py-1 bg-[#181818]/90 hover:bg-[#282828] backdrop-blur-md text-white rounded-lg text-xs font-medium border border-white/15 shadow-xl flex items-center gap-1.5 transition-all"
                  >
                    <Code2 size={13} />
                    <span>Đổi video khác</span>
                  </button>
                </div>
              </div>
            ) : (
              /* Empty state if no video has been submitted yet */
              <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
                <div className="w-16 h-16 rounded-3xl bg-[#ff0000]/10 border border-[#ff0000]/20 flex items-center justify-center text-[#ff0000] mb-4 shadow-2xl">
                  <Tv size={32} />
                </div>
                <h3 className="text-base font-bold text-white mb-1">
                  Chưa có video nào để phát
                </h3>
                <p className="text-xs text-zinc-400 max-w-sm mb-5 leading-relaxed">
                  Vui lòng chuyển về <span className="text-white font-medium">Tab 1: Nhập mã</span> và dán mã nhúng iframe của video YouTube bạn muốn xem.
                </p>
                <button
                  type="button"
                  onClick={() => setActiveTab('input')}
                  className="px-4 py-2 bg-[#ff0000] hover:bg-[#d90000] text-white rounded-xl text-xs font-semibold shadow-md flex items-center gap-2 transition-all cursor-pointer"
                >
                  <Code2 size={14} />
                  <span>Đi tới Tab Nhập mã</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
