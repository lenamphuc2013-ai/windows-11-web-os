import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  Volume1,
  VolumeX,
  Maximize,
  Minimize,
  Repeat,
  FolderOpen,
  ListVideo,
  Settings,
  Sparkles,
  Upload,
  Check,
  ChevronUp,
  FileVideo,
  Monitor,
  PictureInPicture,
  Info,
  Layers,
} from 'lucide-react';
import { useOS } from '../../context/OSContext';

export interface VideoItem {
  id: string;
  title: string;
  url: string;
  type: 'sample' | 'local' | 'custom';
  format: 'mp4' | 'webm' | 'mkv' | 'other';
  duration?: number;
  durationFormatted?: string;
  resolution?: string;
  size?: string;
  thumbnailSvg?: string;
}

const SAMPLE_VIDEOS: VideoItem[] = [
  {
    id: 'sample-nature',
    title: 'Wildlife & Nature Bloom',
    url: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4',
    type: 'sample',
    format: 'mp4',
    durationFormatted: '0:05',
    resolution: '1080p HD',
    size: '1.8 MB',
    thumbnailSvg: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 225'><defs><linearGradient id='g1' x1='0%' y1='0%' x2='100%' y2='100%'><stop offset='0%' stop-color='%2310b981'/><stop offset='100%' stop-color='%23065f46'/></linearGradient></defs><rect width='400' height='225' fill='url(%23g1)'/><circle cx='200' cy='112' r='45' fill='%2334d399' opacity='0.7'/><circle cx='200' cy='112' r='20' fill='%23fef08a'/></svg>`,
  },
  {
    id: 'sample-bunny',
    title: 'Big Buck Bunny (Animation Demo)',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    type: 'sample',
    format: 'mp4',
    durationFormatted: '9:56',
    resolution: '1080p 60fps',
    size: '158 MB',
    thumbnailSvg: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 225'><defs><linearGradient id='g2' x1='0%' y1='0%' x2='100%' y2='100%'><stop offset='0%' stop-color='%2338bdf8'/><stop offset='100%' stop-color='%231e3a8a'/></linearGradient></defs><rect width='400' height='225' fill='url(%23g2)'/><ellipse cx='200' cy='112' rx='70' ry='50' fill='%23bae6fd' opacity='0.5'/><circle cx='180' cy='100' r='8' fill='%230f172a'/><circle cx='220' cy='100' r='8' fill='%230f172a'/></svg>`,
  },
  {
    id: 'sample-blazes',
    title: 'For Bigger Blazes (Action Demo)',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    type: 'sample',
    format: 'mp4',
    durationFormatted: '0:15',
    resolution: '4K Ultra HD',
    size: '14.2 MB',
    thumbnailSvg: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 225'><defs><linearGradient id='g3' x1='0%' y1='0%' x2='100%' y2='100%'><stop offset='0%' stop-color='%23f97316'/><stop offset='100%' stop-color='%23991b1b'/></linearGradient></defs><rect width='400' height='225' fill='url(%23g3)'/><polygon points='200,40 240,160 160,160' fill='%23fbbf24' opacity='0.8'/></svg>`,
  },
  {
    id: 'sample-elephants',
    title: 'Elephants Dream (Sci-Fi Animation)',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    type: 'sample',
    format: 'mp4',
    durationFormatted: '10:53',
    resolution: '1080p Full HD',
    size: '180 MB',
    thumbnailSvg: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 225'><defs><linearGradient id='g4' x1='0%' y1='0%' x2='100%' y2='100%'><stop offset='0%' stop-color='%238b5cf6'/><stop offset='100%' stop-color='%233b0764'/></linearGradient></defs><rect width='400' height='225' fill='url(%23g4)'/><circle cx='200' cy='112' r='60' fill='%23c084fc' opacity='0.4'/></svg>`,
  },
  {
    id: 'sample-webm-flower',
    title: 'Botanical Garden (WebM VP9)',
    url: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm',
    type: 'sample',
    format: 'webm',
    durationFormatted: '0:05',
    resolution: '720p HD',
    size: '1.2 MB',
    thumbnailSvg: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 225'><defs><linearGradient id='g5' x1='0%' y1='0%' x2='100%' y2='100%'><stop offset='0%' stop-color='%2306b6d4'/><stop offset='100%' stop-color='%230f766e'/></linearGradient></defs><rect width='400' height='225' fill='url(%23g5)'/><rect x='150' y='75' width='100' height='75' rx='16' fill='%2367e8f9' opacity='0.6'/></svg>`,
  },
];

interface VideoPlayerAppProps {
  initialVideoUrl?: string;
  initialVideoName?: string;
  filePath?: string;
}

export const VideoPlayerApp: React.FC<VideoPlayerAppProps> = ({
  initialVideoUrl,
  initialVideoName,
  filePath,
}) => {
  const { addNotification, fileSystem, addFile } = useOS();

  // Load videos from OS fileSystem (e.g., C:\Users\User\Videos, C:\Users\User\Desktop)
  const systemVideos = React.useMemo(() => {
    const vids: VideoItem[] = [];
    fileSystem.forEach((item) => {
      if (!item.isDirectory && item.name.match(/\.(mp4|webm|mkv|mov|avi|ogv)$/i) && item.content) {
        vids.push({
          id: `fs-${item.id}`,
          title: item.name,
          url: item.content,
          type: 'local',
          format: item.name.endsWith('.webm') ? 'webm' : 'mp4',
          durationFormatted: '--:--',
          resolution: 'Thư viện tệp',
          size: item.size ? (item.size / (1024 * 1024)).toFixed(1) + ' MB' : 'Local File',
        });
      }
    });
    return vids;
  }, [fileSystem]);

  // Playlist & Active Video
  const [playlist, setPlaylist] = useState<VideoItem[]>(() => {
    const list: VideoItem[] = [];
    const resolvedUrl = initialVideoUrl || (filePath ? fileSystem.find((f) => f.path === filePath)?.content : undefined);
    const resolvedName = initialVideoName || (filePath ? fileSystem.find((f) => f.path === filePath)?.name : undefined) || filePath;

    if (resolvedUrl) {
      list.push({
        id: `video-${Date.now()}`,
        title: resolvedName || 'Tệp Video tùy chỉnh',
        url: resolvedUrl,
        type: 'custom',
        format: resolvedName?.endsWith('.webm') ? 'webm' : 'mp4',
        durationFormatted: '--:--',
        resolution: 'Video Source',
        size: 'Local / Stream',
      });
    }
    // Also include any video from user's systemVideos
    systemVideos.forEach((sv) => {
      if (!list.some((l) => l.title === sv.title || l.url === sv.url)) {
        list.push(sv);
      }
    });
    // Add sample videos
    SAMPLE_VIDEOS.forEach((sv) => {
      if (!list.some((l) => l.id === sv.id)) {
        list.push(sv);
      }
    });
    return list.length > 0 ? list : SAMPLE_VIDEOS;
  });

  // Watch for initialVideoUrl or filePath prop updates when user opens another video while player is open
  useEffect(() => {
    const resolvedUrl = initialVideoUrl || (filePath ? fileSystem.find((f) => f.path === filePath)?.content : undefined);
    const resolvedName = initialVideoName || (filePath ? fileSystem.find((f) => f.path === filePath)?.name : undefined) || filePath;

    if (resolvedUrl) {
      const existingIdx = playlist.findIndex((v) => v.url === resolvedUrl || v.title === resolvedName);
      if (existingIdx >= 0) {
        setCurrentVideoIndex(existingIdx);
        setIsPlaying(true);
      } else {
        const customItem: VideoItem = {
          id: `video-${Date.now()}`,
          title: resolvedName || 'Tệp Video tùy chỉnh',
          url: resolvedUrl,
          type: 'custom',
          format: resolvedName?.endsWith('.webm') ? 'webm' : 'mp4',
          durationFormatted: '--:--',
          resolution: 'Video Source',
          size: 'Local / Stream',
        };
        setPlaylist((prev) => [customItem, ...prev]);
        setCurrentVideoIndex(0);
        setIsPlaying(true);
      }
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.play().catch(() => {});
        }
      }, 100);
    }
  }, [initialVideoUrl, initialVideoName, filePath, fileSystem]);

  const [currentVideoIndex, setCurrentVideoIndex] = useState<number>(0);
  const activeVideo = playlist[currentVideoIndex] || playlist[0];

  // Playback States
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [volume, setVolume] = useState<number>(80);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isLooping, setIsLooping] = useState<boolean>(false);
  const [playbackRate, setPlaybackRate] = useState<number>(1.0);
  const [aspectFit, setAspectFit] = useState<'contain' | 'cover'>('contain');
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [isBuffering, setIsBuffering] = useState<boolean>(false);
  const [showPlaylist, setShowPlaylist] = useState<boolean>(false);
  const [showSpeedMenu, setShowSpeedMenu] = useState<boolean>(false);
  const [isDraggingOver, setIsDraggingOver] = useState<boolean>(false);
  const [feedbackToast, setFeedbackToast] = useState<{ text: string; icon?: string } | null>(null);

  // Hover Seek Bar preview state
  const [seekHoverTime, setSeekHoverTime] = useState<number | null>(null);
  const [seekHoverPos, setSeekHoverPos] = useState<number | null>(null);

  // Auto-hide controls
  const [showControls, setShowControls] = useState<boolean>(true);
  const hideControlsTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Element Refs
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const seekBarRef = useRef<HTMLDivElement | null>(null);

  // Format seconds to mm:ss or hh:mm:ss
  const formatTime = (seconds: number): string => {
    if (isNaN(seconds) || seconds < 0) return '00:00';
    const s = Math.floor(seconds);
    const hrs = Math.floor(s / 3600);
    const mins = Math.floor((s % 3600) / 60);
    const secs = s % 60;
    const pad = (n: number) => n.toString().padStart(2, '0');

    if (hrs > 0) {
      return `${hrs}:${pad(mins)}:${pad(secs)}`;
    }
    return `${pad(mins)}:${pad(secs)}`;
  };

  // Trigger brief visual toast
  const triggerToast = (text: string, icon?: string) => {
    setFeedbackToast({ text, icon });
    setTimeout(() => {
      setFeedbackToast((prev) => (prev?.text === text ? null : prev));
    }, 1500);
  };

  // Reset auto hide controls timer on mouse move
  const handleMouseMove = () => {
    setShowControls(true);
    if (hideControlsTimerRef.current) clearTimeout(hideControlsTimerRef.current);
    if (isPlaying) {
      hideControlsTimerRef.current = setTimeout(() => {
        setShowControls(false);
      }, 3500);
    }
  };

  // Toggle Play / Pause
  const togglePlay = useCallback(() => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current
        .play()
        .then(() => {
          setIsPlaying(true);
          triggerToast('Đang phát', 'play');
        })
        .catch((e) => {
          console.warn('Playback error / autoplay policy:', e);
        });
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
      triggerToast('Tạm dừng', 'pause');
    }
  }, []);

  // Skip -10s / +10s
  const handleSkip = useCallback(
    (seconds: number) => {
      if (!videoRef.current) return;
      const newTime = Math.max(0, Math.min(videoRef.current.duration || 0, videoRef.current.currentTime + seconds));
      videoRef.current.currentTime = newTime;
      setCurrentTime(newTime);
      triggerToast(seconds > 0 ? `+${seconds}s` : `${seconds}s`, seconds > 0 ? 'forward' : 'backward');
    },
    []
  );

  // Change Volume
  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    if (videoRef.current) {
      videoRef.current.volume = newVol / 100;
      if (newVol > 0 && isMuted) {
        setIsMuted(false);
        videoRef.current.muted = false;
      }
    }
  };

  // Toggle Mute
  const toggleMute = () => {
    if (!videoRef.current) return;
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    videoRef.current.muted = nextMute;
    if (nextMute) {
      triggerToast('Tắt tiếng', 'mute');
    } else {
      triggerToast(`Âm lượng: ${volume}%`, 'volume');
    }
  };

  // Seek bar click / drag
  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!seekBarRef.current || !videoRef.current || !duration) return;
    const rect = seekBarRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percentage = Math.max(0, Math.min(1, clickX / rect.width));
    const targetTime = percentage * duration;

    videoRef.current.currentTime = targetTime;
    setCurrentTime(targetTime);
  };

  const handleSeekMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!seekBarRef.current || !duration) return;
    const rect = seekBarRef.current.getBoundingClientRect();
    const hoverX = e.clientX - rect.left;
    const percentage = Math.max(0, Math.min(1, hoverX / rect.width));
    setSeekHoverTime(percentage * duration);
    setSeekHoverPos(hoverX);
  };

  // Toggle Fullscreen (within container or document)
  const toggleFullscreen = () => {
    if (!containerRef.current) return;

    if (!document.fullscreenElement) {
      containerRef.current
        .requestFullscreen()
        .then(() => setIsFullscreen(true))
        .catch(() => {
          // Fallback UI fullscreen toggle
          setIsFullscreen((prev) => !prev);
        });
    } else {
      document
        .exitFullscreen()
        .then(() => setIsFullscreen(false))
        .catch(() => {
          setIsFullscreen(false);
        });
    }
  };

  // Picture in Picture
  const togglePiP = async () => {
    if (!videoRef.current) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else if (videoRef.current.requestPictureInPicture) {
        await videoRef.current.requestPictureInPicture();
        triggerToast('Picture in Picture', 'pip');
      }
    } catch (e) {
      addNotification('Trình phát Video', 'Chế độ Picture in Picture không khả dụng', 'video');
    }
  };

  // Speed Change
  const handleSpeedChange = (speed: number) => {
    setPlaybackRate(speed);
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
    setShowSpeedMenu(false);
    triggerToast(`Tốc độ: ${speed}x`);
  };

  // Process video files uploaded or dragged & dropped
  const processVideoFile = (file: File) => {
    const isMp4 = file.type.includes('mp4') || file.name.toLowerCase().endsWith('.mp4');
    const isWebm = file.type.includes('webm') || file.name.toLowerCase().endsWith('.webm');
    const isOgg = file.type.includes('ogg') || file.name.toLowerCase().endsWith('.ogv');
    const isMkv = file.name.toLowerCase().endsWith('.mkv');

    if (!file.type.startsWith('video/') && !isMp4 && !isWebm && !isOgg && !isMkv) {
      addNotification('Trình phát Video', `Định dạng tệp không được hỗ trợ (${file.name}). Vui lòng chọn tệp MP4 hoặc WebM.`, 'video');
      return;
    }

    const objectUrl = URL.createObjectURL(file);
    const sizeMb = (file.size / (1024 * 1024)).toFixed(1) + ' MB';
    const newVideo: VideoItem = {
      id: `local-${Date.now()}`,
      title: file.name,
      url: objectUrl,
      type: 'local',
      format: isWebm ? 'webm' : 'mp4',
      size: sizeMb,
      resolution: 'Video cục bộ',
      durationFormatted: '--:--',
    };

    setPlaylist((prev) => [newVideo, ...prev]);
    setCurrentVideoIndex(0);
    addNotification('Trình phát Video', `Đang phát tệp video: ${file.name}`, 'video');
    triggerToast(`Đã nạp: ${file.name}`);

    // Persist video file in FileSystem C:\Users\User\Videos
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      addFile({
        name: file.name,
        path: `C:\\Users\\User\\Videos\\${file.name}`,
        isDirectory: false,
        content: dataUrl,
        size: file.size,
        icon: 'Film',
      });
    };
    reader.readAsDataURL(file);

    setTimeout(() => {
      if (videoRef.current) {
        videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
      }
    }, 100);
  };

  // Drag & Drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processVideoFile(e.dataTransfer.files[0]);
    }
  };

  // Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const activeTag = (document.activeElement as HTMLElement)?.tagName;
      if (activeTag === 'INPUT' || activeTag === 'TEXTAREA') return;

      if (e.code === 'Space' || e.key === 'k' || e.key === 'K') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        handleSkip(-10);
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        handleSkip(10);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setVolume((v) => {
          const next = Math.min(100, v + 10);
          handleVolumeChange(next);
          triggerToast(`Âm lượng: ${next}%`);
          return next;
        });
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setVolume((v) => {
          const next = Math.max(0, v - 10);
          handleVolumeChange(next);
          triggerToast(`Âm lượng: ${next}%`);
          return next;
        });
      } else if (e.key === 'm' || e.key === 'M') {
        e.preventDefault();
        toggleMute();
      } else if (e.key === 'f' || e.key === 'F') {
        e.preventDefault();
        toggleFullscreen();
      } else if (e.key === 'l' || e.key === 'L') {
        e.preventDefault();
        setIsLooping((prev) => {
          const next = !prev;
          triggerToast(next ? 'Lặp lại: BẬT' : 'Lặp lại: TẮT');
          return next;
        });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [togglePlay, handleSkip, isMuted, volume]);

  // Video element event sync
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleLoadedMetadata = () => {
      setDuration(video.duration || 0);
      video.volume = isMuted ? 0 : volume / 100;
      video.playbackRate = playbackRate;
      video.loop = isLooping;
    };

    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime || 0);
    };

    const handleWaiting = () => setIsBuffering(true);
    const handlePlaying = () => {
      setIsBuffering(false);
      setIsPlaying(true);
    };
    const handlePause = () => setIsPlaying(false);
    const handleEnded = () => {
      setIsPlaying(false);
      if (!isLooping && currentVideoIndex < playlist.length - 1) {
        // Auto play next video in playlist
        setCurrentVideoIndex((prev) => prev + 1);
      }
    };

    video.addEventListener('loadedmetadata', handleLoadedMetadata);
    video.addEventListener('timeupdate', handleTimeUpdate);
    video.addEventListener('waiting', handleWaiting);
    video.addEventListener('playing', handlePlaying);
    video.addEventListener('pause', handlePause);
    video.addEventListener('ended', handleEnded);

    return () => {
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
      video.removeEventListener('timeupdate', handleTimeUpdate);
      video.removeEventListener('waiting', handleWaiting);
      video.removeEventListener('playing', handlePlaying);
      video.removeEventListener('pause', handlePause);
      video.removeEventListener('ended', handleEnded);
    };
  }, [currentVideoIndex, isLooping, isMuted, volume, playbackRate, playlist.length]);

  // Sync Loop property
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.loop = isLooping;
    }
  }, [isLooping]);

  // Switch video handler
  const handleSelectVideo = (index: number) => {
    setCurrentVideoIndex(index);
    setCurrentTime(0);
    setIsPlaying(true);
    setTimeout(() => {
      if (videoRef.current) {
        videoRef.current.play().catch(() => {});
      }
    }, 100);
  };

  const progressPercent = duration ? (currentTime / duration) * 100 : 0;

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`relative w-full h-full bg-[#0c0c0e] text-white flex flex-col select-none overflow-hidden font-sans ${
        isFullscreen ? 'fixed inset-0 z-[9999]' : ''
      }`}
    >
      {/* Hidden Native File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/mp4,video/webm,video/ogg,video/mkv,.mp4,.webm,.mkv,.avi,.mov"
        className="hidden"
        onChange={(e) => {
          if (e.target.files && e.target.files.length > 0) {
            processVideoFile(e.target.files[0]);
          }
        }}
      />

      {/* Main Video Viewport */}
      <div
        className="relative flex-1 w-full h-full flex items-center justify-center bg-black overflow-hidden cursor-pointer"
        onClick={togglePlay}
        onDoubleClick={toggleFullscreen}
      >
        <video
          ref={videoRef}
          key={activeVideo.url}
          src={activeVideo.url}
          playsInline
          className={`w-full h-full transition-all duration-200 ${
            aspectFit === 'contain' ? 'object-contain' : 'object-cover'
          }`}
        />

        {/* Buffering Spinner */}
        {isBuffering && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 backdrop-blur-sm pointer-events-none z-20">
            <div className="w-12 h-12 border-4 border-sky-500/30 border-t-sky-400 rounded-full animate-spin mb-2" />
            <span className="text-xs font-semibold text-slate-200">Đang tải video...</span>
          </div>
        )}

        {/* Center Play/Pause Pop Overlay on Action */}
        {!isPlaying && !isBuffering && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/20 pointer-events-none z-10">
            <div className="w-16 h-16 rounded-full bg-sky-500/80 backdrop-blur-md text-white flex items-center justify-center shadow-2xl shadow-sky-500/50 hover:scale-110 transition-transform">
              <Play size={28} className="ml-1 fill-white" />
            </div>
          </div>
        )}

        {/* Action Feedback Toast */}
        {feedbackToast && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-black/85 backdrop-blur-xl border border-white/20 px-5 py-3 rounded-2xl shadow-2xl z-30 pointer-events-none flex items-center gap-3 animate-win11-fade">
            <span className="text-sm font-bold text-sky-400 tracking-wide">{feedbackToast.text}</span>
          </div>
        )}

        {/* Drag & Drop Visual Glow Overlay */}
        {isDraggingOver && (
          <div className="absolute inset-0 bg-sky-600/30 backdrop-blur-md border-4 border-dashed border-sky-400 flex flex-col items-center justify-center z-40 animate-pulse pointer-events-none">
            <Upload size={48} className="text-white mb-2" />
            <div className="text-lg font-bold text-white">Thả tệp video vào đây để phát ngay</div>
            <div className="text-xs text-sky-200 mt-1">Hỗ trợ: MP4, WebM, MKV, OGV</div>
          </div>
        )}
      </div>

      {/* Top Header Bar (Auto-Hides) */}
      <div
        className={`absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-black/80 via-black/40 to-transparent flex items-center justify-between z-30 transition-all duration-300 ${
          showControls ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4 pointer-events-none'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-sky-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400">
            <FileVideo size={18} />
          </div>
          <div className="flex flex-col">
            <div className="text-xs font-bold text-white max-w-sm truncate">{activeVideo.title}</div>
            <div className="flex items-center gap-2 text-[10px] text-slate-300">
              <span className="uppercase font-semibold text-sky-400 px-1 py-0.2 bg-sky-500/10 rounded">
                {activeVideo.format}
              </span>
              {activeVideo.resolution && <span>• {activeVideo.resolution}</span>}
              {activeVideo.size && <span>• {activeVideo.size}</span>}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 active:bg-white/30 text-xs font-semibold backdrop-blur-md transition-colors"
            title="Mở tệp video từ máy tính (MP4, WebM)"
          >
            <FolderOpen size={14} />
            <span className="hidden sm:inline">Mở video</span>
          </button>

          <button
            onClick={() => setShowPlaylist(!showPlaylist)}
            className={`p-2 rounded-lg backdrop-blur-md transition-colors ${
              showPlaylist ? 'bg-sky-500 text-white' : 'bg-white/10 hover:bg-white/20 text-slate-200'
            }`}
            title="Danh sách phát (Playlist)"
          >
            <ListVideo size={16} />
          </button>
        </div>
      </div>

      {/* Playlist Drawer (Slide from Right) */}
      {showPlaylist && (
        <div
          onClick={(e) => e.stopPropagation()}
          className="absolute top-0 right-0 bottom-24 w-80 max-w-[85vw] bg-[#161618]/95 backdrop-blur-2xl border-l border-white/10 shadow-2xl z-30 flex flex-col p-4 animate-win11-flyin"
        >
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <ListVideo size={16} className="text-sky-400" />
              <span className="text-xs font-bold uppercase tracking-wider">Danh sách video ({playlist.length})</span>
            </div>
            <button
              onClick={() => setShowPlaylist(false)}
              className="text-xs text-slate-400 hover:text-white px-2 py-1 rounded-md hover:bg-white/10"
            >
              Đóng
            </button>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 mt-3 pr-1">
            {playlist.map((video, idx) => {
              const isSelected = idx === currentVideoIndex;
              return (
                <div
                  key={video.id}
                  onClick={() => handleSelectVideo(idx)}
                  className={`flex items-center gap-3 p-2 rounded-xl cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-sky-500/20 border border-sky-500/40 text-white'
                      : 'hover:bg-white/5 border border-transparent text-slate-300 hover:text-white'
                  }`}
                >
                  <div className="w-14 h-9 rounded-lg bg-black/60 border border-white/10 overflow-hidden shrink-0 flex items-center justify-center relative">
                    {video.thumbnailSvg ? (
                      <img src={video.thumbnailSvg} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <FileVideo size={18} className="text-slate-400" />
                    )}
                    {isSelected && isPlaying && (
                      <div className="absolute inset-0 bg-sky-500/40 flex items-center justify-center">
                        <div className="w-2 h-2 rounded-full bg-white animate-ping" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-semibold truncate">{video.title}</div>
                    <div className="text-[10px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                      <span className="uppercase text-sky-400 font-mono">{video.format}</span>
                      {video.resolution && <span>• {video.resolution}</span>}
                    </div>
                  </div>
                  {isSelected && <Check size={14} className="text-sky-400 shrink-0" />}
                </div>
              );
            })}
          </div>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="mt-3 w-full py-2 bg-white/10 hover:bg-white/20 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors border border-white/10"
          >
            <Upload size={14} />
            <span>Thêm video từ máy tính</span>
          </button>
        </div>
      )}

      {/* Bottom Floating Controls Bar (Fluent Windows 11 Acrylic Bar) */}
      <div
        className={`absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/95 via-black/80 to-transparent z-30 transition-all duration-300 flex flex-col gap-2 ${
          showControls ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Seek Bar Area */}
        <div
          ref={seekBarRef}
          onClick={handleSeek}
          onMouseMove={handleSeekMouseMove}
          onMouseLeave={() => {
            setSeekHoverTime(null);
            setSeekHoverPos(null);
          }}
          className="relative w-full h-4 flex items-center cursor-pointer group"
        >
          {/* Seek Track Background */}
          <div className="w-full h-1.5 group-hover:h-2.5 bg-white/20 rounded-full transition-all duration-150 overflow-hidden relative">
            <div
              className="h-full bg-sky-500 rounded-full transition-all duration-100 relative"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* Hover Time Tooltip */}
          {seekHoverTime !== null && seekHoverPos !== null && (
            <div
              className="absolute -top-7 px-2 py-0.5 rounded bg-black/90 text-[10px] font-mono font-bold text-white border border-white/20 pointer-events-none shadow-lg -translate-x-1/2"
              style={{ left: `${seekHoverPos}px` }}
            >
              {formatTime(seekHoverTime)}
            </div>
          )}

          {/* Draggable Circle Thumb */}
          <div
            className="absolute w-3.5 h-3.5 bg-white rounded-full shadow-md shadow-black/80 opacity-0 group-hover:opacity-100 -translate-x-1/2 transition-opacity pointer-events-none border-2 border-sky-500"
            style={{ left: `${progressPercent}%` }}
          />
        </div>

        {/* Lower Row Controls */}
        <div className="flex items-center justify-between gap-2 pt-1">
          {/* Left: Playback buttons & Time */}
          <div className="flex items-center gap-2">
            {/* Lùi lại 10 giây */}
            <button
              onClick={() => handleSkip(-10)}
              className="p-2 rounded-xl text-slate-200 hover:text-white hover:bg-white/10 active:bg-white/20 transition-all group relative"
              title="Lùi lại 10 giây (Phím mũi tên trái)"
            >
              <RotateCcw size={18} />
              <span className="absolute -bottom-1 -right-1 text-[8px] font-bold text-sky-400 font-mono">10</span>
            </button>

            {/* Play / Pause Primary Button */}
            <button
              onClick={togglePlay}
              className="w-10 h-10 rounded-full bg-sky-500 hover:bg-sky-400 active:scale-95 text-white flex items-center justify-center shadow-lg shadow-sky-500/40 transition-all"
              title={isPlaying ? 'Tạm dừng (Space)' : 'Phát (Space)'}
            >
              {isPlaying ? <Pause size={20} className="fill-white" /> : <Play size={20} className="ml-0.5 fill-white" />}
            </button>

            {/* Tiến tới 10 giây */}
            <button
              onClick={() => handleSkip(10)}
              className="p-2 rounded-xl text-slate-200 hover:text-white hover:bg-white/10 active:bg-white/20 transition-all group relative"
              title="Tiến tới 10 giây (Phím mũi tên phải)"
            >
              <RotateCw size={18} />
              <span className="absolute -bottom-1 -right-1 text-[8px] font-bold text-sky-400 font-mono">10</span>
            </button>

            {/* Loop Toggle */}
            <button
              onClick={() => {
                const next = !isLooping;
                setIsLooping(next);
                triggerToast(next ? 'Lặp lại: BẬT' : 'Lặp lại: TẮT');
              }}
              className={`p-2 rounded-xl transition-all ${
                isLooping
                  ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
              title={isLooping ? 'Đang bật lặp lại (L)' : 'Bật lặp lại video (L)'}
            >
              <Repeat size={17} />
            </button>

            {/* Time Stamp (Current / Total) */}
            <div className="ml-2 text-xs font-mono font-medium text-slate-300 tracking-wider">
              <span className="text-white font-bold">{formatTime(currentTime)}</span>
              <span className="text-slate-500 mx-1">/</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Right: Volume & Display Controls */}
          <div className="flex items-center gap-2">
            {/* Volume Control Group */}
            <div className="flex items-center gap-1.5 group bg-white/5 hover:bg-white/10 px-2.5 py-1.5 rounded-xl border border-white/5 transition-all">
              <button
                onClick={toggleMute}
                className="text-slate-200 hover:text-white transition-colors"
                title={isMuted ? 'Bật âm thanh (M)' : 'Tắt âm thanh (M)'}
              >
                {isMuted || volume === 0 ? (
                  <VolumeX size={18} className="text-rose-400" />
                ) : volume < 50 ? (
                  <Volume1 size={18} />
                ) : (
                  <Volume2 size={18} />
                )}
              </button>

              <input
                type="range"
                min="0"
                max="100"
                value={isMuted ? 0 : volume}
                onChange={(e) => handleVolumeChange(Number(e.target.value))}
                className="w-16 md:w-24 h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-sky-400 focus:outline-none"
                title={`Âm lượng: ${isMuted ? 0 : volume}%`}
              />
              <span className="text-[10px] font-mono text-slate-300 w-7 text-right">
                {isMuted ? '0%' : `${volume}%`}
              </span>
            </div>

            {/* Speed Selector */}
            <div className="relative">
              <button
                onClick={() => setShowSpeedMenu(!showSpeedMenu)}
                className="px-2 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-xs font-mono font-bold text-slate-200 hover:text-white transition-colors"
                title="Tốc độ phát video"
              >
                {playbackRate}x
              </button>

              {showSpeedMenu && (
                <div className="absolute bottom-10 right-0 bg-[#1e1e20]/95 backdrop-blur-xl border border-white/10 rounded-xl p-1 shadow-2xl z-40 text-xs flex flex-col gap-0.5 min-w-[90px] animate-win11-fade">
                  {[0.5, 0.75, 1.0, 1.25, 1.5, 2.0].map((rate) => (
                    <button
                      key={rate}
                      onClick={() => handleSpeedChange(rate)}
                      className={`px-3 py-1.5 rounded-lg text-left flex items-center justify-between ${
                        playbackRate === rate ? 'bg-sky-500 text-white font-bold' : 'hover:bg-white/10 text-slate-200'
                      }`}
                    >
                      <span>{rate}x</span>
                      {playbackRate === rate && <Check size={12} />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Aspect Ratio Mode (Contain / Cover) */}
            <button
              onClick={() => {
                const next = aspectFit === 'contain' ? 'cover' : 'contain';
                setAspectFit(next);
                triggerToast(next === 'contain' ? 'Tỷ lệ: Giữ nguyên (Contain)' : 'Tỷ lệ: Lấp đầy (Cover)');
              }}
              className={`p-2 rounded-xl transition-all ${
                aspectFit === 'cover'
                  ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
              title="Tỷ lệ khung hình (Giữ chuẩn tỉ lệ / Lấp đầy)"
            >
              <Monitor size={17} />
            </button>

            {/* Picture in Picture */}
            <button
              onClick={togglePiP}
              className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors hidden sm:flex"
              title="Picture in Picture"
            >
              <PictureInPicture size={17} />
            </button>

            {/* Fullscreen Toggle */}
            <button
              onClick={toggleFullscreen}
              className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 active:bg-white/20 transition-colors"
              title={isFullscreen ? 'Thu nhỏ (F)' : 'Toàn màn hình (F)'}
            >
              {isFullscreen ? <Minimize size={18} /> : <Maximize size={18} />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
