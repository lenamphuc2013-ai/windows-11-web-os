import React, { useState } from 'react';
import {
  Smartphone,
  MessageSquare,
  Image as ImageIcon,
  PhoneCall,
  Bell,
  BatteryCharging,
  Wifi,
  Send,
  CheckCheck,
  User,
  Plus,
  RefreshCw,
} from 'lucide-react';

interface PhoneMessage {
  id: string;
  sender: string;
  text: string;
  time: string;
  isMe: boolean;
}

export const PhoneLinkApp: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'messages' | 'photos' | 'calls' | 'notifications'>('messages');
  const [messageInput, setMessageInput] = useState('');
  const [selectedContact, setSelectedContact] = useState('Alex Morgan');
  const [messages, setMessages] = useState<PhoneMessage[]>([
    {
      id: 'm1',
      sender: 'Alex Morgan',
      text: 'Hey! Are you working on the new Windows 11 app project?',
      time: '10:24 AM',
      isMe: false,
    },
    {
      id: 'm2',
      sender: 'Me',
      text: 'Yes! Added all 180+ functions and smooth window animations!',
      time: '10:26 AM',
      isMe: true,
    },
    {
      id: 'm3',
      sender: 'Alex Morgan',
      text: 'Awesome, testing it right now on my browser!',
      time: '10:28 AM',
      isMe: false,
    },
  ]);

  const [phoneBattery] = useState(88);
  const [phoneModel] = useState('Galaxy S24 Ultra');

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim()) return;

    const newMsg: PhoneMessage = {
      id: `msg-${Date.now()}`,
      sender: 'Me',
      text: messageInput.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isMe: true,
    };

    setMessages([...messages, newMsg]);
    setMessageInput('');
  };

  return (
    <div className="flex h-full bg-[#f3f3f3] dark:bg-[#202020] text-slate-800 dark:text-slate-100 select-none overflow-hidden font-sans">
      {/* Left Phone Info & Navigation Sidebar */}
      <div className="w-64 bg-slate-200/40 dark:bg-black/20 p-3 border-r border-black/5 dark:border-white/5 flex flex-col justify-between">
        <div className="flex flex-col gap-4">
          {/* Paired Phone Card */}
          <div className="p-3 bg-white dark:bg-white/10 rounded-2xl border border-black/5 dark:border-white/10 shadow-sm flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-sky-500/10 text-sky-500">
              <Smartphone size={22} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-bold truncate">{phoneModel}</div>
              <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                <span className="flex items-center gap-0.5 text-emerald-500 font-semibold">
                  <BatteryCharging size={12} /> {phoneBattery}%
                </span>
                <span>•</span>
                <span className="flex items-center gap-0.5 text-sky-500">
                  <Wifi size={10} /> 5G
                </span>
              </div>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="space-y-1">
            <button
              onClick={() => setActiveTab('messages')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'messages'
                  ? 'bg-white dark:bg-white/15 text-sky-600 dark:text-sky-400 shadow-sm'
                  : 'hover:bg-white/40 dark:hover:bg-white/5 text-slate-600 dark:text-slate-300'
              }`}
            >
              <MessageSquare size={16} /> Messages
            </button>

            <button
              onClick={() => setActiveTab('photos')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'photos'
                  ? 'bg-white dark:bg-white/15 text-sky-600 dark:text-sky-400 shadow-sm'
                  : 'hover:bg-white/40 dark:hover:bg-white/5 text-slate-600 dark:text-slate-300'
              }`}
            >
              <ImageIcon size={16} /> Photos
            </button>

            <button
              onClick={() => setActiveTab('calls')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'calls'
                  ? 'bg-white dark:bg-white/15 text-sky-600 dark:text-sky-400 shadow-sm'
                  : 'hover:bg-white/40 dark:hover:bg-white/5 text-slate-600 dark:text-slate-300'
              }`}
            >
              <PhoneCall size={16} /> Calls
            </button>

            <button
              onClick={() => setActiveTab('notifications')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'notifications'
                  ? 'bg-white dark:bg-white/15 text-sky-600 dark:text-sky-400 shadow-sm'
                  : 'hover:bg-white/40 dark:hover:bg-white/5 text-slate-600 dark:text-slate-300'
              }`}
            >
              <Bell size={16} /> Notifications
            </button>
          </div>
        </div>

        <div className="p-2 text-[10px] text-slate-400 text-center">
          Connected via Bluetooth & Wi-Fi Sync
        </div>
      </div>

      {/* Main Feature View */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Messages Tab */}
        {activeTab === 'messages' && (
          <div className="flex-1 flex flex-col h-full">
            {/* Contact Header */}
            <div className="p-3 border-b border-black/5 dark:border-white/5 bg-white/40 dark:bg-white/5 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-indigo-500 text-white font-bold text-xs flex items-center justify-center">
                AM
              </div>
              <div>
                <div className="text-xs font-bold">{selectedContact}</div>
                <div className="text-[10px] text-emerald-500 font-semibold">Online • SMS synced</div>
              </div>
            </div>

            {/* Chat message bubbles */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex flex-col ${m.isMe ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-xs md:max-w-md px-3.5 py-2 rounded-2xl text-xs shadow-sm ${
                      m.isMe
                        ? 'bg-sky-500 text-white rounded-br-xs'
                        : 'bg-white dark:bg-zinc-800 text-slate-800 dark:text-slate-100 rounded-bl-xs border border-black/5 dark:border-white/10'
                    }`}
                  >
                    {m.text}
                  </div>
                  <span className="text-[9px] text-slate-400 mt-1 px-1">{m.time}</span>
                </div>
              ))}
            </div>

            {/* Message input field */}
            <form
              onSubmit={handleSendMessage}
              className="p-3 border-t border-black/5 dark:border-white/5 bg-white/40 dark:bg-white/5 flex gap-2"
            >
              <input
                type="text"
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                placeholder="Type a message to send via phone..."
                className="flex-1 px-3 py-2 rounded-xl bg-white dark:bg-zinc-800 border border-black/5 dark:border-white/10 text-xs outline-none focus:ring-2 focus:ring-sky-500/50"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow transition-all active:scale-95"
              >
                <Send size={14} /> Send
              </button>
            </form>
          </div>
        )}

        {/* Photos Tab */}
        {activeTab === 'photos' && (
          <div className="p-6 flex-1 overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-sm font-bold">Recent Phone Camera Photos</h3>
              <span className="text-xs text-sky-500 font-semibold cursor-pointer">Sync now</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { id: 1, label: 'Camera_20260826_01.jpg', bg: 'from-blue-600 to-indigo-900', icon: 'Mountain' },
                { id: 2, label: 'Camera_20260826_02.jpg', bg: 'from-amber-500 to-rose-700', icon: 'Sun' },
                { id: 3, label: 'Camera_20260826_03.jpg', bg: 'from-emerald-600 to-teal-900', icon: 'Trees' },
                { id: 4, label: 'Camera_20260826_04.jpg', bg: 'from-purple-600 to-pink-800', icon: 'Sparkles' },
                { id: 5, label: 'Camera_20260826_05.jpg', bg: 'from-cyan-600 to-blue-800', icon: 'CloudRain' },
                { id: 6, label: 'Camera_20260826_06.jpg', bg: 'from-fuchsia-600 to-indigo-900', icon: 'Moon' },
                { id: 7, label: 'Camera_20260826_07.jpg', bg: 'from-orange-500 to-red-800', icon: 'Flame' },
                { id: 8, label: 'Camera_20260826_08.jpg', bg: 'from-slate-700 to-zinc-900', icon: 'Camera' },
              ].map((item) => (
                <div
                  key={item.id}
                  className={`aspect-square rounded-2xl bg-gradient-to-br ${item.bg} border border-black/5 dark:border-white/10 overflow-hidden relative group cursor-pointer hover:shadow-lg transition-all flex flex-col items-center justify-center p-3 text-white`}
                >
                  <ImageIcon size={32} className="opacity-80 group-hover:scale-110 transition-transform" />
                  <span className="text-[10px] opacity-75 mt-2 font-mono truncate max-w-full text-center">{item.label}</span>
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-xs font-bold rounded-2xl">
                    Save to PC
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Calls Tab */}
        {activeTab === 'calls' && (
          <div className="p-6 flex-1 flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center mb-3">
              <PhoneCall size={32} />
            </div>
            <h3 className="text-base font-bold">Make and receive phone calls</h3>
            <p className="text-xs text-slate-500 max-w-sm mt-1 mb-4">
              Use your PC microphone and speakers to answer phone calls seamlessly.
            </p>
            <button className="px-5 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-semibold shadow transition-all">
              Dial a number
            </button>
          </div>
        )}

        {/* Notifications Tab */}
        {activeTab === 'notifications' && (
          <div className="p-6 flex-1 overflow-y-auto space-y-3">
            <h3 className="text-sm font-bold mb-3">Phone Notifications</h3>
            <div className="p-3 bg-white dark:bg-white/5 rounded-xl border border-black/5 dark:border-white/10 flex items-start gap-3">
              <div className="p-2 bg-purple-500/10 text-purple-500 rounded-lg">
                <Bell size={16} />
              </div>
              <div className="flex-1">
                <div className="text-xs font-bold">WhatsApp • New message from Emily</div>
                <div className="text-[11px] text-slate-400 mt-0.5">Let me know when the design is ready!</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
