import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useOS } from '../../context/OSContext';
import { Terminal, Plus, X, ChevronDown } from 'lucide-react';
import {
  executeSingleCommand,
  executeBatchScript,
  formatPrompt,
  resolvePath,
  CmdContext,
  TerminalOutputLine,
  WINDOWS_COLOR_MAP,
} from '../../utils/cmdBatchEngine';
import { executePowerShellCommand } from '../../utils/powerShellEngine';
import { WINDOWS_SYSTEM_ITEMS } from '../../utils/systemFileSystemData';
import {
  executeDiskPartCommand,
  DISKPART_BANNER,
} from '../../utils/diskpartEngine';

export type ShellMode = 'cmd' | 'powershell' | 'diskpart';

export interface TerminalTab {
  id: string;
  mode: ShellMode;
  shellStack: ShellMode[];
  title: string;
  currentDir: string;
  promptTemplate: string;
  lines: TerminalOutputLine[];
  history: string[];
  historyIndex: number;
  inputVal: string;
  dirStack: string[];
  psVars: Record<string, any>;
  psHistory: string[];
  terminalBg?: string;
  terminalFg?: string;
}

interface TerminalAppProps {
  windowId?: string;
  initialMode?: ShellMode;
}

export const TerminalApp: React.FC<TerminalAppProps> = ({ windowId, initialMode = 'cmd' }) => {
  const {
    fileSystem,
    getFilesByDirectory,
    addFile,
    deleteFile,
    takeOwnership,
    grantPermission,
    openApp,
    closeWindow,
    windows,
    addNotification,
    restartSystem,
    shutdownSystem,
    restartToWinRE,
    setIsLockScreen,
    enterSleepMode,
    createHtmlApp,
    restoreFromRestorePoint,
    repairStartup,
    clearSystemFailure,
    renameFile,
    updateFileContent,
  } = useOS();

  const [envVars, setEnvVars] = useState<Record<string, string>>({
    OS: 'Windows_NT',
    PROCESSOR_ARCHITECTURE: 'AMD64',
    NUMBER_OF_PROCESSORS: '8',
    COMPUTERNAME: 'DESKTOP-WIN11-OS',
    USERNAME: 'User',
    USERPROFILE: 'C:\\Users\\User',
    WINDIR: 'C:\\Windows',
    SYSTEMROOT: 'C:\\Windows',
    HOMEDRIVE: 'C:',
    HOMEPATH: '\\Users\\User',
    PATH: 'C:\\Windows\\system32;C:\\Windows;C:\\Windows\\System32\\Wbem;C:\\Apps',
    TEMP: 'C:\\Users\\User\\AppData\\Local\\Temp',
    TMP: 'C:\\Users\\User\\AppData\\Local\\Temp',
  });

  const createInitialTab = (mode: ShellMode): TerminalTab => {
    const isCmd = mode === 'cmd';
    return {
      id: 'tab-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
      mode,
      shellStack: [mode],
      title: isCmd ? 'Command Prompt' : 'Windows PowerShell',
      currentDir: 'C:\\Users\\User',
      promptTemplate: isCmd ? '$p$g' : 'PS $p$g',
      history: [],
      historyIndex: -1,
      inputVal: '',
      dirStack: [],
      psVars: {},
      psHistory: [],
      terminalBg: '#0c0c0c',
      terminalFg: '#cccccc',
      lines: [
        {
          id: 'welcome-' + Date.now(),
          type: 'system',
          text: isCmd
            ? 'Microsoft Windows [Version 10.0.22631.3296]\n(c) Microsoft Corporation. All rights reserved.\n'
            : 'Windows PowerShell\nCopyright (C) Microsoft Corporation. All rights reserved.\n\nInstall the latest PowerShell for new features and improvements! https://aka.ms/PSWindows\n',
        },
      ],
    };
  };

  const resolvedInitialMode: ShellMode = initialMode === 'powershell' ? 'powershell' : 'cmd';
  const [tabs, setTabs] = useState<TerminalTab[]>([createInitialTab(resolvedInitialMode)]);
  const [activeTabId, setActiveTabId] = useState<string>(tabs[0].id);
  const [showNewTabMenu, setShowNewTabMenu] = useState(false);

  const activeTab = tabs.find((t) => t.id === activeTabId) || tabs[0];

  const [executingTabIds, setExecutingTabIds] = useState<Record<string, boolean>>({});
  const activeTimeoutsRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  useEffect(() => {
    return () => {
      activeTimeoutsRef.current.forEach((t) => clearTimeout(t));
    };
  }, []);

  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'auto' });
  }, [activeTab?.lines]);

  useEffect(() => {
    inputRef.current?.focus();
  }, [activeTabId]);

  const updateActiveTab = useCallback(
    (updater: Partial<TerminalTab> | ((prevTab: TerminalTab) => TerminalTab)) => {
      setTabs((prevTabs) =>
        prevTabs.map((tab) => {
          if (tab.id !== activeTabId) return tab;
          if (typeof updater === 'function') {
            return updater(tab);
          }
          return { ...tab, ...updater };
        })
      );
    },
    [activeTabId]
  );

  const getCmdContext = useCallback((): CmdContext => {
    return {
      currentDir: activeTab.currentDir,
      setCurrentDir: (dir: string) => updateActiveTab({ currentDir: dir }),
      envVars,
      setEnvVars,
      fileSystem,
      getFilesByDirectory,
      addFile: (f) => addFile(f),
      deleteFile: (id) => {
        deleteFile(id, true);
      },
      takeOwnership,
      grantPermission,
      openApp,
      closeWindow,
      windows,
      addNotification,
      restartSystem,
      shutdownSystem,
      restartToWinRE,
      setIsLockScreen,
      enterSleepMode,
      setTitle: (t: string) => updateActiveTab({ title: t }),
      setPromptTemplate: (tmpl: string) => updateActiveTab({ promptTemplate: tmpl }),
      promptTemplate: activeTab.promptTemplate,
      dirStack: activeTab.dirStack,
      setDirStack: (action) => {
        updateActiveTab((tab) => ({
          ...tab,
          dirStack: typeof action === 'function' ? action(tab.dirStack) : action,
        }));
      },
      createHtmlApp,
      restoreFromRestorePoint,
      repairStartup,
      clearSystemFailure,
      renameFile,
      updateFileContent,
      setColor: (bg: string, fg: string) => updateActiveTab({ terminalBg: bg, terminalFg: fg }),
    };
  }, [
    activeTab,
    envVars,
    fileSystem,
    getFilesByDirectory,
    addFile,
    deleteFile,
    takeOwnership,
    grantPermission,
    openApp,
    closeWindow,
    windows,
    addNotification,
    restartSystem,
    shutdownSystem,
    restartToWinRE,
    setIsLockScreen,
    enterSleepMode,
    createHtmlApp,
    restoreFromRestorePoint,
    repairStartup,
    clearSystemFailure,
    renameFile,
    updateFileContent,
    updateActiveTab,
  ]);

  const appendLineToTab = useCallback((tabId: string, line: TerminalOutputLine) => {
    setTabs((prevTabs) =>
      prevTabs.map((tab) => {
        if (tab.id !== tabId) return tab;
        return {
          ...tab,
          lines: [...tab.lines, line],
        };
      })
    );
  }, []);

  const runSfcScanRealtime = useCallback(
    (tabId: string, verifyOnly = false) => {
      setExecutingTabIds((prev) => ({ ...prev, [tabId]: true }));

      const steps: { delay: number; text: string }[] = [
        { delay: 150, text: 'Bắt đầu quá trình quét hệ thống...\n' },
        { delay: 650, text: 'Đang xác minh giai đoạn 1/3...  10%' },
        { delay: 1200, text: 'Đang xác minh giai đoạn 1/3...  30%' },
        { delay: 1750, text: 'Đang xác minh giai đoạn 1/3...  50%' },
        { delay: 2300, text: 'Đang xác minh giai đoạn 1/3...  100%\n' },
        { delay: 2900, text: 'Đang xác minh giai đoạn 2/3...  100%\n' },
        { delay: 3500, text: 'Đang xác minh giai đoạn 3/3...  100%\n\n' },
      ];

      steps.forEach(({ delay, text }, idx) => {
        const t = setTimeout(() => {
          appendLineToTab(tabId, {
            id: `sfc-step-${idx}-${Date.now()}`,
            type: 'output',
            text,
          });
        }, delay);
        activeTimeoutsRef.current.push(t);
      });

      // Final result verification step
      const finalTimeout = setTimeout(() => {
        // Check actual virtual file system files under C:\Windows
        const system32Items = WINDOWS_SYSTEM_ITEMS.filter((item) =>
          item.path.toLowerCase().startsWith('c:\\windows')
        );

        const missingItems = system32Items.filter(
          (sysItem) => !fileSystem.some((f) => f.path.toLowerCase() === sysItem.path.toLowerCase())
        );

        const foundIssues = missingItems.length > 0;

        if (foundIssues && !verifyOnly) {
          // Restore all missing system files
          missingItems.forEach((item) => {
            addFile({
              name: item.name,
              path: item.path,
              isDirectory: item.isDirectory,
              content: item.content || '',
              size: item.size || (item.content ? item.content.length : 1024),
              isSystem: true,
              protectionLevel: item.protectionLevel || 'KHÔNG XOÁ',
            });
          });

          // Clear any system failure state
          clearSystemFailure?.();

          // Write log entry to C:\Windows\Logs\CBS\CBS.log
          const logContent = `[CBS] ${new Date().toISOString()} Starting SFC System Repair...\n[CBS] Verified ${system32Items.length} protected system files.\n[CBS] Repaired ${missingItems.length} corrupted/missing components.\n[CBS] Repair completed successfully.`;
          addFile({
            name: 'CBS.log',
            path: 'C:\\Windows\\Logs\\CBS\\CBS.log',
            isDirectory: false,
            content: logContent,
            size: logContent.length,
            isSystem: true,
          });
        }

        let finalText = '';
        if (foundIssues) {
          finalText =
            'Kiểm tra 100% hoàn tất.\n\nBảo vệ tài nguyên Windows đã tìm thấy các tệp bị hỏng và đã sửa chữa chúng thành công.\nChi tiết được ghi lại trong CBS.Log (windir\\Logs\\CBS\\CBS.log).';
        } else {
          finalText =
            'Kiểm tra 100% hoàn tất.\n\nBảo vệ tài nguyên Windows không tìm thấy vi phạm tính toàn vẹn.\nKhông thực hiện bất kỳ thao tác nào.';
        }

        appendLineToTab(tabId, {
          id: `sfc-result-${Date.now()}`,
          type: 'output',
          text: finalText,
        });

        setExecutingTabIds((prev) => ({ ...prev, [tabId]: false }));

        setTimeout(() => {
          inputRef.current?.focus();
        }, 50);
      }, 4100);

      activeTimeoutsRef.current.push(finalTimeout);
    },
    [addFile, clearSystemFailure, fileSystem, appendLineToTab]
  );

  const handleCommand = (cmdStr: string) => {
    const trimmed = cmdStr.trim();
    const currentMode = activeTab.shellStack[activeTab.shellStack.length - 1];
    const promptStr = formatPrompt(activeTab.promptTemplate, activeTab.currentDir, envVars);

    if (!trimmed) {
      updateActiveTab((tab) => ({
        ...tab,
        lines: [
          ...tab.lines,
          { id: 'in-' + Date.now() + '-' + Math.random(), type: 'input', text: promptStr },
        ],
        inputVal: '',
      }));
      return;
    }

    const firstToken = trimmed.split(/\s+/)[0].toLowerCase();

    // 1. Check for 'exit'
    if (firstToken === 'exit' || (currentMode === 'diskpart' && firstToken === 'quit')) {
      if (activeTab.shellStack.length > 1) {
        // Pop the nested shell mode and return to previous shell
        const newStack = activeTab.shellStack.slice(0, -1);
        const previousMode = newStack[newStack.length - 1];
        const isCmd = previousMode === 'cmd';
        const isPs = previousMode === 'powershell';
        updateActiveTab((tab) => ({
          ...tab,
          shellStack: newStack,
          mode: previousMode,
          title: isCmd ? 'Command Prompt' : isPs ? 'Windows PowerShell' : 'DiskPart',
          promptTemplate: isCmd ? '$p$g' : isPs ? 'PS $p$g' : 'DISKPART> ',
          lines: [
            ...tab.lines,
            { id: 'in-' + Date.now(), type: 'input', text: `${promptStr}${trimmed}` },
            ...(currentMode === 'diskpart'
              ? [{ id: 'dp-exit-' + Date.now(), type: 'output' as const, text: 'Leaving DiskPart...\n' }]
              : []),
          ],
          inputVal: '',
        }));
        return;
      }

      // Root shell exit: close tab or window
      if (tabs.length > 1) {
        const nextTabs = tabs.filter((t) => t.id !== activeTabId);
        setTabs(nextTabs);
        setActiveTabId(nextTabs[0].id);
        return;
      }

      if (windowId) {
        closeWindow(windowId);
      } else {
        const currentWin = windows.find((w) => w.appId === 'terminal' || w.appId === 'cmd' || w.appId === 'powershell');
        if (currentWin) {
          closeWindow(currentWin.id);
        }
      }
      return;
    }

    const inputLine: TerminalOutputLine = {
      id: 'in-' + Date.now() + '-' + Math.random(),
      type: 'input',
      text: `${promptStr}${trimmed}`,
    };

    // 1b. If currently in DISKPART shell mode
    if (currentMode === 'diskpart') {
      if (firstToken === 'cls' || firstToken === 'clear') {
        updateActiveTab((tab) => ({
          ...tab,
          lines: [],
          inputVal: '',
          history: [...tab.history, trimmed],
          historyIndex: -1,
        }));
        return;
      }

      const dpResult = executeDiskPartCommand(trimmed);
      if (dpResult.isExit) {
        const newStack = activeTab.shellStack.slice(0, -1);
        const previousMode = newStack[newStack.length - 1] || 'cmd';
        const isCmd = previousMode === 'cmd';
        const isPs = previousMode === 'powershell';
        updateActiveTab((tab) => ({
          ...tab,
          shellStack: newStack,
          mode: previousMode,
          title: isCmd ? 'Command Prompt' : isPs ? 'Windows PowerShell' : 'DiskPart',
          promptTemplate: isCmd ? '$p$g' : isPs ? 'PS $p$g' : 'DISKPART> ',
          lines: [
            ...tab.lines,
            inputLine,
            {
              id: 'dp-exit-' + Date.now(),
              type: 'output',
              text: (dpResult.output || 'Leaving DiskPart...') + '\n',
            },
          ],
          history: [...tab.history, trimmed],
          historyIndex: -1,
          inputVal: '',
        }));
        return;
      }

      updateActiveTab((tab) => ({
        ...tab,
        lines: [
          ...tab.lines,
          inputLine,
          ...(dpResult.output
            ? [{ id: 'dp-out-' + Date.now(), type: 'output' as const, text: dpResult.output }]
            : []),
        ],
        history: [...tab.history, trimmed],
        historyIndex: -1,
        inputVal: '',
      }));
      return;
    }

    // 1c. Check for entering diskpart: `diskpart` or `diskpart.exe`
    if (firstToken === 'diskpart' || firstToken === 'diskpart.exe') {
      const parts = trimmed.split(/\s+/);
      const isHelp =
        parts.includes('/?') ||
        parts.includes('-?') ||
        parts.includes('/help') ||
        parts.includes('-help');

      if (isHelp) {
        updateActiveTab((tab) => ({
          ...tab,
          lines: [
            ...tab.lines,
            inputLine,
            {
              id: 'dp-help-' + Date.now(),
              type: 'output',
              text: `Microsoft DiskPart version 10.0.22621.1\n\nDISKPART [/S <script>] [/?]\n\n<script>    Specifies the script file that contains the commands to run.\n/?          Displays this help screen.`,
            },
          ],
          history: [...tab.history, trimmed],
          historyIndex: -1,
          inputVal: '',
        }));
        return;
      }

      updateActiveTab((tab) => ({
        ...tab,
        shellStack: [...tab.shellStack, 'diskpart'],
        mode: 'diskpart',
        title: 'DiskPart',
        promptTemplate: 'DISKPART> ',
        lines: [
          ...tab.lines,
          inputLine,
          {
            id: 'dp-banner-' + Date.now(),
            type: 'output',
            text: DISKPART_BANNER,
          },
        ],
        history: [...tab.history, trimmed],
        historyIndex: -1,
        inputVal: '',
      }));
      return;
    }

    // 2. Check for switching to PowerShell inside CMD: `powershell` or `pwsh`
    if (currentMode === 'cmd' && (firstToken === 'powershell' || firstToken === 'powershell.exe' || firstToken === 'pwsh')) {
      const hasArgs = trimmed.split(/\s+/).length > 1;
      if (!hasArgs) {
        const bannerText =
          'Windows PowerShell\nCopyright (C) Microsoft Corporation. All rights reserved.\n\nInstall the latest PowerShell for new features and improvements! https://aka.ms/PSWindows\n';
        updateActiveTab((tab) => ({
          ...tab,
          shellStack: [...tab.shellStack, 'powershell'],
          mode: 'powershell',
          title: 'Windows PowerShell',
          promptTemplate: 'PS $p$g',
          lines: [
            ...tab.lines,
            inputLine,
            { id: 'sys-' + Date.now(), type: 'system', text: bannerText },
          ],
          history: [...tab.history, trimmed],
          historyIndex: -1,
          inputVal: '',
        }));
        return;
      }
    }

    // 3. Check for switching to CMD inside PowerShell: `cmd` or `cmd.exe`
    if (currentMode === 'powershell' && (firstToken === 'cmd' || firstToken === 'cmd.exe')) {
      const bannerText =
        'Microsoft Windows [Version 10.0.22631.3296]\n(c) Microsoft Corporation. All rights reserved.\n';
      updateActiveTab((tab) => ({
        ...tab,
        shellStack: [...tab.shellStack, 'cmd'],
        mode: 'cmd',
        title: 'Command Prompt',
        promptTemplate: '$p$g',
        lines: [
          ...tab.lines,
          inputLine,
          { id: 'sys-' + Date.now(), type: 'system', text: bannerText },
        ],
        history: [...tab.history, trimmed],
        historyIndex: -1,
        inputVal: '',
      }));
      return;
    }

    // 4. Check for winver / winver.exe to directly popup the About Windows dialog
    if (firstToken === 'winver' || firstToken === 'winver.exe') {
      openApp('winver');
      updateActiveTab((tab) => ({
        ...tab,
        lines: [...tab.lines, inputLine],
        history: [...tab.history, trimmed],
        historyIndex: -1,
        inputVal: '',
      }));
      return;
    }

    // 5. Check for clear/cls
    if (firstToken === 'cls' || firstToken === 'clear' || (currentMode === 'powershell' && firstToken === 'clear-host')) {
      updateActiveTab((tab) => ({
        ...tab,
        lines: [],
        inputVal: '',
        history: [...tab.history, trimmed],
        historyIndex: -1,
      }));
      return;
    }

    // 6. Check for SFC command (Real-time progressive system verification & repair)
    if (firstToken === 'sfc' || firstToken === 'sfc.exe') {
      const parts = trimmed.split(/\s+/);
      const isHelp =
        parts.includes('/?') ||
        parts.includes('-?') ||
        parts.includes('/help') ||
        parts.includes('-help') ||
        (parts.length === 1 && !trimmed.toLowerCase().includes('/'));

      if (isHelp && (parts.includes('/?') || parts.includes('-?') || parts.includes('/help') || parts.includes('-help'))) {
        updateActiveTab((tab) => ({
          ...tab,
          lines: [
            ...tab.lines,
            inputLine,
            {
              id: 'sfc-help-' + Date.now(),
              type: 'output',
              text: `Microsoft (R) Windows (R) Resource Checker Version 6.0\nSFC [/SCANNOW] [/VERIFYONLY] [/SCANFILE=<file>] [/VERIFYFILE=<file>] [/OFFWINDIR=<dir> /OFFBOOTDIR=<dir>]`,
            },
          ],
          history: [...tab.history, trimmed],
          historyIndex: -1,
          inputVal: '',
        }));
        return;
      }

      // Add input line immediately to the terminal
      updateActiveTab((tab) => ({
        ...tab,
        lines: [...tab.lines, inputLine],
        history: [...tab.history, trimmed],
        historyIndex: -1,
        inputVal: '',
      }));

      // Trigger real-time asynchronous scanning and verification
      const isVerifyOnly = parts.includes('/verifyonly') || parts.includes('-verifyonly');
      runSfcScanRealtime(activeTab.id, isVerifyOnly);
      return;
    }

    const ctx = getCmdContext();
    let outputLines: TerminalOutputLine[] = [];

    if (currentMode === 'powershell') {
      // Execute as PowerShell command
      outputLines = executePowerShellCommand(
        trimmed,
        ctx,
        activeTab.psVars,
        (updater) => {
          updateActiveTab((tab) => ({
            ...tab,
            psVars: typeof updater === 'function' ? updater(tab.psVars) : updater,
          }));
        },
        activeTab.psHistory,
        (updater) => {
          updateActiveTab((tab) => ({
            ...tab,
            psHistory: typeof updater === 'function' ? updater(tab.psHistory) : updater,
          }));
        }
      );
    } else {
      // Check if user is invoking PowerShell CLI from CMD with arguments
      if (firstToken === 'powershell' || firstToken === 'powershell.exe' || firstToken === 'pwsh') {
        outputLines = executePowerShellCommand(
          trimmed,
          ctx,
          activeTab.psVars,
          (updater) => {
            updateActiveTab((tab) => ({
              ...tab,
              psVars: typeof updater === 'function' ? updater(tab.psVars) : updater,
            }));
          },
          activeTab.psHistory,
          (updater) => {
            updateActiveTab((tab) => ({
              ...tab,
              psHistory: typeof updater === 'function' ? updater(tab.psHistory) : updater,
            }));
          }
        );
      } else {
        // Execute as CMD command (or batch file)
        let possibleBatName = firstToken;
        let batArgs: string[] = [];
        if (firstToken === 'call' || firstToken === 'start') {
          const parts = trimmed.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || [];
          possibleBatName = (parts[1] || '').replace(/^["']|["']$/g, '');
          batArgs = parts.slice(2).map((a) => a.replace(/^["']|["']$/g, ''));
        } else {
          const parts = trimmed.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || [];
          batArgs = parts.slice(1).map((a) => a.replace(/^["']|["']$/g, ''));
        }

        if (possibleBatName.startsWith('.\\') || possibleBatName.startsWith('./')) {
          possibleBatName = possibleBatName.substring(2);
        }

        const resolvedBatPath = resolvePath(possibleBatName, activeTab.currentDir);
        const batFile = fileSystem.find(
          (f) =>
            !f.isDirectory &&
            (f.path.toLowerCase() === resolvedBatPath.toLowerCase() ||
              f.path.toLowerCase() === `${resolvedBatPath}.bat`.toLowerCase() ||
              f.path.toLowerCase() === `${resolvedBatPath}.cmd`.toLowerCase() ||
              f.name.toLowerCase() === possibleBatName.toLowerCase() ||
              f.name.toLowerCase() === `${possibleBatName}.bat`.toLowerCase() ||
              f.name.toLowerCase() === `${possibleBatName}.cmd`.toLowerCase())
        );

        if (
          batFile &&
          batFile.content &&
          (batFile.name.toLowerCase().endsWith('.bat') ||
            batFile.name.toLowerCase().endsWith('.cmd') ||
            possibleBatName.toLowerCase().endsWith('.bat') ||
            possibleBatName.toLowerCase().endsWith('.cmd') ||
            firstToken === 'call')
        ) {
          outputLines = executeBatchScript(batFile.content, batArgs, ctx);
        } else {
          outputLines = executeSingleCommand(trimmed, ctx);
        }
      }
    }

    updateActiveTab((tab) => ({
      ...tab,
      lines: [...tab.lines, inputLine, ...outputLines],
      history: [...tab.history, trimmed],
      historyIndex: -1,
      inputVal: '',
    }));
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleCommand(activeTab.inputVal);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (activeTab.history.length > 0) {
        const nextIdx =
          activeTab.historyIndex === -1
            ? activeTab.history.length - 1
            : Math.max(0, activeTab.historyIndex - 1);
        updateActiveTab({
          historyIndex: nextIdx,
          inputVal: activeTab.history[nextIdx] || '',
        });
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (activeTab.historyIndex !== -1) {
        const nextIdx = activeTab.historyIndex + 1;
        if (nextIdx >= activeTab.history.length) {
          updateActiveTab({ historyIndex: -1, inputVal: '' });
        } else {
          updateActiveTab({
            historyIndex: nextIdx,
            inputVal: activeTab.history[nextIdx] || '',
          });
        }
      }
    } else if (e.key === 'Tab') {
      e.preventDefault();
      // Tab completion for files in current directory
      if (activeTab.inputVal.trim()) {
        const parts = activeTab.inputVal.split(/\s+/);
        const lastPart = parts[parts.length - 1];
        const files = getFilesByDirectory(activeTab.currentDir);
        const match = files.find((f) => f.name.toLowerCase().startsWith(lastPart.toLowerCase()));
        if (match) {
          parts[parts.length - 1] = match.name.includes(' ') ? `"${match.name}"` : match.name;
          updateActiveTab({ inputVal: parts.join(' ') });
        }
      }
    }
  };

  const handleAddNewTab = (mode: ShellMode) => {
    const newTab = createInitialTab(mode);
    setTabs((prev) => [...prev, newTab]);
    setActiveTabId(newTab.id);
    setShowNewTabMenu(false);
  };

  const handleCloseTab = (e: React.MouseEvent, tabId: string) => {
    e.stopPropagation();
    if (tabs.length === 1) {
      if (windowId) {
        closeWindow(windowId);
      } else {
        const currentWin = windows.find((w) => w.appId === 'terminal' || w.appId === 'cmd' || w.appId === 'powershell');
        if (currentWin) closeWindow(currentWin.id);
      }
      return;
    }

    const nextTabs = tabs.filter((t) => t.id !== tabId);
    setTabs(nextTabs);
    if (activeTabId === tabId) {
      setActiveTabId(nextTabs[0].id);
    }
  };

  return (
    <div
      style={{
        backgroundColor: activeTab?.terminalBg || '#0c0c0c',
        color: activeTab?.terminalFg || '#cccccc',
      }}
      className="flex flex-col w-full h-full font-mono text-xs select-text overflow-hidden transition-colors duration-150 relative"
      onClick={() => inputRef.current?.focus()}
    >
      {/* Authentic Windows 11 Terminal Tab Bar */}
      <div className="flex items-center h-9 bg-[#181818] border-b border-white/10 select-none px-2 gap-1 relative z-20">
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar max-w-[calc(100%-80px)]">
          {tabs.map((tab) => {
            const isActive = tab.id === activeTabId;
            const currentMode = tab.shellStack[tab.shellStack.length - 1];
            return (
              <div
                key={tab.id}
                onClick={() => setActiveTabId(tab.id)}
                className={`flex items-center gap-2 h-7 px-3 rounded-t-md text-xs font-normal transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#0c0c0c] text-white border-t-2 ' +
                      (currentMode === 'powershell'
                        ? 'border-sky-500'
                        : currentMode === 'diskpart'
                        ? 'border-emerald-500'
                        : 'border-zinc-400') +
                      ' shadow-sm'
                    : 'bg-transparent text-slate-400 hover:bg-white/5 hover:text-slate-200'
                }`}
              >
                <Terminal
                  size={13}
                  className={`shrink-0 ${
                    currentMode === 'powershell'
                      ? 'text-sky-400'
                      : currentMode === 'diskpart'
                      ? 'text-emerald-400'
                      : 'text-zinc-300'
                  }`}
                />
                <span className="truncate max-w-[140px] text-[11px]">{tab.title}</span>
                <button
                  onClick={(e) => handleCloseTab(e, tab.id)}
                  className="p-0.5 ml-1 rounded hover:bg-white/15 text-slate-400 hover:text-white transition-colors"
                >
                  <X size={11} />
                </button>
              </div>
            );
          })}
        </div>

        {/* Plus / New Tab Button */}
        <div className="relative flex items-center">
          <button
            title="Mở tab mới (Command Prompt hoặc PowerShell)"
            onClick={() => setShowNewTabMenu((v) => !v)}
            className="flex items-center gap-0.5 p-1 rounded hover:bg-white/10 text-slate-400 hover:text-white transition-colors ml-1"
          >
            <Plus size={13} />
            <ChevronDown size={10} />
          </button>

          {/* New Tab Dropdown */}
          {showNewTabMenu && (
            <div
              onClick={(e) => e.stopPropagation()}
              className="absolute top-8 left-0 w-48 bg-[#202020] border border-white/15 rounded-lg shadow-2xl p-1 z-50 text-xs text-slate-200 animate-win11-fade"
            >
              <button
                onClick={() => handleAddNewTab('cmd')}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded hover:bg-white/10 text-left"
              >
                <div className="w-2 h-2 rounded-full bg-zinc-400 shrink-0" />
                <span>Command Prompt (CMD)</span>
              </button>
              <button
                onClick={() => handleAddNewTab('powershell')}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded hover:bg-white/10 text-left"
              >
                <div className="w-2 h-2 rounded-full bg-sky-500 shrink-0" />
                <span>Windows PowerShell</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Terminal Output and Prompt */}
      <div
        className="flex-1 p-3 overflow-y-auto space-y-1 leading-relaxed selection:bg-sky-500/40 cursor-text"
        onClick={() => inputRef.current?.focus()}
      >
        {activeTab?.lines.map((l) => {
          const isCustomColor =
            Boolean(activeTab?.terminalFg && activeTab.terminalFg.toLowerCase() !== '#cccccc');

          let extraClass = '';
          if (!isCustomColor) {
            if (l.type === 'error') extraClass = 'text-red-400 font-semibold';
            else if (l.type === 'success') extraClass = 'text-emerald-400 font-medium';
            else if (l.type === 'info') extraClass = 'text-sky-400 font-medium';
            else if (l.type === 'ascii') extraClass = 'text-sky-300 font-bold';
          } else {
            if (l.type === 'error') extraClass = 'font-bold';
            else if (l.type === 'ascii') extraClass = 'font-bold';
          }

          return (
            <div
              key={l.id}
              style={{ color: activeTab?.terminalFg || '#cccccc' }}
              className={`whitespace-pre-wrap font-mono ${extraClass}`}
            >
              {l.text}
            </div>
          );
        })}

        {/* Live Prompt Input Line */}
        {!executingTabIds[activeTab?.id] && (
          <div className="flex items-center gap-2 pt-0.5">
            <span
              style={{ color: activeTab?.terminalFg || '#cccccc' }}
              className="font-bold shrink-0"
            >
              {formatPrompt(activeTab?.promptTemplate || '$p$g', activeTab?.currentDir || 'C:\\Users\\User', envVars)}
            </span>
            <input
              ref={inputRef}
              type="text"
              style={{ color: activeTab?.terminalFg || '#cccccc' }}
              value={activeTab?.inputVal || ''}
              onChange={(e) => updateActiveTab({ inputVal: e.target.value })}
              onKeyDown={handleKeyDown}
              className="flex-1 bg-transparent outline-none border-none font-mono text-xs p-0 m-0 text-inherit caret-current"
              autoFocus
              spellCheck={false}
            />
          </div>
        )}
        <div ref={bottomRef} />
      </div>
    </div>
  );
};
