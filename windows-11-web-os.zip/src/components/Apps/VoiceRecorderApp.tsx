import React, { useState, useEffect, useRef } from 'react';
import { Mic, Square, Play, Pause, Trash2, Bookmark, Volume2, Music, Save, Clock } from 'lucide-react';
import { useOS } from '../../context/OSContext';

interface RecordingItem {
  id: string;
  name: string;
  duration: number; // in seconds
  timestamp: string;
  markers: number[];
}

export const VoiceRecorderApp: React.FC = () => {
  const { addFile, addNotification } = useOS();
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [markers, setMarkers] = useState<number[]>([]);
  const [recordings, setRecordings] = useState<RecordingItem[]>([
    {
      id: 'rec-1',
      name: 'Recording 1.m4a',
      duration: 42,
      timestamp: 'Yesterday, 3:15 PM',
      markers: [12, 28],
    },
    {
      id: 'rec-2',
      name: 'Meeting Note.m4a',
      duration: 185,
      timestamp: 'Aug 24, 10:00 AM',
      markers: [45],
    },
  ]);
  const [selectedRecId, setSelectedRecId] = useState<string>('rec-1');
  const [isPlaying, setIsPlaying] = useState(false);
  const [playProgress, setPlayProgress] = useState(0);

  // Audio wave bars animation simulator
  const [waveHeights, setWaveHeights] = useState<number[]>([15, 25, 40, 60, 30, 20, 45, 75, 50, 25, 30, 65, 40, 20]);

  useEffect(() => {
    let timer: any;
    if (isRecording && !isPaused) {
      timer = setInterval(() => {
        setRecordSeconds((prev) => prev + 1);
        // Randomize waveform bars while recording
        setWaveHeights(Array.from({ length: 18 }, () => Math.floor(Math.random() * 65) + 15));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isRecording, isPaused]);

  useEffect(() => {
    let playTimer: any;
    if (isPlaying) {
      playTimer = setInterval(() => {
        setPlayProgress((prev) => {
          if (prev >= 100) {
            setIsPlaying(false);
            return 0;
          }
          return prev + 2;
        });
      }, 500);
    }
    return () => clearInterval(playTimer);
  }, [isPlaying]);

  const handleStartRecording = () => {
    setIsRecording(true);
    setIsPaused(false);
    setRecordSeconds(0);
    setMarkers([]);
  };

  const handleStopRecording = () => {
    setIsRecording(false);
    const newName = `Voice Recording ${recordings.length + 1}.m4a`;
    const newRec: RecordingItem = {
      id: `rec-${Date.now()}`,
      name: newName,
      duration: recordSeconds || 1,
      timestamp: 'Just now',
      markers,
    };
    setRecordings([newRec, ...recordings]);
    setSelectedRecId(newRec.id);

    // Save file into Music folder
    addFile({
      name: newName,
      path: `C:\\Users\\User\\Music\\${newName}`,
      isDirectory: false,
      size: (recordSeconds || 1) * 128000,
      icon: 'Music',
      content: `[AUDIO_RECORDING_DATA: ${newName} | Duration: ${formatTime(recordSeconds)}]`,
    });

    addNotification('Recording Saved', `Saved ${newName} to C:\\Users\\User\\Music`, 'mediaplayer');
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const selectedRec = recordings.find((r) => r.id === selectedRecId);

  return (
    <div className="flex h-full bg-[#f8f9fa] dark:bg-[#1a1a1a] text-slate-800 dark:text-slate-100 select-none overflow-hidden font-sans">
      {/* Left List of Recordings */}
      <div className="w-64 bg-slate-200/40 dark:bg-black/20 border-r border-black/5 dark:border-white/5 flex flex-col">
        <div className="p-3 border-b border-black/5 dark:border-white/5 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-600 dark:text-slate-300">All Recordings</span>
          <span className="text-[10px] text-slate-400 font-mono">{recordings.length} files</span>
        </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {recordings.map((rec) => (
            <div
              key={rec.id}
              onClick={() => {
                setSelectedRecId(rec.id);
                setIsPlaying(false);
                setPlayProgress(0);
              }}
              className={`p-2.5 rounded-xl cursor-pointer transition-all flex flex-col gap-0.5 ${
                selectedRecId === rec.id
                  ? 'bg-white dark:bg-white/15 shadow-sm ring-1 ring-sky-500/30'
                  : 'hover:bg-white/40 dark:hover:bg-white/5'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold truncate">{rec.name}</span>
                <span className="text-[10px] text-slate-400 font-mono">{formatTime(rec.duration)}</span>
              </div>
              <div className="text-[10px] text-slate-400">{rec.timestamp}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Studio Area */}
      <div className="flex-1 flex flex-col items-center justify-between p-6">
        {/* Top Header */}
        <div className="w-full flex justify-between items-center text-xs text-slate-400">
          <span>{isRecording ? 'RECORDING IN PROGRESS' : 'READY'}</span>
          <span>48.0 kHz • 24-bit PCM • Stereo</span>
        </div>

        {/* Center Live Waveform & Big Counter */}
        <div className="flex flex-col items-center gap-6 my-auto">
          <div className="text-5xl font-extralight tracking-tight font-mono">
            {isRecording ? formatTime(recordSeconds) : selectedRec ? formatTime(selectedRec.duration) : '00:00'}
          </div>

          {/* Dynamic Audio Visualizer Bars */}
          <div className="flex items-center gap-1.5 h-20 px-6 py-2 bg-slate-200/50 dark:bg-black/30 rounded-2xl border border-black/5 dark:border-white/5">
            {waveHeights.map((h, i) => (
              <div
                key={i}
                className={`w-1.5 rounded-full transition-all duration-150 ${
                  isRecording ? 'bg-sky-500 shadow-sm shadow-sky-500/50' : 'bg-slate-400/60 dark:bg-zinc-600'
                }`}
                style={{ height: `${isRecording ? h : 16 + (i % 4) * 8}px` }}
              />
            ))}
          </div>

          {/* Marker indicators */}
          {markers.length > 0 && (
            <div className="flex gap-2 text-[10px] text-sky-500">
              {markers.map((m, idx) => (
                <span key={idx} className="bg-sky-500/10 px-2 py-0.5 rounded-full font-mono">
                  Marker {idx + 1}: {formatTime(m)}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Bottom Control Bar */}
        <div className="flex items-center gap-6 pb-4">
          {isRecording ? (
            <>
              {/* Add Marker Button */}
              <button
                onClick={() => setMarkers([...markers, recordSeconds])}
                className="p-3 rounded-full hover:bg-slate-200 dark:hover:bg-zinc-800 text-slate-600 dark:text-slate-300 transition-all"
                title="Add Marker"
              >
                <Bookmark size={18} />
              </button>

              {/* Stop Recording Button */}
              <button
                onClick={handleStopRecording}
                className="w-14 h-14 rounded-full bg-red-500 hover:bg-red-600 text-white flex items-center justify-center shadow-lg shadow-red-500/30 active:scale-95 transition-all"
                title="Stop Recording"
              >
                <Square size={22} fill="currentColor" />
              </button>

              {/* Pause Recording Button */}
              <button
                onClick={() => setIsPaused(!isPaused)}
                className="p-3 rounded-full hover:bg-slate-200 dark:hover:bg-zinc-800 text-slate-600 dark:text-slate-300 transition-all"
                title={isPaused ? 'Resume' : 'Pause'}
              >
                {isPaused ? <Play size={18} /> : <Pause size={18} />}
              </button>
            </>
          ) : (
            <>
              {/* Play / Pause Selected Recording */}
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                disabled={!selectedRec}
                className="p-3 rounded-full hover:bg-slate-200 dark:hover:bg-zinc-800 text-slate-600 dark:text-slate-300 disabled:opacity-30 transition-all"
                title="Play recording"
              >
                {isPlaying ? <Pause size={20} /> : <Play size={20} />}
              </button>

              {/* Start Big Red Mic Recording Button */}
              <button
                onClick={handleStartRecording}
                className="w-16 h-16 rounded-full bg-sky-500 hover:bg-sky-600 text-white flex items-center justify-center shadow-xl shadow-sky-500/30 active:scale-95 transition-all animate-pulse"
                title="Start Recording"
              >
                <Mic size={28} />
              </button>

              {/* Delete Recording */}
              <button
                onClick={() => {
                  if (selectedRecId) {
                    setRecordings(recordings.filter((r) => r.id !== selectedRecId));
                    setSelectedRecId(recordings[0]?.id || '');
                  }
                }}
                disabled={!selectedRec}
                className="p-3 rounded-full hover:bg-slate-200 dark:hover:bg-zinc-800 text-red-500 disabled:opacity-30 transition-all"
                title="Delete recording"
              >
                <Trash2 size={20} />
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
