import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useOS } from '../../context/OSContext';
import { BUILT_IN_APPS, getLocalizedAppName } from '../../utils/appRegistry';
import { IconRenderer } from '../Common/IconRenderer';
import { useContextMenuTrigger } from '../../hooks/useContextMenuTrigger';
import { ContextMenuItem } from '../../types';
import { TouchKeyboardModal } from './TouchKeyboardModal';
import { InkWorkspaceFlyout } from './InkWorkspaceFlyout';
import { NewToolbarModal } from './NewToolbarModal';
import {
  Search,
  LayoutGrid,
  Wifi,
  Volume2,
  BatteryCharging,
  Sparkles,
  CloudSun,
  Sliders,
  Activity,
  Folder,
  Terminal,
  Settings,
  Power,
  RotateCw,
  LogOut,
  Moon,
  Monitor,
  X,
  Pin,
  PinOff,
  ExternalLink,
  Layers,
  Keyboard,
  PenTool,
  Plus,
  Globe,
  Compass,
  FileText,
  ShoppingBag,
  HardDrive,
  Check,
  ChevronDown,
  Link as LinkIcon,
  Shield,
  Plane,
  WifiOff,
  Volume1,
  VolumeX,
  Battery,
  Zap,
} from 'lucide-react';

interface TaskbarProps {
  isStartOpen: boolean;
  setIsStartOpen: React.Dispatch<React.SetStateAction<boolean>>;
  isWidgetsOpen: boolean;
  setIsWidgetsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  isQuickSettingsOpen: boolean;
  setIsQuickSettingsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  isNotificationsOpen: boolean;
  setIsNotificationsOpen: React.Dispatch<React.SetStateAction<boolean>>;
}

interface CustomToolbar {
  name: string;
  path: string;
}

export const Taskbar: React.FC<TaskbarProps> = ({
  isStartOpen,
  setIsStartOpen,
  isWidgetsOpen,
  setIsWidgetsOpen,
  isQuickSettingsOpen,
  setIsQuickSettingsOpen,
  isNotificationsOpen,
  setIsNotificationsOpen,
}) => {
  const {
    windows,
    activeWindowId,
    focusWindow,
    minimizeWindow,
    restoreWindow,
    closeWindow,
    updateWindowPosition,
    updateWindowSize,
    minimizeAll,
    openApp,
    settings,
    updateSettings,
    showContextMenu,
    restartSystem,
    shutdownSystem,
    enterSleepMode,
    setIsLockScreen,
    addNotification,
    setLanguage,
    currentLang,
    fileSystem,
    t,
  } = useOS();

  const [timeStr, setTimeStr] = useState('');
  const [dateStr, setDateStr] = useState('');

  // Taskbar Pinned Apps (Persisted in localStorage)
  const [pinnedAppIds, setPinnedAppIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('win11_taskbar_pinned_apps');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return ['explorer', 'edge', 'store', 'youtube', 'settings', 'terminal', 'copilot', 'notepad'];
  });

  // Taskbar Customization Options (Persisted in localStorage)
  const [toolbars, setToolbars] = useState<{
    links: boolean;
    languageBar: boolean;
    desktop: boolean;
    custom: CustomToolbar[];
  }>(() => {
    try {
      const saved = localStorage.getItem('win11_taskbar_toolbars');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      links: false,
      languageBar: false,
      desktop: false,
      custom: [],
    };
  });

  const [searchMode, setSearchMode] = useState<'icon' | 'box' | 'hidden'>(() => {
    try {
      const saved = localStorage.getItem('win11_taskbar_search_mode');
      if (saved) return saved as 'icon' | 'box' | 'hidden';
    } catch (e) {}
    return 'icon';
  });

  const [showNews, setShowNews] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('win11_taskbar_show_news');
      if (saved) return saved === 'true';
    } catch (e) {}
    return true;
  });

  const [showTaskView, setShowTaskView] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('win11_taskbar_show_taskview');
      if (saved) return saved === 'true';
    } catch (e) {}
    return true;
  });

  const [showInkWorkspace, setShowInkWorkspace] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('win11_taskbar_show_ink');
      if (saved) return saved === 'true';
    } catch (e) {}
    return false;
  });

  const [showTouchKeyboard, setShowTouchKeyboard] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('win11_taskbar_show_touch_kb');
      if (saved) return saved === 'true';
    } catch (e) {}
    return false;
  });

  const [isTaskbarLocked, setIsTaskbarLocked] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('win11_taskbar_locked');
      if (saved) return saved === 'true';
    } catch (e) {}
    return true;
  });

  // Modal flyouts
  const [isTouchKeyboardOpen, setIsTouchKeyboardOpen] = useState(false);
  const [isInkWorkspaceOpen, setIsInkWorkspaceOpen] = useState(false);
  const [isNewToolbarOpen, setIsNewToolbarOpen] = useState(false);

  // Toolbar Dropdowns
  const [isLinksMenuOpen, setIsLinksMenuOpen] = useState(false);
  const [isDesktopMenuOpen, setIsDesktopMenuOpen] = useState(false);

  // Persist options
  useEffect(() => {
    try {
      localStorage.setItem('win11_taskbar_pinned_apps', JSON.stringify(pinnedAppIds));
      localStorage.setItem('win11_taskbar_toolbars', JSON.stringify(toolbars));
      localStorage.setItem('win11_taskbar_search_mode', searchMode);
      localStorage.setItem('win11_taskbar_show_news', String(showNews));
      localStorage.setItem('win11_taskbar_show_taskview', String(showTaskView));
      localStorage.setItem('win11_taskbar_show_ink', String(showInkWorkspace));
      localStorage.setItem('win11_taskbar_show_touch_kb', String(showTouchKeyboard));
      localStorage.setItem('win11_taskbar_locked', String(isTaskbarLocked));
    } catch (e) {}
  }, [pinnedAppIds, toolbars, searchMode, showNews, showTaskView, showInkWorkspace, showTouchKeyboard, isTaskbarLocked]);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      );
      setDateStr(
        now.toLocaleDateString([], { month: 'numeric', day: 'numeric', year: 'numeric' })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const getAppMetadata = (appId: string) => {
    const app = BUILT_IN_APPS.find((a) => a.id === appId);
    const title = getLocalizedAppName(appId, t) || app?.name || app?.title || appId;
    const icon = app?.icon || 'Folder';
    return { title, icon };
  };

  const handleAppIconClick = (appId: string) => {
    const openWins = windows.filter((w) => w.appId === appId);
    if (openWins.length === 0) {
      openApp(appId);
    } else if (openWins.length === 1) {
      const topWin = openWins[0];
      if (topWin.isMinimized) {
        restoreWindow(topWin.id);
        focusWindow(topWin.id);
      } else if (activeWindowId === topWin.id) {
        minimizeWindow(topWin.id);
      } else {
        focusWindow(topWin.id);
      }
    } else {
      const activeIdx = openWins.findIndex((w) => w.id === activeWindowId && !w.isMinimized);
      if (activeIdx !== -1) {
        const nextIdx = (activeIdx + 1) % openWins.length;
        restoreWindow(openWins[nextIdx].id);
        focusWindow(openWins[nextIdx].id);
      } else {
        const topWin = openWins[0];
        restoreWindow(topWin.id);
        focusWindow(topWin.id);
      }
    }
  };

  const isCenter = settings.taskbarAlignment === 'center';

  // Window Arrangement Functions - Always active and functional
  const cascadeWindows = useCallback(() => {
    let targetWins = windows;
    if (targetWins.length === 0) {
      const id1 = openApp('explorer');
      const id2 = openApp('notepad');
      const id3 = openApp('edge');
      addNotification('Thanh tác vụ', 'Đã mở ứng dụng mẫu và sắp xếp cửa sổ xếp tầng', 'taskbar');
      setTimeout(() => {
        [id1, id2, id3].forEach((id, idx) => {
          if (!id) return;
          restoreWindow(id);
          focusWindow(id);
          const posX = 40 + (idx % 8) * 36;
          const posY = 40 + (idx % 8) * 36;
          const width = Math.min(800, window.innerWidth - 100);
          const height = Math.min(500, window.innerHeight - 140);
          updateWindowPosition(id, posX, posY);
          updateWindowSize(id, width, height);
        });
      }, 100);
      return;
    }

    targetWins.forEach((w, idx) => {
      restoreWindow(w.id);
      focusWindow(w.id);
      const posX = 30 + (idx % 10) * 32;
      const posY = 30 + (idx % 10) * 32;
      const width = Math.min(820, window.innerWidth - 80);
      const height = Math.min(520, window.innerHeight - 130);
      updateWindowPosition(w.id, posX, posY);
      updateWindowSize(w.id, width, height);
    });
    addNotification('Thanh tác vụ', 'Đã sắp xếp các cửa sổ xếp tầng (Cascade)', 'taskbar');
  }, [windows, openApp, restoreWindow, focusWindow, updateWindowPosition, updateWindowSize, addNotification]);

  const stackWindows = useCallback(() => {
    let targetWins = windows;
    if (targetWins.length === 0) {
      const id1 = openApp('explorer');
      const id2 = openApp('notepad');
      addNotification('Thanh tác vụ', 'Đã mở ứng dụng mẫu và sắp xếp cửa sổ xếp chồng', 'taskbar');
      setTimeout(() => {
        const heightPerWin = Math.floor((window.innerHeight - 70) / 2);
        [id1, id2].forEach((id, idx) => {
          if (!id) return;
          restoreWindow(id);
          focusWindow(id);
          updateWindowPosition(id, 16, 16 + idx * heightPerWin);
          updateWindowSize(id, window.innerWidth - 32, Math.max(160, heightPerWin - 10));
        });
      }, 100);
      return;
    }

    const count = targetWins.length;
    const heightPerWin = Math.floor((window.innerHeight - 70) / count);
    targetWins.forEach((w, idx) => {
      restoreWindow(w.id);
      focusWindow(w.id);
      updateWindowPosition(w.id, 16, 16 + idx * heightPerWin);
      updateWindowSize(w.id, window.innerWidth - 32, Math.max(150, heightPerWin - 8));
    });
    addNotification('Thanh tác vụ', 'Đã sắp xếp các cửa sổ xếp chồng (Stacked)', 'taskbar');
  }, [windows, openApp, restoreWindow, focusWindow, updateWindowPosition, updateWindowSize, addNotification]);

  const sideBySideWindows = useCallback(() => {
    let targetWins = windows;
    if (targetWins.length === 0) {
      const id1 = openApp('explorer');
      const id2 = openApp('edge');
      addNotification('Thanh tác vụ', 'Đã mở ứng dụng mẫu và sắp xếp cửa sổ cạnh nhau', 'taskbar');
      setTimeout(() => {
        const widthPerWin = Math.floor((window.innerWidth - 32) / 2);
        [id1, id2].forEach((id, idx) => {
          if (!id) return;
          restoreWindow(id);
          focusWindow(id);
          updateWindowPosition(id, 16 + idx * widthPerWin, 16);
          updateWindowSize(id, Math.max(200, widthPerWin - 8), window.innerHeight - 80);
        });
      }, 100);
      return;
    }

    const count = targetWins.length;
    const widthPerWin = Math.floor((window.innerWidth - 32) / count);
    targetWins.forEach((w, idx) => {
      restoreWindow(w.id);
      focusWindow(w.id);
      updateWindowPosition(w.id, 16 + idx * widthPerWin, 16);
      updateWindowSize(w.id, Math.max(200, widthPerWin - 8), window.innerHeight - 80);
    });
    addNotification('Thanh tác vụ', 'Đã sắp xếp các cửa sổ cạnh nhau (Side by Side)', 'taskbar');
  }, [windows, openApp, restoreWindow, focusWindow, updateWindowPosition, updateWindowSize, addNotification]);

  const toggleShowDesktop = useCallback(() => {
    const anyVisible = windows.some((w) => !w.isMinimized);
    if (windows.length === 0) {
      addNotification('Màn hình nền', 'Đang hiển thị màn hình nền', 'desktop');
      return;
    }
    if (anyVisible) {
      windows.forEach((w) => minimizeWindow(w.id));
      addNotification('Màn hình nền', 'Đã ẩn tất cả cửa sổ', 'desktop');
    } else {
      windows.forEach((w) => restoreWindow(w.id));
      addNotification('Màn hình nền', 'Đã khôi phục tất cả cửa sổ', 'desktop');
    }
  }, [windows, minimizeWindow, restoreWindow, addNotification]);

  // Start Button Context Menu (Win + X Menu)
  const handleStartButtonTrigger = useCallback(
    (coords: { x: number; y: number }) => {
      setIsStartOpen(false);
      setIsWidgetsOpen(false);
      setIsQuickSettingsOpen(false);
      setIsNotificationsOpen(false);

      const winXItems: ContextMenuItem[] = [
        {
          id: 'winx-apps',
          label: t.allApps,
          icon: 'LayoutGrid',
          onClick: () => openApp('settings'),
        },
        {
          id: 'winx-power',
          label: t.quickSettings,
          icon: 'BatteryCharging',
          onClick: () => openApp('settings'),
        },
        {
          id: 'winx-event',
          label: t.taskManager,
          icon: 'Activity',
          onClick: () => openApp('taskmanager'),
        },
        {
          id: 'winx-system',
          label: t.system,
          icon: 'Sliders',
          onClick: () => openApp('settings'),
        },
        {
          id: 'winx-disk',
          label: 'C: Drive',
          icon: 'HardDrive',
          onClick: () => openApp('explorer', { initialPath: 'C:' }),
        },
        {
          id: 'winx-terminal',
          label: t.terminal,
          icon: 'Terminal',
          onClick: () => openApp('terminal'),
        },
        { separator: true, id: 'winx-sep-1', label: '' },
        {
          id: 'winx-taskmgr',
          label: t.taskManager,
          icon: 'Activity',
          shortcut: 'Ctrl+Shift+Esc',
          onClick: () => openApp('taskmanager'),
        },
        {
          id: 'winx-settings',
          label: t.settings,
          icon: 'Settings',
          shortcut: 'Win+I',
          onClick: () => openApp('settings'),
        },
        {
          id: 'winx-explorer',
          label: t.fileExplorer,
          icon: 'Folder',
          shortcut: 'Win+E',
          onClick: () => openApp('explorer'),
        },
        {
          id: 'winx-search',
          label: t.search,
          icon: 'Search',
          shortcut: 'Win+S',
          onClick: () => setIsStartOpen(true),
        },
        {
          id: 'winx-run',
          label: 'Run...',
          icon: 'Terminal',
          shortcut: 'Win+R',
          onClick: () => openApp('run'),
        },
        { separator: true, id: 'winx-sep-2', label: '' },
        {
          id: 'winx-shutdown-group',
          label: t.shutDown,
          icon: 'Power',
          submenu: [
            {
              id: 'winx-signout',
              label: t.signOut,
              icon: 'LogOut',
              onClick: () => setIsLockScreen(true),
            },
            {
              id: 'winx-sleep',
              label: t.sleep,
              icon: 'Moon',
              onClick: () => enterSleepMode(),
            },
            {
              id: 'winx-shutdown',
              label: t.shutDown,
              icon: 'Power',
              danger: true,
              onClick: shutdownSystem,
            },
            {
              id: 'winx-restart',
              label: t.restart,
              icon: 'RotateCw',
              onClick: restartSystem,
            },
          ],
        },
        { separator: true, id: 'winx-sep-3', label: '' },
        {
          id: 'winx-desktop',
          label: 'Desktop',
          icon: 'Monitor',
          shortcut: 'Win+D',
          onClick: toggleShowDesktop,
        },
      ];

      const menuY = Math.max(10, window.innerHeight - 440);
      showContextMenu(Math.max(10, coords.x - 30), menuY, winXItems, 'start');
    },
    [
      setIsStartOpen,
      setIsWidgetsOpen,
      setIsQuickSettingsOpen,
      setIsNotificationsOpen,
      openApp,
      setIsLockScreen,
      shutdownSystem,
      restartSystem,
      toggleShowDesktop,
      showContextMenu,
      t,
      enterSleepMode,
    ]
  );

  const { touchProps: startTouchProps, isTriggeredRef: isStartTriggeredRef } = useContextMenuTrigger({
    onTrigger: handleStartButtonTrigger,
  });

  // Taskbar Empty Area Context Menu - Fully Functional & Rich Features
  const handleTaskbarTrigger = useCallback(
    (coords: { x: number; y: number }) => {
      const items: ContextMenuItem[] = [
        {
          id: 'tb-toolbars',
          label: 'Thanh công cụ (Toolbars)',
          icon: 'Folder',
          submenu: [
            {
              id: 'tb-toolbar-links',
              label: 'Liên kết',
              checked: toolbars.links,
              onClick: () => {
                setToolbars((prev) => {
                  const next = { ...prev, links: !prev.links };
                  addNotification('Thanh tác vụ', next.links ? 'Đã bật thanh công cụ Liên kết' : 'Đã tắt thanh công cụ Liên kết', 'taskbar');
                  return next;
                });
              },
            },
            {
              id: 'tb-toolbar-lang',
              label: 'Thanh ngôn ngữ',
              checked: toolbars.languageBar,
              onClick: () => {
                setToolbars((prev) => {
                  const next = { ...prev, languageBar: !prev.languageBar };
                  addNotification('Thanh tác vụ', next.languageBar ? 'Đã bật thanh ngôn ngữ' : 'Đã tắt thanh ngôn ngữ', 'taskbar');
                  return next;
                });
              },
            },
            {
              id: 'tb-toolbar-desktop',
              label: 'Máy tính để bàn',
              checked: toolbars.desktop,
              onClick: () => {
                setToolbars((prev) => {
                  const next = { ...prev, desktop: !prev.desktop };
                  addNotification('Thanh tác vụ', next.desktop ? 'Đã bật thanh công cụ Máy tính để bàn' : 'Đã tắt thanh công cụ Máy tính để bàn', 'taskbar');
                  return next;
                });
              },
            },
            { separator: true, id: 'tb-toolbar-sep', label: '' },
            {
              id: 'tb-toolbar-new',
              label: 'Thanh công cụ mới…',
              icon: 'Plus',
              onClick: () => setIsNewToolbarOpen(true),
            },
          ],
        },
        {
          id: 'tb-search',
          label: 'Tìm kiếm',
          icon: 'Search',
          submenu: [
            {
              id: 'tb-search-hidden',
              label: 'Ẩn',
              checked: searchMode === 'hidden',
              onClick: () => {
                setSearchMode('hidden');
                addNotification('Tìm kiếm', 'Đã ẩn ô tìm kiếm trên thanh tác vụ', 'taskbar');
              },
            },
            {
              id: 'tb-search-icon',
              label: 'Hiển thị nút tìm kiếm',
              checked: searchMode === 'icon',
              onClick: () => {
                setSearchMode('icon');
                addNotification('Tìm kiếm', 'Đã đặt chế độ biểu tượng tìm kiếm', 'taskbar');
              },
            },
            {
              id: 'tb-search-box',
              label: 'Hiển thị hộp tìm kiếm',
              checked: searchMode === 'box',
              onClick: () => {
                setSearchMode('box');
                addNotification('Tìm kiếm', 'Đã hiển thị hộp tìm kiếm trên thanh tác vụ', 'taskbar');
              },
            },
          ],
        },
        {
          id: 'tb-news',
          label: 'Tin tức và Sở thích',
          icon: 'CloudSun',
          submenu: [
            {
              id: 'tb-news-hidden',
              label: 'Ẩn',
              checked: !showNews,
              onClick: () => {
                setShowNews(false);
                addNotification('Widgets', 'Đã ẩn tiện ích Tin tức & Thời tiết', 'taskbar');
              },
            },
            {
              id: 'tb-news-show',
              label: 'Hiển thị',
              checked: showNews,
              onClick: () => {
                setShowNews(true);
                addNotification('Widgets', 'Đã hiển thị tiện ích Tin tức & Thời tiết', 'taskbar');
              },
            },
          ],
        },
        {
          id: 'tb-taskview',
          label: 'Hiển thị nút Chế độ xem tác vụ',
          icon: 'Layers',
          checked: showTaskView,
          onClick: () => {
            setShowTaskView((prev) => {
              const next = !prev;
              addNotification('Thanh tác vụ', next ? 'Đã bật nút Chế độ xem tác vụ' : 'Đã ẩn nút Chế độ xem tác vụ', 'taskbar');
              return next;
            });
          },
        },
        {
          id: 'tb-ink',
          label: 'Hiển thị nút Không gian làm việc Windows Ink',
          icon: 'PenTool',
          checked: showInkWorkspace,
          onClick: () => {
            setShowInkWorkspace((prev) => {
              const next = !prev;
              addNotification('Thanh tác vụ', next ? 'Đã bật nút Không gian làm việc Windows Ink' : 'Đã ẩn nút Windows Ink', 'taskbar');
              return next;
            });
          },
        },
        {
          id: 'tb-touch-keyboard',
          label: 'Hiển thị nút bàn phím cảm ứng',
          icon: 'Keyboard',
          checked: showTouchKeyboard,
          onClick: () => {
            setShowTouchKeyboard((prev) => {
              const next = !prev;
              addNotification('Thanh tác vụ', next ? 'Đã bật nút Bàn phím cảm ứng' : 'Đã ẩn nút Bàn phím cảm ứng', 'taskbar');
              return next;
            });
          },
        },
        { separator: true, id: 'tb-sep-layout', label: '' },
        {
          id: 'tb-cascade',
          label: 'Cửa sổ xếp tầng',
          icon: 'Layers',
          onClick: cascadeWindows,
        },
        {
          id: 'tb-stacked',
          label: 'Hiển thị cửa sổ xếp chồng',
          icon: 'LayoutGrid',
          onClick: stackWindows,
        },
        {
          id: 'tb-sidebyside',
          label: 'Hiển thị cửa sổ cạnh nhau',
          icon: 'Columns',
          onClick: sideBySideWindows,
        },
        {
          id: 'tb-desktop',
          label: 'Hiển thị màn hình nền',
          icon: 'Monitor',
          shortcut: 'Win+D',
          onClick: toggleShowDesktop,
        },
        { separator: true, id: 'tb-sep-taskmgr', label: '' },
        {
          id: 'tb-taskmanager',
          label: 'Trình quản lý tác vụ',
          icon: 'Activity',
          shortcut: 'Ctrl+Shift+Esc',
          onClick: () => openApp('taskmanager'),
        },
        { separator: true, id: 'tb-sep-props', label: '' },
        {
          id: 'tb-properties',
          label: 'Thuộc tính (Properties)',
          icon: 'Sliders',
          onClick: () => openApp('settings'),
        },
        {
          id: 'tb-lock',
          label: 'Khóa thanh tác vụ',
          checked: isTaskbarLocked,
          onClick: () => {
            setIsTaskbarLocked((prev) => {
              const next = !prev;
              addNotification(
                'Thanh tác vụ',
                next ? 'Đã khóa thanh tác vụ (Locked)' : 'Đã mở khóa thanh tác vụ (Unlocked)',
                'taskbar'
              );
              return next;
            });
          },
        },
        {
          id: 'tb-settings',
          label: 'Cài đặt thanh tác vụ',
          icon: 'Settings',
          onClick: () => openApp('settings'),
        },
      ];

      showContextMenu(coords.x, coords.y, items, 'taskbar');
    },
    [
      toolbars,
      searchMode,
      showNews,
      showTaskView,
      showInkWorkspace,
      showTouchKeyboard,
      isTaskbarLocked,
      cascadeWindows,
      stackWindows,
      sideBySideWindows,
      toggleShowDesktop,
      openApp,
      addNotification,
      showContextMenu,
    ]
  );

  const { touchProps: taskbarTouchProps } = useContextMenuTrigger({
    onTrigger: handleTaskbarTrigger,
  });

  // Taskbar App Icon Context Menu (Windows 11 Jump List)
  const handleAppIconTrigger = useCallback(
    (coords: { x: number; y: number }, appId: string, defaultTitle: string, defaultIcon: string) => {
      const openWins = windows.filter((w) => w.appId === appId);
      const isPinned = pinnedAppIds.includes(appId);

      const items: ContextMenuItem[] = [];

      // === 1. Đã ghim / Ứng dụng ===
      items.push({
        header: isPinned ? 'Đã ghim' : 'Cửa sổ',
        id: `header-pinned-${appId}`,
        label: isPinned ? 'Đã ghim' : 'Cửa sổ',
      });

      if (openWins.length > 0) {
        openWins.forEach((w, idx) => {
          items.push({
            id: `app-win-${w.id}`,
            label: w.title || `${defaultTitle} (${idx + 1})`,
            icon: w.icon || defaultIcon || 'ExternalLink',
            onClick: () => {
              if (w.isMinimized) {
                restoreWindow(w.id);
              }
              focusWindow(w.id);
            },
          });
        });
      } else {
        items.push({
          id: `app-item-pinned-${appId}`,
          label: defaultTitle,
          icon: defaultIcon || 'ExternalLink',
          onClick: () => openApp(appId),
        });
      }

      // ─── Đường kẻ phân cách ───
      items.push({ separator: true, id: `sep-tasks-${appId}`, label: '' });

      // === 2. Tác vụ ===
      items.push({
        header: 'Tác vụ',
        id: `header-tasks-${appId}`,
        label: 'Tác vụ',
      });

      // Cửa sổ mới
      items.push({
        id: `app-action-new-window-${appId}`,
        label: 'Cửa sổ mới',
        icon: 'Plus',
        onClick: () => {
          openApp(appId);
          addNotification('Thanh tác vụ', `Đã mở cửa sổ mới cho ${defaultTitle}`, 'taskbar');
        },
      });

      // Cửa sổ InPrivate / Ẩn danh mới
      items.push({
        id: `app-action-incognito-${appId}`,
        label: appId === 'edge' ? 'Cửa sổ InPrivate mới' : 'Cửa sổ Ẩn danh mới',
        icon: 'Shield',
        onClick: () => {
          if (appId === 'edge') {
            openApp('edge', { initialUrl: 'about:inprivate', incognito: true });
          } else {
            openApp(appId, { incognito: true });
          }
          addNotification(
            'Thanh tác vụ',
            `Đã mở ${appId === 'edge' ? 'Cửa sổ InPrivate mới' : 'Cửa sổ Ẩn danh mới'} (${defaultTitle})`,
            'taskbar'
          );
        },
      });

      // ─── Đường kẻ phân cách ───
      items.push({ separator: true, id: `sep-pin-${appId}`, label: '' });

      // === 3. Ghim vào thanh tác vụ / Bỏ ghim khỏi thanh tác vụ ===
      if (isPinned) {
        items.push({
          id: `app-action-unpin-${appId}`,
          label: 'Bỏ ghim khỏi thanh tác vụ',
          icon: 'PinOff',
          onClick: () => {
            setPinnedAppIds((prev) => {
              const next = prev.filter((id) => id !== appId);
              try {
                localStorage.setItem('win11_taskbar_pinned_apps', JSON.stringify(next));
              } catch (e) {}
              return next;
            });
            addNotification('Thanh tác vụ', `Đã bỏ ghim "${defaultTitle}" khỏi thanh tác vụ`, 'taskbar');
          },
        });
      } else {
        items.push({
          id: `app-action-pin-${appId}`,
          label: 'Ghim vào thanh tác vụ',
          icon: 'Pin',
          onClick: () => {
            setPinnedAppIds((prev) => {
              if (prev.includes(appId)) return prev;
              const next = [...prev, appId];
              try {
                localStorage.setItem('win11_taskbar_pinned_apps', JSON.stringify(next));
              } catch (e) {}
              return next;
            });
            addNotification('Thanh tác vụ', `Đã ghim "${defaultTitle}" vào thanh tác vụ`, 'taskbar');
          },
        });
      }

      // === 4. Đóng cửa sổ / Đóng tất cả cửa sổ ===
      if (openWins.length > 0) {
        // ─── Đường kẻ phân cách ───
        items.push({ separator: true, id: `sep-close-${appId}`, label: '' });

        if (openWins.length === 1) {
          items.push({
            id: `app-action-close-one-${appId}`,
            label: 'Đóng cửa sổ',
            icon: 'X',
            danger: true,
            onClick: () => {
              closeWindow(openWins[0].id);
            },
          });
        } else {
          items.push({
            id: `app-action-close-all-${appId}`,
            label: 'Đóng tất cả cửa sổ',
            icon: 'X',
            danger: true,
            onClick: () => {
              openWins.forEach((w) => closeWindow(w.id));
            },
          });
        }
      }

      showContextMenu(coords.x, coords.y, items, 'taskbar');
    },
    [windows, pinnedAppIds, restoreWindow, focusWindow, openApp, addNotification, closeWindow, showContextMenu]
  );

  // Group running unpinned apps by unique appId
  const unpinnedRunningAppIds: string[] = Array.from(
    new Set<string>(
      windows
        .map((w) => w.appId)
        .filter((appId): appId is string => Boolean(appId) && !pinnedAppIds.includes(appId))
    )
  );

  const handleAddCustomToolbar = (name: string, path: string) => {
    setToolbars((prev) => ({
      ...prev,
      custom: [...prev.custom.filter((c) => c.name !== name), { name, path }],
    }));
    addNotification('Thanh công cụ', `Đã thêm thanh công cụ "${name}"`, 'taskbar');
  };

  return (
    <>
      <div
        {...taskbarTouchProps}
        onClick={(e) => {
          e.stopPropagation();
          setIsLinksMenuOpen(false);
          setIsDesktopMenuOpen(false);
        }}
        className="fixed bottom-0 left-0 right-0 h-12 bg-white/85 dark:bg-[#181818]/90 backdrop-blur-2xl border-t border-white/30 dark:border-white/10 flex items-center justify-between px-3 select-none z-40 touch-manipulation shadow-lg"
      >
        {/* Left side: Widgets & News (if enabled) */}
        <div className="flex items-center min-w-[40px]">
          {showNews && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsWidgetsOpen(!isWidgetsOpen);
                setIsStartOpen(false);
                setIsQuickSettingsOpen(false);
                setIsNotificationsOpen(false);
              }}
              className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                isWidgetsOpen
                  ? 'bg-white/40 dark:bg-white/10 shadow-sm'
                  : 'hover:bg-white/20 dark:hover:bg-white/5 text-slate-700 dark:text-slate-200'
              }`}
              title="Tin tức và Sở thích (Widgets & Feeds)"
            >
              <CloudSun size={18} className="text-amber-500 shrink-0" />
              <div className="text-left leading-tight hidden sm:block">
                <div className="text-[11px] font-bold">28°C</div>
                <div className="text-[9px] text-slate-500 dark:text-slate-400">Nắng nhẹ</div>
              </div>
            </button>
          )}
        </div>

        {/* Center: Start Button + App Icons + Task View + Search */}
        <div
          className={`flex items-center gap-1 ${
            isCenter ? 'absolute left-1/2 -translate-x-1/2' : 'ml-2'
          }`}
        >
          {/* Start Button with Win + X Right Click & Mobile Long Press */}
          <button
            {...startTouchProps}
            onMouseDown={(e) => e.stopPropagation()}
            onClick={(e) => {
              e.stopPropagation();
              if (isStartTriggeredRef.current) return;
              setIsStartOpen((prev) => !prev);
              setIsWidgetsOpen(false);
              setIsQuickSettingsOpen(false);
              setIsNotificationsOpen(false);
            }}
            className={`w-10 h-10 rounded-lg flex items-center justify-center transition-all ${
              isStartOpen
                ? 'bg-white/40 dark:bg-white/15 scale-95 shadow-inner'
                : 'hover:bg-white/20 dark:hover:bg-white/5 active:scale-90'
            }`}
            title={t.start}
          >
            {/* Windows 11 Iconic Logo */}
            <div className="grid grid-cols-2 gap-0.5 w-5 h-5">
              <div className="bg-sky-500 rounded-[1.5px]" />
              <div className="bg-sky-500 rounded-[1.5px]" />
              <div className="bg-sky-500 rounded-[1.5px]" />
              <div className="bg-sky-500 rounded-[1.5px]" />
            </div>
          </button>

          {/* Search Button / Search Box */}
          {searchMode === 'box' && (
            <div
              onClick={() => {
                setIsStartOpen(true);
              }}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100/90 dark:bg-white/10 hover:bg-white/80 dark:hover:bg-white/15 border border-slate-200/60 dark:border-white/10 text-xs text-slate-500 dark:text-zinc-400 cursor-pointer shadow-sm min-w-[140px] max-w-[200px] transition-all"
              title="Tìm kiếm ứng dụng, tệp tin và web"
            >
              <Search size={14} className="text-sky-500" />
              <span className="truncate text-[11px]">Tìm kiếm...</span>
            </div>
          )}

          {searchMode === 'icon' && (
            <button
              onClick={() => setIsStartOpen(true)}
              className="w-10 h-10 rounded-lg flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-white/20 dark:hover:bg-white/5 active:scale-95 transition-all"
              title="Tìm kiếm (Search)"
            >
              <Search size={18} />
            </button>
          )}

          {/* Task View Button (Chế độ xem tác vụ) */}
          {showTaskView && (
            <button
              onClick={() => {
                if (windows.length > 0) {
                  cascadeWindows();
                } else {
                  addNotification('Chế độ xem tác vụ', 'Hiện chưa có cửa sổ nào đang mở', 'taskbar');
                }
              }}
              className="w-10 h-10 rounded-lg flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-white/20 dark:hover:bg-white/5 active:scale-95 transition-all"
              title="Chế độ xem tác vụ (Task View / Cascade Windows)"
            >
              <Layers size={18} />
            </button>
          )}

          {/* Pinned Applications */}
          {pinnedAppIds.map((appId) => {
            const meta = getAppMetadata(appId);
            const appWins = windows.filter((w) => w.appId === appId);
            const isOpen = appWins.length > 0;
            const isActive = appWins.some((w) => w.id === activeWindowId && !w.isMinimized);

            return (
              <TaskbarAppButton
                key={appId}
                appId={appId}
                title={meta.title}
                icon={meta.icon}
                isOpen={isOpen}
                isActive={isActive}
                onClick={() => handleAppIconClick(appId)}
                onContextMenuTrigger={(coords) =>
                  handleAppIconTrigger(coords, appId, meta.title, meta.icon)
                }
              />
            );
          })}

          {/* Dynamic Running Extra Unpinned Windows */}
          <AnimatePresence>
            {unpinnedRunningAppIds.map((appId) => {
              const meta = getAppMetadata(appId);
              const matchingWins = windows.filter((w) => w.appId === appId);
              const isActive = matchingWins.some((w) => w.id === activeWindowId && !w.isMinimized);
              const displayTitle = matchingWins[0]?.customData?.appName || meta.title;
              const displayIcon = matchingWins[0]?.icon || meta.icon;

              return (
                <motion.div
                  key={appId}
                  initial={{ opacity: 0, scale: 0.7, width: 0 }}
                  animate={{ opacity: 1, scale: 1, width: 'auto' }}
                  exit={{ opacity: 0, scale: 0.7, width: 0 }}
                  transition={{ type: 'spring', damping: 24, stiffness: 350 }}
                >
                  <TaskbarAppButton
                    appId={appId}
                    title={displayTitle}
                    icon={displayIcon}
                    isOpen={true}
                    isActive={isActive}
                    onClick={() => handleAppIconClick(appId)}
                    onContextMenuTrigger={(coords) =>
                      handleAppIconTrigger(coords, appId, displayTitle, displayIcon)
                    }
                  />
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

        {/* Right side: Toolbars, System Tray & Clock */}
        <div className="flex items-center gap-1.5">
          {/* Links Toolbar */}
          {toolbars.links && (
            <div className="relative">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setIsLinksMenuOpen(!isLinksMenuOpen);
                  setIsDesktopMenuOpen(false);
                }}
                className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-white/20 dark:hover:bg-white/5 transition-colors"
                title="Thanh công cụ Liên kết (Links)"
              >
                <LinkIcon size={12} className="text-sky-500" />
                <span>Liên kết</span>
                <ChevronDown size={11} className="opacity-70" />
              </button>

              {isLinksMenuOpen && (
                <div
                  className="absolute right-0 bottom-full mb-2 w-48 acrylic-blur bg-white/95 dark:bg-[#1f1f1f]/95 rounded-xl shadow-2xl border border-white/60 dark:border-white/10 p-1.5 text-xs text-slate-800 dark:text-slate-100 z-50 backdrop-blur-2xl animate-win11-fade"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Liên kết nhanh
                  </div>
                  <div
                    onClick={() => {
                      setIsLinksMenuOpen(false);
                      openApp('edge', { initialUrl: 'https://www.google.com' });
                    }}
                    className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-sky-500/10 cursor-pointer"
                  >
                    <Globe size={13} className="text-blue-500" />
                    <span>Google</span>
                  </div>
                  <div
                    onClick={() => {
                      setIsLinksMenuOpen(false);
                      openApp('edge', { initialUrl: 'https://www.bing.com' });
                    }}
                    className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-sky-500/10 cursor-pointer"
                  >
                    <Globe size={13} className="text-sky-500" />
                    <span>Bing Search</span>
                  </div>
                  <div
                    onClick={() => {
                      setIsLinksMenuOpen(false);
                      openApp('edge', { initialUrl: 'https://github.com' });
                    }}
                    className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-sky-500/10 cursor-pointer"
                  >
                    <Globe size={13} className="text-purple-500" />
                    <span>GitHub</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Desktop Toolbar */}
          {toolbars.desktop && (
            <div className="relative">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setIsDesktopMenuOpen(!isDesktopMenuOpen);
                  setIsLinksMenuOpen(false);
                }}
                className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-white/20 dark:hover:bg-white/5 transition-colors"
                title="Thanh công cụ Máy tính để bàn (Desktop)"
              >
                <Monitor size={12} className="text-sky-500" />
                <span>Desktop »</span>
              </button>

              {isDesktopMenuOpen && (
                <div
                  className="absolute right-0 bottom-full mb-2 w-52 max-h-64 overflow-y-auto acrylic-blur bg-white/95 dark:bg-[#1f1f1f]/95 rounded-xl shadow-2xl border border-white/60 dark:border-white/10 p-1.5 text-xs text-slate-800 dark:text-slate-100 z-50 backdrop-blur-2xl animate-win11-fade flex flex-col gap-0.5"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Máy tính để bàn
                  </div>
                  <div
                    onClick={() => {
                      setIsDesktopMenuOpen(false);
                      openApp('explorer', { initialPath: 'This PC' });
                    }}
                    className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-sky-500/10 cursor-pointer"
                  >
                    <HardDrive size={13} className="text-sky-500" />
                    <span>This PC (Ổ đĩa C:)</span>
                  </div>
                  <div
                    onClick={() => {
                      setIsDesktopMenuOpen(false);
                      openApp('notepad');
                    }}
                    className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-sky-500/10 cursor-pointer"
                  >
                    <FileText size={13} className="text-amber-500" />
                    <span>Notepad</span>
                  </div>
                  <div
                    onClick={() => {
                      setIsDesktopMenuOpen(false);
                      openApp('terminal');
                    }}
                    className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-sky-500/10 cursor-pointer"
                  >
                    <Terminal size={13} className="text-emerald-500" />
                    <span>Command Prompt</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Language Bar Toolbar */}
          {toolbars.languageBar && (
            <button
              onClick={() => {
                const nextLang = currentLang === 'vi' ? 'en' : 'vi';
                setLanguage(nextLang);
                updateSettings({ language: nextLang });
                addNotification('Ngôn ngữ', `Đã chuyển sang ${nextLang === 'vi' ? 'Tiếng Việt' : 'English'}`, 'taskbar');
              }}
              className="px-2 py-1 rounded-lg text-xs font-bold text-slate-700 dark:text-slate-200 bg-slate-200/60 dark:bg-white/10 hover:bg-white/30 transition-colors"
              title="Chuyển đổi ngôn ngữ nhập"
            >
              {currentLang === 'vi' ? 'VIE' : 'ENG'}
            </button>
          )}

          {/* Windows Ink Workspace Tray Button */}
          {showInkWorkspace && (
            <button
              onClick={() => setIsInkWorkspaceOpen(true)}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-white/20 dark:hover:bg-white/5 active:scale-95 transition-all"
              title="Không gian làm việc Windows Ink"
            >
              <PenTool size={15} className="text-sky-500" />
            </button>
          )}

          {/* Touch Keyboard Tray Button */}
          {showTouchKeyboard && (
            <button
              onClick={() => setIsTouchKeyboardOpen(true)}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-white/20 dark:hover:bg-white/5 active:scale-95 transition-all"
              title="Bàn phím cảm ứng (Touch Keyboard)"
            >
              <Keyboard size={16} />
            </button>
          )}

          {/* Quick Settings pill (Wi-Fi, Volume, Battery) */}
          {/* Quick Settings pill (Wi-Fi, Volume, Battery status) */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsQuickSettingsOpen((prev) => !prev);
              setIsStartOpen(false);
              setIsWidgetsOpen(false);
              setIsNotificationsOpen(false);
            }}
            className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-slate-700 dark:text-slate-200 transition-all ${
              isQuickSettingsOpen
                ? 'bg-white/40 dark:bg-white/15 shadow-sm ring-1 ring-white/20'
                : 'hover:bg-white/20 dark:hover:bg-white/5'
            }`}
            title={t.quickSettings}
          >
            {/* Wi-Fi / Airplane status icon */}
            {settings.isAirplaneMode ? (
              <Plane size={14} className="text-sky-500 animate-pulse" />
            ) : !settings.isWifiOn ? (
              <WifiOff size={14} className="text-amber-500/80" />
            ) : (
              <Wifi size={14} />
            )}

            {/* Audio / Volume status icon */}
            {!settings.soundEnabled || settings.volume === 0 ? (
              <VolumeX size={14} className="text-amber-500" />
            ) : settings.volume < 40 ? (
              <Volume1 size={14} />
            ) : (
              <Volume2 size={14} />
            )}

            {/* Battery / Energy Saver status icon */}
            <div className="flex items-center gap-0.5">
              {settings.isBatterySaver ? (
                <div className="flex items-center text-amber-500">
                  <Battery size={14} />
                  <Zap size={10} className="-ml-1.5 fill-current" />
                </div>
              ) : (
                <BatteryCharging size={14} className="text-emerald-500" />
              )}
            </div>
          </button>

          {/* Date & Time pill (Opens Notification Center & Calendar) */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsNotificationsOpen((prev) => !prev);
              setIsStartOpen(false);
              setIsWidgetsOpen(false);
              setIsQuickSettingsOpen(false);
            }}
            className={`flex flex-col items-end px-2.5 py-1 rounded-lg text-right leading-tight text-slate-700 dark:text-slate-200 transition-all ${
              isNotificationsOpen
                ? 'bg-white/40 dark:bg-white/15 shadow-sm ring-1 ring-white/20'
                : 'hover:bg-white/20 dark:hover:bg-white/5'
            }`}
            title={`${t.notifications} & Lịch`}
          >
            <span className="text-xs font-semibold">{timeStr}</span>
            <span className="text-[10px] text-slate-500 dark:text-slate-400">{dateStr}</span>
          </button>

          {/* Peek Desktop / Show Desktop Line on far right */}
          <div
            onClick={(e) => {
              e.stopPropagation();
              toggleShowDesktop();
            }}
            className="w-2 h-8 border-l border-slate-300 dark:border-zinc-700 hover:bg-white/30 dark:hover:bg-white/10 cursor-pointer ml-0.5 rounded-r"
            title={t.showDesktop}
          />
        </div>
      </div>

      {/* Flyouts & Dialogs for Taskbar Options */}
      <TouchKeyboardModal
        isOpen={isTouchKeyboardOpen}
        onClose={() => setIsTouchKeyboardOpen(false)}
      />

      <InkWorkspaceFlyout
        isOpen={isInkWorkspaceOpen}
        onClose={() => setIsInkWorkspaceOpen(false)}
      />

      <NewToolbarModal
        isOpen={isNewToolbarOpen}
        onClose={() => setIsNewToolbarOpen(false)}
        onAddToolbar={handleAddCustomToolbar}
      />
    </>
  );
};

// Subcomponent for individual taskbar app button with right-click & long-press
interface TaskbarAppButtonProps {
  appId: string;
  title: string;
  icon: string;
  isOpen: boolean;
  isActive: boolean;
  onClick: () => void;
  onContextMenuTrigger: (coords: { x: number; y: number }) => void;
}

const TaskbarAppButton: React.FC<TaskbarAppButtonProps> = ({
  appId,
  title,
  icon,
  isOpen,
  isActive,
  onClick,
  onContextMenuTrigger,
}) => {
  const btnRef = useRef<HTMLButtonElement>(null);

  const handleTrigger = useCallback(
    (coords: { x: number; y: number }) => {
      if (btnRef.current) {
        const rect = btnRef.current.getBoundingClientRect();
        onContextMenuTrigger({ x: rect.left + rect.width / 2, y: rect.top });
      } else {
        onContextMenuTrigger(coords);
      }
    },
    [onContextMenuTrigger]
  );

  const { touchProps, isTriggeredRef } = useContextMenuTrigger({
    onTrigger: handleTrigger,
  });

  return (
    <button
      ref={btnRef}
      {...touchProps}
      onClick={(e) => {
        e.stopPropagation();
        if (isTriggeredRef.current) return;
        onClick();
      }}
      className={`relative w-10 h-10 rounded-lg flex items-center justify-center transition-all ${
        isActive
          ? 'bg-white/40 dark:bg-white/15 shadow-sm'
          : 'hover:bg-white/20 dark:hover:bg-white/5 active:scale-95'
      }`}
      title={title}
    >
      <div className="w-6 h-6 flex items-center justify-center">
        <IconRenderer name={icon} size={22} />
      </div>

      {/* Windows 11 active/open dot indicator */}
      {isOpen && (
        <div
          className={`absolute bottom-0.5 rounded-full transition-all ${
            isActive ? 'w-4 h-1 bg-sky-500' : 'w-1.5 h-1.5 bg-slate-400 dark:bg-slate-300'
          }`}
        />
      )}
    </button>
  );
};

