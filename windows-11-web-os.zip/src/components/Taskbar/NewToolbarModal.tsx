import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Folder, X, Plus, HardDrive, Check } from 'lucide-react';
import { useOS } from '../../context/OSContext';

interface NewToolbarModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddToolbar: (name: string, path: string) => void;
}

export const NewToolbarModal: React.FC<NewToolbarModalProps> = ({
  isOpen,
  onClose,
  onAddToolbar,
}) => {
  const { fileSystem } = useOS();
  const [selectedFolder, setSelectedFolder] = useState('C:\\Users\\User\\Documents');
  const [customName, setCustomName] = useState('');

  if (!isOpen) return null;

  const directories = fileSystem
    .filter((f) => f.isDirectory)
    .sort((a, b) => a.path.localeCompare(b.path));

  const handleCreate = () => {
    const name = customName.trim() || selectedFolder.split('\\').filter(Boolean).pop() || 'Thư mục mới';
    onAddToolbar(name, selectedFolder);
    onClose();
  };

  return (
    <AnimatePresence>
      <div
        id="new-toolbar-modal-backdrop"
        className="fixed inset-0 z-[10000] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          id="new-toolbar-modal-container"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="w-full max-w-md acrylic-blur bg-white/95 dark:bg-[#1f1f1f]/95 rounded-2xl shadow-2xl border border-white/60 dark:border-white/10 p-5 flex flex-col gap-4 text-slate-800 dark:text-slate-100 select-none backdrop-blur-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-2 border-b border-slate-200/60 dark:border-zinc-800/60">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-sky-500/15 text-sky-600 dark:text-sky-400 flex items-center justify-center">
                <Folder size={16} />
              </div>
              <div>
                <h3 className="text-sm font-bold">Thanh công cụ mới - Chọn một thư mục</h3>
                <p className="text-[11px] text-slate-500 dark:text-zinc-400">
                  Chọn thư mục để ghim làm thanh công cụ trên thanh tác vụ
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:bg-red-500 hover:text-white transition-colors"
            >
              <X size={15} />
            </button>
          </div>

          {/* Folder Tree Selector */}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-zinc-300">
              Danh sách thư mục có sẵn:
            </label>
            <div className="max-h-48 overflow-y-auto rounded-xl border border-slate-200/80 dark:border-zinc-700/80 bg-slate-50/50 dark:bg-black/30 p-2 flex flex-col gap-1 text-xs">
              {directories.map((dir) => {
                const isSelected = selectedFolder === dir.path;
                return (
                  <div
                    key={dir.path}
                    onClick={() => setSelectedFolder(dir.path)}
                    className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-sky-500 text-white font-medium shadow-sm'
                        : 'hover:bg-slate-200/60 dark:hover:bg-zinc-800/60 text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      {dir.path.length <= 3 ? <HardDrive size={14} /> : <Folder size={14} />}
                      <span className="truncate">{dir.path}</span>
                    </div>
                    {isSelected && <Check size={14} className="shrink-0 stroke-[2.5]" />}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Name input */}
          <div className="flex flex-col gap-1">
            <label className="text-xs font-semibold text-slate-600 dark:text-zinc-300">
              Tên thanh công cụ (tùy chọn):
            </label>
            <input
              type="text"
              value={customName}
              onChange={(e) => setCustomName(e.target.value)}
              placeholder={selectedFolder.split('\\').filter(Boolean).pop() || 'Tên hiển thị'}
              className="px-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800/60 text-slate-800 dark:text-slate-100 outline-none focus:ring-2 focus:ring-sky-500/50"
            />
          </div>

          {/* Buttons */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200/60 dark:border-zinc-800/60">
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-600 dark:text-zinc-300 hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors"
            >
              Hủy
            </button>
            <button
              onClick={handleCreate}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-sky-500 hover:bg-sky-600 text-white text-xs font-semibold shadow-sm active:scale-95 transition-transform"
            >
              <Plus size={14} />
              <span>Chọn thư mục</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
