import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Keyboard, ArrowUp, Delete, CornerDownLeft, Sparkles, Globe, Copy, Check } from 'lucide-react';
import { soundManager } from '../../utils/sound';

interface TouchKeyboardModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TouchKeyboardModal: React.FC<TouchKeyboardModalProps> = ({ isOpen, onClose }) => {
  const [typedText, setTypedText] = useState('');
  const [isShift, setIsShift] = useState(false);
  const [isCaps, setIsCaps] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleKeyPress = (key: string) => {
    soundManager.playKeypress();
    setTypedText((prev) => prev + (isShift || isCaps ? key.toUpperCase() : key.toLowerCase()));
    if (isShift) setIsShift(false);
  };

  const handleBackspace = () => {
    soundManager.playKeypress();
    setTypedText((prev) => prev.slice(0, -1));
  };

  const handleSpace = () => {
    soundManager.playKeypress();
    setTypedText((prev) => prev + ' ');
  };

  const handleEnter = () => {
    soundManager.playKeypress();
    setTypedText((prev) => prev + '\n');
  };

  const handleCopy = () => {
    if (!typedText) return;
    navigator.clipboard.writeText(typedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const row1 = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '='];
  const row2 = ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']'];
  const row3 = ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', "'"];
  const row4 = ['z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/'];

  return (
    <AnimatePresence>
      <div
        id="touch-keyboard-backdrop"
        className="fixed inset-0 z-[10000] pointer-events-none flex items-end justify-center pb-14 px-4"
      >
        <motion.div
          id="touch-keyboard-panel"
          initial={{ opacity: 0, y: 60, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 60, scale: 0.96 }}
          transition={{ type: 'spring', damping: 25, stiffness: 350 }}
          className="pointer-events-auto w-full max-w-3xl acrylic-blur bg-white/95 dark:bg-[#1f1f1f]/95 rounded-2xl shadow-2xl border border-white/60 dark:border-white/10 p-3 flex flex-col gap-2 select-none backdrop-blur-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header Bar */}
          <div className="flex items-center justify-between px-2 pb-1 border-b border-slate-200/60 dark:border-zinc-800/60">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-200">
              <Keyboard size={16} className="text-sky-500" />
              <span>Bàn phím cảm ứng (Touch Keyboard)</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium text-slate-600 dark:text-zinc-300 hover:bg-slate-200/60 dark:hover:bg-zinc-800/60 transition-colors"
                title="Sao chép nội dung vừa gõ"
              >
                {copied ? <Check size={12} className="text-emerald-500" /> : <Copy size={12} />}
                <span>{copied ? 'Đã chép' : 'Sao chép'}</span>
              </button>
              <button
                onClick={onClose}
                className="w-6 h-6 rounded flex items-center justify-center text-slate-500 hover:bg-red-500 hover:text-white transition-colors"
                title="Đóng bàn phím"
              >
                <X size={14} />
              </button>
            </div>
          </div>

          {/* Text preview input */}
          <div className="px-1">
            <div className="w-full min-h-[32px] max-h-[60px] overflow-y-auto px-3 py-1.5 text-xs bg-slate-100/80 dark:bg-black/40 rounded-lg border border-slate-200/60 dark:border-zinc-700/60 text-slate-800 dark:text-slate-100 font-sans break-all">
              {typedText || <span className="text-slate-400 italic">Nhấn các phím bên dưới để gõ...</span>}
            </div>
          </div>

          {/* Keyboard Grid */}
          <div className="flex flex-col gap-1.5 p-1">
            {/* Number Row */}
            <div className="flex gap-1.5">
              {row1.map((k) => (
                <button
                  key={k}
                  onClick={() => handleKeyPress(k)}
                  className="flex-1 h-9 rounded-lg bg-white dark:bg-[#2b2b2b] hover:bg-slate-100 dark:hover:bg-[#383838] active:scale-95 shadow-sm border border-slate-200/60 dark:border-white/5 text-xs font-semibold text-slate-800 dark:text-slate-100 transition-transform flex items-center justify-center"
                >
                  {k}
                </button>
              ))}
              <button
                onClick={handleBackspace}
                className="w-14 h-9 rounded-lg bg-slate-200/80 dark:bg-[#282828] hover:bg-slate-300 dark:hover:bg-[#353535] active:scale-95 text-xs font-semibold text-slate-800 dark:text-slate-100 flex items-center justify-center"
                title="Backspace"
              >
                <Delete size={16} />
              </button>
            </div>

            {/* QWERTY Row */}
            <div className="flex gap-1.5">
              <button
                onClick={() => setIsCaps((prev) => !prev)}
                className={`w-12 h-9 rounded-lg text-xs font-bold transition-colors flex items-center justify-center ${
                  isCaps
                    ? 'bg-sky-500 text-white shadow-sm'
                    : 'bg-slate-200/80 dark:bg-[#282828] hover:bg-slate-300 dark:hover:bg-[#353535] text-slate-800 dark:text-slate-100'
                }`}
                title="Caps Lock"
              >
                Caps
              </button>
              {row2.map((k) => (
                <button
                  key={k}
                  onClick={() => handleKeyPress(k)}
                  className="flex-1 h-9 rounded-lg bg-white dark:bg-[#2b2b2b] hover:bg-slate-100 dark:hover:bg-[#383838] active:scale-95 shadow-sm border border-slate-200/60 dark:border-white/5 text-xs font-semibold text-slate-800 dark:text-slate-100 transition-transform flex items-center justify-center uppercase"
                >
                  {isShift || isCaps ? k.toUpperCase() : k}
                </button>
              ))}
            </div>

            {/* ASDF Row */}
            <div className="flex gap-1.5 pl-3">
              {row3.map((k) => (
                <button
                  key={k}
                  onClick={() => handleKeyPress(k)}
                  className="flex-1 h-9 rounded-lg bg-white dark:bg-[#2b2b2b] hover:bg-slate-100 dark:hover:bg-[#383838] active:scale-95 shadow-sm border border-slate-200/60 dark:border-white/5 text-xs font-semibold text-slate-800 dark:text-slate-100 transition-transform flex items-center justify-center uppercase"
                >
                  {isShift || isCaps ? k.toUpperCase() : k}
                </button>
              ))}
              <button
                onClick={handleEnter}
                className="w-16 h-9 rounded-lg bg-sky-500 hover:bg-sky-600 text-white active:scale-95 text-xs font-semibold flex items-center justify-center gap-1 shadow-sm"
                title="Enter"
              >
                <CornerDownLeft size={14} />
              </button>
            </div>

            {/* ZXCV Row */}
            <div className="flex gap-1.5">
              <button
                onClick={() => setIsShift((prev) => !prev)}
                className={`w-14 h-9 rounded-lg text-xs font-bold transition-colors flex items-center justify-center ${
                  isShift
                    ? 'bg-sky-500 text-white shadow-sm'
                    : 'bg-slate-200/80 dark:bg-[#282828] hover:bg-slate-300 dark:hover:bg-[#353535] text-slate-800 dark:text-slate-100'
                }`}
                title="Shift"
              >
                <ArrowUp size={15} />
              </button>
              {row4.map((k) => (
                <button
                  key={k}
                  onClick={() => handleKeyPress(k)}
                  className="flex-1 h-9 rounded-lg bg-white dark:bg-[#2b2b2b] hover:bg-slate-100 dark:hover:bg-[#383838] active:scale-95 shadow-sm border border-slate-200/60 dark:border-white/5 text-xs font-semibold text-slate-800 dark:text-slate-100 transition-transform flex items-center justify-center uppercase"
                >
                  {isShift || isCaps ? k.toUpperCase() : k}
                </button>
              ))}
            </div>

            {/* Bottom Space Row */}
            <div className="flex gap-1.5 pt-0.5">
              <button
                onClick={() => handleKeyPress('🌐')}
                className="w-12 h-9 rounded-lg bg-slate-200/80 dark:bg-[#282828] hover:bg-slate-300 dark:hover:bg-[#353535] text-slate-700 dark:text-slate-200 text-xs flex items-center justify-center"
                title="Language"
              >
                <Globe size={15} />
              </button>
              <button
                onClick={() => handleKeyPress('✨')}
                className="w-12 h-9 rounded-lg bg-slate-200/80 dark:bg-[#282828] hover:bg-slate-300 dark:hover:bg-[#353535] text-amber-500 text-xs flex items-center justify-center"
                title="Emojis"
              >
                <Sparkles size={15} />
              </button>
              <button
                onClick={handleSpace}
                className="flex-1 h-9 rounded-lg bg-white dark:bg-[#2b2b2b] hover:bg-slate-100 dark:hover:bg-[#383838] active:scale-95 shadow-sm border border-slate-200/60 dark:border-white/5 text-xs font-medium text-slate-500 dark:text-slate-400 flex items-center justify-center"
              >
                Space
              </button>
              <button
                onClick={() => setTypedText('')}
                className="px-3 h-9 rounded-lg bg-slate-200/80 dark:bg-[#282828] hover:bg-red-500 hover:text-white active:scale-95 text-xs font-medium text-slate-700 dark:text-slate-300 transition-colors"
                title="Xóa trắng"
              >
                Xóa
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
