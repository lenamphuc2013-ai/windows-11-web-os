import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PenTool, Crop, Image, StickyNote, X, Settings } from 'lucide-react';
import { useOS } from '../../context/OSContext';

interface InkWorkspaceFlyoutProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InkWorkspaceFlyout: React.FC<InkWorkspaceFlyoutProps> = ({ isOpen, onClose }) => {
  const { openApp, addNotification } = useOS();

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div
        id="ink-workspace-backdrop"
        className="fixed inset-0 z-[10000] pointer-events-none flex items-end justify-end pb-14 pr-8"
      >
        <motion.div
          id="ink-workspace-panel"
          initial={{ opacity: 0, y: 30, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 30, scale: 0.95 }}
          transition={{ type: 'spring', damping: 25, stiffness: 350 }}
          className="pointer-events-auto w-80 acrylic-blur bg-white/95 dark:bg-[#1f1f1f]/95 rounded-2xl shadow-2xl border border-white/60 dark:border-white/10 p-3 select-none backdrop-blur-2xl flex flex-col gap-3"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-1 pb-1 border-b border-slate-200/60 dark:border-zinc-800/60">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-100">
              <PenTool size={16} className="text-sky-500" />
              <span>Windows Ink Workspace</span>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  onClose();
                  openApp('settings');
                }}
                className="w-6 h-6 rounded flex items-center justify-center text-slate-500 hover:bg-slate-200/60 dark:hover:bg-zinc-800/60 transition-colors"
                title="Cài đặt Bút & Windows Ink"
              >
                <Settings size={13} />
              </button>
              <button
                onClick={onClose}
                className="w-6 h-6 rounded flex items-center justify-center text-slate-500 hover:bg-red-500 hover:text-white transition-colors"
                title="Đóng"
              >
                <X size={14} />
              </button>
            </div>
          </div>

          {/* Quick Action Tiles */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                onClose();
                openApp('paint');
              }}
              className="flex flex-col items-center justify-center gap-2 p-3 rounded-xl bg-slate-100/80 dark:bg-white/5 hover:bg-sky-500/10 dark:hover:bg-white/10 border border-slate-200/50 dark:border-white/5 transition-all text-center group"
            >
              <div className="w-10 h-10 rounded-full bg-blue-500/10 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Image size={20} />
              </div>
              <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-200">
                Bảng vẽ Paint
              </span>
            </button>

            <button
              onClick={() => {
                onClose();
                openApp('snippingtool');
              }}
              className="flex flex-col items-center justify-center gap-2 p-3 rounded-xl bg-slate-100/80 dark:bg-white/5 hover:bg-sky-500/10 dark:hover:bg-white/10 border border-slate-200/50 dark:border-white/5 transition-all text-center group"
            >
              <div className="w-10 h-10 rounded-full bg-amber-500/10 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Crop size={20} />
              </div>
              <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-200">
                Cắt toàn màn hình
              </span>
            </button>
          </div>

          {/* Sticky Notes Quick Tile */}
          <button
            onClick={() => {
              onClose();
              openApp('notepad', {
                fileName: 'Ghi-chu-nhanh.txt',
                content: 'Ghi chú nhanh từ Windows Ink Workspace...',
              });
              addNotification('Windows Ink', 'Đã mở Ghi chú nhanh (Quick Sticky Notes)', 'notepad');
            }}
            className="flex items-center gap-3 p-2.5 rounded-xl bg-amber-500/10 dark:bg-amber-500/15 hover:bg-amber-500/20 border border-amber-500/30 transition-all text-left"
          >
            <div className="w-8 h-8 rounded-lg bg-amber-500 text-white flex items-center justify-center shrink-0">
              <StickyNote size={18} />
            </div>
            <div>
              <div className="text-xs font-semibold text-amber-900 dark:text-amber-200">
                Ghi chú dán (Sticky Notes)
              </div>
              <div className="text-[10px] text-amber-800/70 dark:text-amber-300/70">
                Tạo ghi chú nhanh trên màn hình
              </div>
            </div>
          </button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
