import React from 'react';
import {
  Sun,
  CloudSun,
  CloudRain,
  TrendingUp,
  TrendingDown,
  Globe,
  Trophy,
  ExternalLink,
} from 'lucide-react';

interface WidgetsPanelProps {
  onClose: () => void;
}

export const WidgetsPanel: React.FC<WidgetsPanelProps> = ({ onClose }) => {
  return (
    <div
      onClick={(e) => e.stopPropagation()}
      className="fixed bottom-14 left-3 w-96 max-h-[85vh] bg-white/80 dark:bg-[#1e1e1e]/85 backdrop-blur-2xl rounded-2xl border border-white/20 dark:border-white/10 shadow-2xl p-4 text-slate-800 dark:text-slate-100 select-none z-50 animate-win11-flyin overflow-y-auto space-y-4"
    >
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-zinc-800">
        <h2 className="font-bold text-sm">Widgets Board</h2>
        <span className="text-[11px] text-slate-400">Windows 11 Live Feeds</span>
      </div>

      {/* Weather Widget */}
      <div className="p-4 rounded-2xl bg-gradient-to-br from-sky-500 to-blue-600 text-white shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold opacity-90">Hanoi, Vietnam</div>
            <div className="text-3xl font-extrabold tracking-tight">28°C</div>
            <div className="text-[11px] opacity-80">Partly Cloudy • Humidity 65%</div>
          </div>
          <CloudSun size={48} className="text-amber-300 drop-shadow" />
        </div>

        {/* 4-day forecast */}
        <div className="grid grid-cols-4 pt-2 border-t border-white/20 text-center text-[11px]">
          <div>
            <div className="opacity-75">Thu</div>
            <Sun size={16} className="mx-auto my-1 text-amber-300" />
            <div className="font-bold">30°</div>
          </div>
          <div>
            <div className="opacity-75">Fri</div>
            <CloudSun size={16} className="mx-auto my-1 text-amber-300" />
            <div className="font-bold">29°</div>
          </div>
          <div>
            <div className="opacity-75">Sat</div>
            <CloudRain size={16} className="mx-auto my-1 text-sky-200" />
            <div className="font-bold">26°</div>
          </div>
          <div>
            <div className="opacity-75">Sun</div>
            <Sun size={16} className="mx-auto my-1 text-amber-300" />
            <div className="font-bold">31°</div>
          </div>
        </div>
      </div>

      {/* Stock Markets */}
      <div className="p-3.5 rounded-2xl bg-white dark:bg-zinc-800/80 border border-slate-200 dark:border-zinc-700/60 shadow-sm space-y-2">
        <div className="font-bold text-xs flex items-center justify-between">
          <span>Watchlist</span>
          <TrendingUp size={14} className="text-emerald-500" />
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs">
          {[
            { symbol: 'MSFT', name: 'Microsoft', price: '$420.55', change: '+1.42%', up: true },
            { symbol: 'GOOGL', name: 'Alphabet', price: '$178.20', change: '+0.88%', up: true },
            { symbol: 'NVDA', name: 'NVIDIA', price: '$128.90', change: '+3.15%', up: true },
            { symbol: 'AAPL', name: 'Apple Inc.', price: '$224.30', change: '-0.32%', up: false },
          ].map((st) => (
            <div key={st.symbol} className="p-2 rounded-xl bg-slate-100 dark:bg-zinc-700/50">
              <div className="font-bold">{st.symbol}</div>
              <div className="text-[10px] text-slate-400 truncate">{st.name}</div>
              <div className="flex items-center justify-between mt-1">
                <span className="font-mono font-semibold">{st.price}</span>
                <span
                  className={`text-[10px] font-bold ${
                    st.up ? 'text-emerald-500' : 'text-red-500'
                  }`}
                >
                  {st.change}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Top Stories News */}
      <div className="space-y-2">
        <span className="font-bold text-xs text-slate-400 uppercase tracking-wider">Top Stories</span>
        {[
          {
            title: 'HTML5 Web OS Revolution: Fast In-Browser Executable Environments',
            source: 'TechRadar',
            time: '2h ago',
          },
          {
            title: 'Next-Gen AI Systems Powering Productivity in Modern Desktops',
            source: 'Verge',
            time: '4h ago',
          },
        ].map((news, i) => (
          <div
            key={i}
            className="p-3 rounded-2xl bg-white dark:bg-zinc-800/80 border border-slate-200 dark:border-zinc-700/60 shadow-sm hover:border-sky-500 cursor-pointer transition-colors"
          >
            <div className="font-semibold text-xs leading-snug">{news.title}</div>
            <div className="flex items-center gap-2 mt-1.5 text-[10px] text-slate-400">
              <span className="font-medium text-sky-500">{news.source}</span>
              <span>•</span>
              <span>{news.time}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
