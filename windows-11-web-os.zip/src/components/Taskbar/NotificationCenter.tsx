import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { IconRenderer } from '../Common/IconRenderer';
import {
  Bell,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Moon,
  Check,
} from 'lucide-react';

interface NotificationCenterProps {
  onClose: () => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({ onClose }) => {
  const { notifications, clearNotifications } = useOS();
  const [currentDate, setCurrentDate] = useState(new Date());

  const daysOfWeek = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

  // Calendar calculations
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));

  const today = new Date();
  const isCurrentMonth = today.getFullYear() === year && today.getMonth() === month;

  return (
    <div
      onClick={(e) => e.stopPropagation()}
      className="fixed bottom-14 right-3 w-88 bg-white/80 dark:bg-[#202020]/85 backdrop-blur-2xl rounded-2xl border border-white/20 dark:border-white/10 shadow-2xl p-4 text-slate-800 dark:text-slate-100 select-none z-50 animate-win11-flyin flex flex-col gap-4 max-h-[85vh] overflow-hidden"
    >
      {/* Notifications Header */}
      <div className="flex items-center justify-between">
        <span className="font-bold text-xs">Notifications</span>
        {notifications.length > 0 && (
          <button
            onClick={clearNotifications}
            className="text-[11px] text-sky-600 dark:text-sky-400 hover:underline flex items-center gap-1"
          >
            <Trash2 size={12} /> Clear all
          </button>
        )}
      </div>

      {/* Notifications List */}
      <div className="max-h-40 overflow-y-auto space-y-2">
        {notifications.length === 0 ? (
          <div className="text-center py-4 text-slate-400 text-xs italic">
            No new notifications
          </div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              className="p-3 rounded-xl bg-white dark:bg-zinc-800/90 border border-slate-200 dark:border-zinc-700/60 shadow-sm space-y-1"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 font-bold text-xs">
                  <IconRenderer name={n.appIcon || 'Bell'} size={14} />
                  <span>{n.title}</span>
                </div>
                <span className="text-[10px] text-slate-400">
                  {n.timestamp instanceof Date
                    ? n.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                    : typeof n.timestamp === 'number'
                    ? new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                    : String(n.timestamp || '')}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 dark:text-zinc-300">{n.message}</p>
            </div>
          ))
        )}
      </div>

      {/* Calendar Section */}
      <div className="pt-3 border-t border-slate-200 dark:border-zinc-800">
        <div className="flex items-center justify-between mb-2">
          <span className="font-bold text-xs">
            {currentDate.toLocaleString('default', { month: 'long' })} {year}
          </span>
          <div className="flex items-center gap-1">
            <button
              onClick={prevMonth}
              className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-700 transition-colors"
            >
              <ChevronLeft size={15} />
            </button>
            <button
              onClick={nextMonth}
              className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-700 transition-colors"
            >
              <ChevronRight size={15} />
            </button>
          </div>
        </div>

        {/* Days of week */}
        <div className="grid grid-cols-7 text-center font-semibold text-[10px] text-slate-400 mb-1">
          {daysOfWeek.map((d) => (
            <div key={d}>{d}</div>
          ))}
        </div>

        {/* Calendar Day Grid */}
        <div className="grid grid-cols-7 text-center text-xs gap-y-1">
          {Array.from({ length: firstDay }).map((_, i) => (
            <div key={'empty-' + i} />
          ))}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const dayNum = i + 1;
            const isToday = isCurrentMonth && today.getDate() === dayNum;
            return (
              <div
                key={dayNum}
                className={`w-7 h-7 mx-auto rounded-full flex items-center justify-center font-medium cursor-pointer transition-all ${
                  isToday
                    ? 'bg-sky-500 text-white font-bold shadow'
                    : 'hover:bg-slate-200 dark:hover:bg-zinc-700'
                }`}
              >
                {dayNum}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
