import React, { useState, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import { soundManager } from '../../utils/sound';
import {
  Wifi,
  WifiOff,
  Bluetooth,
  Moon,
  Sun,
  Volume2,
  Volume1,
  VolumeX,
  SunMedium,
  SunDim,
  BatteryCharging,
  Battery,
  Settings,
  Plane,
  ChevronRight,
  ChevronLeft,
  Check,
  Zap,
  Headphones,
  Mouse,
  RefreshCw,
} from 'lucide-react';

interface QuickSettingsProps {
  onClose: () => void;
}

type QuickSettingsSubpage = 'main' | 'wifi' | 'bluetooth';

export const QuickSettings: React.FC<QuickSettingsProps> = ({ onClose }) => {
  const { settings, updateSettings, openApp, addNotification } = useOS();
  const [subpage, setSubpage] = useState<QuickSettingsSubpage>('main');

  // Real Battery API State
  const [batteryLevel, setBatteryLevel] = useState<number>(98);
  const [isCharging, setIsCharging] = useState<boolean>(true);

  useEffect(() => {
    let batteryObj: any = null;

    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        batteryObj = battery;
        const updateBattery = () => {
          setBatteryLevel(Math.round(battery.level * 100));
          setIsCharging(battery.charging);
        };
        updateBattery();
        battery.addEventListener('levelchange', updateBattery);
        battery.addEventListener('chargingchange', updateBattery);
      }).catch(() => {});
    }

    return () => {
      if (batteryObj) {
        try {
          batteryObj.removeEventListener('levelchange', () => {});
          batteryObj.removeEventListener('chargingchange', () => {});
        } catch (e) {}
      }
    };
  }, []);

  // Action status calculations
  const isWifiActive = settings.isWifiOn && !settings.isAirplaneMode;
  const isBluetoothActive = settings.isBluetoothOn && !settings.isAirplaneMode;
  const isDark = settings.theme === 'dark';
  const isAudioActive = settings.soundEnabled && settings.volume > 0;
  const isAirplaneActive = !!settings.isAirplaneMode;
  const isBatterySaverActive = !!settings.isBatterySaver;

  // Toggle Handlers
  const handleToggleWifi = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (isWifiActive) {
      updateSettings({ isWifiOn: false });
      soundManager.playClick();
      addNotification('Mạng Wi-Fi', 'Đã tắt kết nối Wi-Fi', 'network');
    } else {
      updateSettings({ isWifiOn: true, isAirplaneMode: false });
      soundManager.playNotification();
      addNotification('Mạng Wi-Fi', `Đã kết nối với ${settings.wifiNetwork || 'Lenamphuc_5G_VIP'}`, 'network');
    }
  };

  const handleToggleBluetooth = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (isBluetoothActive) {
      updateSettings({ isBluetoothOn: false });
      soundManager.playClick();
      addNotification('Bluetooth', 'Đã tắt kết nối Bluetooth', 'system');
    } else {
      updateSettings({ isBluetoothOn: true, isAirplaneMode: false });
      soundManager.playNotification();
      addNotification('Bluetooth', 'Bluetooth đã bật. Đang sẵn sàng ghép đôi thiết bị.', 'system');
    }
  };

  const handleToggleTheme = () => {
    const newTheme = isDark ? 'light' : 'dark';
    updateSettings({ theme: newTheme });
    soundManager.playClick();
    addNotification('Giao diện', `Đã chuyển sang chế độ ${newTheme === 'dark' ? 'Tối (Dark mode)' : 'Sáng (Light mode)'}`, 'system');
  };

  const handleToggleAudio = () => {
    if (isAudioActive) {
      updateSettings({ soundEnabled: false });
      soundManager.playClick();
      addNotification('Âm thanh', 'Đã tắt tiếng (Muted)', 'system');
    } else {
      const vol = settings.volume === 0 ? 75 : settings.volume;
      updateSettings({ soundEnabled: true, volume: vol });
      soundManager.setVolume(vol);
      soundManager.playVolumeBeep();
      addNotification('Âm thanh', `Đã bật âm thanh (${vol}%)`, 'system');
    }
  };

  const handleToggleAirplane = () => {
    if (isAirplaneActive) {
      updateSettings({ isAirplaneMode: false, isWifiOn: true, isBluetoothOn: true });
      soundManager.playNotification();
      addNotification('Chế độ máy bay', 'Đã tắt chế độ máy bay. Đã khôi phục Wi-Fi và Bluetooth.', 'system');
    } else {
      updateSettings({ isAirplaneMode: true, isWifiOn: false, isBluetoothOn: false });
      soundManager.playClick();
      addNotification('Chế độ máy bay', 'Đã bật chế độ máy bay (Đã tắt Wi-Fi và Bluetooth).', 'system');
    }
  };

  const handleToggleBatterySaver = () => {
    if (isBatterySaverActive) {
      updateSettings({ isBatterySaver: false });
      soundManager.playClick();
      addNotification('Tiết kiệm pin', 'Đã tắt chế độ Tiết kiệm pin (Hiệu năng tiêu chuẩn)', 'system');
    } else {
      updateSettings({
        isBatterySaver: true,
        brightness: Math.min(settings.brightness, 60),
      });
      soundManager.playNotification();
      addNotification('Tiết kiệm pin', 'Đã bật chế độ Tiết kiệm pin (Giảm độ sáng và tiết kiệm năng lượng)', 'system');
    }
  };

  // Slider change handlers
  const handleBrightnessChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value);
    updateSettings({ brightness: val });
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value);
    updateSettings({
      volume: val,
      soundEnabled: val > 0,
    });
    soundManager.setVolume(val);
    soundManager.playVolumeBeep();
  };

  // Available Wi-Fi Networks list
  const wifiList = [
    { name: settings.wifiNetwork || 'Lenamphuc_5G_VIP', signal: '5G', connected: isWifiActive, secured: true },
    { name: 'Windows11_HighSpeed', signal: '5G', connected: false, secured: true },
    { name: 'Home_Office_Network', signal: '2.4G', connected: false, secured: true },
    { name: 'Coffee_Free_WiFi', signal: 'Free', connected: false, secured: false },
  ];

  // Paired Bluetooth Devices list
  const bluetoothList = [
    { name: 'Lenamphuc AirPods Max', type: 'audio', battery: '95%', connected: isBluetoothActive },
    { name: 'Windows Precision Wireless Mouse', type: 'mouse', battery: '82%', connected: isBluetoothActive },
    { name: 'Bluetooth Mechanical Keyboard', type: 'keyboard', battery: '100%', connected: isBluetoothActive },
  ];

  return (
    <div
      onClick={(e) => e.stopPropagation()}
      className="fixed bottom-14 right-3 w-88 bg-slate-100/90 dark:bg-[#1f1f1f]/90 backdrop-blur-2xl rounded-2xl border border-white/30 dark:border-white/10 shadow-2xl p-4 text-slate-800 dark:text-slate-100 select-none z-50 animate-win11-flyin transition-all duration-200"
      style={{
        boxShadow: '0 20px 40px rgba(0, 0, 0, 0.35)',
      }}
    >
      {/* SUBPAGE: WI-FI SELECTOR */}
      {subpage === 'wifi' && (
        <div className="animate-win11-fade">
          <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-200 dark:border-white/10">
            <button
              onClick={() => setSubpage('main')}
              className="p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/10 text-slate-600 dark:text-slate-300 flex items-center gap-1 text-xs font-semibold"
            >
              <ChevronLeft size={16} />
              <span>Quay lại</span>
            </button>
            <span className="text-xs font-bold text-slate-700 dark:text-slate-200">Mạng Wi-Fi</span>
            <button
              onClick={() => handleToggleWifi()}
              className={`text-xs px-2.5 py-1 rounded-md font-semibold transition-colors ${
                isWifiActive ? 'bg-sky-500 text-white' : 'bg-slate-300 dark:bg-zinc-700 text-slate-700 dark:text-slate-200'
              }`}
            >
              {isWifiActive ? 'Đang Bật' : 'Đang Tắt'}
            </button>
          </div>

          <div className="space-y-1.5 max-h-60 overflow-y-auto pr-1">
            {wifiList.map((net, i) => (
              <div
                key={i}
                onClick={() => {
                  if (net.connected) {
                    handleToggleWifi();
                  } else {
                    updateSettings({ wifiNetwork: net.name, isWifiOn: true, isAirplaneMode: false });
                    soundManager.playNotification();
                    addNotification('Wi-Fi', `Đã kết nối với "${net.name}"`, 'network');
                  }
                }}
                className={`p-2.5 rounded-xl text-xs flex items-center justify-between cursor-pointer transition-all ${
                  net.connected && isWifiActive
                    ? 'bg-sky-500/15 border border-sky-500/40 text-sky-600 dark:text-sky-400 font-semibold'
                    : 'hover:bg-black/5 dark:hover:bg-white/5 border border-transparent text-slate-700 dark:text-slate-200'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Wifi size={16} className={net.connected && isWifiActive ? 'text-sky-500' : 'text-slate-400'} />
                  <div>
                    <div className="font-medium">{net.name}</div>
                    <div className="text-[10px] opacity-70">
                      {net.connected && isWifiActive ? 'Đã kết nối, an toàn' : net.secured ? 'Được bảo mật' : 'Mạng mở'}
                    </div>
                  </div>
                </div>

                {net.connected && isWifiActive ? (
                  <span className="flex items-center gap-1 text-[11px] text-sky-500 font-semibold">
                    <Check size={14} /> Đang dùng
                  </span>
                ) : (
                  <span className="text-[11px] text-slate-400 font-normal">Kết nối</span>
                )}
              </div>
            ))}
          </div>

          <div className="pt-3 mt-3 border-t border-slate-200 dark:border-white/10 flex items-center justify-between text-xs">
            <button
              onClick={() => {
                openApp('settings', { page: 'network' });
                onClose();
              }}
              className="text-sky-500 hover:underline flex items-center gap-1 font-medium"
            >
              Cài đặt mạng khác
            </button>
          </div>
        </div>
      )}

      {/* SUBPAGE: BLUETOOTH DEVICES */}
      {subpage === 'bluetooth' && (
        <div className="animate-win11-fade">
          <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-200 dark:border-white/10">
            <button
              onClick={() => setSubpage('main')}
              className="p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/10 text-slate-600 dark:text-slate-300 flex items-center gap-1 text-xs font-semibold"
            >
              <ChevronLeft size={16} />
              <span>Quay lại</span>
            </button>
            <span className="text-xs font-bold text-slate-700 dark:text-slate-200">Bluetooth</span>
            <button
              onClick={() => handleToggleBluetooth()}
              className={`text-xs px-2.5 py-1 rounded-md font-semibold transition-colors ${
                isBluetoothActive ? 'bg-sky-500 text-white' : 'bg-slate-300 dark:bg-zinc-700 text-slate-700 dark:text-slate-200'
              }`}
            >
              {isBluetoothActive ? 'Đang Bật' : 'Đang Tắt'}
            </button>
          </div>

          <div className="space-y-1.5 max-h-60 overflow-y-auto pr-1">
            {bluetoothList.map((dev, i) => (
              <div
                key={i}
                onClick={() => {
                  if (!isBluetoothActive) {
                    updateSettings({ isBluetoothOn: true, isAirplaneMode: false });
                  }
                  soundManager.playClick();
                  addNotification('Bluetooth', `Đã kết nối với thiết bị: ${dev.name}`, 'system');
                }}
                className={`p-2.5 rounded-xl text-xs flex items-center justify-between cursor-pointer transition-all ${
                  dev.connected && isBluetoothActive
                    ? 'bg-sky-500/15 border border-sky-500/40 text-sky-600 dark:text-sky-400 font-semibold'
                    : 'hover:bg-black/5 dark:hover:bg-white/5 border border-transparent text-slate-700 dark:text-slate-200'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  {dev.type === 'audio' ? (
                    <Headphones size={16} className={isBluetoothActive ? 'text-sky-500' : 'text-slate-400'} />
                  ) : dev.type === 'mouse' ? (
                    <Mouse size={16} className={isBluetoothActive ? 'text-sky-500' : 'text-slate-400'} />
                  ) : (
                    <Bluetooth size={16} className={isBluetoothActive ? 'text-sky-500' : 'text-slate-400'} />
                  )}
                  <div>
                    <div className="font-medium">{dev.name}</div>
                    <div className="text-[10px] opacity-70">
                      {isBluetoothActive ? `Đã kết nối • Pin ${dev.battery}` : 'Đã ngắt kết nối'}
                    </div>
                  </div>
                </div>

                {isBluetoothActive && (
                  <span className="flex items-center gap-1 text-[11px] text-sky-500 font-semibold">
                    <Check size={14} />
                  </span>
                )}
              </div>
            ))}
          </div>

          <div className="pt-3 mt-3 border-t border-slate-200 dark:border-white/10 flex items-center justify-between text-xs">
            <button
              onClick={() => {
                openApp('settings', { page: 'bluetooth' });
                onClose();
              }}
              className="text-sky-500 hover:underline flex items-center gap-1 font-medium"
            >
              Thêm thiết bị Bluetooth
            </button>
          </div>
        </div>
      )}

      {/* MAIN VIEW: 6 TILES GRID + SLIDERS + FOOTER */}
      {subpage === 'main' && (
        <div className="animate-win11-fade">
          {/* Quick Action Buttons Grid (Exact 3x2 Layout from User Image) */}
          <div className="grid grid-cols-3 gap-2.5 mb-3.5">
            {/* 1. Wi-Fi Button */}
            <div className="relative group">
              <button
                id="quick-wifi-toggle"
                onClick={() => handleToggleWifi()}
                className={`w-full flex flex-col items-center justify-center p-3 rounded-2xl font-medium text-xs shadow-sm active:scale-95 transition-all duration-150 ${
                  isWifiActive
                    ? 'bg-[#0078d4] dark:bg-sky-500 text-white shadow-sky-500/20 shadow-md'
                    : 'bg-white/80 dark:bg-zinc-800/80 text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-zinc-700'
                }`}
                title={isWifiActive ? `Wi-Fi: ${settings.wifiNetwork || 'Lenamphuc_5G_VIP'}` : 'Bật Wi-Fi'}
              >
                {isWifiActive ? <Wifi size={20} className="mb-1.5" /> : <WifiOff size={20} className="mb-1.5 opacity-60" />}
                <span className="font-semibold tracking-tight">Wi-Fi</span>
              </button>

              {/* Submenu arrow chevron on hover/focus */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setSubpage('wifi');
                }}
                className={`absolute right-1 top-1 p-1 rounded-full text-xs transition-opacity ${
                  isWifiActive ? 'text-white/80 hover:text-white hover:bg-white/20' : 'text-slate-400 hover:bg-black/10'
                }`}
                title="Xem danh sách mạng Wi-Fi"
              >
                <ChevronRight size={14} />
              </button>
            </div>

            {/* 2. Bluetooth Button */}
            <div className="relative group">
              <button
                id="quick-bluetooth-toggle"
                onClick={() => handleToggleBluetooth()}
                className={`w-full flex flex-col items-center justify-center p-3 rounded-2xl font-medium text-xs shadow-sm active:scale-95 transition-all duration-150 ${
                  isBluetoothActive
                    ? 'bg-[#0078d4] dark:bg-sky-500 text-white shadow-sky-500/20 shadow-md'
                    : 'bg-white/80 dark:bg-zinc-800/80 text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-zinc-700'
                }`}
                title={isBluetoothActive ? 'Bluetooth đang bật' : 'Bật Bluetooth'}
              >
                <Bluetooth size={20} className="mb-1.5" />
                <span className="font-semibold tracking-tight">Bluetooth</span>
              </button>

              {/* Submenu arrow chevron */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setSubpage('bluetooth');
                }}
                className={`absolute right-1 top-1 p-1 rounded-full text-xs transition-opacity ${
                  isBluetoothActive ? 'text-white/80 hover:text-white hover:bg-white/20' : 'text-slate-400 hover:bg-black/10'
                }`}
                title="Xem thiết bị Bluetooth"
              >
                <ChevronRight size={14} />
              </button>
            </div>

            {/* 3. Dark Mode / Light Mode */}
            <button
              id="quick-darkmode-toggle"
              onClick={handleToggleTheme}
              className={`flex flex-col items-center justify-center p-3 rounded-2xl font-medium text-xs shadow-sm active:scale-95 transition-all duration-150 ${
                isDark
                  ? 'bg-[#0078d4] dark:bg-sky-500 text-white shadow-sky-500/20 shadow-md'
                  : 'bg-white/80 dark:bg-zinc-800/80 text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-zinc-700'
              }`}
              title={isDark ? 'Chế độ Tối (Bấm để đổi sang Sáng)' : 'Chế độ Sáng (Bấm để đổi sang Tối)'}
            >
              {isDark ? <Moon size={20} className="mb-1.5" /> : <Sun size={20} className="mb-1.5" />}
              <span className="font-semibold tracking-tight">{isDark ? 'Dark mode' : 'Light mode'}</span>
            </button>

            {/* 4. Audio (Mute / Unmute) */}
            <button
              id="quick-audio-toggle"
              onClick={handleToggleAudio}
              className={`flex flex-col items-center justify-center p-3 rounded-2xl font-medium text-xs shadow-sm active:scale-95 transition-all duration-150 ${
                isAudioActive
                  ? 'bg-[#0078d4] dark:bg-sky-500 text-white shadow-sky-500/20 shadow-md'
                  : 'bg-white/80 dark:bg-zinc-800/80 text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-zinc-700'
              }`}
              title={isAudioActive ? `Âm thanh: ${settings.volume}%` : 'Bật âm thanh'}
            >
              {isAudioActive ? <Volume2 size={20} className="mb-1.5" /> : <VolumeX size={20} className="mb-1.5 text-amber-500" />}
              <span className="font-semibold tracking-tight">Audio</span>
            </button>

            {/* 5. Airplane Mode */}
            <button
              id="quick-airplane-toggle"
              onClick={handleToggleAirplane}
              className={`flex flex-col items-center justify-center p-3 rounded-2xl font-medium text-xs shadow-sm active:scale-95 transition-all duration-150 ${
                isAirplaneActive
                  ? 'bg-[#0078d4] dark:bg-sky-500 text-white shadow-sky-500/20 shadow-md'
                  : 'bg-white/80 dark:bg-zinc-800/80 text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-zinc-700'
              }`}
              title={isAirplaneActive ? 'Tắt chế độ máy bay' : 'Bật chế độ máy bay'}
            >
              <Plane size={20} className="mb-1.5" />
              <span className="font-semibold tracking-tight">Airplane</span>
            </button>

            {/* 6. Battery Saver */}
            <button
              id="quick-battery-toggle"
              onClick={handleToggleBatterySaver}
              className={`flex flex-col items-center justify-center p-3 rounded-2xl font-medium text-xs shadow-sm active:scale-95 transition-all duration-150 ${
                isBatterySaverActive
                  ? 'bg-[#0078d4] dark:bg-sky-500 text-white shadow-sky-500/20 shadow-md'
                  : 'bg-white/80 dark:bg-zinc-800/80 text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-zinc-700'
              }`}
              title={isBatterySaverActive ? 'Tắt chế độ tiết kiệm pin' : 'Bật chế độ tiết kiệm pin'}
            >
              <div className="flex items-center justify-center mb-1.5 relative">
                {isBatterySaverActive ? (
                  <Zap size={20} className="text-amber-300 fill-amber-300" />
                ) : (
                  <span className="text-emerald-500 font-bold text-sm tracking-tighter flex items-center">
                    [⚡]
                  </span>
                )}
              </div>
              <span className="font-semibold tracking-tight">Battery</span>
            </button>
          </div>

          {/* Sliders Card (Grey Container with Brightness & Volume) */}
          <div className="space-y-3.5 bg-black/5 dark:bg-white/5 p-3.5 rounded-2xl mb-3.5 border border-black/5 dark:border-white/5">
            {/* Brightness Slider */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  const newB = settings.brightness > 50 ? 40 : 100;
                  updateSettings({ brightness: newB });
                  soundManager.playClick();
                }}
                className="text-slate-500 hover:text-sky-500 transition-colors shrink-0"
                title={`Độ sáng màn hình: ${settings.brightness}% (Bấm để chuyển nhanh)`}
              >
                {settings.brightness > 60 ? <SunMedium size={18} /> : <SunDim size={18} />}
              </button>

              <div className="relative flex-1 flex items-center">
                <input
                  id="quick-brightness-slider"
                  type="range"
                  min="20"
                  max="100"
                  value={settings.brightness}
                  onChange={handleBrightnessChange}
                  className="w-full accent-[#0078d4] dark:accent-sky-500 cursor-pointer h-2 bg-slate-300/80 dark:bg-zinc-700 rounded-lg appearance-none"
                  style={{
                    background: `linear-gradient(to right, #0078d4 0%, #0078d4 ${((settings.brightness - 20) / 80) * 100}%, rgba(160, 160, 160, 0.3) ${((settings.brightness - 20) / 80) * 100}%, rgba(160, 160, 160, 0.3) 100%)`,
                  }}
                />
              </div>

              <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 w-8 text-right shrink-0">
                {settings.brightness}%
              </span>
            </div>

            {/* Volume Slider */}
            <div className="flex items-center gap-3">
              <button
                onClick={handleToggleAudio}
                className="text-slate-500 hover:text-sky-500 transition-colors shrink-0"
                title={`Âm lượng: ${settings.volume}% (Bấm để tắt/bật tiếng)`}
              >
                {!settings.soundEnabled || settings.volume === 0 ? (
                  <VolumeX size={18} className="text-amber-500" />
                ) : settings.volume < 40 ? (
                  <Volume1 size={18} />
                ) : (
                  <Volume2 size={18} />
                )}
              </button>

              <div className="relative flex-1 flex items-center">
                <input
                  id="quick-volume-slider"
                  type="range"
                  min="0"
                  max="100"
                  value={settings.soundEnabled ? settings.volume : 0}
                  onChange={handleVolumeChange}
                  className="w-full accent-[#0078d4] dark:accent-sky-500 cursor-pointer h-2 bg-slate-300/80 dark:bg-zinc-700 rounded-lg appearance-none"
                  style={{
                    background: `linear-gradient(to right, #0078d4 0%, #0078d4 ${settings.soundEnabled ? settings.volume : 0}%, rgba(160, 160, 160, 0.3) ${settings.soundEnabled ? settings.volume : 0}%, rgba(160, 160, 160, 0.3) 100%)`,
                  }}
                />
              </div>

              <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 w-8 text-right shrink-0">
                {settings.soundEnabled ? `${settings.volume}%` : 'Mute'}
              </span>
            </div>
          </div>

          {/* Bottom Tray: Battery & All Settings */}
          <div className="flex items-center justify-between pt-1 border-t border-slate-200 dark:border-white/10 text-xs">
            <button
              onClick={() => {
                openApp('settings', { page: 'power' });
                onClose();
              }}
              className="flex items-center gap-2 text-slate-600 dark:text-slate-300 hover:text-sky-500 font-medium py-1 px-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              title="Xem chi tiết Pin & Nguồn"
            >
              <span className="text-emerald-500 font-bold text-xs tracking-tighter">
                [⚡]
              </span>
              <span>
                {batteryLevel}% ({isCharging ? 'Fully charged' : 'Đang sử dụng pin'})
              </span>
            </button>

            <button
              id="quick-all-settings-btn"
              onClick={() => {
                openApp('settings');
                onClose();
              }}
              className="p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/10 text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors"
              title="Mở toàn bộ Cài đặt (Win + I)"
            >
              <Settings size={17} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
