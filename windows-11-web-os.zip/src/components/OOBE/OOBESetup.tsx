import React, { useState, useEffect } from 'react';
import {
  Globe,
  Keyboard,
  Wifi,
  User,
  Laptop,
  ShieldCheck,
  Check,
  ChevronRight,
  Search,
  Lock,
  WifiOff,
  Volume2,
  Accessibility,
  Power,
  Sparkles,
  ArrowLeft,
  Eye,
  EyeOff,
  Radio,
  CheckCircle2,
} from 'lucide-react';
import { Win11Spinner } from '../BootScreen/Win11Spinner';
import { soundManager } from '../../utils/sound';

export interface OOBEData {
  region: string;
  keyboardLayout: string;
  secondKeyboardLayout?: string;
  wifiNetwork: string;
  userName: string;
  userEmail: string;
  deviceName: string;
  privacyLocation: boolean;
  privacyDiagnostic: boolean;
  privacyFindDevice: boolean;
  privacyTailored: boolean;
  termsAccepted: boolean;
}

interface OOBESetupProps {
  initialData?: Partial<OOBEData>;
  onComplete: (data: OOBEData) => void;
}

const COUNTRIES = [
  { id: 'VN', name: 'Việt Nam', flag: '🇻🇳' },
  { id: 'US', name: 'United States', flag: '🇺🇸' },
  { id: 'JP', name: 'Japan (日本)', flag: '🇯🇵' },
  { id: 'KR', name: 'South Korea (대한민국)', flag: '🇰🇷' },
  { id: 'GB', name: 'United Kingdom', flag: '🇬🇧' },
  { id: 'SG', name: 'Singapore', flag: '🇸🇬' },
  { id: 'FR', name: 'France', flag: '🇫🇷' },
  { id: 'DE', name: 'Germany (Deutschland)', flag: '🇩🇪' },
  { id: 'AU', name: 'Australia', flag: '🇦🇺' },
  { id: 'CA', name: 'Canada', flag: '🇨🇦' },
  { id: 'TH', name: 'Thailand (ประเทศไทย)', flag: '🇹🇭' },
  { id: 'TW', name: 'Taiwan (台灣)', flag: '🇹🇼' },
];

const KEYBOARD_LAYOUTS = [
  { id: 'vi_telex', name: 'Tiếng Việt (Telex)', desc: 'Bộ gõ Telex chuẩn Windows 11 (Khuyên dùng)' },
  { id: 'vi_vni', name: 'Tiếng Việt (VNI)', desc: 'Bộ gõ VNI quy tắc phím số' },
  { id: 'en_us', name: 'English (US - QWERTY)', desc: 'Bố cục bàn phím chuẩn quốc tế' },
  { id: 'vi_simple', name: 'Tiếng Việt (Simple Telex)', desc: 'Bộ gõ Telex đơn giản' },
  { id: 'en_uk', name: 'English (United Kingdom)', desc: 'Bố cục bàn phím chuẩn Anh quốc' },
];

const WIFI_NETWORKS = [
  { id: 'wifi-1', name: 'Lenamphuc-5G-UltraSpeed', secure: true, signal: 4, speed: '1200 Mbps (Wi-Fi 6)' },
  { id: 'wifi-2', name: 'FPT_Telecom_Wi-Fi_6_Pro', secure: true, signal: 4, speed: '800 Mbps' },
  { id: 'wifi-3', name: 'VNPT_Fiber_5G_Home', secure: true, signal: 3, speed: '500 Mbps' },
  { id: 'wifi-4', name: 'Viettel_HighSpeed_Mesh', secure: true, signal: 3, speed: '600 Mbps' },
  { id: 'wifi-5', name: 'Ethernet (Cáp mạng LAN)', secure: false, signal: 4, speed: '10 Gbps High Speed' },
];

export const OOBESetup: React.FC<OOBESetupProps> = ({ initialData, onComplete }) => {
  // Wizard step: 1: Region, 2: Keyboard, 3: Second Keyboard, 4: Network, 5: Account, 6: PC Name, 7: Privacy & Terms, 8: Finishing
  const [step, setStep] = useState<number>(1);

  // Form State
  const [region, setRegion] = useState(initialData?.region || 'Việt Nam');
  const [regionSearch, setRegionSearch] = useState('');
  const [keyboardLayout, setKeyboardLayout] = useState(initialData?.keyboardLayout || 'Tiếng Việt (Telex)');
  const [secondLayout, setSecondLayout] = useState<string | undefined>(undefined);

  // Network State
  const [selectedWifi, setSelectedWifi] = useState<string>('Lenamphuc-5G-UltraSpeed');
  const [wifiPassword, setWifiPassword] = useState('lenamphuc2026');
  const [isWifiConnected, setIsWifiConnected] = useState(true);
  const [isConnectingWifi, setIsConnectingWifi] = useState(false);

  // Account State
  const [userEmail, setUserEmail] = useState(initialData?.userEmail || 'lenamphuc2013@gmail.com');
  const [userName, setUserName] = useState(initialData?.userName || 'lenamphuc');
  const [userPassword, setUserPassword] = useState('••••••••');
  const [showPassword, setShowPassword] = useState(false);
  const [isOfflineAccount, setIsOfflineAccount] = useState(false);

  // PC Name State
  const [deviceName, setDeviceName] = useState(initialData?.deviceName || 'LAPTOP-LENAMPHUC');

  // Privacy & Terms State
  const [privacyLocation, setPrivacyLocation] = useState(true);
  const [privacyDiagnostic, setPrivacyDiagnostic] = useState(true);
  const [privacyFindDevice, setPrivacyFindDevice] = useState(true);
  const [privacyTailored, setPrivacyTailored] = useState(true);
  const [termsAccepted, setTermsAccepted] = useState(true);

  // Finishing Screen animation state
  const [finishingPhase, setFinishingPhase] = useState<number>(0);

  // Handle step completion
  const handleNextStep = () => {
    soundManager.playClick();
    if (step < 7) {
      setStep((prev) => prev + 1);
    } else if (step === 7) {
      // Begin Finishing Sequence
      setStep(8);
    }
  };

  const handlePrevStep = () => {
    soundManager.playClick();
    if (step > 1 && step < 8) {
      setStep((prev) => prev - 1);
    }
  };

  // Connecting Wi-Fi Simulation
  const handleConnectWifi = (wifiName: string) => {
    setIsConnectingWifi(true);
    setTimeout(() => {
      setSelectedWifi(wifiName);
      setIsWifiConnected(true);
      setIsConnectingWifi(false);
      soundManager.playClick();
    }, 600);
  };

  // Finishing Phase Sequence (Hi -> Getting ready -> This might take a few minutes -> Almost there -> Desktop)
  useEffect(() => {
    if (step === 8) {
      const phrases = [
        0, // "Xin chào (Hi)"
        1, // "Chúng tôi đang chuẩn bị mọi thứ cho bạn (Getting things ready for you)"
        2, // "Việc này có thể mất vài phút (This might take a few minutes)"
        3, // "Đừng tắt PC của bạn (Don't turn off your PC)"
        4, // "Gần xong rồi (Almost there)"
      ];

      const timer0 = setTimeout(() => setFinishingPhase(1), 2200);
      const timer1 = setTimeout(() => setFinishingPhase(2), 5200);
      const timer2 = setTimeout(() => setFinishingPhase(3), 8200);
      const timer3 = setTimeout(() => setFinishingPhase(4), 11200);
      const timer4 = setTimeout(() => {
        // Complete OOBE and enter desktop
        soundManager.playStartup();
        onComplete({
          region,
          keyboardLayout,
          secondKeyboardLayout: secondLayout,
          wifiNetwork: selectedWifi,
          userName: userName.trim() || 'lenamphuc',
          userEmail: userEmail.trim() || 'lenamphuc2013@gmail.com',
          deviceName: deviceName.trim() || 'LAPTOP-LENAMPHUC',
          privacyLocation,
          privacyDiagnostic,
          privacyFindDevice,
          privacyTailored,
          termsAccepted,
        });
      }, 13800);

      return () => {
        clearTimeout(timer0);
        clearTimeout(timer1);
        clearTimeout(timer2);
        clearTimeout(timer3);
        clearTimeout(timer4);
      };
    }
  }, [
    step,
    region,
    keyboardLayout,
    secondLayout,
    selectedWifi,
    userName,
    userEmail,
    deviceName,
    privacyLocation,
    privacyDiagnostic,
    privacyFindDevice,
    privacyTailored,
    termsAccepted,
    onComplete,
  ]);

  const filteredCountries = COUNTRIES.filter((c) =>
    c.name.toLowerCase().includes(regionSearch.toLowerCase())
  );

  // =========================================================================
  // VIEW: STEP 8 - WINDOWS 11 "GETTING THINGS READY" ANIMATED SCREEN
  // =========================================================================
  if (step === 8) {
    return (
      <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center text-white select-none overflow-hidden font-sans">
        {/* Ambient Pulsing Deep Blue / Cyan Waves */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-40">
          <div className="absolute -top-40 -left-40 w-[600px] h-[600px] bg-[#005a9e]/40 rounded-full blur-[120px] animate-pulse" />
          <div className="absolute -bottom-40 -right-40 w-[600px] h-[600px] bg-[#0078d4]/30 rounded-full blur-[140px] animate-pulse" />
          <div className="absolute top-1/3 left-1/3 w-[500px] h-[500px] bg-[#00b7c3]/20 rounded-full blur-[160px] animate-pulse" />
        </div>

        <div className="relative z-10 flex flex-col items-center justify-center max-w-xl text-center px-6 space-y-6 animate-win11-fade">
          {finishingPhase === 0 && (
            <div className="space-y-3 animate-win11-fade">
              <h1 className="text-4xl sm:text-5xl font-light tracking-tight text-white">Xin chào</h1>
              <p className="text-sm sm:text-base text-zinc-400 font-light">Chào mừng bạn đến với Windows 11</p>
            </div>
          )}

          {finishingPhase === 1 && (
            <div className="space-y-4 animate-win11-fade flex flex-col items-center">
              <Win11Spinner size={46} dotSize={5} color="#0078d4" />
              <h2 className="text-2xl sm:text-3xl font-light tracking-tight text-white">
                Chúng tôi đang chuẩn bị mọi thứ cho bạn
              </h2>
              <p className="text-xs text-zinc-400 font-light">Đang cấu hình tài khoản {userEmail}...</p>
            </div>
          )}

          {finishingPhase === 2 && (
            <div className="space-y-4 animate-win11-fade flex flex-col items-center">
              <Win11Spinner size={46} dotSize={5} color="#38bdf8" />
              <h2 className="text-2xl sm:text-3xl font-light tracking-tight text-white">
                Việc này có thể mất vài phút
              </h2>
              <p className="text-xs text-zinc-400 font-light">Đang áp dụng cài đặt bảo mật và tối ưu hóa hệ thống {deviceName}...</p>
            </div>
          )}

          {finishingPhase === 3 && (
            <div className="space-y-4 animate-win11-fade flex flex-col items-center">
              <Win11Spinner size={46} dotSize={5} color="#22c55e" />
              <h2 className="text-2xl sm:text-3xl font-light tracking-tight text-white">
                Đừng tắt PC của bạn
              </h2>
              <p className="text-xs text-zinc-400 font-light">Đang chuẩn bị màn hình Desktop và nạp các ứng dụng...</p>
            </div>
          )}

          {finishingPhase === 4 && (
            <div className="space-y-4 animate-win11-fade flex flex-col items-center">
              <Win11Spinner size={46} dotSize={5} color="#ffffff" />
              <h2 className="text-2xl sm:text-3xl font-light tracking-tight text-white">
                Gần xong rồi
              </h2>
              <p className="text-xs text-zinc-300 font-light">Windows 11 đã sẵn sàng!</p>
            </div>
          )}
        </div>

        {/* Skip button for instant entry */}
        <button
          onClick={() => {
            soundManager.playStartup();
            onComplete({
              region,
              keyboardLayout,
              secondKeyboardLayout: secondLayout,
              wifiNetwork: selectedWifi,
              userName: userName.trim() || 'lenamphuc',
              userEmail: userEmail.trim() || 'lenamphuc2013@gmail.com',
              deviceName: deviceName.trim() || 'LAPTOP-LENAMPHUC',
              privacyLocation,
              privacyDiagnostic,
              privacyFindDevice,
              privacyTailored,
              termsAccepted,
            });
          }}
          className="absolute bottom-8 px-4 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-xs text-zinc-400 hover:text-white transition-all backdrop-blur-md border border-white/10"
        >
          Nhấp để vào Desktop ngay
        </button>
      </div>
    );
  }

  // =========================================================================
  // MAIN OOBE SETUP WIZARD (STEPS 1 - 7)
  // =========================================================================
  return (
    <div className="fixed inset-0 z-50 bg-[#0d1117] flex items-center justify-center p-4 select-none font-sans overflow-hidden">
      {/* Dynamic Windows 11 Flow Wallpaper / Ambient Backdrop */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-all duration-1000 scale-105 filter blur-[2px] opacity-80"
        style={{
          backgroundImage: `radial-gradient(circle at 50% 50%, #002b49 0%, #081627 50%, #020712 100%)`,
        }}
      />
      {/* Bloom glow spheres */}
      <div className="absolute -top-32 -left-32 w-[550px] h-[550px] bg-[#0078d4]/30 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-[550px] h-[550px] bg-[#00b7c3]/20 rounded-full blur-[140px] pointer-events-none" />

      {/* Central Windows 11 Mica Glass Setup Card */}
      <div className="relative w-full max-w-4xl h-[620px] max-h-[92vh] bg-[#1c222d]/90 backdrop-blur-2xl rounded-3xl border border-white/15 shadow-[0_20px_70px_rgba(0,0,0,0.7)] flex flex-col justify-between overflow-hidden text-slate-100 animate-win11-fade">
        
        {/* Top Mini Bar: Step indicator / Back button */}
        <div className="flex items-center justify-between px-8 pt-6 pb-2">
          <div className="flex items-center gap-3">
            {step > 1 && (
              <button
                onClick={handlePrevStep}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-slate-300 hover:text-white transition-all"
                title="Quay lại"
              >
                <ArrowLeft size={16} />
              </button>
            )}
            <div className="flex items-center gap-2">
              <div className="grid grid-cols-2 gap-0.5 w-4 h-4">
                <div className="bg-[#0078d4] rounded-[1px]" />
                <div className="bg-[#0078d4] rounded-[1px]" />
                <div className="bg-[#0078d4] rounded-[1px]" />
                <div className="bg-[#0078d4] rounded-[1px]" />
              </div>
              <span className="text-xs font-semibold tracking-wider text-slate-300">
                THIẾT LẬP WINDOWS 11 (OOBE)
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span>Bước {step} / 7</span>
            <div className="flex gap-1 ml-2">
              {[1, 2, 3, 4, 5, 6, 7].map((s) => (
                <div
                  key={s}
                  className={`h-1.5 rounded-full transition-all ${
                    s === step
                      ? 'w-5 bg-[#0078d4]'
                      : s < step
                      ? 'w-2 bg-emerald-500'
                      : 'w-2 bg-white/20'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Content Body (Split Left / Right) */}
        <div className="flex-1 px-8 py-4 flex flex-col md:flex-row gap-8 overflow-y-auto">
          
          {/* LEFT SIDE: Step Title & Descriptive Icon */}
          <div className="md:w-5/12 flex flex-col justify-center space-y-4 pr-2">
            {step === 1 && (
              <>
                <div className="w-14 h-14 rounded-2xl bg-sky-500/20 text-sky-400 flex items-center justify-center border border-sky-500/30 shadow-lg">
                  <Globe size={30} />
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white leading-tight">
                  Đây có phải là quốc gia hoặc vùng chính xác không?
                </h1>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Chọn quốc gia của bạn để Windows 11 tự động áp dụng định dạng ngày giờ, múi giờ và nội dung phù hợp.
                </p>
              </>
            )}

            {step === 2 && (
              <>
                <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30 shadow-lg">
                  <Keyboard size={30} />
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white leading-tight">
                  Đây có phải là bố cục bàn phím hoặc phương thức nhập chính xác không?
                </h1>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Nếu bạn sử dụng kiểu gõ Telex hoặc VNI, hãy chọn phương thức nhập Tiếng Việt bên dưới.
                </p>
              </>
            )}

            {step === 3 && (
              <>
                <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 shadow-lg">
                  <Wifi size={30} />
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white leading-tight">
                  Hãy kết nối bạn với mạng
                </h1>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Bạn sẽ cần kết nối internet để tải các bản cập nhật bảo mật mới nhất và hoàn tất thiết lập thiết bị.
                </p>
              </>
            )}

            {step === 4 && (
              <>
                <div className="w-14 h-14 rounded-2xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-500/30 shadow-lg">
                  <User size={30} />
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white leading-tight">
                  Mở khóa trải nghiệm Microsoft của bạn
                </h1>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Đăng nhập bằng tài khoản Microsoft để đồng bộ mật khẩu, OneDrive và các ứng dụng trên mọi thiết bị.
                </p>
              </>
            )}

            {step === 5 && (
              <>
                <div className="w-14 h-14 rounded-2xl bg-sky-500/20 text-sky-400 flex items-center justify-center border border-sky-500/30 shadow-lg">
                  <Laptop size={30} />
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white leading-tight">
                  Hãy đặt tên cho PC của bạn
                </h1>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Đặt tên duy nhất để dễ dàng nhận biết thiết bị này khi kết nối mạng nội bộ hoặc chia sẻ qua Bluetooth / Wi-Fi.
                </p>
              </>
            )}

            {step === 6 && (
              <>
                <div className="w-14 h-14 rounded-2xl bg-teal-500/20 text-teal-400 flex items-center justify-center border border-teal-500/30 shadow-lg">
                  <ShieldCheck size={30} />
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white leading-tight">
                  Chọn cài đặt quyền riêng tư & Điều khoản sử dụng
                </h1>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Xem lại và điều chỉnh các quyền bảo mật cho thiết bị của bạn. Bạn luôn có thể thay đổi các cài đặt này sau trong Settings.
                </p>
              </>
            )}

            {step === 7 && (
              <>
                <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30 shadow-lg">
                  <Sparkles size={30} />
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white leading-tight">
                  Sẵn sàng trải nghiệm Windows 11
                </h1>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Mọi thông tin đã được thiết lập hoàn tất. Nhấp &ldquo;Bắt đầu sử dụng&rdquo; để khởi tạo môi trường làm việc của bạn.
                </p>
              </>
            )}
          </div>

          {/* RIGHT SIDE: Interactive Step Inputs */}
          <div className="md:w-7/12 flex flex-col justify-center">

            {/* STEP 1: CHỌN QUỐC GIA / VÙNG */}
            {step === 1 && (
              <div className="space-y-3">
                <div className="relative">
                  <Search size={14} className="absolute left-3.5 top-3 text-slate-400" />
                  <input
                    type="text"
                    value={regionSearch}
                    onChange={(e) => setRegionSearch(e.target.value)}
                    placeholder="Tìm kiếm quốc gia hoặc vùng..."
                    className="w-full bg-[#131720] border border-white/15 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-[#0078d4] focus:ring-1 focus:ring-[#0078d4]"
                  />
                </div>

                <div className="max-h-72 overflow-y-auto space-y-1.5 pr-1 custom-scrollbar">
                  {filteredCountries.map((c) => {
                    const isSelected = region === c.name;
                    return (
                      <div
                        key={c.id}
                        onClick={() => {
                          setRegion(c.name);
                          soundManager.playClick();
                        }}
                        className={`flex items-center justify-between px-4 py-3 rounded-xl cursor-pointer transition-all border ${
                          isSelected
                            ? 'bg-[#0078d4] text-white font-semibold border-sky-400 shadow-md shadow-sky-600/30'
                            : 'bg-[#151a24] hover:bg-[#1f2633] text-slate-200 border-white/5'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-lg">{c.flag}</span>
                          <span className="text-xs">{c.name}</span>
                        </div>
                        {isSelected && <Check size={16} className="text-white" />}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 2: CHỌN BỐ CỤC BÀN PHÍM */}
            {step === 2 && (
              <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                {KEYBOARD_LAYOUTS.map((kb) => {
                  const isSelected = keyboardLayout === kb.name;
                  return (
                    <div
                      key={kb.id}
                      onClick={() => {
                        setKeyboardLayout(kb.name);
                        soundManager.playClick();
                      }}
                      className={`p-3.5 rounded-xl cursor-pointer transition-all border flex items-start justify-between ${
                        isSelected
                          ? 'bg-[#0078d4] text-white font-semibold border-sky-400 shadow-md shadow-sky-600/30'
                          : 'bg-[#151a24] hover:bg-[#1f2633] text-slate-200 border-white/5'
                      }`}
                    >
                      <div>
                        <div className="text-xs font-bold">{kb.name}</div>
                        <div className={`text-[11px] mt-0.5 ${isSelected ? 'text-sky-100' : 'text-slate-400'}`}>
                          {kb.desc}
                        </div>
                      </div>
                      {isSelected && <Check size={16} className="text-white shrink-0 mt-0.5" />}
                    </div>
                  );
                })}
              </div>
            )}

            {/* STEP 3: KẾT NỐI WI-FI / MẠNG */}
            {step === 3 && (
              <div className="space-y-3">
                <div className="max-h-72 overflow-y-auto space-y-2 pr-1">
                  {WIFI_NETWORKS.map((wf) => {
                    const isConnected = selectedWifi === wf.name && isWifiConnected;
                    return (
                      <div
                        key={wf.id}
                        onClick={() => handleConnectWifi(wf.name)}
                        className={`p-3.5 rounded-xl cursor-pointer transition-all border flex items-center justify-between ${
                          isConnected
                            ? 'bg-emerald-950/40 border-emerald-500/60 text-white'
                            : 'bg-[#151a24] hover:bg-[#1f2633] border-white/5 text-slate-200'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-lg ${isConnected ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/5 text-slate-400'}`}>
                            <Wifi size={18} />
                          </div>
                          <div>
                            <div className="text-xs font-bold flex items-center gap-1.5">
                              <span>{wf.name}</span>
                              {wf.secure && <Lock size={11} className="text-slate-400" />}
                            </div>
                            <div className="text-[11px] text-slate-400 mt-0.5">
                              {wf.speed} • {isConnected ? 'Đã kết nối an toàn (Connected)' : 'Sẵn sàng kết nối'}
                            </div>
                          </div>
                        </div>

                        {isConnected ? (
                          <div className="flex items-center gap-1 text-emerald-400 text-xs font-semibold">
                            <CheckCircle2 size={16} />
                            <span>Đã kết nối</span>
                          </div>
                        ) : (
                          <button className="px-3 py-1 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-medium text-slate-300">
                            Kết nối
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 4: ĐĂNG NHẬP TÀI KHOẢN MICROSOFT */}
            {step === 4 && (
              <div className="space-y-4">
                <div className="p-4 bg-[#151a24] rounded-2xl border border-white/10 space-y-3">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="grid grid-cols-2 gap-0.5 w-4 h-4">
                      <div className="bg-[#f25022] rounded-[1px]" />
                      <div className="bg-[#7fba00] rounded-[1px]" />
                      <div className="bg-[#00a4ef] rounded-[1px]" />
                      <div className="bg-[#ffb900] rounded-[1px]" />
                    </div>
                    <span className="text-xs font-bold text-white">Tài khoản Microsoft</span>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 font-medium mb-1">
                      Email, điện thoại hoặc Skype
                    </label>
                    <input
                      type="text"
                      value={userEmail}
                      onChange={(e) => {
                        setUserEmail(e.target.value);
                        // Extract prefix as username if applicable
                        const prefix = e.target.value.split('@')[0];
                        if (prefix) setUserName(prefix);
                      }}
                      placeholder="lenamphuc2013@gmail.com"
                      className="w-full bg-[#0d1117] border border-white/15 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#0078d4]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 font-medium mb-1">
                      Mật khẩu
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={userPassword}
                        onChange={(e) => setUserPassword(e.target.value)}
                        className="w-full bg-[#0d1117] border border-white/15 rounded-xl px-3.5 py-2 text-xs text-white pr-10 focus:outline-none focus:border-[#0078d4]"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
                      >
                        {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <button
                    onClick={() => {
                      setUserEmail('lenamphuc (Offline Account)');
                      setUserName('lenamphuc');
                      setIsOfflineAccount(true);
                    }}
                    className="text-sky-400 hover:underline"
                  >
                    Tùy chọn đăng nhập / Tài khoản cục bộ
                  </button>
                  <span className="text-slate-500 text-[11px]">Bảo mật bởi Microsoft Security</span>
                </div>
              </div>
            )}

            {/* STEP 5: NHẬP TÊN MÁY TÍNH */}
            {step === 5 && (
              <div className="space-y-4">
                <div className="p-5 bg-[#151a24] rounded-2xl border border-white/10 space-y-3">
                  <label className="block text-xs text-slate-300 font-semibold">
                    Tên PC (Tối đa 15 ký tự, không chứa khoảng trắng đặc biệt)
                  </label>
                  <div className="relative">
                    <Laptop size={16} className="absolute left-3.5 top-3 text-sky-400" />
                    <input
                      type="text"
                      maxLength={15}
                      value={deviceName}
                      onChange={(e) => setDeviceName(e.target.value.toUpperCase().replace(/\s+/g, '-'))}
                      placeholder="LAPTOP-LENAMPHUC"
                      className="w-full bg-[#0d1117] border border-white/15 rounded-xl pl-10 pr-4 py-2.5 text-sm font-mono font-bold tracking-wider text-white focus:outline-none focus:border-[#0078d4]"
                    />
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Ví dụ: <code className="text-sky-400 font-mono">LAPTOP-LENAMPHUC</code>, <code className="text-sky-400 font-mono">LENAMPHUC-PC</code>, <code className="text-sky-400 font-mono">WIN11-PRO</code>.
                  </p>
                </div>
              </div>
            )}

            {/* STEP 6: ĐỒNG Ý ĐIỀU KHOẢN & QUYỀN RIÊNG TƯ */}
            {step === 6 && (
              <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                {/* Privacy Toggle 1 */}
                <div className="p-3 bg-[#151a24] rounded-xl border border-white/5 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-semibold text-white">Vị trí (Location)</div>
                    <div className="text-[11px] text-slate-400">Cho phép các ứng dụng cung cấp thông tin thời tiết và bản đồ chính xác.</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={privacyLocation}
                    onChange={(e) => setPrivacyLocation(e.target.checked)}
                    className="w-4 h-4 accent-[#0078d4] cursor-pointer"
                  />
                </div>

                {/* Privacy Toggle 2 */}
                <div className="p-3 bg-[#151a24] rounded-xl border border-white/5 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-semibold text-white">Tìm thiết bị của tôi (Find My Device)</div>
                    <div className="text-[11px] text-slate-400">Định vị thiết bị trong trường hợp bị thất lạc.</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={privacyFindDevice}
                    onChange={(e) => setPrivacyFindDevice(e.target.checked)}
                    className="w-4 h-4 accent-[#0078d4] cursor-pointer"
                  />
                </div>

                {/* Privacy Toggle 3 */}
                <div className="p-3 bg-[#151a24] rounded-xl border border-white/5 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-semibold text-white">Dữ liệu chẩn đoán (Diagnostic Data)</div>
                    <div className="text-[11px] text-slate-400">Gửi dữ liệu giúp duy trì Windows 11 an toàn và cập nhật.</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={privacyDiagnostic}
                    onChange={(e) => setPrivacyDiagnostic(e.target.checked)}
                    className="w-4 h-4 accent-[#0078d4] cursor-pointer"
                  />
                </div>

                {/* Terms Acceptance Card */}
                <div className="p-3.5 bg-sky-950/30 border border-sky-500/40 rounded-xl space-y-2">
                  <div className="text-xs font-bold text-sky-300">Điều khoản Cấp phép Phần mềm Microsoft</div>
                  <label className="flex items-start gap-2.5 cursor-pointer text-[11px] text-slate-200">
                    <input
                      type="checkbox"
                      checked={termsAccepted}
                      onChange={(e) => setTermsAccepted(e.target.checked)}
                      className="mt-0.5 w-4 h-4 accent-[#0078d4] cursor-pointer"
                    />
                    <span>
                      Tôi đồng ý với Điều khoản dịch vụ của Microsoft, Thỏa thuận Giấy phép Người dùng Cuối (EULA) và Chính sách Quyền riêng tư của Windows 11.
                    </span>
                  </label>
                </div>
              </div>
            )}

            {/* STEP 7: TỔNG QUAN XÁC NHẬN */}
            {step === 7 && (
              <div className="space-y-3">
                <div className="p-4 bg-[#151a24] rounded-2xl border border-white/10 space-y-2.5 text-xs">
                  <div className="flex items-center justify-between pb-2 border-b border-white/10">
                    <span className="text-slate-400">Quốc gia / Vùng:</span>
                    <span className="font-bold text-white">{region}</span>
                  </div>
                  <div className="flex items-center justify-between pb-2 border-b border-white/10">
                    <span className="text-slate-400">Bàn phím:</span>
                    <span className="font-bold text-white">{keyboardLayout}</span>
                  </div>
                  <div className="flex items-center justify-between pb-2 border-b border-white/10">
                    <span className="text-slate-400">Mạng kết nối:</span>
                    <span className="font-bold text-emerald-400">{selectedWifi}</span>
                  </div>
                  <div className="flex items-center justify-between pb-2 border-b border-white/10">
                    <span className="text-slate-400">Tài khoản:</span>
                    <span className="font-bold text-sky-400">{userEmail}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Tên PC:</span>
                    <span className="font-bold font-mono text-amber-400">{deviceName}</span>
                  </div>
                </div>
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-[11px] text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 size={16} className="shrink-0" />
                  <span>Sẵn sàng cài đặt và khởi tạo cấu hình Windows 11 cá nhân hóa của bạn.</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Bar: Action buttons & Accessibility / Power icons */}
        <div className="flex items-center justify-between px-8 py-5 bg-[#141820]/90 border-t border-white/10">
          <div className="flex items-center gap-3 text-slate-400">
            <button className="p-2 hover:bg-white/10 rounded-xl text-slate-300 transition-colors" title="Trợ năng (Ease of Access)">
              <Accessibility size={18} />
            </button>
            <button className="p-2 hover:bg-white/10 rounded-xl text-slate-300 transition-colors" title="Âm lượng (Volume)">
              <Volume2 size={18} />
            </button>
          </div>

          <div className="flex items-center gap-3">
            {step === 5 && (
              <button
                onClick={handleNextStep}
                className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-xs text-slate-300 font-semibold transition-all"
              >
                Bỏ qua lúc này
              </button>
            )}

            <button
              onClick={handleNextStep}
              disabled={step === 6 && !termsAccepted}
              className="flex items-center gap-2 px-7 py-2.5 rounded-xl bg-[#0078d4] hover:bg-[#0067b8] active:scale-95 disabled:opacity-40 disabled:hover:bg-[#0078d4] text-white font-bold text-xs transition-all shadow-lg shadow-[#0078d4]/30"
            >
              <span>{step === 1 ? 'Có (Yes)' : step === 6 ? 'Chấp nhận (Accept)' : step === 7 ? 'Bắt đầu sử dụng' : 'Tiếp theo (Next)'}</span>
              <ChevronRight size={15} />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
