import React, { useState, useEffect } from 'react';
import { Win11Spinner } from './Win11Spinner';
import { soundManager } from '../../utils/sound';
import { OOBESetup, OOBEData } from '../OOBE/OOBESetup';
import { BootState } from '../../types';
import { Power } from 'lucide-react';

interface BootScreenProps {
  bootState: BootState;
  oobeCompleted: boolean;
  userName?: string;
  userEmail?: string;
  deviceName?: string;
  requireLockOnStartup?: boolean;
  onBootComplete: (shouldLock?: boolean) => void;
  onPowerOn: () => void;
  onCompleteOOBE: (data: OOBEData) => void;
}

export const BootScreen: React.FC<BootScreenProps> = ({
  bootState,
  oobeCompleted,
  userName = 'lenamphuc',
  userEmail = 'lenamphuc2013@gmail.com',
  deviceName = 'LAPTOP-LENAMPHUC',
  requireLockOnStartup = true,
  onBootComplete,
  onPowerOn,
  onCompleteOOBE,
}) => {
  // Boot Sequence phases: 'oem' (lenamphuc) -> 'win11_loading' -> 'oobe' (if not completed) OR 'welcome' -> 'desktop'
  const [phase, setPhase] = useState<'oem' | 'win11_loading' | 'oobe' | 'welcome'>('oem');
  const [fadeComplete, setFadeComplete] = useState(false);

  useEffect(() => {
    if (bootState === 'booting') {
      setPhase('oem');
      setFadeComplete(false);

      // Phase 1: Manufacturer OEM Logo (lenamphuc) for 2.0s
      const timer1 = setTimeout(() => {
        setPhase('win11_loading');
      }, 2000);

      // Phase 2: Windows 11 4-square logo + Spinning dots for 2.2s
      const timer2 = setTimeout(() => {
        if (!oobeCompleted) {
          // If first boot or factory reset -> Transition to OOBE
          setPhase('oobe');
        } else if (requireLockOnStartup) {
          // Like genuine Windows 100%: Boot sequence directly hands over to Lock Screen!
          setFadeComplete(true);
          const timerLock = setTimeout(() => {
            onBootComplete(true);
          }, 350);
          return () => clearTimeout(timerLock);
        } else {
          // If lock screen bypassed in settings -> Welcome screen with startup chime
          setPhase('welcome');
          soundManager.playStartup();
        }
      }, 4200);

      // Phase 3 (Only if OOBE completed and requireLockOnStartup is false): Welcome screen for 1.5s -> Desktop
      const timer3 = setTimeout(() => {
        if (oobeCompleted && !requireLockOnStartup) {
          setFadeComplete(true);
          const timer4 = setTimeout(() => {
            onBootComplete(false);
          }, 400);
          return () => clearTimeout(timer4);
        }
      }, 5800);

      return () => {
        clearTimeout(timer1);
        clearTimeout(timer2);
        clearTimeout(timer3);
      };
    }
  }, [bootState, oobeCompleted, requireLockOnStartup, onBootComplete]);

  // Handle immediate skip during normal boot
  const handleSkip = () => {
    if (bootState === 'booting') {
      if (!oobeCompleted) {
        setPhase('oobe');
      } else if (requireLockOnStartup) {
        onBootComplete(true);
      } else {
        soundManager.playStartup();
        onBootComplete(false);
      }
    }
  };

  // Listen for key press or click when shut down to power on PC
  useEffect(() => {
    if (bootState === 'shutdown') {
      const handleKeyDown = (e: KeyboardEvent) => {
        e.preventDefault();
        onPowerOn();
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }
  }, [bootState, onPowerOn]);

  if (bootState === 'desktop') {
    return null;
  }

  // Shutting down state: smooth fade-out with Authentic Windows 11 Spinner and "Đang tắt máy..."
  if (bootState === 'shutting_down') {
    return (
      <div className="fixed inset-0 z-[100] bg-[#000000] flex flex-col items-center justify-center text-white select-none animate-win11-fade transition-opacity duration-700">
        <div className="flex flex-col items-center gap-6">
          <Win11Spinner size={46} dotSize={5} color="#ffffff" />
          <div className="flex items-center gap-2 text-base font-normal tracking-wide text-zinc-200">
            <span>⏳</span>
            <span>Đang tắt máy...</span>
          </div>
        </div>
      </div>
    );
  }

  // Shutdown state: Powered off screen with click or key press to power on
  if (bootState === 'shutdown') {
    return (
      <div
        id="win11-shutdown-screen"
        onClick={onPowerOn}
        className="fixed inset-0 z-[100] bg-black text-white select-none flex flex-col items-center justify-center cursor-pointer group outline-none"
        style={{ backgroundColor: '#000000' }}
      >
        <div className="flex flex-col items-center gap-4 text-center px-4 transition-all duration-500 opacity-60 group-hover:opacity-100">
          <div className="w-16 h-16 rounded-full bg-zinc-900 border border-zinc-700/80 flex items-center justify-center text-zinc-300 group-hover:text-sky-400 group-hover:border-sky-500/60 shadow-xl transition-all group-hover:scale-110">
            <Power size={28} />
          </div>
          <div className="space-y-1">
            <p className="text-sm font-medium text-zinc-200">Máy tính đã tắt nguồn</p>
            <p className="text-xs text-zinc-500">Nhấp chuột hoặc nhấn phím bất kỳ để bật máy</p>
          </div>
        </div>
      </div>
    );
  }

  // Restarting state
  if (bootState === 'restarting') {
    return (
      <div className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center text-white select-none">
        <div className="flex flex-col items-center gap-8 animate-win11-fade">
          {/* Windows 11 4-square logo */}
          <div className="grid grid-cols-2 gap-1.5 w-16 h-16">
            <div className="bg-[#0078D4] rounded-[3px]" />
            <div className="bg-[#0078D4] rounded-[3px]" />
            <div className="bg-[#0078D4] rounded-[3px]" />
            <div className="bg-[#0078D4] rounded-[3px]" />
          </div>

          <div className="flex flex-col items-center gap-4">
            <Win11Spinner size={46} dotSize={5} color="#ffffff" />
            <span className="text-sm font-medium text-zinc-300">Đang khởi động lại...</span>
          </div>
        </div>
      </div>
    );
  }

  // RENDER: OOBE SETUP WIZARD
  if (phase === 'oobe' || bootState === 'oobe') {
    return (
      <OOBESetup
        initialData={{
          userName,
          userEmail,
          deviceName,
          region: 'Việt Nam',
          keyboardLayout: 'Tiếng Việt (Telex)',
        }}
        onComplete={(data) => {
          onCompleteOOBE(data);
        }}
      />
    );
  }

  // Booting State (OEM Logo -> Windows 11 Spinner -> Welcome)
  return (
    <div
      onClick={handleSkip}
      className={`fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center text-white select-none transition-opacity duration-500 cursor-pointer ${
        fadeComplete ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* ================================================================= */}
      {/* PHASE 1: LOGO NHÀ SẢN XUẤT (lenamphuc)                           */}
      {/* ================================================================= */}
      {phase === 'oem' && (
        <div className="flex flex-col items-center justify-center space-y-8 animate-win11-fade">
          {/* Manufacturer Emblem & Wordmark */}
          <div className="flex flex-col items-center gap-4">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-cyan-600 via-sky-500 to-indigo-600 p-[2px] shadow-[0_0_40px_rgba(14,165,233,0.3)]">
              <div className="w-full h-full bg-black rounded-2xl flex items-center justify-center text-cyan-400 font-mono text-3xl font-black tracking-tighter">
                LP
              </div>
            </div>

            <div className="text-center space-y-1">
              <h1 className="text-4xl sm:text-5xl font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-b from-white via-slate-100 to-slate-400 lowercase font-sans">
                lenamphuc
              </h1>
              <div className="text-[11px] font-mono tracking-[0.35em] text-cyan-400 uppercase opacity-90">
                Personal Computing Systems
              </div>
            </div>
          </div>

          {/* BIOS / Boot Options Legend at bottom of OEM screen */}
          <div className="absolute bottom-10 flex items-center gap-6 text-[11px] font-mono text-zinc-500 tracking-wider">
            <span>[F2] UEFI Setup</span>
            <span>•</span>
            <span>[F12] Boot Device</span>
            <span>•</span>
            <span>[Esc] Diagnostics</span>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/* PHASE 2: LOGO WINDOWS 11 + VÒNG TRÒN CHẤM XOAY (ĐANG TẢI)        */}
      {/* ================================================================= */}
      {phase === 'win11_loading' && (
        <div className="flex flex-col items-center gap-14 animate-win11-fade">
          {/* Official Windows 11 Blue 4-pane Logo */}
          <div className="grid grid-cols-2 gap-2 w-24 h-24 drop-shadow-[0_0_30px_rgba(0,120,212,0.45)]">
            <div className="bg-[#0078D4] rounded-[4px]" />
            <div className="bg-[#0078D4] rounded-[4px]" />
            <div className="bg-[#0078D4] rounded-[4px]" />
            <div className="bg-[#0078D4] rounded-[4px]" />
          </div>

          {/* Authentic Circular Spinner */}
          <div className="flex flex-col items-center gap-4">
            <Win11Spinner size={50} dotSize={5.5} color="#ffffff" />
            <div className="text-xs text-zinc-400 font-normal tracking-wide">
              Đang tải Windows 11...
            </div>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/* PHASE 3: WINDOWS 11 WELCOME (CHÀO MỪNG)                          */}
      {/* ================================================================= */}
      {phase === 'welcome' && (
        <div className="flex flex-col items-center gap-6 animate-win11-fade">
          {/* User Avatar */}
          <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-sky-500 via-indigo-500 to-purple-600 p-1 shadow-2xl">
            <div className="w-full h-full rounded-full bg-zinc-900 flex items-center justify-center text-3xl font-bold text-white shadow-inner uppercase">
              {userName.charAt(0) || 'L'}
            </div>
          </div>

          <div className="text-center space-y-1">
            <h1 className="text-2xl font-semibold text-white tracking-tight">{userName}</h1>
            <p className="text-xs text-zinc-400">{userEmail}</p>
          </div>

          {/* Welcome Spinner */}
          <div className="flex items-center gap-3 mt-2">
            <Win11Spinner size={28} dotSize={3.5} color="#38bdf8" />
            <span className="text-sm font-medium text-slate-300">Chào mừng</span>
          </div>
        </div>
      )}

      {/* Skip Hint at bottom */}
      <div className="absolute bottom-6 text-center text-xs text-zinc-600 hover:text-zinc-400 transition-colors pointer-events-none">
        Nhấp chuột vào màn hình hoặc bấm phím bất kỳ để tiếp tục
      </div>
    </div>
  );
};
