import React from 'react';

interface Win11SpinnerProps {
  size?: number;
  dotSize?: number;
  color?: string;
  className?: string;
}

export const Win11Spinner: React.FC<Win11SpinnerProps> = ({
  size = 52,
  dotSize = 5,
  color = '#ffffff',
  className = '',
}) => {
  // Real Windows 11 uses 6 dots in sequential orbital chasing sequence
  const dots = [0, 1, 2, 3, 4, 5];

  return (
    <div
      className={`relative flex items-center justify-center ${className}`}
      style={{ width: `${size}px`, height: `${size}px` }}
      aria-label="Loading..."
    >
      {dots.map((index) => {
        // Tight 0.14s staggered delay creates the connected train effect
        const delay = index * 0.14;
        return (
          <div
            key={index}
            className="absolute inset-0 flex items-start justify-center win11-spinner-orbit"
            style={{
              animationDelay: `${delay}s`,
            }}
          >
            <div
              className="rounded-full shadow-sm"
              style={{
                width: `${dotSize}px`,
                height: `${dotSize}px`,
                backgroundColor: color,
                boxShadow: `0 0 6px ${color}90`,
              }}
            />
          </div>
        );
      })}
    </div>
  );
};

