import React, { useEffect, useState } from 'react';
import { useOS } from '../../context/OSContext';
import { IconRenderer } from '../Common/IconRenderer';
import { X } from 'lucide-react';

interface AltTabModalProps {
  onClose: () => void;
}

export const AltTabModal: React.FC<AltTabModalProps> = ({ onClose }) => {
  const { windows, activeWindowId, focusWindow, closeWindow } = useOS();
  const [selectedIndex, setSelectedIndex] = useState(0);

  useEffect(() => {
    if (windows.length > 0) {
      const idx = windows.findIndex((w) => w.id === activeWindowId);
      setSelectedIndex(idx >= 0 ? (idx + 1) % windows.length : 0);
    }
  }, []);

  const handleSelectWindow = (id: string) => {
    focusWindow(id);
    onClose();
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/40 backdrop-blur-md animate-win11-fade"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="max-w-4xl w-full bg-slate-900/90 text-white rounded-2xl border border-white/20 p-6 shadow-2xl backdrop-blur-2xl flex flex-col gap-4 select-none"
      >
        <div className="flex items-center justify-between text-xs text-slate-300 font-semibold border-b border-white/10 pb-3">
          <span>Chuyển đổi cửa sổ đang chạy (Alt + Tab)</span>
          <span>{windows.length} cửa sổ</span>
        </div>

        {windows.length === 0 ? (
          <div className="py-12 text-center text-slate-400 text-sm">
            Không có ứng dụng nào đang mở trên màn hình nền.
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 max-h-[60vh] overflow-y-auto p-1">
            {windows.map((win, idx) => {
              const isSelected = selectedIndex === idx;
              return (
                <div
                  key={win.id}
                  onClick={() => handleSelectWindow(win.id)}
                  className={`group relative flex flex-col rounded-xl overflow-hidden cursor-pointer transition-all border p-3 ${
                    isSelected
                      ? 'bg-sky-600/30 border-sky-400 ring-2 ring-sky-400 scale-105 shadow-xl'
                      : 'bg-white/5 border-white/10 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-1.5 overflow-hidden">
                      <IconRenderer name={win.icon} size={16} />
                      <span className="text-xs font-semibold truncate">{win.title}</span>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        closeWindow(win.id);
                      }}
                      className="opacity-0 group-hover:opacity-100 p-1 hover:bg-red-500 rounded transition-all"
                      title="Đóng cửa sổ"
                    >
                      <X size={12} />
                    </button>
                  </div>

                  <div className="w-full h-24 rounded-lg bg-black/40 border border-white/5 flex items-center justify-center p-2 text-center text-[10px] text-slate-400">
                    <div className="flex flex-col items-center gap-1">
                      <IconRenderer name={win.icon} size={28} />
                      <span className="truncate max-w-[120px]">{win.title}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
