import React, { useState, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import { Shield, ShieldCheck, CheckCircle2, X, RefreshCw } from 'lucide-react';

export const DefenderScanModal: React.FC = () => {
  const { defenderScanDialog, closeDefenderScan } = useOS();
  const [scannedFilesCount, setScannedFilesCount] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  useEffect(() => {
    if (!defenderScanDialog.isOpen) {
      setScannedFilesCount(0);
      setIsFinished(false);
      return;
    }

    setScannedFilesCount(0);
    setIsFinished(false);

    const interval = setInterval(() => {
      setScannedFilesCount((prev) => {
        if (prev >= 48) {
          clearInterval(interval);
          setIsFinished(true);
          return 48;
        }
        return prev + 6;
      });
    }, 120);

    return () => clearInterval(interval);
  }, [defenderScanDialog.isOpen]);

  if (!defenderScanDialog.isOpen) return null;

  return (
    <div
      id="defender-scan-backdrop"
      className="fixed inset-0 z-[100003] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 select-none animate-win11-fade"
      onClick={closeDefenderScan}
    >
      <div
        id="defender-scan-dialog"
        className="w-full max-w-md bg-white dark:bg-[#202020] text-slate-800 dark:text-zinc-100 rounded-2xl shadow-2xl border border-slate-200 dark:border-zinc-700 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200/80 dark:border-zinc-800 bg-slate-50 dark:bg-[#1a1a1a]">
          <div className="flex items-center gap-2">
            <Shield size={16} className="text-sky-500" />
            <span className="text-xs font-bold">Microsoft Defender Antivirus</span>
          </div>
          <button
            onClick={closeDefenderScan}
            className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-400 hover:text-slate-700 dark:hover:text-zinc-200"
          >
            <X size={14} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 text-center space-y-4">
          <div className="mx-auto w-16 h-16 rounded-2xl flex items-center justify-center bg-sky-500/10 border border-sky-500/20 text-sky-500">
            {isFinished ? (
              <ShieldCheck size={36} className="text-emerald-500 animate-win11-pop" />
            ) : (
              <RefreshCw size={36} className="animate-spin text-sky-500" />
            )}
          </div>

          <div className="space-y-1">
            <h3 className="text-sm font-bold text-slate-900 dark:text-zinc-100">
              {isFinished ? 'Quét hoàn tất: Không tìm thấy mối đe dọa nào' : 'Đang quét bảo mật tệp...'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-zinc-400 truncate max-w-sm mx-auto">
              {defenderScanDialog.targetName || 'Mục đã chọn'}
            </p>
          </div>

          {/* Progress / Stats */}
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-zinc-800/60 border border-slate-200 dark:border-zinc-700/60 text-xs space-y-2 text-left">
            <div className="flex justify-between text-slate-600 dark:text-zinc-400">
              <span>Số tệp đã quét:</span>
              <span className="font-semibold text-slate-900 dark:text-zinc-100">{scannedFilesCount}</span>
            </div>
            <div className="flex justify-between text-slate-600 dark:text-zinc-400">
              <span>Mối đe dọa phát hiện:</span>
              <span className="font-bold text-emerald-600 dark:text-emerald-400">0 mối đe dọa (An toàn)</span>
            </div>
            <div className="flex justify-between text-slate-600 dark:text-zinc-400">
              <span>Cơ sở dữ liệu virus:</span>
              <span className="text-slate-700 dark:text-zinc-300">1.407.391.0 (Mới nhất)</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-5 py-3 bg-slate-50 dark:bg-[#1a1a1a] border-t border-slate-200/80 dark:border-zinc-800 text-xs">
          <button
            onClick={closeDefenderScan}
            className="px-5 py-2 bg-sky-600 hover:bg-sky-500 active:scale-95 text-white font-medium rounded-xl transition-all shadow-sm"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
