import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { ShieldAlert, RefreshCw, X, Folder, FileCode, Cpu, HardDrive } from 'lucide-react';
import { IconRenderer } from '../Common/IconRenderer';

export const AccessDeniedModal: React.FC = () => {
  const { accessDeniedDialog, closeAccessDeniedDialog } = useOS();
  const [isRetrying, setIsRetrying] = useState(false);
  const [retryNotice, setRetryNotice] = useState<string | null>(null);

  if (!accessDeniedDialog.isOpen || !accessDeniedDialog.fileItem) return null;

  const item = accessDeniedDialog.fileItem;

  const handleRetry = () => {
    setIsRetrying(true);
    setRetryNotice(null);
    setTimeout(() => {
      setIsRetrying(false);
      setRetryNotice(
        'Truy cập vẫn bị từ chối: Bạn không có quyền xóa tệp hệ thống bằng giao diện người dùng (chuột phải). Tệp hệ thống chỉ có thể xóa bằng dòng lệnh chiếm quyền: takeown -> icacls -> del trong Terminal!'
      );
    }, 800);
  };

  const formattedSize =
    item.size !== undefined
      ? item.size > 1024 * 1024
        ? `${(item.size / (1024 * 1024)).toFixed(1)} MB`
        : `${(item.size / 1024).toFixed(1)} KB`
      : 'Thư mục hệ thống';

  const formattedDate = new Date(item.modifiedAt || item.createdAt).toLocaleDateString('vi-VN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div
      id="access-denied-backdrop"
      className="fixed inset-0 z-[100002] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 select-none animate-win11-fade"
      onClick={closeAccessDeniedDialog}
    >
      <div
        id="access-denied-dialog"
        className="w-full max-w-md bg-white dark:bg-[#202020] text-slate-800 dark:text-zinc-100 rounded-2xl shadow-2xl border border-slate-200 dark:border-zinc-700 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Title Bar */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200/80 dark:border-zinc-800 bg-slate-50 dark:bg-[#1a1a1a]">
          <div className="flex items-center gap-2">
            <ShieldAlert size={18} className="text-amber-500" />
            <span className="text-xs font-bold tracking-tight">Truy cập tệp bị từ chối (File Access Denied)</span>
          </div>
          <button
            onClick={closeAccessDeniedDialog}
            className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-400 hover:text-slate-700 dark:hover:text-zinc-200 transition-colors"
          >
            <X size={14} />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-5 space-y-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0 text-amber-600 dark:text-amber-400">
              {item.isDirectory ? (
                <Folder size={28} />
              ) : item.icon ? (
                <IconRenderer name={item.icon} size={28} />
              ) : (
                <FileCode size={28} />
              )}
            </div>
            <div className="space-y-1 text-xs">
              <p className="text-sm font-semibold text-slate-900 dark:text-zinc-100">
                Bạn cần quyền từ <b>TrustedInstaller</b> để thực hiện thao tác này
              </p>
              <p className="text-slate-500 dark:text-zinc-400 leading-relaxed">
                Bạn cần cấp quyền từ <span className="font-semibold text-slate-700 dark:text-zinc-300">TrustedInstaller / SYSTEM</span> để thực hiện thay đổi đối với tệp này.
              </p>
            </div>
          </div>

          {/* File Card Info */}
          <div className="p-3 rounded-xl bg-slate-100 dark:bg-zinc-800/60 border border-slate-200 dark:border-zinc-700/60 text-xs space-y-1.5 font-sans">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 dark:text-zinc-400">Tên tệp:</span>
              <span className="font-semibold text-slate-800 dark:text-zinc-200 truncate max-w-[240px]">
                {item.name}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500 dark:text-zinc-400">Vị trí:</span>
              <span className="font-mono text-[11px] text-slate-700 dark:text-zinc-300 truncate max-w-[240px]">
                {item.path}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500 dark:text-zinc-400">Kích thước:</span>
              <span className="text-slate-700 dark:text-zinc-300">{formattedSize}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500 dark:text-zinc-400">Ngày tạo:</span>
              <span className="text-slate-700 dark:text-zinc-300">{formattedDate}</span>
            </div>
            <div className="flex items-center justify-between pt-1 border-t border-slate-200/80 dark:border-zinc-700/80">
              <span className="text-slate-500 dark:text-zinc-400">Chủ sở hữu hiện tại:</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-500/15 text-red-600 dark:text-red-400">
                {item.owner || 'TrustedInstaller'}
              </span>
            </div>
          </div>

          {/* Retry Warning or Prompt */}
          {retryNotice ? (
            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-600 dark:text-red-400 text-xs leading-relaxed">
              {retryNotice}
            </div>
          ) : (
            <div className="p-2.5 rounded-xl bg-sky-500/10 border border-sky-500/20 text-sky-700 dark:text-sky-300 text-xs space-y-1">
              <p className="font-semibold">💡 Cách xóa tệp hệ thống an toàn:</p>
              <p className="text-[11px] font-mono text-slate-700 dark:text-zinc-300">
                Mở Terminal/CMD và dùng 3 lệnh:
                <br />1. takeown /f "{item.name}"
                <br />2. icacls "{item.name}" /grant administrators:F
                <br />3. del /F /Q "{item.name}"
              </p>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-2 px-5 py-3.5 bg-slate-50 dark:bg-[#1a1a1a] border-t border-slate-200/80 dark:border-zinc-800 text-xs">
          <button
            onClick={handleRetry}
            disabled={isRetrying}
            className="flex items-center gap-1.5 px-4 py-2 bg-sky-600 hover:bg-sky-500 active:scale-95 text-white font-medium rounded-xl transition-all shadow-sm"
          >
            <RefreshCw size={13} className={isRetrying ? 'animate-spin' : ''} />
            <span>{isRetrying ? 'Đang thử lại...' : 'Thử lại (Try Again)'}</span>
          </button>
          <button
            onClick={closeAccessDeniedDialog}
            className="px-4 py-2 hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-300 font-medium rounded-xl transition-colors"
          >
            Hủy bỏ (Cancel)
          </button>
        </div>
      </div>
    </div>
  );
};
