import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { HardDrive, X, PieChart, Sparkles, Check } from 'lucide-react';

export const DrivePropertiesModal: React.FC = () => {
  const { drivePropertiesDialog, closeDriveProperties, addNotification } = useOS();
  const [activeTab, setActiveTab] = useState<'general' | 'tools' | 'hardware'>('general');
  const [isCleaning, setIsCleaning] = useState(false);
  const [cleaned, setCleaned] = useState(false);

  if (!drivePropertiesDialog.isOpen) return null;

  const isC = drivePropertiesDialog.driveLetter === 'C';
  const driveLabel = isC ? 'Local Disk (C:)' : 'Data (D:)';
  const fileSystemType = 'NTFS';

  // Drive metrics
  const totalGB = isC ? 953 : 2048;
  const freeGB = isC ? (cleaned ? 868 : 842) : 1850;
  const usedGB = totalGB - freeGB;
  const usedPercent = Math.round((usedGB / totalGB) * 100);

  const handleDiskCleanup = () => {
    setIsCleaning(true);
    setTimeout(() => {
      setIsCleaning(false);
      setCleaned(true);
      addNotification(
        'Dọn đĩa (Disk Cleanup) hoàn tất',
        `Đã dọn dẹp thành công 26.4 GB tệp tạm thời trên ổ ${driveLabel}.`,
        'system'
      );
    }, 1200);
  };

  return (
    <div
      id="drive-properties-backdrop"
      className="fixed inset-0 z-[100003] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 select-none animate-win11-fade"
      onClick={closeDriveProperties}
    >
      <div
        id="drive-properties-dialog"
        className="w-full max-w-md bg-white dark:bg-[#202020] text-slate-800 dark:text-zinc-100 rounded-2xl shadow-2xl border border-slate-200 dark:border-zinc-700 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Title Bar */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200/80 dark:border-zinc-800 bg-slate-50 dark:bg-[#1a1a1a]">
          <div className="flex items-center gap-2">
            <HardDrive size={16} className="text-sky-500" />
            <span className="text-xs font-bold">Thuộc tính của {driveLabel}</span>
          </div>
          <button
            onClick={closeDriveProperties}
            className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-400 hover:text-slate-700 dark:hover:text-zinc-200"
          >
            <X size={14} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-200 dark:border-zinc-800 bg-slate-100/70 dark:bg-zinc-900/50 px-3 pt-2 gap-1 text-xs">
          <button
            onClick={() => setActiveTab('general')}
            className={`px-3 py-1.5 rounded-t-lg font-medium transition-all ${
              activeTab === 'general'
                ? 'bg-white dark:bg-[#202020] text-sky-600 dark:text-sky-400 border-t-2 border-sky-500 shadow-sm'
                : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900'
            }`}
          >
            Chung (General)
          </button>
          <button
            onClick={() => setActiveTab('tools')}
            className={`px-3 py-1.5 rounded-t-lg font-medium transition-all ${
              activeTab === 'tools'
                ? 'bg-white dark:bg-[#202020] text-sky-600 dark:text-sky-400 border-t-2 border-sky-500 shadow-sm'
                : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900'
            }`}
          >
            Công cụ (Tools)
          </button>
          <button
            onClick={() => setActiveTab('hardware')}
            className={`px-3 py-1.5 rounded-t-lg font-medium transition-all ${
              activeTab === 'hardware'
                ? 'bg-white dark:bg-[#202020] text-sky-600 dark:text-sky-400 border-t-2 border-sky-500 shadow-sm'
                : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900'
            }`}
          >
            Phần cứng (Hardware)
          </button>
        </div>

        {/* Content */}
        <div className="p-4 text-xs space-y-4">
          {activeTab === 'general' && (
            <div className="space-y-4 animate-win11-fade">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-500">
                  <HardDrive size={28} />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900 dark:text-zinc-100">{driveLabel}</p>
                  <p className="text-slate-500 dark:text-zinc-400">Hệ thống tệp: {fileSystemType}</p>
                </div>
              </div>

              {/* Usage Breakdown */}
              <div className="space-y-2.5 p-3.5 rounded-xl bg-slate-50 dark:bg-zinc-800/60 border border-slate-200 dark:border-zinc-700/60">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-sm bg-sky-500"></span>
                    <span className="text-slate-600 dark:text-zinc-400">Dung lượng đã dùng:</span>
                  </div>
                  <span className="font-semibold text-slate-900 dark:text-zinc-100">{usedGB} GB</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-sm bg-slate-300 dark:bg-zinc-600"></span>
                    <span className="text-slate-600 dark:text-zinc-400">Dung lượng còn trống:</span>
                  </div>
                  <span className="font-semibold text-slate-900 dark:text-zinc-100">{freeGB} GB</span>
                </div>
                <div className="pt-2 border-t border-slate-200 dark:border-zinc-700 flex justify-between font-bold">
                  <span>Tổng dung lượng:</span>
                  <span>{totalGB} GB</span>
                </div>

                {/* Progress bar */}
                <div className="w-full h-3 bg-slate-200 dark:bg-zinc-700 rounded-full overflow-hidden mt-2">
                  <div
                    className="h-full bg-sky-500 transition-all duration-500"
                    style={{ width: `${usedPercent}%` }}
                  />
                </div>
              </div>

              {/* Disk Cleanup Button */}
              <div className="flex items-center justify-between pt-1">
                <div className="text-slate-500 dark:text-zinc-400 text-[11px]">
                  Dọn dẹp tệp tin tạm thời để giải phóng dung lượng.
                </div>
                <button
                  onClick={handleDiskCleanup}
                  disabled={isCleaning}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-800 dark:text-zinc-200 font-medium rounded-xl border border-slate-300 dark:border-zinc-600 transition-colors"
                >
                  <Sparkles size={13} className={isCleaning ? 'animate-spin text-amber-500' : 'text-sky-500'} />
                  <span>{isCleaning ? 'Đang dọn dẹp...' : 'Dọn đĩa (Disk Cleanup)'}</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'tools' && (
            <div className="space-y-4 animate-win11-fade text-xs">
              <div className="p-3 rounded-xl border border-slate-200 dark:border-zinc-700 space-y-2">
                <p className="font-semibold text-slate-800 dark:text-zinc-200">Kiểm tra lỗi (Error checking):</p>
                <p className="text-slate-500 dark:text-zinc-400 text-[11px]">
                  Tùy chọn này sẽ kiểm tra các lỗi hệ thống tệp trên ổ đĩa.
                </p>
                <button
                  onClick={() => addNotification('Kiểm tra ổ đĩa', `Ổ đĩa ${driveLabel} hoạt động bình thường. Không có lỗi nào.`, 'system')}
                  className="px-3 py-1.5 bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 dark:hover:bg-zinc-700 rounded-lg border border-slate-300 dark:border-zinc-600 font-medium"
                >
                  Kiểm tra (Check)
                </button>
              </div>

              <div className="p-3 rounded-xl border border-slate-200 dark:border-zinc-700 space-y-2">
                <p className="font-semibold text-slate-800 dark:text-zinc-200">Tối ưu hóa và chống phân mảnh ổ đĩa:</p>
                <p className="text-slate-500 dark:text-zinc-400 text-[11px]">
                  Tối ưu hóa các ổ đĩa của bạn có thể giúp máy tính chạy hiệu quả hơn.
                </p>
                <button
                  onClick={() => addNotification('Tối ưu hóa', `Ổ đĩa ${driveLabel} đã được tối ưu hóa 0% phân mảnh.`, 'system')}
                  className="px-3 py-1.5 bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 dark:hover:bg-zinc-700 rounded-lg border border-slate-300 dark:border-zinc-600 font-medium"
                >
                  Tối ưu hóa (Optimize)
                </button>
              </div>
            </div>
          )}

          {activeTab === 'hardware' && (
            <div className="space-y-3 animate-win11-fade text-xs">
              <p className="font-semibold text-slate-800 dark:text-zinc-200">Tất cả các ổ đĩa:</p>
              <div className="border border-slate-200 dark:border-zinc-700 rounded-xl overflow-hidden divide-y divide-slate-200 dark:divide-zinc-800">
                <div className="p-2.5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <HardDrive size={16} className="text-sky-500" />
                    <span className="font-medium">NVMe SAMSUNG MZVL21T0HCLR-00B00</span>
                  </div>
                  <span className="text-slate-500 text-[11px]">Disk drives</span>
                </div>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/50 border border-slate-200 dark:border-zinc-700/50 text-[11px] space-y-1">
                <p>Nhà sản xuất: (Standard disk drives)</p>
                <p>Vị trí: Bus Number 0, Target Id 0, LUN 0</p>
                <p className="text-emerald-600 dark:text-emerald-400 font-medium">Trạng thái thiết bị: Thiết bị này đang hoạt động bình thường.</p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2 px-4 py-3 bg-slate-50 dark:bg-[#1a1a1a] border-t border-slate-200/80 dark:border-zinc-800 text-xs">
          <button
            onClick={closeDriveProperties}
            className="px-5 py-2 bg-sky-600 hover:bg-sky-500 active:scale-95 text-white font-medium rounded-xl transition-all shadow-sm"
          >
            OK
          </button>
          <button
            onClick={closeDriveProperties}
            className="px-4 py-2 hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-300 font-medium rounded-xl transition-colors"
          >
            Hủy bỏ
          </button>
        </div>
      </div>
    </div>
  );
};
