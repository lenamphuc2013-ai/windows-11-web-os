import React, { useState, useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import { Play, HelpCircle, X } from 'lucide-react';

interface RunDialogModalProps {
  onClose: () => void;
}

export const RunDialogModal: React.FC<RunDialogModalProps> = ({ onClose }) => {
  const { openApp, addNotification } = useOS();
  const [command, setCommand] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = command.trim().toLowerCase();
    if (!cmd) return;

    onClose();

    if (cmd === 'cmd' || cmd === 'cmd.exe') {
      openApp('cmd');
    } else if (cmd === 'powershell' || cmd === 'powershell.exe' || cmd === 'pwsh') {
      openApp('powershell');
    } else if (cmd === 'terminal' || cmd === 'wt') {
      openApp('terminal');
    } else if (cmd === 'explorer' || cmd === 'explorer.exe' || cmd === 'this pc' || cmd === 'my computer') {
      openApp('explorer', { initialPath: 'This PC' });
    } else if (cmd === 'calc' || cmd === 'calculator') {
      openApp('calculator');
    } else if (cmd === 'notepad' || cmd === 'notepad.exe') {
      openApp('notepad');
    } else if (cmd === 'edge' || cmd === 'msedge' || cmd === 'browser') {
      openApp('edge');
    } else if (cmd === 'taskmgr' || cmd === 'taskmanager') {
      openApp('taskmanager');
    } else if (cmd === 'ms-settings:' || cmd === 'settings' || cmd === 'control') {
      openApp('settings');
    } else if (cmd === 'snippingtool') {
      openApp('snippingtool');
    } else if (cmd === 'mspaint' || cmd === 'paint') {
      openApp('paint');
    } else if (cmd === 'camera') {
      openApp('camera');
    } else if (cmd === 'copilot') {
      openApp('copilot');
    } else if (cmd === 'store' || cmd === 'ms-windows-store:') {
      openApp('store');
    } else if (cmd === 'winver' || cmd === 'winver.exe') {
      openApp('winver');
    } else if (cmd === 'dxdiag' || cmd === 'dxdiag.exe') {
      openApp('dxdiag');
    } else if (cmd.startsWith('http://') || cmd.startsWith('https://') || cmd.startsWith('www.')) {
      openApp('edge', { initialUrl: cmd.startsWith('http') ? cmd : `https://${cmd}` });
    } else {
      // Try opening as terminal command or notify
      addNotification('Run (Chạy)', `Đang thực thi lệnh: "${command}"...`, 'system');
      openApp('terminal');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-start p-4 sm:p-12 pointer-events-none">
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-white/90 dark:bg-[#202020]/95 backdrop-blur-xl rounded-2xl border border-white/20 dark:border-white/10 shadow-2xl p-5 text-slate-800 dark:text-slate-100 pointer-events-auto select-none animate-win11-flyin"
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-zinc-800">
          <div className="flex items-center gap-2 font-bold text-sm">
            <div className="w-5 h-5 rounded bg-sky-500 text-white flex items-center justify-center text-xs font-black">
              R
            </div>
            <span>Chạy (Run)</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-700 transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        <p className="text-xs text-slate-600 dark:text-slate-300 my-3">
          Nhập tên chương trình, thư mục, tài liệu hoặc tài nguyên Internet để Windows mở cho bạn:
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex items-center gap-3">
            <label className="text-xs font-semibold shrink-0">Mở (Open):</label>
            <input
              ref={inputRef}
              type="text"
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              placeholder="cmd, explorer, notepad, calc, ms-settings:..."
              className="flex-1 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-xs focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-zinc-800">
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-sky-500 hover:bg-sky-600 text-white text-xs font-medium transition-colors shadow"
            >
              OK
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-slate-200 dark:bg-zinc-800 hover:bg-slate-300 dark:hover:bg-zinc-700 text-xs font-medium transition-colors"
            >
              Hủy
            </button>
            <button
              type="button"
              onClick={() => {
                setCommand('notepad');
              }}
              className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-800 text-xs font-medium transition-colors"
            >
              Duyệt...
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
