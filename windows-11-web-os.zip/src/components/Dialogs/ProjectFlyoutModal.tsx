import React, { useState } from 'react';
import { Monitor, Copy, SplitSquareVertical, Tv, X, Check } from 'lucide-react';
import { useOS } from '../../context/OSContext';

interface ProjectFlyoutModalProps {
  onClose: () => void;
}

export const ProjectFlyoutModal: React.FC<ProjectFlyoutModalProps> = ({ onClose }) => {
  const { addNotification } = useOS();
  const [selectedMode, setSelectedMode] = useState<'pc-only' | 'duplicate' | 'extend' | 'second-only'>('pc-only');

  const options = [
    {
      id: 'pc-only' as const,
      title: 'Chỉ màn hình PC (PC screen only)',
      desc: 'Chỉ sử dụng màn hình chính của thiết bị',
      icon: Monitor,
    },
    {
      id: 'duplicate' as const,
      title: 'Nhân bản (Duplicate)',
      desc: 'Hiển thị cùng một nội dung trên tất cả các màn hình',
      icon: Copy,
    },
    {
      id: 'extend' as const,
      title: 'Mở rộng (Extend)',
      desc: 'Mở rộng không gian làm việc qua màn hình thứ hai',
      icon: SplitSquareVertical,
    },
    {
      id: 'second-only' as const,
      title: 'Chỉ màn hình thứ hai (Second screen only)',
      desc: 'Tắt màn hình PC và chỉ hiển thị trên màn hình phụ',
      icon: Tv,
    },
  ];

  const handleSelect = (id: typeof selectedMode, title: string) => {
    setSelectedMode(id);
    addNotification('Chế độ trình chiếu (Project)', `Đã chuyển sang: ${title}`, 'display');
    setTimeout(() => onClose(), 350);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start sm:items-center justify-end p-4 sm:p-8 pointer-events-none">
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-xs bg-white/95 dark:bg-[#202020]/95 backdrop-blur-2xl rounded-2xl border border-white/20 dark:border-white/10 shadow-2xl p-4 text-slate-800 dark:text-slate-100 select-none animate-win11-flyin pointer-events-auto flex flex-col gap-3"
      >
        <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-zinc-800">
          <span className="font-bold text-xs">Chiếu màn hình (Project - Win + P)</span>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-700 transition-colors"
          >
            <X size={15} />
          </button>
        </div>

        <div className="space-y-1.5">
          {options.map((opt) => {
            const Icon = opt.icon;
            const isSelected = selectedMode === opt.id;
            return (
              <button
                key={opt.id}
                onClick={() => handleSelect(opt.id, opt.title)}
                className={`w-full p-3 rounded-xl flex items-start gap-3 text-left transition-all border ${
                  isSelected
                    ? 'bg-sky-500/15 border-sky-500/80 text-sky-600 dark:text-sky-400 font-semibold'
                    : 'border-transparent hover:bg-slate-100 dark:hover:bg-zinc-800'
                }`}
              >
                <div className={`p-2 rounded-lg ${isSelected ? 'bg-sky-500 text-white' : 'bg-slate-200 dark:bg-zinc-700 text-slate-700 dark:text-slate-200'}`}>
                  <Icon size={18} />
                </div>
                <div className="flex-1">
                  <div className="text-xs font-semibold leading-tight">{opt.title}</div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 leading-snug">{opt.desc}</div>
                </div>
                {isSelected && <Check size={16} className="text-sky-500 shrink-0 mt-1" />}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
