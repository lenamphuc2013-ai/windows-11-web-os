import React, { useState } from 'react';
import { Clipboard, Trash2, Check, X, ShieldAlert, Sparkles } from 'lucide-react';
import { useOS } from '../../context/OSContext';

interface ClipboardHistoryModalProps {
  onClose: () => void;
}

export const ClipboardHistoryModal: React.FC<ClipboardHistoryModalProps> = ({ onClose }) => {
  const { addNotification } = useOS();
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const [historyItems, setHistoryItems] = useState([
    {
      id: 'clip-1',
      text: 'takeown /f "C:\\Windows\\System32\\ntoskrnl.exe"',
      timestamp: 'Vừa xong',
      type: 'text',
    },
    {
      id: 'clip-2',
      text: 'icacls "C:\\Windows\\System32\\ntoskrnl.exe" /grant administrators:F',
      timestamp: '1 phút trước',
      type: 'text',
    },
    {
      id: 'clip-3',
      text: 'del /F /Q "C:\\Windows\\System32\\ntoskrnl.exe"',
      timestamp: '2 phút trước',
      type: 'text',
    },
    {
      id: 'clip-4',
      text: 'https://microsoft.com/windows/windows-11',
      timestamp: '10 phút trước',
      type: 'url',
    },
    {
      id: 'clip-5',
      text: 'lenamphuc2013@gmail.com',
      timestamp: '15 phút trước',
      type: 'text',
    },
  ]);

  const handlePaste = (item: typeof historyItems[0]) => {
    navigator.clipboard?.writeText(item.text);
    setCopiedId(item.id);
    addNotification('Clipboard (Bộ nhớ tạm)', `Đã sao chép nội dung: "${item.text.slice(0, 30)}..."`, 'info');
    setTimeout(() => {
      setCopiedId(null);
      onClose();
    }, 400);
  };

  const handleClearAll = () => {
    setHistoryItems([]);
    addNotification('Clipboard', 'Đã xóa toàn bộ lịch sử bộ nhớ tạm.', 'info');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/20 backdrop-blur-xs">
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm bg-white/95 dark:bg-[#202020]/95 backdrop-blur-2xl rounded-2xl border border-white/20 dark:border-white/10 shadow-2xl p-4 text-slate-800 dark:text-slate-100 select-none animate-win11-flyin flex flex-col max-h-[460px]"
      >
        <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-zinc-800">
          <div className="flex items-center gap-2 font-bold text-xs">
            <Clipboard size={16} className="text-sky-500" />
            <span>Lịch sử bộ nhớ tạm (Win + V)</span>
          </div>
          <div className="flex items-center gap-1">
            {historyItems.length > 0 && (
              <button
                onClick={handleClearAll}
                className="text-[11px] text-red-500 hover:text-red-600 px-2 py-0.5 rounded hover:bg-red-500/10 transition-colors flex items-center gap-1"
                title="Xóa tất cả"
              >
                <Trash2 size={12} /> Xóa hết
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-700 transition-colors"
            >
              <X size={15} />
            </button>
          </div>
        </div>

        <p className="text-[11px] text-slate-500 dark:text-slate-400 my-2">
          Bấm vào bất kỳ mục nào để sao chép vào bộ nhớ tạm và dán ngay:
        </p>

        {/* List of clipboard items */}
        <div className="flex-1 overflow-y-auto space-y-2 py-1">
          {historyItems.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs italic">
              Lịch sử bộ nhớ tạm trống.
            </div>
          ) : (
            historyItems.map((item) => (
              <div
                key={item.id}
                onClick={() => handlePaste(item)}
                className={`p-3 rounded-xl border border-slate-200 dark:border-zinc-700/70 bg-white dark:bg-zinc-900/80 hover:border-sky-500 hover:bg-sky-500/5 cursor-pointer transition-all flex flex-col gap-1 relative ${
                  copiedId === item.id ? 'ring-2 ring-sky-500 bg-sky-500/10' : ''
                }`}
              >
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                  <span>{item.type.toUpperCase()}</span>
                  <span>{item.timestamp}</span>
                </div>
                <div className="text-xs text-slate-700 dark:text-slate-200 font-mono break-all line-clamp-3">
                  {item.text}
                </div>
                {copiedId === item.id && (
                  <div className="absolute top-2 right-2 flex items-center gap-1 text-[10px] text-sky-500 font-bold bg-sky-500/20 px-2 py-0.5 rounded-full">
                    <Check size={12} /> Đã chọn
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        <div className="pt-2 border-t border-slate-200 dark:border-zinc-800 text-[10px] text-slate-400 text-center">
          Dữ liệu clipboard được đồng bộ hóa an toàn trên Windows 11
        </div>
      </div>
    </div>
  );
};
