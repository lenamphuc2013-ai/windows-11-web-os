import React, { useState, useEffect } from 'react';
import { Mic, MicOff, Settings, X, Sparkles } from 'lucide-react';
import { useOS } from '../../context/OSContext';

interface VoiceTypingOverlayProps {
  onClose: () => void;
}

export const VoiceTypingOverlay: React.FC<VoiceTypingOverlayProps> = ({ onClose }) => {
  const { addNotification } = useOS();
  const [isListening, setIsListening] = useState(true);
  const [transcript, setTranscript] = useState('Đang lắng nghe giọng nói của bạn...');

  useEffect(() => {
    const timer = setTimeout(() => {
      setTranscript('Đã nhận diện: "Xin chào Windows 11 tiếng Việt"');
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 pointer-events-auto select-none animate-win11-flyin">
      <div className="bg-slate-900/95 text-white backdrop-blur-2xl px-5 py-3 rounded-full border border-white/20 shadow-2xl flex items-center gap-4">
        <button
          onClick={() => setIsListening(!isListening)}
          className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
            isListening ? 'bg-sky-500 animate-pulse text-white shadow-lg' : 'bg-zinc-700 text-zinc-400'
          }`}
        >
          {isListening ? <Mic size={20} /> : <MicOff size={20} />}
        </button>

        <div className="flex flex-col">
          <div className="flex items-center gap-1.5 text-xs font-bold text-sky-400">
            <Sparkles size={13} />
            <span>Windows Voice Typing (Win + H)</span>
          </div>
          <span className="text-[11px] text-slate-300 font-medium max-w-xs truncate">
            {transcript}
          </span>
        </div>

        <button
          onClick={onClose}
          className="p-1 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
        >
          <X size={16} />
        </button>
      </div>
    </div>
  );
};
