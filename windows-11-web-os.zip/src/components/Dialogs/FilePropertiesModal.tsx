import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { X, Shield, Folder, FileCode, Check, Ban, Lock, Key } from 'lucide-react';
import { IconRenderer } from '../Common/IconRenderer';

export const FilePropertiesModal: React.FC = () => {
  const { filePropertiesDialog, closeFileProperties } = useOS();
  const [activeTab, setActiveTab] = useState<'general' | 'security' | 'details'>('general');

  if (!filePropertiesDialog.isOpen || !filePropertiesDialog.fileItem) return null;

  const item = filePropertiesDialog.fileItem;

  const formattedSize =
    item.size !== undefined
      ? item.size > 1024 * 1024
        ? `${(item.size / (1024 * 1024)).toFixed(2)} MB (${item.size.toLocaleString()} bytes)`
        : `${(item.size / 1024).toFixed(2)} KB (${item.size.toLocaleString()} bytes)`
      : 'Thư mục hệ thống';

  const dateCreated =
    typeof item.createdAt === 'number'
      ? new Date(item.createdAt).toLocaleString('vi-VN')
      : item.createdAt instanceof Date
      ? item.createdAt.toLocaleString('vi-VN')
      : String(item.createdAt || 'Không rõ');

  const dateModified =
    typeof (item.modifiedAt || item.createdAt) === 'number'
      ? new Date(item.modifiedAt || item.createdAt).toLocaleString('vi-VN')
      : (item.modifiedAt || item.createdAt) instanceof Date
      ? (item.modifiedAt || item.createdAt).toLocaleString('vi-VN')
      : String(item.modifiedAt || item.createdAt || 'Không rõ');

  const isOwnerAdmin = item.owner === 'Administrators';
  const hasIcacls = item.icaclsGranted;

  const renderProtectionBadge = () => {
    const level = item.protectionLevel;
    if (!level) return null;

    switch (level) {
      case 'KHÔNG XOÁ':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30">
            <Shield size={11} className="text-rose-500" />
            KHÔNG XOÁ (Tuyệt đối quan trọng)
          </span>
        );
      case 'BẢO VỆ':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30">
            <Lock size={11} className="text-amber-500" />
            BẢO VỆ (WinRE & Khôi phục)
          </span>
        );
      case 'CẨN THẬN':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30">
            <Shield size={11} className="text-sky-500" />
            CẨN THẬN (Dữ liệu người dùng / AppData)
          </span>
        );
      case 'AN TOÀN XOÁ':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
            <Check size={11} className="text-emerald-500" />
            AN TOÀN XOÁ (File tạm, Log, App cá nhân)
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div
      id="file-properties-backdrop"
      className="fixed inset-0 z-[100003] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 select-none animate-win11-fade"
      onClick={closeFileProperties}
    >
      <div
        id="file-properties-dialog"
        className="w-full max-w-md bg-white dark:bg-[#202020] text-slate-800 dark:text-zinc-100 rounded-2xl shadow-2xl border border-slate-200 dark:border-zinc-700 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Title Bar */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200/80 dark:border-zinc-800 bg-slate-50 dark:bg-[#1a1a1a]">
          <div className="flex items-center gap-2 truncate max-w-[320px]">
            {item.isDirectory ? (
              <Folder size={16} className="text-amber-500 shrink-0" />
            ) : item.icon ? (
              <IconRenderer name={item.icon} size={16} />
            ) : (
              <FileCode size={16} className="text-sky-500 shrink-0" />
            )}
            <span className="text-xs font-bold truncate">Thuộc tính: {item.name}</span>
          </div>
          <button
            onClick={closeFileProperties}
            className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-400 hover:text-slate-700 dark:hover:text-zinc-200 transition-colors"
          >
            <X size={14} />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 dark:border-zinc-800 bg-slate-100/70 dark:bg-zinc-900/50 px-3 pt-2 gap-1 text-xs">
          <button
            onClick={() => setActiveTab('general')}
            className={`px-3 py-1.5 rounded-t-lg font-medium transition-all ${
              activeTab === 'general'
                ? 'bg-white dark:bg-[#202020] text-sky-600 dark:text-sky-400 border-t-2 border-sky-500 shadow-sm'
                : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900 dark:hover:text-zinc-200'
            }`}
          >
            Chung (General)
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`px-3 py-1.5 rounded-t-lg font-medium transition-all ${
              activeTab === 'security'
                ? 'bg-white dark:bg-[#202020] text-sky-600 dark:text-sky-400 border-t-2 border-sky-500 shadow-sm'
                : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900 dark:hover:text-zinc-200'
            }`}
          >
            Bảo mật (Security)
          </button>
          <button
            onClick={() => setActiveTab('details')}
            className={`px-3 py-1.5 rounded-t-lg font-medium transition-all ${
              activeTab === 'details'
                ? 'bg-white dark:bg-[#202020] text-sky-600 dark:text-sky-400 border-t-2 border-sky-500 shadow-sm'
                : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900 dark:hover:text-zinc-200'
            }`}
          >
            Chi tiết (Details)
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-4 text-xs space-y-3 min-h-[310px]">
          {activeTab === 'general' && (
            <div className="space-y-3 animate-win11-fade">
              <div className="flex items-center gap-3 pb-3 border-b border-slate-200/80 dark:border-zinc-800">
                <div className="w-12 h-12 rounded-xl bg-slate-100 dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 flex items-center justify-center shrink-0">
                  {item.isDirectory ? (
                    <Folder size={26} className="text-amber-500" />
                  ) : item.icon ? (
                    <IconRenderer name={item.icon} size={26} />
                  ) : (
                    <FileCode size={26} className="text-sky-500" />
                  )}
                </div>
                <div className="truncate flex-1">
                  <p className="text-sm font-semibold truncate text-slate-900 dark:text-zinc-100">{item.name}</p>
                  <p className="text-slate-500 dark:text-zinc-400 mb-1">
                    {item.isDirectory ? 'Thư mục hệ thống / tệp tin' : 'Tệp thực thi / Tệp hệ thống'}
                  </p>
                  {renderProtectionBadge()}
                </div>
              </div>

              {item.description && (
                <div className="p-2.5 bg-slate-50 dark:bg-zinc-800/70 border border-slate-200/80 dark:border-zinc-700/80 rounded-xl">
                  <span className="text-[11px] font-semibold text-slate-700 dark:text-zinc-300 block mb-0.5">
                    Mô tả chức năng:
                  </span>
                  <p className="text-[11px] text-slate-600 dark:text-zinc-400 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              )}

              <div className="space-y-2">
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-zinc-800/60">
                  <span className="text-slate-500 dark:text-zinc-400">Loại tệp:</span>
                  <span className="font-medium text-slate-800 dark:text-zinc-200">
                    {item.name.split('.').pop()?.toUpperCase() || 'FOLDER'} File
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-zinc-800/60">
                  <span className="text-slate-500 dark:text-zinc-400">Vị trí:</span>
                  <span className="font-mono text-[11px] text-slate-700 dark:text-zinc-300 truncate max-w-[240px]">
                    {item.path}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-zinc-800/60">
                  <span className="text-slate-500 dark:text-zinc-400">Kích thước:</span>
                  <span className="font-medium text-slate-800 dark:text-zinc-200">{formattedSize}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-zinc-800/60">
                  <span className="text-slate-500 dark:text-zinc-400">Ngày tạo:</span>
                  <span className="text-slate-700 dark:text-zinc-300">{dateCreated}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-zinc-800/60">
                  <span className="text-slate-500 dark:text-zinc-400">Sửa đổi lần cuối:</span>
                  <span className="text-slate-700 dark:text-zinc-300">{dateModified}</span>
                </div>
              </div>

              {/* Attributes */}
              <div className="pt-2">
                <span className="text-slate-500 dark:text-zinc-400 block mb-1.5 font-medium">Thuộc tính (Attributes):</span>
                <div className="flex items-center gap-4 text-xs">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={item.isReadOnly ?? false}
                      readOnly
                      className="rounded border-slate-300 text-sky-600 focus:ring-0"
                    />
                    <span>Chỉ đọc (Read-only)</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={item.hidden ?? false}
                      readOnly
                      className="rounded border-slate-300 text-sky-600 focus:ring-0"
                    />
                    <span>Ẩn (Hidden)</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={item.isSystem ?? false}
                      readOnly
                      className="rounded border-slate-300 text-sky-600 focus:ring-0"
                    />
                    <span>Hệ thống (System)</span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-3 animate-win11-fade">
              <div>
                <p className="font-semibold text-slate-700 dark:text-zinc-300 mb-1">
                  Tên nhóm hoặc người dùng (Group or user names):
                </p>
                <div className="p-2 border border-slate-200 dark:border-zinc-700 rounded-xl bg-slate-50 dark:bg-zinc-800/50 space-y-1 text-xs max-h-28 overflow-y-auto">
                  <div
                    className={`flex items-center justify-between p-1.5 rounded-lg ${
                      !isOwnerAdmin ? 'bg-sky-500/10 font-bold text-sky-600 dark:text-sky-400' : 'text-slate-600 dark:text-zinc-400'
                    }`}
                  >
                    <span>🛡️ TrustedInstaller (Chủ sở hữu gốc)</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-600 dark:text-amber-400">
                      Toàn quyền
                    </span>
                  </div>
                  <div className="flex items-center justify-between p-1.5 rounded-lg text-slate-600 dark:text-zinc-400">
                    <span>💻 SYSTEM</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-zinc-700 text-slate-700 dark:text-zinc-300">
                      Toàn quyền
                    </span>
                  </div>
                  <div
                    className={`flex items-center justify-between p-1.5 rounded-lg ${
                      isOwnerAdmin ? 'bg-sky-500/10 font-bold text-sky-600 dark:text-sky-400' : 'text-slate-600 dark:text-zinc-400'
                    }`}
                  >
                    <span>👤 Administrators (Quản trị viên)</span>
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded ${
                        hasIcacls
                          ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                          : isOwnerAdmin
                          ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                          : 'bg-slate-200 dark:bg-zinc-700 text-slate-700 dark:text-zinc-300'
                      }`}
                    >
                      {hasIcacls ? 'Toàn quyền (Full Control)' : isOwnerAdmin ? 'Chủ sở hữu (Chưa cấp quyền)' : 'Chỉ đọc (Read)'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between p-1.5 rounded-lg text-slate-600 dark:text-zinc-400">
                    <span>👥 Users (Người dùng thông thường)</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-zinc-700 text-slate-700 dark:text-zinc-300">
                      Đọc & thực thi
                    </span>
                  </div>
                </div>
              </div>

              {/* Permissions Table */}
              <div>
                <p className="font-semibold text-slate-700 dark:text-zinc-300 mb-1">
                  Quyền cho Administrators (Permissions for Administrators):
                </p>
                <div className="border border-slate-200 dark:border-zinc-700 rounded-xl overflow-hidden text-xs">
                  <div className="grid grid-cols-3 bg-slate-100 dark:bg-zinc-800 px-3 py-1.5 font-semibold text-slate-700 dark:text-zinc-300">
                    <span>Quyền</span>
                    <span className="text-center">Cho phép (Allow)</span>
                    <span className="text-center">Từ chối (Deny)</span>
                  </div>
                  <div className="divide-y divide-slate-100 dark:divide-zinc-800 bg-white dark:bg-zinc-900/50">
                    <div className="grid grid-cols-3 px-3 py-1 items-center">
                      <span>Toàn quyền (Full control)</span>
                      <span className="text-center font-bold text-emerald-600">{hasIcacls ? '✓' : ''}</span>
                      <span className="text-center font-bold text-red-500">{!hasIcacls ? '✓' : ''}</span>
                    </div>
                    <div className="grid grid-cols-3 px-3 py-1 items-center">
                      <span>Sửa đổi (Modify)</span>
                      <span className="text-center font-bold text-emerald-600">{hasIcacls ? '✓' : ''}</span>
                      <span className="text-center font-bold text-red-500">{!hasIcacls ? '✓' : ''}</span>
                    </div>
                    <div className="grid grid-cols-3 px-3 py-1 items-center">
                      <span>Đọc & thực thi (Read & exec)</span>
                      <span className="text-center font-bold text-emerald-600">✓</span>
                      <span className="text-center"></span>
                    </div>
                    <div className="grid grid-cols-3 px-3 py-1 items-center">
                      <span>Đọc (Read)</span>
                      <span className="text-center font-bold text-emerald-600">✓</span>
                      <span className="text-center"></span>
                    </div>
                    <div className="grid grid-cols-3 px-3 py-1 items-center">
                      <span>Ghi (Write)</span>
                      <span className="text-center font-bold text-emerald-600">{hasIcacls ? '✓' : ''}</span>
                      <span className="text-center font-bold text-red-500">{!hasIcacls ? '✓' : ''}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-2 bg-slate-100 dark:bg-zinc-800/60 rounded-xl text-[11px] text-slate-600 dark:text-zinc-400">
                <span>Chủ sở hữu hiện tại: </span>
                <b className={isOwnerAdmin ? 'text-emerald-600' : 'text-amber-500'}>
                  {item.owner || 'TrustedInstaller'}
                </b>
                {hasIcacls && <span className="ml-2 text-emerald-600 font-semibold">(Đã cấp quyền qua icacls)</span>}
              </div>
            </div>
          )}

          {activeTab === 'details' && (
            <div className="space-y-2 animate-win11-fade text-xs">
              <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-zinc-800">
                <span className="text-slate-500 dark:text-zinc-400">Mô tả tệp:</span>
                <span className="font-medium text-slate-800 dark:text-zinc-200">
                  {item.description || (item.isHtmlApp ? 'Ứng dụng HTML Web OS' : item.name)}
                </span>
              </div>
              {item.protectionLevel && (
                <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-zinc-800">
                  <span className="text-slate-500 dark:text-zinc-400">Mức độ bảo vệ:</span>
                  <span className="font-bold text-slate-800 dark:text-zinc-200">{item.protectionLevel}</span>
                </div>
              )}
              {item.associatedApp && (
                <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-zinc-800">
                  <span className="text-slate-500 dark:text-zinc-400">Ứng dụng mở mặc định:</span>
                  <span className="font-mono text-slate-800 dark:text-zinc-200">{item.associatedApp}</span>
                </div>
              )}
              {item.symlinkTarget && (
                <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-zinc-800">
                  <span className="text-slate-500 dark:text-zinc-400">Đích liên kết (Symlink):</span>
                  <span className="font-mono text-[11px] text-slate-800 dark:text-zinc-200">{item.symlinkTarget}</span>
                </div>
              )}
              <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-zinc-800">
                <span className="text-slate-500 dark:text-zinc-400">Loại:</span>
                <span className="text-slate-800 dark:text-zinc-200">{item.isDirectory ? 'Thư mục' : 'Tệp tin'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-zinc-800">
                <span className="text-slate-500 dark:text-zinc-400">Phiên bản tệp:</span>
                <span className="font-mono text-slate-800 dark:text-zinc-200">10.0.22631.3296</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-zinc-800">
                <span className="text-slate-500 dark:text-zinc-400">Tên sản phẩm:</span>
                <span className="text-slate-800 dark:text-zinc-200">Microsoft® Windows® Operating System</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-zinc-800">
                <span className="text-slate-500 dark:text-zinc-400">Bản quyền:</span>
                <span className="text-slate-800 dark:text-zinc-200">© Microsoft Corporation. All rights reserved.</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-zinc-800">
                <span className="text-slate-500 dark:text-zinc-400">Máy tính:</span>
                <span className="text-slate-800 dark:text-zinc-200">DESKTOP-WIN11PRO</span>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-2 px-4 py-3 bg-slate-50 dark:bg-[#1a1a1a] border-t border-slate-200/80 dark:border-zinc-800 text-xs">
          <button
            onClick={closeFileProperties}
            className="px-5 py-2 bg-sky-600 hover:bg-sky-500 active:scale-95 text-white font-medium rounded-xl transition-all shadow-sm"
          >
            OK
          </button>
          <button
            onClick={closeFileProperties}
            className="px-4 py-2 hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-300 font-medium rounded-xl transition-colors"
          >
            Hủy bỏ
          </button>
        </div>
      </div>
    </div>
  );
};
