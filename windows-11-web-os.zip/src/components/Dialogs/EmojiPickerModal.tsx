import React, { useState } from 'react';
import { Smile, Search, Heart, Sparkles, X, Copy, Check } from 'lucide-react';
import { useOS } from '../../context/OSContext';

interface EmojiPickerModalProps {
  onClose: () => void;
}

const EMOJI_CATEGORIES = [
  {
    name: 'Mặt cười & Cảm xúc',
    emojis: ['😀', '😃', '😄', '😁', '😆', '😅', '🤣', '😂', '🙂', '😉', '😊', '😇', '🥰', '😍', '🤩', '😘', '😋', '😜', '🤪', '😎', '🥳', '😏', '🤔', '🤫', '🤭', '🤐', '🤨', '😐', '😑', '😶', '😏', '😒', '🙄', '😬', '😮‍💨', '🤥', '😌', '😔', '😪', '🤤', '😴', '😷', '🤒', '🤕', '🤢', '🤮', '🤧', '🥵', '🥶', '🥴', '😵', '🤯', '🤠', '🥳', '🥸', '😎', '🤓', '🧐'],
  },
  {
    name: 'Cử chỉ & Cơ thể',
    emojis: ['👍', '👎', '👌', '🤌', '🤏', '✌️', '🤞', '🫰', '🤟', '🤘', '🤙', '👈', '👉', '👆', '🖕', '👇', '☝️', '👋', '🤚', '🖐️', '✋', '🖖', '👏', '🙌', '👐', '🤲', '🤝', '🙏', '✍️', '💪', '🦾', '🦿', '🦵', '🦶'],
  },
  {
    name: 'Biểu tượng & Trái tim',
    emojis: ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '❣️', '💕', '💞', '💓', '💗', '💖', '💘', '💝', '💟', '☮️', '✝️', '☪️', '🕉️', '☸️', '✡️', '🔯', '🕎', '☯️', '☦️', '🛐', '⛎', '♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓', '🆔', '⚛️'],
  },
  {
    name: 'Kaomoji Nhật Bản (っ˘ڡ˘ς)',
    emojis: ['(•‿•)', '(｡♥‿♥｡)', '(✿◠‿◠)', '(ᵔᴥᵔ)', 'ʕ•ᴥ•ʔ', '(•_•)', '(▀̿Ĺ̯▀̿ ̿)', '(づ｡◕‿‿◕｡)づ', '¯\\_(ツ)_/¯', '(╯°□°）╯︵ ┻━┻', '(ง\'̀-\'́)ง', '(ノಠ益ಠ)ノ', 'ಠ_ಠ', '(ಥ﹏ಥ)', '(ノ^_^)ノ'],
  },
  {
    name: 'Ký tự đặc biệt (Symbols)',
    emojis: ['™', '®', '©', '°', '±', '≠', '≤', '≥', '÷', '×', '√', '∞', 'µ', 'π', 'Ω', '∑', '∫', '∆', '≈', '‰', '€', '$', '¥', '£', '₫', '¢', '★', '☆', '✦', '✧', '♠', '♣', '♥', '♦', '♪', '♫', '✓', '✗', '→', '←', '↑', '↓', '↔', '▲', '▼', '◄', '►'],
  },
];

export const EmojiPickerModal: React.FC<EmojiPickerModalProps> = ({ onClose }) => {
  const { addNotification } = useOS();
  const [activeCat, setActiveCat] = useState(0);
  const [search, setSearch] = useState('');
  const [copiedEmoji, setCopiedEmoji] = useState<string | null>(null);

  const handleCopy = (emoji: string) => {
    navigator.clipboard?.writeText(emoji);
    setCopiedEmoji(emoji);
    addNotification('Đã sao chép', `Biểu tượng "${emoji}" đã được sao chép vào bộ nhớ tạm!`, 'info');
    setTimeout(() => setCopiedEmoji(null), 1500);
  };

  const filteredEmojis = search.trim()
    ? EMOJI_CATEGORIES.flatMap((c) => c.emojis).filter((e) => e.includes(search))
    : EMOJI_CATEGORIES[activeCat].emojis;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/20 backdrop-blur-xs">
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm bg-white/95 dark:bg-[#202020]/95 backdrop-blur-2xl rounded-2xl border border-white/20 dark:border-white/10 shadow-2xl p-4 text-slate-800 dark:text-slate-100 select-none animate-win11-flyin flex flex-col max-h-[480px]"
      >
        <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-zinc-800">
          <div className="flex items-center gap-2 font-bold text-xs">
            <Smile size={16} className="text-amber-500" />
            <span>Biểu tượng cảm xúc, Kaomoji & Ký hiệu (Win + .)</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-700 transition-colors"
          >
            <X size={15} />
          </button>
        </div>

        {/* Search */}
        <div className="relative my-2.5">
          <Search size={14} className="absolute left-2.5 top-2.5 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Tìm kiếm biểu tượng..."
            className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-slate-200 dark:border-zinc-700 bg-white/80 dark:bg-zinc-900/80 text-xs focus:outline-none focus:ring-2 focus:ring-sky-500"
          />
        </div>

        {/* Category Tabs */}
        {!search && (
          <div className="flex items-center gap-1 overflow-x-auto pb-2 mb-2 border-b border-slate-200 dark:border-zinc-800 text-[11px] font-medium shrink-0">
            {EMOJI_CATEGORIES.map((cat, idx) => (
              <button
                key={cat.name}
                onClick={() => setActiveCat(idx)}
                className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
                  activeCat === idx
                    ? 'bg-sky-500 text-white font-semibold shadow-xs'
                    : 'hover:bg-slate-200 dark:hover:bg-zinc-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                {cat.name.split(' ')[0]}
              </button>
            ))}
          </div>
        )}

        {/* Emoji Grid */}
        <div className="flex-1 overflow-y-auto grid grid-cols-6 gap-2 p-1 text-2xl text-center">
          {filteredEmojis.map((emoji, i) => (
            <button
              key={i}
              onClick={() => handleCopy(emoji)}
              className="p-2 rounded-xl hover:bg-slate-200 dark:hover:bg-zinc-800 hover:scale-115 transition-all flex items-center justify-center cursor-pointer relative"
              title="Bấm để sao chép"
            >
              <span className="text-xl">{emoji}</span>
              {copiedEmoji === emoji && (
                <div className="absolute inset-0 bg-sky-500/80 rounded-xl flex items-center justify-center text-white text-xs">
                  <Check size={14} />
                </div>
              )}
            </button>
          ))}
        </div>

        <div className="pt-2 border-t border-slate-200 dark:border-zinc-800 text-[10px] text-slate-400 text-center">
          Bấm vào bất kỳ biểu tượng nào để tự động chép vào Clipboard
        </div>
      </div>
    </div>
  );
};
