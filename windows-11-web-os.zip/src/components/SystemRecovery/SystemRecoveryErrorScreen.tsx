import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { WinRETerminal } from '../WinRE/WinRETerminal';
import { UEFIUtility } from '../WinRE/UEFIUtility';
import { StartupSettingsScreen } from '../WinRE/StartupSettingsScreen';
import { SafeModeType, UEFIConfig } from '../../types/winre';
import {
  AlertTriangle,
  RotateCcw,
  Wrench,
  RotateCw,
  Trash2,
  Power,
  CheckCircle2,
  ShieldAlert,
  Loader2,
  HardDrive,
  UserCheck,
  FileText,
  Terminal,
  Sliders,
  Cpu,
  Archive,
  RefreshCw,
  ChevronLeft,
  Info,
  Layers,
  FileCode,
  ShieldCheck,
  HelpCircle,
  ExternalLink,
} from 'lucide-react';

interface SystemRecoveryErrorScreenProps {
  isOpen?: boolean;
  fileName?: string;
  filePath?: string;
  errorCode?: string;
  onStartupRepair?: () => void;
  onSystemRestore?: () => void;
  onResetKeepFiles?: () => void;
  onResetRemoveAll?: () => void;
  onShutdown?: () => void;
}

export const SystemRecoveryErrorScreen: React.FC<SystemRecoveryErrorScreenProps> = (props) => {
  const {
    systemFailure,
    restoreFromRestorePoint,
    repairStartup,
    resetPCKeepPersonalFiles,
    resetPCRemoveEverything,
    shutdownSystemFailure,
    startSafeMode,
    uefiConfig,
    updateUEFIConfig,
    clearSystemFailure,
    setBootState,
  } = useOS();

  // Active sub-views: 'main' | 'cmd' | 'startup-settings' | 'uefi' | 'system-image' | 'uninstall-updates' | 'log-modal' | 'restore-points'
  const [subView, setSubView] = useState<string>('main');
  const [activeAction, setActiveAction] = useState<string | null>(null);
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [selectedRestorePoint, setSelectedRestorePoint] = useState<string>('rp-1');
  const [selectedUpdateType, setSelectedUpdateType] = useState<'quality' | 'feature'>('quality');
  const [showLogModal, setShowLogModal] = useState<boolean>(false);

  // Category tab: 'all' | 'quick' | 'advanced' | 'reset'
  const [activeTab, setActiveTab] = useState<'all' | 'quick' | 'advanced' | 'reset'>('all');

  const isFailed = props.isOpen !== undefined ? props.isOpen : systemFailure.isFailed;
  if (!isFailed) return null;

  const fileName = props.fileName || systemFailure.failedFileName || 'ntoskrnl.exe';
  const filePath = props.filePath || systemFailure.failedFilePath || 'C:\\Windows\\System32\\ntoskrnl.exe';
  const errorCode = props.errorCode || systemFailure.errorCode || '0xc0000098';

  // Handler 1: Khôi phục từ điểm khôi phục (System Restore)
  const handleSystemRestore = () => {
    setSubView('main');
    setActiveAction('restore');
    setProgressPercent(10);
    setStatusMessage('Đang khởi động Windows System Restore...');

    setTimeout(() => {
      setProgressPercent(40);
      setStatusMessage('Đang quét và đối chiếu các tệp hệ thống bị thiếu từ Restore Point...');
    }, 1000);

    setTimeout(() => {
      setProgressPercent(75);
      setStatusMessage('Đang khôi phục Windows Registry, System32 và phân quyền TrustedInstaller...');
    }, 2200);

    setTimeout(() => {
      setProgressPercent(100);
      setStatusMessage('Khôi phục hoàn tất! Đang khởi động lại vào màn hình chính...');
      setTimeout(() => {
        if (props.onSystemRestore) {
          props.onSystemRestore();
        } else {
          restoreFromRestorePoint();
        }
      }, 1000);
    }, 3400);
  };

  // Handler 2: Sửa lỗi khởi động tự động (Startup Repair)
  const handleStartupRepair = () => {
    setSubView('main');
    setActiveAction('repair');
    setProgressPercent(15);
    setStatusMessage('Đang chẩn đoán PC của bạn (Diagnosing your PC)...');

    setTimeout(() => {
      setProgressPercent(50);
      setStatusMessage(`Đang sửa chữa thành phần khởi động bị hỏng: ${fileName}...`);
    }, 1200);

    setTimeout(() => {
      setProgressPercent(90);
      setStatusMessage('Đã sao chép tệp khởi động sạch từ kho lưu trữ WinSxS / Recovery...');
    }, 2400);

    setTimeout(() => {
      setProgressPercent(100);
      setStatusMessage('Sửa lỗi thành công! Đang khởi động lại Windows 11...');
      setTimeout(() => {
        if (props.onStartupRepair) {
          props.onStartupRepair();
        } else {
          repairStartup();
        }
      }, 1000);
    }, 3500);
  };

  // Handler 3: Thử khởi động lại bình thường
  const handleNormalReboot = () => {
    setActiveAction('reboot');
    setProgressPercent(30);
    setStatusMessage('Đang chuẩn bị khởi động lại Windows 11...');
    setTimeout(() => {
      setProgressPercent(100);
      setStatusMessage('Đang khởi động lại...');
      setTimeout(() => {
        clearSystemFailure();
        setBootState('restarting');
        setTimeout(() => {
          setBootState('booting');
        }, 1200);
      }, 800);
    }, 1200);
  };

  // Handler 4: Đặt lại máy - Giữ tệp cá nhân (Keep my files)
  const handleResetKeepFiles = () => {
    setSubView('main');
    setActiveAction('reset-keep');
    setProgressPercent(20);
    setStatusMessage('Đang chuẩn bị cài đặt lại Windows (Giữ lại tệp cá nhân)...');

    setTimeout(() => {
      setProgressPercent(55);
      setStatusMessage('Đang lưu trữ ảnh, tài liệu và dữ liệu người dùng tại C:\\Users và ổ D:...');
    }, 1200);

    setTimeout(() => {
      setProgressPercent(80);
      setStatusMessage('Đang thiết lập lại toàn bộ hệ điều hành Windows 11 gốc...');
    }, 2400);

    setTimeout(() => {
      setProgressPercent(100);
      setStatusMessage('Đang khởi động lại vào màn hình thiết lập tài khoản mới (OOBE)...');
      setTimeout(() => {
        if (props.onResetKeepFiles) {
          props.onResetKeepFiles();
        } else {
          resetPCKeepPersonalFiles();
        }
      }, 1200);
    }, 3600);
  };

  // Handler 5: Đặt lại máy - Xóa hết (Remove everything)
  const handleResetRemoveAll = () => {
    if (
      !confirm(
        'CẢNH BÁO: Thao tác này sẽ xóa sạch toàn bộ dữ liệu, tài khoản và cài đặt. Bạn có chắc chắn muốn xóa hết?'
      )
    ) {
      return;
    }
    setSubView('main');
    setActiveAction('reset-all');
    setProgressPercent(20);
    setStatusMessage('Đang xóa toàn bộ ổ đĩa và dữ liệu người dùng...');

    setTimeout(() => {
      setProgressPercent(60);
      setStatusMessage('Đang khôi phục cài đặt xuất xưởng Windows 11 ban đầu...');
    }, 1200);

    setTimeout(() => {
      setProgressPercent(90);
      setStatusMessage('Đang dọn dẹp phân vùng và chuẩn bị màn hình khởi động mới...');
    }, 2400);

    setTimeout(() => {
      setProgressPercent(100);
      setStatusMessage('Đã xóa sạch! Đang khởi động như máy tính mới mua...');
      setTimeout(() => {
        if (props.onResetRemoveAll) {
          props.onResetRemoveAll();
        } else {
          resetPCRemoveEverything();
        }
      }, 1200);
    }, 3600);
  };

  // Handler 6: Gỡ cài đặt bản cập nhật (Uninstall Updates)
  const handleUninstallUpdate = (type: 'quality' | 'feature') => {
    setSelectedUpdateType(type);
    setSubView('main');
    setActiveAction('uninstall-update');
    setProgressPercent(15);
    setStatusMessage(
      `Đang gỡ bỏ bản cập nhật ${type === 'quality' ? 'chất lượng KB5034848' : 'tính năng 23H2'}...`
    );

    setTimeout(() => {
      setProgressPercent(60);
      setStatusMessage('Đang khôi phục các tệp nhân hệ thống ntoskrnl và driver trước đó...');
    }, 1500);

    setTimeout(() => {
      setProgressPercent(100);
      setStatusMessage('Gỡ bản cập nhật thành công! Khởi động lại Windows 11...');
      setTimeout(() => {
        restoreFromRestorePoint();
      }, 1200);
    }, 3200);
  };

  // Handler 7: Khôi phục từ ảnh sao lưu hệ thống (System Image Recovery)
  const handleSystemImageRestore = () => {
    setSubView('main');
    setActiveAction('image-restore');
    setProgressPercent(15);
    setStatusMessage('Đang đọc ảnh sao lưu WindowsImageBackup từ ổ đĩa D:...');

    setTimeout(() => {
      setProgressPercent(55);
      setStatusMessage('Đang nạp lại ảnh phân vùng hệ thống EFI + Windows 11 Pro...');
    }, 1500);

    setTimeout(() => {
      setProgressPercent(100);
      setStatusMessage('Khôi phục ảnh hoàn tất! Đang khởi động lại...');
      setTimeout(() => {
        restoreFromRestorePoint();
      }, 1200);
    }, 3200);
  };

  // Handler 8: Tắt máy tính
  const handleShutdown = () => {
    if (props.onShutdown) {
      props.onShutdown();
    } else {
      shutdownSystemFailure();
    }
  };

  // SUB-VIEW: Command Prompt (Terminal)
  if (subView === 'cmd') {
    return (
      <div className="fixed inset-0 z-[100000] bg-black">
        <WinRETerminal
          onClose={() => setSubView('main')}
          onRepairSuccess={() => {
            // Repair system files in the virtual filesystem
            restoreFromRestorePoint();
          }}
        />
      </div>
    );
  }

  // SUB-VIEW: Startup Settings (Safe Mode selection)
  if (subView === 'startup-settings') {
    return (
      <div className="fixed inset-0 z-[100000]">
        <StartupSettingsScreen
          onSelectOption={(num, sm) => {
            startSafeMode(sm);
          }}
          onCancel={() => setSubView('main')}
        />
      </div>
    );
  }

  // SUB-VIEW: UEFI / BIOS Utility
  if (subView === 'uefi') {
    return (
      <div className="fixed inset-0 z-[100000]">
        <UEFIUtility
          config={uefiConfig}
          onSaveAndExit={(newCfg) => {
            updateUEFIConfig(newCfg);
            handleSystemRestore();
          }}
          onDiscardAndExit={() => setSubView('main')}
        />
      </div>
    );
  }

  // SUB-VIEW: Select Restore Point Wizard
  if (subView === 'restore-points') {
    return (
      <div className="fixed inset-0 z-[100000] bg-[#004275] text-white flex flex-col justify-between p-6 sm:p-12 font-sans select-none overflow-y-auto">
        <div className="max-w-3xl mx-auto w-full space-y-6 animate-win11-fade">
          <button
            onClick={() => setSubView('main')}
            className="flex items-center gap-2 text-xs font-semibold text-sky-200 hover:text-white transition-colors"
          >
            <ChevronLeft size={16} /> Quay lại danh sách tùy chọn (Back)
          </button>

          <div>
            <h1 className="text-3xl font-light">Khôi phục Hệ thống (System Restore)</h1>
            <p className="text-xs text-sky-100 mt-1">
              Chọn điểm khôi phục trước khi sự cố xóa tệp xảy ra (Dữ liệu cá nhân, ảnh, tài liệu được giữ nguyên 100%):
            </p>
          </div>

          <div className="space-y-2.5">
            {[
              {
                id: 'rp-1',
                date: '2026-08-28 14:30:00 (Hôm nay)',
                desc: 'Điểm khôi phục trước khi gỡ / chỉnh sửa tệp hệ thống',
                type: 'System Checkpoint',
                badge: 'Khuyên dùng',
              },
              {
                id: 'rp-2',
                date: '2026-08-25 09:15:22',
                desc: 'Windows Update KB5034848 (Cập nhật hệ thống)',
                type: 'Windows Update',
              },
              {
                id: 'rp-3',
                date: '2026-08-20 18:00:00',
                desc: 'Cài đặt Visual Studio & Driver mở rộng (Thủ công)',
                type: 'Manual',
              },
            ].map((rp) => (
              <div
                key={rp.id}
                onClick={() => setSelectedRestorePoint(rp.id)}
                className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-center justify-between text-xs ${
                  selectedRestorePoint === rp.id
                    ? 'bg-white/20 border-emerald-400 shadow-lg'
                    : 'bg-white/10 border-white/10 hover:bg-white/15'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-white">{rp.desc}</span>
                    {rp.badge && (
                      <span className="text-[10px] bg-emerald-500/40 text-emerald-200 border border-emerald-400/50 px-2 py-0.5 rounded-full font-bold">
                        {rp.badge}
                      </span>
                    )}
                  </div>
                  <div className="text-sky-200 text-xs">Thời gian tạo: {rp.date}</div>
                </div>
                <span className="text-[11px] bg-black/40 text-sky-200 px-2.5 py-1 rounded-lg font-mono">
                  {rp.type}
                </span>
              </div>
            ))}
          </div>

          <div className="flex gap-3 pt-2">
            <button
              onClick={handleSystemRestore}
              className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition-all"
            >
              Tiến hành Khôi phục ngay (Restore)
            </button>
            <button
              onClick={() => setSubView('main')}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl transition-all"
            >
              Hủy bỏ (Cancel)
            </button>
          </div>
        </div>
      </div>
    );
  }

  // SUB-VIEW: System Image Wizard
  if (subView === 'system-image') {
    return (
      <div className="fixed inset-0 z-[100000] bg-[#004275] text-white flex flex-col justify-between p-6 sm:p-12 font-sans select-none overflow-y-auto">
        <div className="max-w-3xl mx-auto w-full space-y-6 animate-win11-fade">
          <button
            onClick={() => setSubView('main')}
            className="flex items-center gap-2 text-xs font-semibold text-sky-200 hover:text-white transition-colors"
          >
            <ChevronLeft size={16} /> Quay lại danh sách tùy chọn (Back)
          </button>

          <div>
            <h1 className="text-3xl font-light">Khôi phục từ Ảnh Hệ thống (System Image Recovery)</h1>
            <p className="text-xs text-sky-100 mt-1">Tìm thấy bản sao lưu hình ảnh hệ thống trên thiết bị:</p>
          </div>

          <div className="p-5 bg-black/30 rounded-2xl border border-white/20 space-y-3 text-xs">
            <div className="flex items-center justify-between font-bold text-sm">
              <span className="text-emerald-300">Vị trí: D:\WindowsImageBackup\WIN11-PC</span>
              <span className="text-sky-300 font-mono">Dung lượng: 42.8 GB</span>
            </div>
            <div className="text-sky-200">Thời gian sao lưu: 2026-08-10 22:45:10 | Ổ đĩa: Local Disk (C:)</div>
            <div className="text-sky-200">Bản sao lưu gồm: Toàn bộ phân vùng EFI Boot + Windows 11 Pro System32</div>
          </div>

          <div className="flex gap-3 pt-2">
            <button
              onClick={handleSystemImageRestore}
              className="px-6 py-2.5 bg-sky-500 hover:bg-sky-400 active:scale-95 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition-all"
            >
              Bắt đầu Khôi phục Ảnh (Start Re-imaging)
            </button>
            <button
              onClick={() => setSubView('main')}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl transition-all"
            >
              Hủy (Cancel)
            </button>
          </div>
        </div>
      </div>
    );
  }

  // SUB-VIEW: Uninstall Updates Wizard
  if (subView === 'uninstall-updates') {
    return (
      <div className="fixed inset-0 z-[100000] bg-[#004275] text-white flex flex-col justify-between p-6 sm:p-12 font-sans select-none overflow-y-auto">
        <div className="max-w-3xl mx-auto w-full space-y-6 animate-win11-fade">
          <button
            onClick={() => setSubView('main')}
            className="flex items-center gap-2 text-xs font-semibold text-sky-200 hover:text-white transition-colors"
          >
            <ChevronLeft size={16} /> Quay lại danh sách tùy chọn (Back)
          </button>

          <div>
            <h1 className="text-3xl font-light">Gỡ cài đặt Bản cập nhật (Uninstall Updates)</h1>
            <p className="text-xs text-sky-100 mt-1">Chọn loại bản cập nhật bạn muốn gỡ bỏ để phục hồi Windows:</p>
          </div>

          <div className="space-y-3">
            <button
              onClick={() => handleUninstallUpdate('quality')}
              className="w-full p-4 bg-white/10 hover:bg-white/20 active:scale-[0.99] rounded-2xl transition-all border border-white/20 text-left flex items-center justify-between group"
            >
              <div className="space-y-1">
                <div className="text-sm font-bold text-white group-hover:text-sky-200">
                  Gỡ bản cập nhật chất lượng gần nhất (Uninstall latest quality update)
                </div>
                <div className="text-xs text-sky-100">
                  Gỡ bản cập nhật bảo mật định kỳ hàng tháng (Ví dụ: KB5034848) để khôi phục tệp hệ thống cũ.
                </div>
              </div>
              <span className="text-xs text-sky-200 group-hover:text-white">→</span>
            </button>

            <button
              onClick={() => handleUninstallUpdate('feature')}
              className="w-full p-4 bg-white/10 hover:bg-white/20 active:scale-[0.99] rounded-2xl transition-all border border-white/20 text-left flex items-center justify-between group"
            >
              <div className="space-y-1">
                <div className="text-sm font-bold text-white group-hover:text-sky-200">
                  Gỡ bản cập nhật tính năng gần nhất (Uninstall latest feature update)
                </div>
                <div className="text-xs text-sky-100">
                  Gỡ bản nâng cấp phiên bản lớn hàng năm (Ví dụ: Windows 11 23H2) quay về bản dựng trước.
                </div>
              </div>
              <span className="text-xs text-sky-200 group-hover:text-white">→</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      id="system-recovery-screen"
      className="fixed inset-0 z-[100000] text-white flex flex-col justify-between p-4 sm:p-8 md:p-10 font-sans select-none overflow-y-auto"
      style={{
        background: 'radial-gradient(ellipse at center, #005a9e 0%, #004275 65%, #002544 100%)',
      }}
    >
      {/* Top Banner & Error Info Card */}
      <div className="max-w-4xl mx-auto w-full pt-2 sm:pt-4 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3.5">
            <div className="p-3 bg-amber-500/20 border border-amber-400/40 rounded-2xl text-amber-300 shrink-0">
              <AlertTriangle size={34} />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-light tracking-wide flex items-center gap-2">
                <span>Phục hồi (Recovery)</span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-red-500/30 text-red-200 border border-red-400/40 font-semibold font-mono">
                  WinRE 11
                </span>
              </h1>
              <p className="text-xs sm:text-sm text-blue-200 mt-0.5">
                Hệ thống phát hiện tệp hoặc thành phần cốt lõi của Windows bị thiếu / hỏng
              </p>
            </div>
          </div>

          {/* Quick diagnostic button */}
          <button
            onClick={() => setShowLogModal(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-semibold text-sky-200 hover:text-white transition-all self-start sm:self-auto"
          >
            <FileText size={16} />
            <span>Xem chi tiết nhật ký (SrtTrail.txt)</span>
          </button>
        </div>

        {/* Error Details Box */}
        <div className="bg-blue-950/60 border border-blue-400/30 backdrop-blur-md rounded-2xl p-4 sm:p-5 space-y-2.5 text-xs sm:text-sm shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-amber-300 font-semibold">
              <ShieldAlert size={18} />
              <span>Tệp hệ thống quan trọng bị xóa hoặc không thể tải:</span>
            </div>
            <span className="text-[11px] font-mono bg-red-500/20 text-red-300 px-2 py-0.5 rounded border border-red-500/30">
              Critical
            </span>
          </div>

          <div className="font-mono text-xs sm:text-sm bg-black/40 p-3 rounded-xl border border-white/10 text-emerald-300 select-text flex items-center justify-between">
            <span>{filePath}</span>
            <span className="text-xs text-slate-400 hidden sm:inline">Owner: TrustedInstaller</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 text-blue-200 text-xs">
            <div>
              Mã lỗi (Error code): <span className="font-mono font-bold text-white">{errorCode}</span>
            </div>
            <div>
              Trạng thái: <span className="text-red-300 font-semibold">Missing Operating Component</span>
            </div>
            <div>
              Phân vùng: <span className="text-sky-300 font-semibold">C: (Windows 11 NTFS)</span>
            </div>
          </div>
        </div>

        {/* Diagnostic Log Modal */}
        {showLogModal && (
          <div className="fixed inset-0 z-[100005] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-slate-900 border border-white/20 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl animate-win11-scale">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="flex items-center gap-2 text-sky-400 font-bold text-sm">
                  <FileCode size={18} />
                  <span>C:\Windows\System32\Logfiles\Srt\SrtTrail.txt</span>
                </div>
                <button
                  onClick={() => setShowLogModal(false)}
                  className="p-1.5 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"
                >
                  ✕
                </button>
              </div>

              <div className="font-mono text-xs text-slate-300 bg-black/50 p-4 rounded-xl space-y-1.5 max-h-80 overflow-y-auto border border-white/10">
                <div className="text-sky-300">Startup Repair diagnostic and repair log</div>
                <div>---------------------------</div>
                <div>Number of repair attempts: 1</div>
                <div>Session detail:</div>
                <div> System Disk = \Device\Harddisk0</div>
                <div> Windows directory = C:\Windows</div>
                <div> AutoChk Run = 0</div>
                <div> Number of root causes = 1</div>
                <div className="text-amber-300 pt-2">Root cause found:</div>
                <div className="text-red-300 font-bold">
                  ---------------------------
                  <br />
                  Critical boot file {filePath} is missing or corrupted.
                  <br />
                  Repair action: File restore from WinSxS / System Restore Point
                  <br />
                  Result: Ready to repair
                  <br />
                  Error code = {errorCode}
                </div>
                <div className="text-emerald-400 pt-2">
                  Recommended action: Run "System Restore" or "Startup Repair" below.
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => {
                    setShowLogModal(false);
                    handleStartupRepair();
                  }}
                  className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs rounded-xl transition-all"
                >
                  Chạy Sửa chữa Ngay (Repair)
                </button>
                <button
                  onClick={() => setShowLogModal(false)}
                  className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs rounded-xl transition-all"
                >
                  Đóng (Close)
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Progress Display when an action is running */}
        {activeAction && (
          <div className="bg-black/50 border border-sky-400/40 backdrop-blur-md rounded-2xl p-6 space-y-4 animate-win11-fade shadow-2xl">
            <div className="flex items-center gap-3">
              <Loader2 size={24} className="animate-spin text-sky-400 shrink-0" />
              <span className="text-base font-medium text-white">{statusMessage}</span>
            </div>
            <div className="w-full h-3 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-sky-400 to-emerald-400 transition-all duration-300 ease-out"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <div className="flex justify-between items-center text-xs text-blue-200 font-mono">
              <span>Đang thực thi nhiệm vụ phục hồi...</span>
              <span className="font-bold text-white text-sm">{progressPercent}%</span>
            </div>
          </div>
        )}

        {/* Category Tabs & Options Selection Menu */}
        {!activeAction && (
          <div className="space-y-4">
            {/* Category Filter Pills */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {[
                { id: 'all', label: 'Tất cả chức năng' },
                { id: 'quick', label: 'Khôi phục Nhanh (Khuyên dùng)' },
                { id: 'advanced', label: 'Công cụ Chuyên sâu (CMD / Safe Mode / UEFI)' },
                { id: 'reset', label: 'Cài đặt lại Windows (Reset)' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                    activeTab === tab.id
                      ? 'bg-white text-slate-900 shadow-md font-bold'
                      : 'bg-white/10 hover:bg-white/20 text-sky-100'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Option 1: System Restore (Best - No data loss) */}
              {(activeTab === 'all' || activeTab === 'quick') && (
                <button
                  id="recovery-option-restore"
                  onClick={() => setSubView('restore-points')}
                  className="group p-4 rounded-2xl bg-white/10 hover:bg-white/20 active:scale-[0.99] border border-emerald-400/40 hover:border-emerald-400 backdrop-blur-md flex items-start gap-3.5 transition-all text-left shadow-lg md:col-span-2"
                >
                  <div className="p-3 bg-emerald-500/20 text-emerald-300 rounded-xl group-hover:bg-emerald-500/30 transition-colors shrink-0">
                    <RotateCcw size={24} />
                  </div>
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-base font-semibold text-white group-hover:text-emerald-200 transition-colors">
                        Khôi phục từ điểm khôi phục (System Restore)
                      </span>
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/30 text-emerald-200 border border-emerald-400/40">
                        KHUYÊN DÙNG • KHÔNG MẤT GÌ CẢ
                      </span>
                    </div>
                    <p className="text-xs text-blue-100 mt-1 leading-relaxed">
                      Quay lại trạng thái trước khi bị xóa tệp. Giữ nguyên tài khoản cũ, mật khẩu cũ, toàn bộ ứng dụng và tệp cá nhân. Khởi động thẳng vào màn hình chính.
                    </p>
                  </div>
                </button>
              )}

              {/* Option 2: Startup Repair */}
              {(activeTab === 'all' || activeTab === 'quick') && (
                <button
                  id="recovery-option-repair"
                  onClick={handleStartupRepair}
                  className="group p-4 rounded-2xl bg-white/10 hover:bg-white/20 active:scale-[0.99] border border-sky-400/30 hover:border-sky-400 backdrop-blur-md flex items-start gap-3.5 transition-all text-left shadow-lg"
                >
                  <div className="p-3 bg-sky-500/20 text-sky-300 rounded-xl group-hover:bg-sky-500/30 transition-colors shrink-0">
                    <Wrench size={22} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white group-hover:text-sky-200 transition-colors">
                        Sửa lỗi khởi động tự động (Startup Repair)
                      </span>
                    </div>
                    <p className="text-xs text-blue-100 mt-1 leading-relaxed">
                      Tự động sửa chữa boot record BCD và sao chép lại tệp hệ thống bị thiếu từ kho lưu trữ WinSxS.
                    </p>
                  </div>
                </button>
              )}

              {/* Option 3: Normal Reboot */}
              {(activeTab === 'all' || activeTab === 'quick') && (
                <button
                  id="recovery-option-reboot"
                  onClick={handleNormalReboot}
                  className="group p-4 rounded-2xl bg-white/10 hover:bg-white/20 active:scale-[0.99] border border-white/20 hover:border-white/40 backdrop-blur-md flex items-start gap-3.5 transition-all text-left shadow-lg"
                >
                  <div className="p-3 bg-white/15 text-white rounded-xl group-hover:bg-white/25 transition-colors shrink-0">
                    <RefreshCw size={22} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white transition-colors">
                        Thử khởi động lại bình thường (Try Normal Reboot)
                      </span>
                    </div>
                    <p className="text-xs text-blue-100 mt-1 leading-relaxed">
                      Khởi động lại máy để thử nạp lại phiên bản ntoskrnl dự phòng của hệ điều hành.
                    </p>
                  </div>
                </button>
              )}

              {/* Option 4: Command Prompt (CMD) */}
              {(activeTab === 'all' || activeTab === 'advanced') && (
                <button
                  id="recovery-option-cmd"
                  onClick={() => setSubView('cmd')}
                  className="group p-4 rounded-2xl bg-white/10 hover:bg-white/20 active:scale-[0.99] border border-cyan-400/30 hover:border-cyan-400 backdrop-blur-md flex items-start gap-3.5 transition-all text-left shadow-lg"
                >
                  <div className="p-3 bg-cyan-500/20 text-cyan-300 rounded-xl group-hover:bg-cyan-500/30 transition-colors shrink-0">
                    <Terminal size={22} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white group-hover:text-cyan-200 transition-colors">
                        Dấu nhắc lệnh Cứu hộ (Command Prompt - CMD)
                      </span>
                    </div>
                    <p className="text-xs text-blue-100 mt-1 leading-relaxed">
                      Chạy các lệnh quản trị ngoại tuyến: <code className="font-mono text-cyan-300 font-bold">sfc /scannow</code>, <code className="font-mono text-cyan-300">bootrec</code>, <code className="font-mono text-cyan-300">chkdsk</code>, <code className="font-mono text-cyan-300">diskpart</code>.
                    </p>
                  </div>
                </button>
              )}

              {/* Option 5: Startup Settings / Safe Mode */}
              {(activeTab === 'all' || activeTab === 'advanced') && (
                <button
                  id="recovery-option-safemode"
                  onClick={() => setSubView('startup-settings')}
                  className="group p-4 rounded-2xl bg-white/10 hover:bg-white/20 active:scale-[0.99] border border-purple-400/30 hover:border-purple-400 backdrop-blur-md flex items-start gap-3.5 transition-all text-left shadow-lg"
                >
                  <div className="p-3 bg-purple-500/20 text-purple-300 rounded-xl group-hover:bg-purple-500/30 transition-colors shrink-0">
                    <Sliders size={22} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white group-hover:text-purple-200 transition-colors">
                        Cài đặt Khởi động & Chế độ An toàn (Safe Mode)
                      </span>
                    </div>
                    <p className="text-xs text-blue-100 mt-1 leading-relaxed">
                      Khởi động vào Safe Mode (Tối thiểu, Có mạng, Có CMD) hoặc tắt kiểm tra chữ ký trình điều khiển.
                    </p>
                  </div>
                </button>
              )}

              {/* Option 6: UEFI / BIOS */}
              {(activeTab === 'all' || activeTab === 'advanced') && (
                <button
                  id="recovery-option-uefi"
                  onClick={() => setSubView('uefi')}
                  className="group p-4 rounded-2xl bg-white/10 hover:bg-white/20 active:scale-[0.99] border border-indigo-400/30 hover:border-indigo-400 backdrop-blur-md flex items-start gap-3.5 transition-all text-left shadow-lg"
                >
                  <div className="p-3 bg-indigo-500/20 text-indigo-300 rounded-xl group-hover:bg-indigo-500/30 transition-colors shrink-0">
                    <Cpu size={22} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white group-hover:text-indigo-200 transition-colors">
                        Cài đặt UEFI / BIOS Firmware
                      </span>
                    </div>
                    <p className="text-xs text-blue-100 mt-1 leading-relaxed">
                      Cấu hình phần cứng máy tính: Secure Boot, TPM 2.0, thứ tự ổ đĩa khởi động Boot Order và XMP RAM.
                    </p>
                  </div>
                </button>
              )}

              {/* Option 7: Uninstall Updates */}
              {(activeTab === 'all' || activeTab === 'advanced') && (
                <button
                  id="recovery-option-uninstall-updates"
                  onClick={() => setSubView('uninstall-updates')}
                  className="group p-4 rounded-2xl bg-white/10 hover:bg-white/20 active:scale-[0.99] border border-amber-400/30 hover:border-amber-400 backdrop-blur-md flex items-start gap-3.5 transition-all text-left shadow-lg"
                >
                  <div className="p-3 bg-amber-500/20 text-amber-300 rounded-xl group-hover:bg-amber-500/30 transition-colors shrink-0">
                    <Layers size={22} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white group-hover:text-amber-200 transition-colors">
                        Gỡ cài đặt bản cập nhật gần đây (Uninstall Updates)
                      </span>
                    </div>
                    <p className="text-xs text-blue-100 mt-1 leading-relaxed">
                      Gỡ bỏ bản cập nhật chất lượng KB hoặc bản cập nhật tính năng mới cài gây xung đột hệ thống.
                    </p>
                  </div>
                </button>
              )}

              {/* Option 8: System Image Recovery */}
              {(activeTab === 'all' || activeTab === 'advanced') && (
                <button
                  id="recovery-option-system-image"
                  onClick={() => setSubView('system-image')}
                  className="group p-4 rounded-2xl bg-white/10 hover:bg-white/20 active:scale-[0.99] border border-teal-400/30 hover:border-teal-400 backdrop-blur-md flex items-start gap-3.5 transition-all text-left shadow-lg"
                >
                  <div className="p-3 bg-teal-500/20 text-teal-300 rounded-xl group-hover:bg-teal-500/30 transition-colors shrink-0">
                    <Archive size={22} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white group-hover:text-teal-200 transition-colors">
                        Khôi phục từ Ảnh Hệ thống (System Image Recovery)
                      </span>
                    </div>
                    <p className="text-xs text-blue-100 mt-1 leading-relaxed">
                      Ghi lại toàn bộ ổ đĩa từ tệp sao lưu WindowsImageBackup có sẵn trên phân vùng ổ D:.
                    </p>
                  </div>
                </button>
              )}

              {/* Option 9: Reset PC - Keep personal files */}
              {(activeTab === 'all' || activeTab === 'reset') && (
                <button
                  id="recovery-option-reset-keep"
                  onClick={handleResetKeepFiles}
                  className="group p-4 rounded-2xl bg-white/10 hover:bg-white/20 active:scale-[0.99] border border-amber-400/30 hover:border-amber-400 backdrop-blur-md flex items-start gap-3.5 transition-all text-left shadow-lg"
                >
                  <div className="p-3 bg-amber-500/20 text-amber-300 rounded-xl group-hover:bg-amber-500/30 transition-colors shrink-0">
                    <RotateCw size={22} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white group-hover:text-amber-200 transition-colors">
                        Đặt lại máy (Giữ tệp cá nhân - Keep my files)
                      </span>
                    </div>
                    <p className="text-xs text-blue-100 mt-1 leading-relaxed">
                      Khôi phục Windows sạch. Giữ nguyên ảnh, tài liệu và dữ liệu ở Desktop, Documents, Downloads và ổ D:.
                    </p>
                  </div>
                </button>
              )}

              {/* Option 10: Reset PC - Remove all */}
              {(activeTab === 'all' || activeTab === 'reset') && (
                <button
                  id="recovery-option-reset-all"
                  onClick={handleResetRemoveAll}
                  className="group p-4 rounded-2xl bg-white/10 hover:bg-white/20 active:scale-[0.99] border border-red-400/30 hover:border-red-400 backdrop-blur-md flex items-start gap-3.5 transition-all text-left shadow-lg"
                >
                  <div className="p-3 bg-red-500/20 text-red-300 rounded-xl group-hover:bg-red-500/30 transition-colors shrink-0">
                    <Trash2 size={22} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white group-hover:text-red-200 transition-colors">
                        Đặt lại máy (Xóa hết - Remove everything)
                      </span>
                    </div>
                    <p className="text-xs text-blue-100 mt-1 leading-relaxed">
                      Xóa sạch toàn bộ dữ liệu, ứng dụng và tài khoản. Đưa Windows về trạng thái ban đầu xuất xưởng.
                    </p>
                  </div>
                </button>
              )}
            </div>

            {/* Option 11: Shut down */}
            <div className="pt-2">
              <button
                id="recovery-option-shutdown"
                onClick={handleShutdown}
                className="w-full p-3 rounded-2xl bg-black/30 hover:bg-black/40 border border-white/15 active:scale-[0.99] flex items-center justify-center gap-2.5 transition-all text-xs sm:text-sm font-semibold text-slate-300 hover:text-white"
              >
                <Power size={18} className="text-red-400" />
                <span>Tắt máy tính (Turn off your PC)</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className="max-w-4xl mx-auto w-full pt-6 pb-2 border-t border-white/15 flex flex-col sm:flex-row items-center justify-between text-xs text-blue-200 gap-2">
        <span className="flex items-center gap-2">
          <ShieldCheck size={16} className="text-emerald-400" />
          <span>Môi trường phục hồi Windows (Windows Recovery Environment - WinRE)</span>
        </span>
        <span className="font-mono text-[11px] text-blue-300">
          Build: 10.0.22631.3296 (Windows 11 Pro) | UEFI x64
        </span>
      </div>
    </div>
  );
};
