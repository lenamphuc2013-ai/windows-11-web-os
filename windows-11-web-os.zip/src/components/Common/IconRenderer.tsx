import React from 'react';
import * as LucideIcons from 'lucide-react';

interface IconRendererProps {
  name?: string;
  className?: string;
  size?: number;
  color?: string;
  type?: 'lucide' | 'image' | 'emoji' | 'svg';
}

export const IconRenderer: React.FC<IconRendererProps> = ({
  name = 'File',
  className = 'w-5 h-5',
  size = 20,
  color,
  type,
}) => {
  // If it looks like an image URL
  if (type === 'image' || (typeof name === 'string' && (name.startsWith('http') || name.startsWith('data:image')))) {
    return (
      <img
        src={name}
        alt="icon"
        className={`${className} object-contain rounded`}
        style={{ width: size, height: size }}
      />
    );
  }

  // If it's an emoji (or single Unicode char)
  if (type === 'emoji' || (typeof name === 'string' && name.length <= 4 && /\p{Extended_Pictographic}/u.test(name))) {
    return (
      <span
        className={`inline-flex items-center justify-center ${className}`}
        style={{ fontSize: size * 0.85, width: size, height: size }}
      >
        {name}
      </span>
    );
  }

  // Windows 11 custom SVG icons if name matches
  if (name === 'WinLogo') {
    return (
      <svg
        viewBox="0 0 24 24"
        className={className}
        style={{ width: size, height: size }}
        fill="currentColor"
      >
        <rect x="2" y="2" width="9.5" height="9.5" rx="1" fill="#00adef" />
        <rect x="12.5" y="2" width="9.5" height="9.5" rx="1" fill="#00adef" />
        <rect x="2" y="12.5" width="9.5" height="9.5" rx="1" fill="#00adef" />
        <rect x="12.5" y="12.5" width="9.5" height="9.5" rx="1" fill="#00adef" />
      </svg>
    );
  }

  if (name === 'YouTube' || name === 'Youtube') {
    return (
      <svg
        viewBox="0 0 24 24"
        className={className}
        style={{ width: size, height: size }}
      >
        <path
          d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814z"
          fill="#FF0000"
        />
        <path d="M9.545 15.568V8.432L15.818 12l-6.273 3.568z" fill="#FFFFFF" />
      </svg>
    );
  }

  // Lucide icon fallback
  const LucideIcon = (LucideIcons as any)[name] || LucideIcons.FileCode;

  return <LucideIcon className={className} size={size} color={color} />;
};
