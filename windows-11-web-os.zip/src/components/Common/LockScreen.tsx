import React, { useState, useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import {
  Lock,
  ArrowRight,
  ArrowLeft,
  User,
  Eye,
  EyeOff,
  Wifi,
  Power,
  Accessibility,
  CloudSun,
  Calendar,
  KeyRound,
  Camera,
  Moon,
  RotateCcw,
  AlertCircle,
  Sparkles,
  LogIn,
  Key,
  ShieldCheck,
} from 'lucide-react';
import { Win11Spinner } from '../BootScreen/Win11Spinner';
import { soundManager } from '../../utils/sound';

interface LockScreenProps {
  isLocked: boolean;
  onUnlock: () => void;
}

export const LockScreen: React.FC<LockScreenProps> = ({ isLocked, onUnlock }) => {
  const { settings, t, enterSleepMode, restartSystem, shutdownSystem, restartToWinRE, addNotification } = useOS();
  const [timeStr, setTimeStr] = useState('');
  const [dateStr, setDateStr] = useState('');
  const [isPromptVisible, setIsPromptVisible] = useState(false);
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [pinError, setPinError] = useState<string | null>(null);
  const [isShaking, setIsShaking] = useState(false);
  const [isWelcoming, setIsWelcoming] = useState(false);

  // Authentication configuration detection
  const hasPinConfigured = Boolean(settings.hasPin || (settings.requireLockPin && settings.lockPin));
  const hasPasswordConfigured = Boolean(settings.hasPassword && settings.password);
  const isAuthRequired = hasPinConfigured || hasPasswordConfigured;

  const [activeAuthType, setActiveAuthType] = useState<'pin' | 'password'>(() => {
    if (hasPinConfigured) return 'pin';
    if (hasPasswordConfigured) return 'password';
    return 'pin';
  });

  useEffect(() => {
    if (hasPinConfigured) {
      setActiveAuthType('pin');
    } else if (hasPasswordConfigured) {
      setActiveAuthType('password');
    }
  }, [hasPinConfigured, hasPasswordConfigured]);

  // Bottom-right flyouts
  const [showPowerMenu, setShowPowerMenu] = useState(false);
  const [showAccessibilityMenu, setShowAccessibilityMenu] = useState(false);
  const [showWifiTooltip, setShowWifiTooltip] = useState(false);
  const [showSpotlightInfo, setShowSpotlightInfo] = useState(false);

  // Accessibility toggles (in-session simulation)
  const [highContrast, setHighContrast] = useState(false);
  const [largeText, setLargeText] = useState(false);

  const pinInputRef = useRef<HTMLInputElement>(null);

  // Update real-time clock and localized date
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const locale =
        settings.language === 'vi'
          ? 'vi-VN'
          : settings.language === 'en'
          ? 'en-US'
          : settings.language === 'ja'
          ? 'ja-JP'
          : settings.language === 'ko'
          ? 'ko-KR'
          : 'vi-VN';

      setTimeStr(
        now.toLocaleTimeString(locale, {
          hour: '2-digit',
          minute: '2-digit',
          hour12: false,
        })
      );

      setDateStr(
        now.toLocaleDateString(locale, {
          weekday: 'long',
          month: 'long',
          day: 'numeric',
        })
      );
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [settings.language]);

  // Focus PIN input when sign-in prompt is displayed
  useEffect(() => {
    if (isPromptVisible && !isWelcoming) {
      setTimeout(() => {
        pinInputRef.current?.focus();
      }, 150);
    }
  }, [isPromptVisible, isWelcoming]);

  // Handle keyboard navigation & unlocking
  useEffect(() => {
    if (!isLocked) {
      setIsPromptVisible(false);
      setPin('');
      setPinError(null);
      setIsWelcoming(false);
      setShowPowerMenu(false);
      setShowAccessibilityMenu(false);
      return;
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      // Dismiss popovers on Escape or go back to clock view
      if (e.key === 'Escape') {
        if (showPowerMenu || showAccessibilityMenu || showSpotlightInfo) {
          setShowPowerMenu(false);
          setShowAccessibilityMenu(false);
          setShowSpotlightInfo(false);
          return;
        }
        if (isPromptVisible && !isWelcoming) {
          setIsPromptVisible(false);
          setPin('');
          setPinError(null);
          return;
        }
      }

      // Enter key opens prompt or submits
      if (e.key === 'Enter') {
        if (!isPromptVisible) {
          setIsPromptVisible(true);
        }
      } else {
        if (!isPromptVisible) {
          setIsPromptVisible(true);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    isLocked,
    isPromptVisible,
    isWelcoming,
    showPowerMenu,
    showAccessibilityMenu,
    showSpotlightInfo,
  ]);

  // Validate and submit unlock
  const handleUnlockSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (isWelcoming) return;

    setPinError(null);

    // If PIN or password is required, check correctness
    if (isAuthRequired) {
      if (activeAuthType === 'pin' && hasPinConfigured) {
        const targetPin = settings.lockPin || '1234';
        if (pin !== targetPin) {
          setIsShaking(true);
          setPinError(
            settings.language === 'en'
              ? 'The PIN is incorrect. Try again.'
              : 'Mã PIN không chính xác. Vui lòng thử lại.'
          );
          setTimeout(() => setIsShaking(false), 500);
          setTimeout(() => pinInputRef.current?.select(), 100);
          return;
        }
      } else if (activeAuthType === 'password' && hasPasswordConfigured) {
        const targetPass = settings.password || '';
        if (pin !== targetPass) {
          setIsShaking(true);
          setPinError(
            settings.language === 'en'
              ? 'The password is incorrect. Try again.'
              : 'Mật khẩu không chính xác. Vui lòng thử lại.'
          );
          setTimeout(() => setIsShaking(false), 500);
          setTimeout(() => pinInputRef.current?.select(), 100);
          return;
        }
      }
    }

    // Correct PIN/password or no password set: Authenticate and show Welcome state!
    setIsWelcoming(true);
    soundManager.playStartup();

    setTimeout(() => {
      onUnlock();
      setIsWelcoming(false);
      setIsPromptVisible(false);
      setPin('');
      setPinError(null);
    }, 850);
  };

  if (!isLocked) return null;

  const lockWallpaper = settings.lockScreenWallpaper || settings.wallpaper;
  const isSpotlight = settings.lockScreenType === 'spotlight';

  return (
    <div
      id="win11-lock-screen"
      onClick={() => {
        if (!isPromptVisible && !isWelcoming) {
          setIsPromptVisible(true);
        }
        setShowPowerMenu(false);
        setShowAccessibilityMenu(false);
        setShowWifiTooltip(false);
      }}
      className={`fixed inset-0 z-50 select-none bg-cover bg-center flex flex-col justify-between transition-all duration-700 overflow-hidden ${
        highContrast ? 'contrast-125' : ''
      }`}
      style={{ backgroundImage: `url("${lockWallpaper}")` }}
    >
      {/* Acrylic frosted glass overlay when sign-in prompt is active */}
      <div
        className={`absolute inset-0 transition-all duration-700 pointer-events-none ${
          isPromptVisible
            ? settings.showLockBackgroundOnSignIn !== false
              ? 'bg-black/50 backdrop-blur-2xl'
              : 'bg-zinc-950/80 backdrop-blur-3xl'
            : 'bg-black/15'
        }`}
      />

      {/* ===================================================================== */}
      {/* 1. TOP BAR: Windows Spotlight Badge & Back Arrow                      */}
      {/* ===================================================================== */}
      <div className="relative z-20 w-full px-6 py-4 sm:px-8 sm:py-5 flex items-center justify-between text-white shrink-0">
        {/* Back button (when prompt is open, like genuine Windows 11) */}
        {isPromptVisible && !isWelcoming ? (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsPromptVisible(false);
              setPin('');
              setPinError(null);
            }}
            className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 active:scale-95 text-white/90 text-xs backdrop-blur-md border border-white/15 transition-all shadow-md"
            title="Quay lại (Esc)"
          >
            <ArrowLeft size={16} />
            <span>Quay lại</span>
          </button>
        ) : (
          <div />
        )}

        {/* Windows Spotlight Camera Badge */}
        {!isPromptVisible && isSpotlight && (
          <div className="relative">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowSpotlightInfo(!showSpotlightInfo);
              }}
              className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/30 hover:bg-black/50 active:scale-95 backdrop-blur-md border border-white/15 text-white text-xs transition-all shadow-md group"
            >
              <Camera size={14} className="text-sky-300 group-hover:scale-110 transition-transform" />
              <span className="font-medium text-[11px] drop-shadow">Thích hình ảnh bạn thấy?</span>
            </button>

            {showSpotlightInfo && (
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute right-0 top-10 w-72 p-4 bg-zinc-900/90 backdrop-blur-xl border border-white/20 rounded-2xl text-white shadow-2xl space-y-2 animate-win11-fade z-30"
              >
                <div className="font-bold text-xs flex items-center gap-1.5 text-sky-400">
                  <Sparkles size={14} />
                  <span>Tiêu điểm của Windows (Spotlight)</span>
                </div>
                <p className="text-[11px] text-zinc-300 leading-relaxed">
                  Cảnh quan thiên nhiên kỳ vĩ độ phân giải cao được tuyển chọn bởi Windows 11.
                </p>
                <div className="flex gap-2 pt-1 border-t border-white/10">
                  <button
                    onClick={() => {
                      addNotification('Màn hình khóa', 'Cảm ơn phản hồi của bạn! Windows sẽ lưu sở thích này.', 'settings');
                      setShowSpotlightInfo(false);
                    }}
                    className="flex-1 py-1 px-2 rounded-lg bg-white/10 hover:bg-white/20 text-[10px] font-semibold text-center"
                  >
                    Tôi thích ảnh này
                  </button>
                  <button
                    onClick={() => {
                      addNotification('Màn hình khóa', 'Đã ghi nhận. Hình ảnh mới sẽ được gợi ý.', 'settings');
                      setShowSpotlightInfo(false);
                    }}
                    className="flex-1 py-1 px-2 rounded-lg bg-white/10 hover:bg-white/20 text-[10px] text-zinc-400 text-center"
                  >
                    Không phải gu của tôi
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ===================================================================== */}
      {/* 2. MAIN VIEWPORT AREA (Both Clock View & Centered Sign-in Prompt)    */}
      {/* ===================================================================== */}
      <div className="relative flex-1 w-full flex flex-col items-center justify-center overflow-hidden z-10 px-4 sm:px-8 min-h-0">
        {/* Clock, Date & Status Widget (Slides up & fades away when prompt is open) */}
        <div
          className={`absolute inset-0 flex flex-col justify-center sm:justify-start sm:pt-6 md:pt-10 px-6 sm:px-12 md:px-16 text-white transition-all duration-500 ease-out ${
            isPromptVisible ? '-translate-y-32 opacity-0 pointer-events-none' : 'translate-y-0 opacity-100'
          }`}
        >
          <h1 className="text-6xl sm:text-7xl md:text-8xl lg:text-9xl font-extralight tracking-tight drop-shadow-[0_4px_16px_rgba(0,0,0,0.5)]">
            {timeStr}
          </h1>
          <p className="text-lg sm:text-xl md:text-2xl font-normal mt-1 sm:mt-2 drop-shadow-[0_2px_8px_rgba(0,0,0,0.5)] capitalize text-slate-100">
            {dateStr}
          </p>

          {/* Lock Screen Status Widget (Weather or Calendar) */}
          {settings.lockScreenStatusWidget !== 'none' && (
            <div className="mt-4 sm:mt-6 flex items-center gap-3 px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-2xl bg-black/25 backdrop-blur-md border border-white/15 drop-shadow-lg text-xs max-w-sm">
              {settings.lockScreenStatusWidget === 'calendar' ? (
                <>
                  <Calendar size={18} className="text-sky-400 shrink-0" />
                  <div>
                    <div className="font-semibold text-white">Lịch làm việc</div>
                    <div className="text-[11px] text-white/80">Hôm nay không có sự kiện nào cần nhắc nhở</div>
                  </div>
                </>
              ) : (
                <>
                  <CloudSun size={20} className="text-amber-300 shrink-0 drop-shadow" />
                  <div>
                    <div className="font-semibold text-white flex items-center gap-2">
                      <span>28°C Nắng nhẹ</span>
                      <span className="text-[10px] text-white/60">• Hà Nội</span>
                    </div>
                    <div className="text-[11px] text-white/80">Cao 32° / Thấp 24° • Độ ẩm 68%</div>
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        {/* 3. SIGN-IN SCREEN PROMPT: Avatar, User Name, PIN Input & Welcome State */}
        <div
          className={`relative z-20 w-full max-w-sm mx-auto flex flex-col items-center justify-center px-4 py-2 sm:p-6 text-white transition-all duration-500 my-auto ${
            isPromptVisible ? 'scale-100 opacity-100 translate-y-0' : 'scale-95 opacity-0 pointer-events-none translate-y-6'
          }`}
        >
          {/* User Avatar with fluent gradient border */}
          <div className="relative mb-2.5 sm:mb-3.5">
            <div className="w-20 h-20 sm:w-24 sm:h-24 md:w-26 md:h-26 rounded-full bg-gradient-to-tr from-sky-500 via-indigo-500 to-purple-600 p-[3px] shadow-[0_10px_35px_rgba(0,0,0,0.6)]">
              <div className="w-full h-full rounded-full bg-zinc-900/90 backdrop-blur-md flex items-center justify-center text-sky-400 overflow-hidden">
                <span className="text-3xl sm:text-4xl font-black text-white uppercase font-sans">
                  {(settings.userName || 'L').charAt(0)}
                </span>
              </div>
            </div>
          </div>

          {/* User Display Name & Email */}
          <h2 className="text-xl sm:text-2xl font-semibold tracking-wide drop-shadow-md text-white text-center">
            {settings.userName || 'lenamphuc'}
          </h2>
          <p className="text-xs text-white/60 mb-3.5 sm:mb-4 font-normal text-center">
            {settings.userEmail || 'lenamphuc2013@gmail.com'}
          </p>

          {/* If Welcome state: Display Windows 11 spinning dots with "Chào mừng" */}
          {isWelcoming ? (
            <div className="flex flex-col items-center gap-3 py-4 animate-win11-fade">
              <Win11Spinner size={36} dotSize={4.5} color="#38bdf8" />
              <span className="text-base font-medium text-white tracking-wide">
                {settings.language === 'en' ? 'Welcome' : 'Chào mừng'}
              </span>
            </div>
          ) : !isAuthRequired ? (
            /* NO PASSWORD / NO PIN SET: Direct Sign In Button (Authentic Windows 11) */
            <div className="w-full flex flex-col items-center gap-3 animate-win11-fade">
              <button
                type="button"
                onClick={() => handleUnlockSubmit()}
                className="px-10 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 active:scale-95 text-white font-semibold text-sm shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer border border-sky-400/40"
              >
                <LogIn size={16} />
                <span>{settings.language === 'en' ? 'Sign in' : 'Đăng nhập'}</span>
              </button>
              <div className="text-[11px] text-white/60 text-center max-w-xs">
                {settings.language === 'en'
                  ? 'Account has no password. Press Enter or click Sign in.'
                  : 'Tài khoản chưa đặt mật khẩu. Nhấn Enter hoặc bấm Đăng nhập để vào Desktop.'}
              </div>
            </div>
          ) : (
            /* Sign In Form with PIN or Password input */
            <form
              onSubmit={handleUnlockSubmit}
              className={`w-full flex flex-col items-center gap-2.5 sm:gap-3 transition-transform ${
                isShaking ? 'animate-shake' : ''
              }`}
            >
              <div className="relative w-full flex items-center">
                <input
                  ref={pinInputRef}
                  type={showPin ? 'text' : 'password'}
                  value={pin}
                  onChange={(e) => {
                    setPin(e.target.value);
                    if (pinError) setPinError(null);
                  }}
                  placeholder={
                    activeAuthType === 'pin'
                      ? (settings.language === 'en' ? 'PIN' : 'Nhập mã PIN')
                      : (settings.language === 'en' ? 'Password' : 'Nhập mật khẩu')
                  }
                  className={`w-full px-4 py-2 sm:py-2.5 pr-20 bg-black/40 border rounded-xl text-white placeholder-zinc-400 text-sm focus:outline-none focus:ring-2 backdrop-blur-md transition-all ${
                    pinError
                      ? 'border-red-500/80 focus:border-red-500 focus:ring-red-500/30'
                      : 'border-white/20 focus:border-sky-400 focus:ring-sky-400/30'
                  }`}
                />

                <div className="absolute right-2 flex items-center gap-1">
                  {/* Peek / Reveal toggle */}
                  <button
                    type="button"
                    onClick={() => setShowPin(!showPin)}
                    className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-white/10 transition-colors"
                    title={showPin ? 'Ẩn' : 'Hiển thị'}
                  >
                    {showPin ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>

                  {/* Submit button */}
                  <button
                    type="submit"
                    className="p-1.5 rounded-lg bg-sky-500 hover:bg-sky-400 active:scale-95 text-white transition-all shadow-md"
                    title="Đăng nhập"
                  >
                    <ArrowRight size={16} />
                  </button>
                </div>
              </div>

              {/* Error Message */}
              {pinError && (
                <div className="flex items-center gap-1.5 text-xs text-red-400 font-medium animate-win11-fade">
                  <AlertCircle size={14} className="shrink-0" />
                  <span>{pinError}</span>
                </div>
              )}

              {/* Sign-in options (Toggle between PIN and Password if both exist) */}
              {hasPinConfigured && hasPasswordConfigured && (
                <div className="flex flex-col items-center gap-1 pt-1">
                  <span className="text-[11px] text-white/50">Tùy chọn đăng nhập</span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setActiveAuthType('pin');
                        setPin('');
                        setPinError(null);
                      }}
                      className={`p-2 rounded-xl border transition-all ${
                        activeAuthType === 'pin'
                          ? 'border-sky-400 bg-sky-500/20 text-sky-300'
                          : 'border-white/20 hover:bg-white/10 text-white/70'
                      }`}
                      title="Mã PIN Windows Hello"
                    >
                      <KeyRound size={16} />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setActiveAuthType('password');
                        setPin('');
                        setPinError(null);
                      }}
                      className={`p-2 rounded-xl border transition-all ${
                        activeAuthType === 'password'
                          ? 'border-sky-400 bg-sky-500/20 text-sky-300'
                          : 'border-white/20 hover:bg-white/10 text-white/70'
                      }`}
                      title="Mật khẩu tài khoản"
                    >
                      <Key size={16} />
                    </button>
                  </div>
                </div>
              )}

              {/* Sign in action button */}
              <div className="flex items-center justify-center pt-1">
                <button
                  type="submit"
                  className="px-6 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 active:scale-95 text-white text-xs font-medium backdrop-blur-md border border-white/20 transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <LogIn size={13} />
                  <span>{settings.language === 'en' ? 'Sign in' : 'Đăng nhập'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* ===================================================================== */}
      {/* 4. BOTTOM BAR: Hint & System Controls (Network, Accessibility, Power)  */}
      {/* ===================================================================== */}
      <div className="relative z-20 w-full px-6 py-4 sm:px-8 sm:py-5 flex items-center justify-between text-white shrink-0">
        {/* Bottom Hint on Lock Screen (Hidden when prompt is active) */}
        {!isPromptVisible ? (
          <div className="flex items-center gap-2 text-white/80 text-xs sm:text-sm drop-shadow-md animate-bounce">
            <Lock size={15} />
            <span>Nhấn phím bất kỳ hoặc nhấp chuột để mở khóa</span>
          </div>
        ) : (
          <div />
        )}

        {/* Windows 11 System Tray Controls (Bottom-Right) */}
        <div className="flex items-center gap-3 relative ml-auto">
          {/* Internet / WiFi status */}
          <div className="relative">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setShowWifiTooltip(!showWifiTooltip);
                setShowPowerMenu(false);
                setShowAccessibilityMenu(false);
              }}
              className="p-2 rounded-xl bg-black/25 hover:bg-black/50 active:scale-95 backdrop-blur-md border border-white/15 text-white/90 transition-all shadow-md"
              title="Mạng & Internet"
            >
              <Wifi size={17} />
            </button>

            {showWifiTooltip && (
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute right-0 bottom-12 w-64 p-3.5 bg-zinc-900/95 backdrop-blur-2xl border border-white/20 rounded-2xl text-white shadow-2xl text-xs space-y-1.5 animate-win11-fade z-30"
              >
                <div className="font-bold flex items-center gap-2 text-sky-400">
                  <Wifi size={15} />
                  <span>{settings.wifiNetwork || 'Lenamphuc-5G-UltraSpeed'}</span>
                </div>
                <div className="text-[11px] text-zinc-300">Đã kết nối, internet an toàn</div>
              </div>
            )}
          </div>

          {/* Accessibility (Trợ năng) Button */}
          <div className="relative">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setShowAccessibilityMenu(!showAccessibilityMenu);
                setShowPowerMenu(false);
                setShowWifiTooltip(false);
              }}
              className="p-2 rounded-xl bg-black/25 hover:bg-black/50 active:scale-95 backdrop-blur-md border border-white/15 text-white/90 transition-all shadow-md"
              title="Trợ năng (Ease of Access)"
            >
              <Accessibility size={17} />
            </button>

            {showAccessibilityMenu && (
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute right-0 bottom-12 w-64 p-3 bg-zinc-900/95 backdrop-blur-2xl border border-white/20 rounded-2xl text-white shadow-2xl text-xs space-y-2 animate-win11-fade z-30"
              >
                <div className="font-bold text-xs text-white pb-1 border-b border-white/10">Trợ năng</div>
                <label className="flex items-center justify-between cursor-pointer py-1 hover:bg-white/5 px-1.5 rounded-lg">
                  <span className="text-zinc-200">Độ tương phản cao</span>
                  <input
                    type="checkbox"
                    checked={highContrast}
                    onChange={(e) => setHighContrast(e.target.checked)}
                    className="accent-sky-500 rounded"
                  />
                </label>
                <label className="flex items-center justify-between cursor-pointer py-1 hover:bg-white/5 px-1.5 rounded-lg">
                  <span className="text-zinc-200">Chữ lớn dễ đọc</span>
                  <input
                    type="checkbox"
                    checked={largeText}
                    onChange={(e) => setLargeText(e.target.checked)}
                    className="accent-sky-500 rounded"
                  />
                </label>
              </div>
            )}
          </div>

          {/* Power Button (Sleep, Restart, Shut Down right from lock screen!) */}
          <div className="relative">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setShowPowerMenu(!showPowerMenu);
                setShowAccessibilityMenu(false);
                setShowWifiTooltip(false);
              }}
              className="p-2 rounded-xl bg-black/25 hover:bg-black/50 active:scale-95 backdrop-blur-md border border-white/15 text-white/90 transition-all shadow-md"
              title="Nguồn điện (Power)"
            >
              <Power size={17} />
            </button>

            {showPowerMenu && (
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute right-0 bottom-12 w-48 p-1.5 bg-zinc-900/95 backdrop-blur-2xl border border-white/20 rounded-2xl text-white shadow-2xl text-xs space-y-1 animate-win11-fade z-30"
              >
                <button
                  type="button"
                  onClick={() => {
                    setShowPowerMenu(false);
                    enterSleepMode();
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-white/10 text-left font-medium transition-colors cursor-pointer"
                >
                  <Moon size={14} className="text-amber-400" />
                  <span>{t.sleep}</span>
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    setShowPowerMenu(false);
                    if (e.shiftKey) {
                      restartToWinRE();
                    } else {
                      restartSystem();
                    }
                  }}
                  className="w-full flex items-center justify-between px-3 py-2 rounded-xl hover:bg-white/10 text-left font-medium transition-colors cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <RotateCcw size={14} className="text-sky-400" />
                    <span>{t.restart}</span>
                  </div>
                  <span className="text-[10px] text-zinc-400 opacity-0 group-hover:opacity-100 transition-opacity">Shift+↻</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowPowerMenu(false);
                    shutdownSystem();
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-red-500 hover:text-white text-red-400 text-left font-medium transition-colors cursor-pointer"
                >
                  <Power size={14} />
                  <span>{t.shutDown}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
