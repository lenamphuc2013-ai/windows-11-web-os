import React, { useEffect, useState } from 'react';

interface SleepOverlayProps {
  isSleeping: boolean;
  onWakeUp: () => void;
}

export const SleepOverlay: React.FC<SleepOverlayProps> = ({ isSleeping, onWakeUp }) => {
  const [hasRendered, setHasRendered] = useState(false);
  const [canWake, setCanWake] = useState(false);

  useEffect(() => {
    if (isSleeping) {
      setHasRendered(true);
      setCanWake(false);

      // 400ms grace period to prevent immediate re-wake from the click/release that triggered sleep
      const graceTimer = setTimeout(() => {
        setCanWake(true);
      }, 400);

      const handleWakeEvent = (e: Event) => {
        e.stopPropagation();
        onWakeUp();
      };

      // Listen after grace period
      let listenersAttached = false;
      const attachTimer = setTimeout(() => {
        listenersAttached = true;
        window.addEventListener('mousemove', handleWakeEvent, { capture: true, once: true });
        window.addEventListener('mousedown', handleWakeEvent, { capture: true, once: true });
        window.addEventListener('keydown', handleWakeEvent, { capture: true, once: true });
        window.addEventListener('wheel', handleWakeEvent, { capture: true, once: true });
        window.addEventListener('touchstart', handleWakeEvent, { capture: true, once: true });
      }, 400);

      return () => {
        clearTimeout(graceTimer);
        clearTimeout(attachTimer);
        if (listenersAttached) {
          window.removeEventListener('mousemove', handleWakeEvent, { capture: true });
          window.removeEventListener('mousedown', handleWakeEvent, { capture: true });
          window.removeEventListener('keydown', handleWakeEvent, { capture: true });
          window.removeEventListener('wheel', handleWakeEvent, { capture: true });
          window.removeEventListener('touchstart', handleWakeEvent, { capture: true });
        }
      };
    } else {
      setCanWake(false);
      const timer = setTimeout(() => setHasRendered(false), 500);
      return () => clearTimeout(timer);
    }
  }, [isSleeping, onWakeUp]);

  if (!isSleeping && !hasRendered) {
    return null;
  }

  return (
    <div
      id="win11-sleep-screen"
      onClick={() => {
        if (canWake) onWakeUp();
      }}
      className={`fixed inset-0 z-[200] bg-black cursor-none transition-opacity duration-700 select-none ${
        isSleeping ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
      }`}
      style={{
        backgroundColor: '#000000',
      }}
    >
      {/* Completely black screen - Authentic Windows 11 Sleep Mode */}
    </div>
  );
};
