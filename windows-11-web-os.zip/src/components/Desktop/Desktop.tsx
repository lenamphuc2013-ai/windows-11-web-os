import React, { useState, useCallback, useRef, useEffect } from 'react';
import { AnimatePresence } from 'motion/react';
import { useOS } from '../../context/OSContext';
import { IconRenderer } from '../Common/IconRenderer';
import { WindowContainer } from './WindowContainer';
import { AddHtmlAppModal } from '../Apps/AddHtmlAppModal';
import { useContextMenuTrigger } from '../../hooks/useContextMenuTrigger';
import { ContextMenuItem } from '../../types';
import { generateFileContextMenu } from '../../utils/fileContextMenu';
import { DEFAULT_WALLPAPERS } from '../../utils/fileSystem';
import { soundManager } from '../../utils/sound';
import {
  Folder,
  HardDrive,
  Trash2,
  FileCode,
  FileText,
  Plus,
  RefreshCw,
  Sliders,
  Palette,
  Terminal,
  Grid,
  ArrowDownAZ,
  ExternalLink,
  Edit,
  Trash,
  Copy,
  Info,
} from 'lucide-react';

interface DesktopProps {
  onCloseFlyouts: () => void;
}

export const Desktop: React.FC<DesktopProps> = ({ onCloseFlyouts }) => {
  const {
    settings,
    windows,
    fileSystem,
    getFilesByDirectory,
    openApp,
    isAddAppModalOpen,
    setIsAddAppModalOpen,
    createHtmlApp,
    addFile,
    deleteFile,
    renameFile,
    clipboard,
    setClipboard,
    pasteFile,
    createArchiveFile,
    createShortcutFile,
    pinFolder,
    showContextMenu,
    minimizeWindow,
    addNotification,
    openFileProperties,
    openDefenderScan,
    safeMode,
    enterWinRE,
    restartSystem,
    updateSettings,
    t,
  } = useOS();

  const [selectedIconIds, setSelectedIconIds] = useState<string[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const [iconSize, setIconSize] = useState<'small' | 'medium' | 'large'>('medium');
  const [showDesktopIcons, setShowDesktopIcons] = useState(true);
  const [sortBy, setSortBy] = useState<'name' | 'size' | 'type' | 'date'>('name');
  const [autoArrange, setAutoArrange] = useState(true);
  const [alignToGrid, setAlignToGrid] = useState(true);

  // Rubber-band Blue Selection Box state
  const [selectionBox, setSelectionBox] = useState<{
    isSelecting: boolean;
    startX: number;
    startY: number;
    currentX: number;
    currentY: number;
  } | null>(null);

  const desktopContainerRef = useRef<HTMLDivElement>(null);

  // Mouse handlers for desktop left-click drag multi-selection
  const handleMouseDown = (e: React.MouseEvent) => {
    // Only trigger on primary left-click and directly on desktop background (not on windows or context menu)
    if (e.button !== 0) return;
    const target = e.target as HTMLElement;
    if (target.closest('[data-icon-id]') || target.closest('[data-window]') || target.closest('[data-context-menu]')) {
      return;
    }

    onCloseFlyouts();
    if (!e.ctrlKey && !e.metaKey) {
      setSelectedIconIds([]);
    }

    setSelectionBox({
      isSelecting: true,
      startX: e.clientX,
      startY: e.clientY,
      currentX: e.clientX,
      currentY: e.clientY,
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!selectionBox || !selectionBox.isSelecting) return;

    const curX = e.clientX;
    const curY = e.clientY;

    setSelectionBox((prev) => (prev ? { ...prev, currentX: curX, currentY: curY } : null));

    // Calculate selection rectangle
    const selLeft = Math.min(selectionBox.startX, curX);
    const selRight = Math.max(selectionBox.startX, curX);
    const selTop = Math.min(selectionBox.startY, curY);
    const selBottom = Math.max(selectionBox.startY, curY);

    // Find all icons intersecting with selection rectangle
    const iconElements = document.querySelectorAll<HTMLElement>('[data-icon-id]');
    const newlySelected: string[] = [];

    iconElements.forEach((el) => {
      const rect = el.getBoundingClientRect();
      const intersects = !(
        rect.right < selLeft ||
        rect.left > selRight ||
        rect.bottom < selTop ||
        rect.top > selBottom
      );

      const iconId = el.getAttribute('data-icon-id');
      if (intersects && iconId) {
        newlySelected.push(iconId);
      }
    });

    setSelectedIconIds(newlySelected);
  };

  const handleMouseUp = () => {
    if (selectionBox?.isSelecting) {
      setSelectionBox(null);
    }
  };

  // Keyboard navigation / Del key handling
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Delete' && selectedIconIds.length > 0) {
        selectedIconIds.forEach((id) => {
          deleteFile(id);
        });
        setSelectedIconIds([]);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedIconIds, deleteFile]);

  // Desktop files from virtual filesystem
  const rawDesktopFiles = getFilesByDirectory('C:\\Users\\User\\Desktop');

  // Sort files
  const desktopFiles = [...rawDesktopFiles].sort((a, b) => {
    if (sortBy === 'name') return a.name.localeCompare(b.name);
    if (sortBy === 'size') return (b.size || 0) - (a.size || 0);
    if (sortBy === 'date') return (b.modifiedAt || 0) - (a.modifiedAt || 0);
    if (sortBy === 'type') {
      const extA = a.name.split('.').pop() || '';
      const extB = b.name.split('.').pop() || '';
      return extA.localeCompare(extB);
    }
    return 0;
  });

  // Static Desktop Shortcuts
  const defaultShortcuts = [
    {
      id: 'shortcut-pc',
      name: t.thisPC,
      icon: 'HardDrive',
      onClick: () => openApp('explorer', { initialPath: 'This PC' }),
    },
    {
      id: 'shortcut-apps',
      name: `${t.appsFolder} (C:\\Apps)`,
      icon: 'Folder',
      isAppFolder: true,
      onClick: () => openApp('explorer', { initialPath: 'C:\\Apps' }),
    },
    {
      id: 'shortcut-bin',
      name: t.recycleBin,
      icon: 'Trash2',
      onClick: () => openApp('explorer', { initialPath: 'C:\\Users\\User\\Desktop' }),
    },
    {
      id: 'shortcut-edge',
      name: t.browser,
      icon: 'Compass',
      onClick: () => openApp('edge'),
    },
    {
      id: 'shortcut-store',
      name: t.store,
      icon: 'ShoppingBag',
      onClick: () => openApp('store'),
    },
    {
      id: 'shortcut-copilot',
      name: t.copilot,
      icon: 'Sparkles',
      onClick: () => openApp('copilot'),
    },
    {
      id: 'shortcut-youtube',
      name: 'YouTube',
      icon: 'YouTube',
      onClick: () => openApp('youtube'),
    },
  ];

  // Desktop Background Context Menu (Right Click & Mobile Long Press)
  const handleDesktopTrigger = useCallback(
    (coords: { x: number; y: number }) => {
      onCloseFlyouts();
      setSelectedIconIds([]);

      const items: ContextMenuItem[] = [
        {
          id: 'view',
          label: t.view,
          icon: 'LayoutGrid',
          submenu: [
            {
              id: 'view-large',
              label: t.largeIcons,
              checked: iconSize === 'large',
              onClick: () => {
                setIconSize('large');
                soundManager.playNotification();
              },
            },
            {
              id: 'view-medium',
              label: t.mediumIcons,
              checked: iconSize === 'medium',
              onClick: () => {
                setIconSize('medium');
                soundManager.playNotification();
              },
            },
            {
              id: 'view-small',
              label: t.smallIcons,
              checked: iconSize === 'small',
              onClick: () => {
                setIconSize('small');
                soundManager.playNotification();
              },
            },
            { separator: true, id: 'view-sep-1', label: '' },
            {
              id: 'view-auto-arrange',
              label: 'Tự động sắp xếp biểu tượng (Auto arrange)',
              checked: autoArrange,
              onClick: () => {
                setAutoArrange((prev) => !prev);
                soundManager.playNotification();
              },
            },
            {
              id: 'view-align-grid',
              label: 'Căn chỉnh biểu tượng theo lưới (Align to grid)',
              checked: alignToGrid,
              onClick: () => {
                setAlignToGrid((prev) => !prev);
                soundManager.playNotification();
              },
            },
            { separator: true, id: 'view-sep-2', label: '' },
            {
              id: 'view-show-icons',
              label: t.showDesktop,
              checked: showDesktopIcons,
              onClick: () => {
                setShowDesktopIcons((prev) => !prev);
                soundManager.playNotification();
              },
            },
          ],
        },
        {
          id: 'sort-by',
          label: t.sortBy,
          icon: 'ArrowDownAZ',
          submenu: [
            {
              id: 'sort-name',
              label: t.name,
              checked: sortBy === 'name',
              onClick: () => {
                setSortBy('name');
                addNotification(t.sortBy, `Đã sắp xếp theo ${t.name}`, 'desktop');
                soundManager.playNotification();
              },
            },
            {
              id: 'sort-size',
              label: t.size,
              checked: sortBy === 'size',
              onClick: () => {
                setSortBy('size');
                addNotification(t.sortBy, `Đã sắp xếp theo ${t.size}`, 'desktop');
                soundManager.playNotification();
              },
            },
            {
              id: 'sort-type',
              label: t.itemType,
              checked: sortBy === 'type',
              onClick: () => {
                setSortBy('type');
                addNotification(t.sortBy, `Đã sắp xếp theo ${t.itemType}`, 'desktop');
                soundManager.playNotification();
              },
            },
            {
              id: 'sort-date',
              label: t.dateModified,
              checked: sortBy === 'date',
              onClick: () => {
                setSortBy('date');
                addNotification(t.sortBy, `Đã sắp xếp theo ${t.dateModified}`, 'desktop');
                soundManager.playNotification();
              },
            },
          ],
        },
        {
          id: 'refresh',
          label: t.refresh,
          icon: 'RefreshCw',
          shortcut: 'F5',
          onClick: () => {
            addNotification(t.refresh, 'Đã làm mới các biểu tượng màn hình', 'desktop');
            soundManager.playNotification();
          },
        },
        { separator: true, id: 'sep-paste', label: '' },
        {
          id: 'paste',
          label: 'Dán (Paste)',
          icon: 'Clipboard',
          shortcut: 'Ctrl+V',
          disabled: !clipboard,
          onClick: () => {
            if (clipboard?.item) {
              pasteFile('C:\\Users\\User\\Desktop');
            } else {
              addNotification('Dán (Paste)', 'Khay nhớ tạm trống. Vui lòng sao chép một tệp hoặc thư mục trước.', 'desktop');
              soundManager.playNotification();
            }
          },
        },
        {
          id: 'paste-shortcut',
          label: 'Dán lối tắt (Paste shortcut)',
          icon: 'CornerUpRight',
          disabled: !clipboard,
          onClick: () => {
            if (clipboard?.item) {
              createShortcutFile(clipboard.item, 'C:\\Users\\User\\Desktop');
            } else {
              addNotification('Dán lối tắt', 'Vui lòng sao chép một tệp hoặc ứng dụng trước để tạo lối tắt.', 'desktop');
              soundManager.playNotification();
            }
          },
        },
        { separator: true, id: 'sep-1', label: '' },
        {
          id: 'new',
          label: t.new || 'Mới',
          icon: 'Plus',
          submenu: [
            {
              id: 'new-folder',
              label: t.newFolder,
              icon: 'Folder',
              onClick: () => {
                const folderName = `${t.newFolder} (${Date.now().toString().slice(-4)})`;
                addFile({
                  name: folderName,
                  path: `C:\\Users\\User\\Desktop\\${folderName}`,
                  isDirectory: true,
                  createdAt: Date.now(),
                  modifiedAt: Date.now(),
                  icon: 'Folder',
                });
                addNotification(t.newFolder, `"${folderName}"`, 'explorer');
                soundManager.playNotification();
              },
            },
            {
              id: 'new-shortcut',
              label: 'Lối tắt (Shortcut)',
              icon: 'CornerUpRight',
              onClick: () => {
                const docName = `Lối tắt mới (${Date.now().toString().slice(-4)}).lnk`;
                addFile({
                  name: docName,
                  path: `C:\\Users\\User\\Desktop\\${docName}`,
                  isDirectory: false,
                  content: 'Shortcut to Explorer',
                  size: 512,
                  createdAt: Date.now(),
                  modifiedAt: Date.now(),
                  icon: 'CornerUpRight',
                  symlinkTarget: 'C:\\Windows\\explorer.exe',
                  description: 'Lối tắt Windows 11',
                });
                addNotification('Lối tắt', `Đã tạo ${docName}`, 'explorer');
                soundManager.playNotification();
              },
            },
            {
              id: 'new-text',
              label: t.newTextDoc,
              icon: 'FileText',
              onClick: () => {
                const docName = `Văn bản mới (${Date.now().toString().slice(-4)}).txt`;
                const newDoc = addFile({
                  name: docName,
                  path: `C:\\Users\\User\\Desktop\\${docName}`,
                  isDirectory: false,
                  content: '',
                  size: 0,
                  createdAt: Date.now(),
                  modifiedAt: Date.now(),
                  icon: 'FileText',
                });
                openApp('notepad', { filePath: newDoc.path, fileName: newDoc.name, content: '' });
                addNotification(t.newTextDoc, `Đã tạo "${docName}"`, 'notepad');
              },
            },
            {
              id: 'new-paint',
              label: 'Hình ảnh Bitmap (.bmp)',
              icon: 'Image',
              onClick: () => {
                const imgName = `Hình ảnh mới (${Date.now().toString().slice(-4)}).bmp`;
                addFile({
                  name: imgName,
                  path: `C:\\Users\\User\\Desktop\\${imgName}`,
                  isDirectory: false,
                  content: '',
                  size: 0,
                  createdAt: Date.now(),
                  modifiedAt: Date.now(),
                  icon: 'Image',
                });
                openApp('paint');
                addNotification('Paint', `Đã tạo "${imgName}"`, 'paint');
              },
            },
            {
              id: 'new-json',
              label: 'Tệp cấu hình JSON (.json)',
              icon: 'FileCode',
              onClick: () => {
                const jsonName = `config_${Date.now().toString().slice(-4)}.json`;
                const content = JSON.stringify({ name: 'Windows11 Config', version: '24H2', enabled: true }, null, 2);
                addFile({
                  name: jsonName,
                  path: `C:\\Users\\User\\Desktop\\${jsonName}`,
                  isDirectory: false,
                  content,
                  size: content.length,
                  createdAt: Date.now(),
                  modifiedAt: Date.now(),
                  icon: 'FileCode',
                });
                openApp('notepad', { filePath: `C:\\Users\\User\\Desktop\\${jsonName}`, fileName: jsonName, content });
              },
            },
            {
              id: 'new-html',
              label: t.addNewHtmlApp,
              icon: 'Code',
              onClick: () => {
                setIsAddAppModalOpen(true);
              },
            },
          ],
        },
        { separator: true, id: 'sep-2', label: '' },
        {
          id: 'display-settings',
          label: t.displaySettings,
          icon: 'Sliders',
          onClick: () => openApp('settings', { initialSection: 'system' }),
        },
        {
          id: 'personalize',
          label: t.personalize,
          icon: 'Palette',
          onClick: () => openApp('settings', { initialSection: 'personalization' }),
        },
        {
          id: 'open-terminal',
          label: 'Mở trong Terminal',
          icon: 'Terminal',
          onClick: () => openApp('terminal', { initialPath: 'C:\\Users\\User\\Desktop' }),
        },
        {
          id: 'add-html-app',
          label: t.addNewHtmlApp,
          icon: 'FileCode',
          onClick: () => setIsAddAppModalOpen(true),
        },
      ];

      showContextMenu(coords.x, coords.y, items, 'desktop');
    },
    [
      onCloseFlyouts,
      iconSize,
      showDesktopIcons,
      sortBy,
      clipboard,
      pasteFile,
      createShortcutFile,
      addNotification,
      addFile,
      setIsAddAppModalOpen,
      openApp,
      showContextMenu,
      t,
    ]
  );

  const { touchProps: desktopTouchProps } = useContextMenuTrigger({
    onTrigger: handleDesktopTrigger,
  });

  // Icon Context Menu
  const handleIconTrigger = useCallback(
    (coords: { x: number; y: number }, fileOrShortcut: any, isFile: boolean) => {
      onCloseFlyouts();
      // Ensure synchronous selection so the item turns blue immediately
      setSelectedIconIds([fileOrShortcut.id]);

      if (isFile) {
        const fullMenu = generateFileContextMenu({
          item: fileOrShortcut,
          onOpen: (it) => {
            if (it.isHtmlApp || it.name.endsWith('.html') || it.name.endsWith('.htm')) {
              openApp('app-runner', {
                filePath: it.path,
                appName: it.appMetadata?.title || it.name,
              });
            } else if (it.name.match(/\.(mp4|webm|mkv|mov|avi|ogv)$/i)) {
              openApp('videoplayer', {
                filePath: it.path,
                fileName: it.name,
                videoUrl: it.content || undefined,
              });
            } else if (it.name.match(/\.(png|jpe?g|svg|webp|gif|bmp)$/i)) {
              openApp('photos', {
                filePath: it.path,
                fileName: it.name,
              });
            } else if (it.isDirectory) {
              openApp('explorer', { initialPath: it.path });
            } else {
              openApp('notepad', {
                filePath: it.path,
                content: it.content,
              });
            }
          },
          onOpenNewWindow: (it) => openApp('explorer', { initialPath: it.path }),
          onDelete: (it) => {
            deleteFile(it.id);
          },
          onRename: (it) => {
            const newName = prompt('Nhập tên mới cho tệp/thư mục:', it.name);
            if (newName && newName.trim()) {
              renameFile(it.id, newName.trim());
            }
          },
          onCopy: (it) => {
            setClipboard(it, 'copy');
          },
          onCut: (it) => {
            setClipboard(it, 'cut');
          },
          onAddToArchive: (it, fmt) => {
            createArchiveFile(it, fmt || 'rar');
          },
          onCreateShortcut: (it) => {
            createShortcutFile(it, 'C:\\Users\\User\\Desktop');
          },
          onSendToDesktop: (it) => {
            createShortcutFile(it, 'C:\\Users\\User\\Desktop');
          },
          onPinQuickAccess: (it) => {
            pinFolder(it.path);
          },
          onProperties: (it) => {
            openFileProperties(it);
          },
          onDefenderScan: (it) => {
            openDefenderScan(it.name);
          },
          onSetAsWallpaper: (it) => {
            if (it.content) {
              updateSettings({ wallpaper: it.content });
              addNotification(t.personalize, `${t.setAsWallpaper}: "${it.name}"`, 'desktop');
            }
          },
          notify: (title, msg) => addNotification(title, msg, 'desktop'),
        });

        showContextMenu(coords.x, coords.y, fullMenu, 'file', fileOrShortcut);
        return;
      }

      const isHtml = fileOrShortcut.isHtmlApp || fileOrShortcut.name?.endsWith('.html');

      const items: ContextMenuItem[] = [
        {
          id: 'open',
          label: t.open,
          icon: 'ExternalLink',
          onClick: () => {
            fileOrShortcut.onClick();
          },
        },
        {
          id: 'pin-start',
          label: t.pinToStart,
          icon: 'LayoutGrid',
          onClick: () => {
            addNotification(t.pinToStart, `"${fileOrShortcut.name}"`, 'start');
          },
        },
        {
          id: 'pin-taskbar',
          label: t.pinToTaskbar,
          icon: 'Check',
          onClick: () => {
            addNotification(t.pinToTaskbar, `"${fileOrShortcut.name}"`, 'taskbar');
          },
        },
        { separator: true, id: 'icon-sep-1', label: '' },
        {
          id: 'properties',
          label: t.properties,
          icon: 'Info',
          onClick: () => {
            addNotification(
              t.properties,
              `${t.name}: ${fileOrShortcut.name}\nLoại: Lối tắt ứng dụng hệ thống`,
              'explorer'
            );
          },
        },
      ];

      showContextMenu(coords.x, coords.y, items, 'shortcut', fileOrShortcut);
    },
    [onCloseFlyouts, openApp, addNotification, deleteFile, openFileProperties, openDefenderScan, showContextMenu, t]
  );

  const handleDesktopClick = (e: React.MouseEvent) => {
    if (!selectionBox) {
      if (!e.ctrlKey && !e.metaKey) {
        setSelectedIconIds([]);
      }
    }
    onCloseFlyouts();
  };

  // Drag & drop file upload
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files: File[] = Array.from(e.dataTransfer.files);

    files.forEach((file: File) => {
      const isHtml = file.name.endsWith('.html') || file.name.endsWith('.htm');
      const isVideo = /\.(mp4|webm|mkv|mov|avi|ogv)$/i.test(file.name) || file.type.startsWith('video/');
      const isImage = /\.(png|jpe?g|svg|webp|gif|bmp|ico|avif)$/i.test(file.name) || file.type.startsWith('image/');
      const isGif = /\.gif$/i.test(file.name) || file.type === 'image/gif';
      const isAudio = /\.(mp3|wav|ogg|flac|m4a|aac|wma)$/i.test(file.name) || file.type.startsWith('audio/');
      const isTextOrCode =
        /\.(txt|md|json|js|ts|jsx|tsx|css|bat|cmd|ps1|log|csv|xml|ini|conf|py|c|cpp|h|java|sql)$/i.test(file.name) ||
        file.type.startsWith('text/');

      if (isHtml) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const content = event.target?.result as string;
          const appTitle = file.name.replace(/\.[^/.]+$/, '');
          createHtmlApp(appTitle, 'Code', content, 'custom');
          soundManager.playNotification();
          addNotification('Ứng dụng mới', `Đã lưu và cài đặt ứng dụng: ${appTitle}`, 'system');
        };
        reader.readAsText(file);
      } else if (isGif || isImage) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const content = event.target?.result as string;
          addFile({
            name: file.name,
            path: `C:\\Users\\User\\Desktop\\${file.name}`,
            isDirectory: false,
            content,
            size: file.size,
            icon: 'Image',
          });
          soundManager.playNotification();
          addNotification(
            'Màn hình chính',
            isGif
              ? `Đã lưu cục bộ GIF động "${file.name}". Bấm đúp để xem hoặc chuột phải để Đặt làm hình nền!`
              : `Đã lưu cục bộ hình ảnh "${file.name}".`,
            'desktop'
          );
        };
        reader.readAsDataURL(file);
      } else if (isVideo) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const dataUrl = event.target?.result as string;
          const filePath = `C:\\Users\\User\\Desktop\\${file.name}`;
          addFile({
            name: file.name,
            path: filePath,
            isDirectory: false,
            content: dataUrl,
            size: file.size,
            icon: 'Film',
          });
          soundManager.playNotification();
          addNotification(
            'Màn hình chính',
            `Đã lưu video "${file.name}" cục bộ ngoài Desktop.`,
            'desktop'
          );
        };
        reader.readAsDataURL(file);
      } else if (isAudio) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const dataUrl = event.target?.result as string;
          const filePath = `C:\\Users\\User\\Desktop\\${file.name}`;
          addFile({
            name: file.name,
            path: filePath,
            isDirectory: false,
            content: dataUrl,
            size: file.size,
            icon: 'Music',
          });
          soundManager.playNotification();
          addNotification(
            'Màn hình chính',
            `Đã lưu tệp âm thanh "${file.name}" cục bộ ngoài Desktop.`,
            'desktop'
          );
        };
        reader.readAsDataURL(file);
      } else if (isTextOrCode) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const content = event.target?.result as string;
          const icon = file.name.match(/\.(bat|cmd|ps1)$/i)
            ? 'Terminal'
            : file.name.match(/\.(js|ts|json|py|css|html)$/i)
            ? 'FileCode'
            : 'FileText';
          addFile({
            name: file.name,
            path: `C:\\Users\\User\\Desktop\\${file.name}`,
            isDirectory: false,
            content,
            size: file.size,
            icon,
          });
          soundManager.playNotification();
          addNotification('Màn hình chính', `Đã lưu tệp văn bản "${file.name}" cục bộ.`, 'desktop');
        };
        reader.readAsText(file);
      } else {
        const reader = new FileReader();
        reader.onload = (event) => {
          const content = event.target?.result as string;
          const icon = file.name.match(/\.(zip|rar|7z|tar|gz)$/i)
            ? 'Archive'
            : 'FileText';
          addFile({
            name: file.name,
            path: `C:\\Users\\User\\Desktop\\${file.name}`,
            isDirectory: false,
            content,
            size: file.size,
            icon,
          });
          soundManager.playNotification();
          addNotification('Màn hình chính', `Đã lưu tệp "${file.name}" cục bộ ngoài Desktop.`, 'desktop');
        };
        reader.readAsDataURL(file);
      }
    });
  };

  // Icon sizing classes
  const iconSizeClasses = {
    small: { container: 'w-18 h-20', icon: 28, text: 'text-[10px]' },
    medium: { container: 'w-22 h-24', icon: 36, text: 'text-[11px]' },
    large: { container: 'w-28 h-28', icon: 46, text: 'text-[12px]' },
  }[iconSize];

  // Compute effective wallpaper style with fallback
  const wallpaperUrl = settings.wallpaper || DEFAULT_WALLPAPERS[0].url;

  return (
    <div
      ref={desktopContainerRef}
      {...desktopTouchProps}
      onClick={handleDesktopClick}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`fixed inset-0 bottom-12 bg-cover bg-center select-none overflow-hidden touch-manipulation ${
        settings.theme === 'dark' ? 'dark' : ''
      }`}
      style={{
        backgroundImage: safeMode !== 'none' ? 'none' : `url("${wallpaperUrl}")`,
        backgroundColor: safeMode !== 'none' ? '#000000' : (settings.theme === 'light' ? '#f1f5f9' : '#0a101f'),
      }}
    >
      {/* Windows 11 Built-in Ambient Bloom Glow Underlay (Ensures rich visuals even if offline) */}
      {safeMode === 'none' && (
        <div className="absolute inset-0 pointer-events-none -z-10 opacity-70 overflow-hidden">
          <div className="absolute -right-20 top-1/4 w-[600px] h-[600px] rounded-full bg-sky-500/20 blur-[120px]" />
          <div className="absolute right-1/4 bottom-10 w-[500px] h-[500px] rounded-full bg-blue-600/15 blur-[100px]" />
        </div>
      )}

      {/* Windows 11 Rubber-Band Blue Multi-Selection Box */}
      {selectionBox && selectionBox.isSelecting && (
        <div
          className="fixed border border-[#0078d4] bg-[#0078d4]/25 pointer-events-none z-30 transition-none shadow-sm"
          style={{
            left: `${Math.min(selectionBox.startX, selectionBox.currentX)}px`,
            top: `${Math.min(selectionBox.startY, selectionBox.currentY)}px`,
            width: `${Math.abs(selectionBox.currentX - selectionBox.startX)}px`,
            height: `${Math.abs(selectionBox.currentY - selectionBox.startY)}px`,
          }}
        />
      )}

      {/* Safe Mode Watermarks & Banner */}
      {safeMode !== 'none' && (
        <div className="pointer-events-none absolute inset-0 z-10 select-none text-zinc-400 font-mono text-xs opacity-75">
          <div className="absolute top-2 left-3">
            Safe Mode {safeMode === 'safe-networking' ? '(with Networking)' : safeMode === 'safe-cmd' ? '(Command Prompt)' : ''}
          </div>
          <div className="absolute top-2 right-3">
            Safe Mode {safeMode === 'safe-networking' ? '(with Networking)' : safeMode === 'safe-cmd' ? '(Command Prompt)' : ''}
          </div>
          <div className="absolute bottom-2 left-3">
            Safe Mode {safeMode === 'safe-networking' ? '(with Networking)' : safeMode === 'safe-cmd' ? '(Command Prompt)' : ''}
          </div>
          <div className="absolute bottom-2 right-3">
            Safe Mode {safeMode === 'safe-networking' ? '(with Networking)' : safeMode === 'safe-cmd' ? '(Command Prompt)' : ''}
          </div>
          <div className="absolute top-2 left-1/2 -translate-x-1/2 text-[11px] text-zinc-400 font-sans font-medium bg-black/70 px-3 py-0.5 rounded border border-zinc-800 pointer-events-auto">
            <span>Microsoft (R) Windows (R) (Build 22631.3296) - Safe Mode</span>
            <button
              onClick={() => restartSystem()}
              className="ml-3 text-sky-400 hover:underline cursor-pointer"
            >
              Exit Safe Mode
            </button>
          </div>
        </div>
      )}

      {/* Drag & Drop Visual Overlay */}
      {isDragOver && (
        <div className="absolute inset-0 bg-sky-500/20 backdrop-blur-sm border-4 border-dashed border-sky-400 z-50 flex flex-col items-center justify-center text-white font-bold pointer-events-none animate-win11-fade">
          <div className="p-6 bg-slate-900/85 rounded-3xl flex flex-col items-center gap-3 shadow-2xl border border-white/20 max-w-md text-center">
            <FileCode size={48} className="text-sky-400 animate-bounce" />
            <div className="text-lg">{t.dropFilesHere}</div>
            <p className="text-xs text-slate-300 font-normal">
              Thả tệp <span className="text-sky-400 font-bold">Video (.mp4, .webm)</span> để phát ngay bằng Trình phát Video & lưu vào hệ thống, hoặc <span className="text-emerald-400 font-bold">.html</span> để cài đặt ứng dụng!
            </p>
          </div>
        </div>
      )}

      {/* Desktop Grid Icons Container */}
      {showDesktopIcons && (
        <div className="p-3 flex flex-col flex-wrap items-start content-start gap-1 max-h-full">
          {/* System Shortcuts */}
          {defaultShortcuts.map((sc) => {
            const isSelected = selectedIconIds.includes(sc.id);
            return (
              <DesktopIconItem
                key={sc.id}
                item={sc}
                isFile={false}
                isSelected={isSelected}
                iconSizeClasses={iconSizeClasses}
                onSelect={(multi) => {
                  if (multi) {
                    setSelectedIconIds((prev) =>
                      prev.includes(sc.id) ? prev.filter((id) => id !== sc.id) : [...prev, sc.id]
                    );
                  } else {
                    setSelectedIconIds([sc.id]);
                  }
                }}
                onOpen={() => sc.onClick()}
                onContextMenuTrigger={(coords) => handleIconTrigger(coords, sc, false)}
              />
            );
          })}

          {/* Files & HTML Apps on Desktop */}
          {desktopFiles.map((file) => {
            const isSelected = selectedIconIds.includes(file.id);
            return (
              <DesktopIconItem
                key={file.id}
                item={file}
                isFile={true}
                isSelected={isSelected}
                iconSizeClasses={iconSizeClasses}
                onSelect={(multi) => {
                  if (multi) {
                    setSelectedIconIds((prev) =>
                      prev.includes(file.id) ? prev.filter((id) => id !== file.id) : [...prev, file.id]
                    );
                  } else {
                    setSelectedIconIds([file.id]);
                  }
                }}
                onOpen={() => {
                  if (file.isHtmlApp || file.name.endsWith('.html') || file.name.endsWith('.htm')) {
                    openApp('app-runner', {
                      filePath: file.path,
                      appName: file.appMetadata?.title || file.name,
                    });
                  } else if (file.name.match(/\.(mp4|webm|mkv|mov|avi|ogv)$/i)) {
                    openApp('videoplayer', {
                      filePath: file.path,
                      fileName: file.name,
                      videoUrl: file.content || undefined,
                    });
                  } else if (file.name.match(/\.(png|jpe?g|svg|webp|gif|bmp)$/i)) {
                    openApp('photos', {
                      filePath: file.path,
                      fileName: file.name,
                    });
                  } else if (file.isDirectory) {
                    openApp('explorer', { initialPath: file.path });
                  } else {
                    openApp('notepad', { filePath: file.path, content: file.content });
                  }
                }}
                onContextMenuTrigger={(coords) => handleIconTrigger(coords, file, true)}
              />
            );
          })}
        </div>
      )}

      {/* Render All Open Windows with Fluent Motion Entrance & Exit */}
      <AnimatePresence>
        {windows
          .filter((win) => !win.isMinimized)
          .map((win) => (
            <WindowContainer key={win.id} window={win} />
          ))}
      </AnimatePresence>

      {/* Add / Upload Custom HTML App Modal */}
      {isAddAppModalOpen && (
        <AddHtmlAppModal onClose={() => setIsAddAppModalOpen(false)} />
      )}
    </div>
  );
};

// Sub-component for individual desktop icon with full right-click, multi-select, and mobile long-press support
interface DesktopIconItemProps {
  item: any;
  isFile: boolean;
  isSelected: boolean;
  iconSizeClasses: { container: string; icon: number; text: string };
  onSelect: (multi?: boolean) => void;
  onOpen: () => void;
  onContextMenuTrigger: (coords: { x: number; y: number }) => void;
}

const DesktopIconItem: React.FC<DesktopIconItemProps> = ({
  item,
  isFile,
  isSelected,
  iconSizeClasses,
  onSelect,
  onOpen,
  onContextMenuTrigger,
}) => {
  const iconName = item.appMetadata?.icon || item.icon;
  const isHtml = isFile && (item.isHtmlApp || item.name?.endsWith('.html'));
  const isImageOrGif =
    isFile &&
    ((typeof item.content === 'string' && item.content.startsWith('data:image/')) ||
      /\.(gif|png|jpe?g|webp|svg|bmp|ico|avif)$/i.test(item.name || ''));
  const isGif =
    isFile &&
    (/\.gif$/i.test(item.name || '') ||
      (typeof item.content === 'string' && item.content.startsWith('data:image/gif')));
  const lastTapTimeRef = React.useRef<number>(0);

  const { touchProps, isTriggeredRef } = useContextMenuTrigger({
    onTrigger: onContextMenuTrigger,
  });

  const handleClick = (e: React.MouseEvent | React.TouchEvent) => {
    e.stopPropagation();
    if (isTriggeredRef.current) return;

    const isMulti = 'ctrlKey' in e && (e.ctrlKey || e.metaKey);
    const now = Date.now();
    const timeSinceLastTap = now - lastTapTimeRef.current;
    lastTapTimeRef.current = now;

    // Double tap within 400ms -> Open app immediately
    if (timeSinceLastTap < 400) {
      onOpen();
    } else {
      onSelect(isMulti);
    }
  };

  return (
    <div
      {...touchProps}
      data-icon-id={item.id}
      onClick={handleClick}
      onDoubleClick={(e) => {
        e.stopPropagation();
        onOpen();
      }}
      className={`flex flex-col items-center justify-center ${iconSizeClasses.container} p-1 rounded-xl cursor-pointer transition-all active:scale-95 touch-manipulation select-none relative z-10 ${
        isSelected
          ? 'bg-[#0078d4]/35 border border-[#0078d4]/80 ring-1 ring-sky-300/40 backdrop-blur-sm shadow-md'
          : 'hover:bg-white/10'
      }`}
    >
      {isImageOrGif && item.content ? (
        <div className="relative w-11 h-11 rounded-lg overflow-hidden border border-white/40 shadow-md bg-black/20 flex items-center justify-center mb-1 pointer-events-none">
          <img
            src={item.content}
            alt={item.name}
            className="w-full h-full object-cover select-none"
            loading="lazy"
          />
          {isGif && (
            <span className="absolute bottom-0 right-0 px-1 py-0.2 bg-purple-600/90 text-white text-[8px] font-bold rounded-tl leading-tight">
              GIF
            </span>
          )}
        </div>
      ) : (
        <div className="flex items-center justify-center drop-shadow-md mb-1 relative pointer-events-none">
          <IconRenderer name={iconName} size={iconSizeClasses.icon} />
          {isHtml && (
            <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-sky-500 text-[9px] font-bold text-white flex items-center justify-center shadow">
              ▶
            </span>
          )}
        </div>
      )}
      <span
        className={`${iconSizeClasses.text} font-medium text-white text-center line-clamp-2 px-1 text-shadow-win leading-tight pointer-events-none`}
      >
        {item.appMetadata?.title || item.name}
      </span>
    </div>
  );
};
