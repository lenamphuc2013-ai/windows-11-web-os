import React, { useState, useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import { IconRenderer } from '../Common/IconRenderer';
import { Check, ChevronRight } from 'lucide-react';

export const ContextMenu: React.FC = () => {
  const { contextMenu, closeContextMenu } = useOS();
  const [activeSubmenu, setActiveSubmenu] = useState<string | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const [menuPos, setMenuPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (contextMenu.isOpen) {
      setActiveSubmenu(null);
      // Clamp within viewport
      const menuWidth = 250;

      if (contextMenu.targetType === 'taskbar') {
        // Bottom-anchored right above taskbar, centered horizontally around the clicked icon
        const x = Math.max(10, Math.min(contextMenu.x - menuWidth / 2, window.innerWidth - menuWidth - 10));
        setMenuPos({ x, y: 0 });
      } else {
        const menuHeight = Math.min(contextMenu.items.length * 36 + 20, 520);
        const x = Math.max(10, Math.min(contextMenu.x, window.innerWidth - menuWidth - 14));
        const y = Math.max(10, Math.min(contextMenu.y, window.innerHeight - menuHeight - 56));
        setMenuPos({ x, y });
      }
    }
  }, [contextMenu.isOpen, contextMenu.x, contextMenu.y, contextMenu.items.length, contextMenu.targetType]);

  if (!contextMenu.isOpen) return null;

  const isTaskbarMenu = contextMenu.targetType === 'taskbar';
  const shouldSubmenuFlyLeft = menuPos.x + 250 + 230 > window.innerWidth;

  return (
    <div
      id="win11-context-menu-backdrop"
      className="fixed inset-0 z-[99999] select-none"
      onClick={closeContextMenu}
      onContextMenu={(e) => {
        e.preventDefault();
        closeContextMenu();
      }}
      onTouchStart={(e) => {
        // If clicking outside menu container
        if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
          closeContextMenu();
        }
      }}
    >
      <div
        ref={menuRef}
        id="win11-context-menu-container"
        className="fixed z-[100000] min-w-[240px] max-w-[290px] overflow-visible acrylic-blur bg-[#fbfbfb]/95 dark:bg-[#202020]/95 text-slate-800 dark:text-slate-100 rounded-xl shadow-2xl border border-white/60 dark:border-white/10 p-1.5 text-xs animate-win11-fade backdrop-blur-2xl"
        style={
          isTaskbarMenu
            ? {
                left: `${menuPos.x}px`,
                bottom: '56px',
              }
            : {
                left: `${menuPos.x}px`,
                top: `${menuPos.y}px`,
              }
        }
        onClick={(e) => e.stopPropagation()}
      >
        {contextMenu.items.map((item, idx) => {
          if (item.separator) {
            return (
              <div
                key={`sep-${idx}`}
                className="my-1 border-t border-slate-200/80 dark:border-zinc-700/80"
              />
            );
          }

          if (item.header) {
            return (
              <div
                key={`header-${idx}`}
                className="px-3 pt-1.5 pb-0.5 text-[11px] font-semibold text-slate-500 dark:text-zinc-400 select-none"
              >
                {item.header}
              </div>
            );
          }

          const hasSubmenu = Boolean(item.submenu && item.submenu.length > 0);
          const isSubmenuOpen = activeSubmenu === item.id;

          return (
            <div
              key={item.id || idx}
              id={`context-item-${item.id || idx}`}
              className={`relative flex items-center justify-between px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer select-none group/item ${
                item.disabled
                  ? 'opacity-40 cursor-not-allowed'
                  : item.danger
                  ? 'hover:bg-red-500/15 text-red-600 dark:text-red-400'
                  : isSubmenuOpen
                  ? 'bg-sky-500/15 dark:bg-white/15'
                  : 'hover:bg-sky-500/10 dark:hover:bg-white/10 active:bg-sky-500/20'
              }`}
              onMouseEnter={() => {
                if (hasSubmenu) {
                  setActiveSubmenu(item.id);
                } else {
                  setActiveSubmenu(null);
                }
              }}
              onClick={() => {
                if (item.disabled) return;
                if (hasSubmenu) {
                  setActiveSubmenu(isSubmenuOpen ? null : item.id);
                  return;
                }
                if (item.onClick) {
                  item.onClick();
                  closeContextMenu();
                }
              }}
            >
              <div className="flex items-center gap-2.5 truncate flex-1 mr-2">
                {/* Icon or Checkmark */}
                <div className="w-4 h-4 flex items-center justify-center shrink-0">
                  {item.checked ? (
                    <Check size={14} className="text-sky-500 dark:text-sky-400 stroke-[2.5]" />
                  ) : item.iconComponent ? (
                    item.iconComponent
                  ) : item.icon ? (
                    <IconRenderer name={item.icon} size={15} className="opacity-85" />
                  ) : null}
                </div>

                <span className="truncate font-medium text-[12px]">{item.label}</span>
              </div>

              <div className="flex items-center gap-1.5 text-[10px] text-slate-400 dark:text-zinc-400 shrink-0">
                {item.shortcut && <span className="font-mono text-[10px]">{item.shortcut}</span>}
                {hasSubmenu && <ChevronRight size={13} className="opacity-60" />}
              </div>

              {/* Submenu Floating Flyout */}
              {hasSubmenu && isSubmenuOpen && (
                <div
                  id={`context-submenu-${item.id}`}
                  className="absolute min-w-[220px] max-w-[290px] acrylic-blur bg-[#fbfbfb]/98 dark:bg-[#202020]/98 text-slate-800 dark:text-slate-100 rounded-xl shadow-2xl border border-white/60 dark:border-white/10 p-1.5 text-xs animate-win11-fade backdrop-blur-2xl z-[100002]"
                  style={{
                    left: shouldSubmenuFlyLeft ? 'auto' : '100%',
                    right: shouldSubmenuFlyLeft ? '100%' : 'auto',
                    marginLeft: shouldSubmenuFlyLeft ? '0px' : '4px',
                    marginRight: shouldSubmenuFlyLeft ? '4px' : '0px',
                    top: idx > contextMenu.items.length / 2 ? 'auto' : '-4px',
                    bottom: idx > contextMenu.items.length / 2 ? '-4px' : 'auto',
                  }}
                  onMouseEnter={() => setActiveSubmenu(item.id)}
                  onClick={(e) => e.stopPropagation()}
                >
                  {item.submenu!.map((sub, sIdx) => {
                    if (sub.separator) {
                      return (
                        <div
                          key={`sub-sep-${sIdx}`}
                          className="my-1 border-t border-slate-200/80 dark:border-zinc-700/80"
                        />
                      );
                    }
                    return (
                      <div
                        key={sub.id || sIdx}
                        id={`submenu-item-${sub.id || sIdx}`}
                        className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer select-none ${
                          sub.disabled
                            ? 'opacity-40 cursor-not-allowed'
                            : 'hover:bg-sky-500/10 dark:hover:bg-white/10 active:bg-sky-500/20'
                        }`}
                        onClick={(e) => {
                          e.stopPropagation();
                          if (sub.disabled) return;
                          if (sub.onClick) {
                            sub.onClick();
                            closeContextMenu();
                          }
                        }}
                      >
                        <div className="flex items-center gap-2.5 truncate flex-1 mr-2">
                          <div className="w-4 h-4 flex items-center justify-center shrink-0">
                            {sub.checked ? (
                              <Check size={14} className="text-sky-500 dark:text-sky-400 stroke-[2.5]" />
                            ) : sub.iconComponent ? (
                              sub.iconComponent
                            ) : sub.icon ? (
                              <IconRenderer name={sub.icon} size={15} className="opacity-85" />
                            ) : null}
                          </div>
                          <span className="truncate font-medium text-[12px]">{sub.label}</span>
                        </div>
                        {sub.shortcut && (
                          <span className="text-[10px] text-slate-400 dark:text-zinc-400 font-mono">
                            {sub.shortcut}
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
