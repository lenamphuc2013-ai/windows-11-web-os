import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useOS } from '../../context/OSContext';
import { WindowItem } from '../../types';
import { IconRenderer } from '../Common/IconRenderer';
import { FileExplorerApp } from '../Apps/FileExplorerApp';
import { HtmlAppRunner } from '../Apps/HtmlAppRunner';
import { EdgeBrowserApp } from '../Apps/EdgeBrowserApp';
import { TerminalApp } from '../Apps/TerminalApp';
import { NotepadApp } from '../Apps/NotepadApp';
import { CalculatorApp } from '../Apps/CalculatorApp';
import { PaintApp } from '../Apps/PaintApp';
import { StoreApp } from '../Apps/StoreApp';
import { SettingsApp } from '../Apps/SettingsApp';
import { TaskManagerApp } from '../Apps/TaskManagerApp';
import { PhotosApp } from '../Apps/PhotosApp';
import { CopilotApp } from '../Apps/CopilotApp';
import { ClockApp } from '../Apps/ClockApp';
import { MediaPlayerApp } from '../Apps/MediaPlayerApp';
import { VideoPlayerApp } from '../Apps/VideoPlayerApp';
import { CameraApp } from '../Apps/CameraApp';
import { WeatherApp } from '../Apps/WeatherApp';
import { SnippingToolApp } from '../Apps/SnippingToolApp';
import { WindowsSecurityApp } from '../Apps/WindowsSecurityApp';
import { VoiceRecorderApp } from '../Apps/VoiceRecorderApp';
import { MapsApp } from '../Apps/MapsApp';
import { YouTubeApp } from '../Apps/YouTubeApp';
import { PhoneLinkApp } from '../Apps/PhoneLinkApp';
import { XboxApp } from '../Apps/XboxApp';
import { WinverDialog } from '../Apps/WinverDialog';
import { DxDiagDialog } from '../Apps/DxDiagDialog';
import { ControlPanelApp } from '../Apps/ControlPanelApp';
import { Minus, Square, Copy, X } from 'lucide-react';
import { getLocalizedAppName } from '../../utils/appRegistry';

interface WindowContainerProps {
  window: WindowItem;
}

export const WindowContainer: React.FC<WindowContainerProps> = ({ window: win }) => {
  const {
    activeWindowId,
    focusWindow,
    closeWindow,
    minimizeWindow,
    maximizeWindow,
    updateWindowPosition,
    updateWindowSize,
    fileSystem,
    settings,
    t,
  } = useOS();

  const displayTitle =
    win.customData?.windowTitle ||
    win.customData?.appName ||
    win.customData?.fileName ||
    (win.appId ? getLocalizedAppName(win.appId, t) : win.title) ||
    win.title;

  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [isResizing, setIsResizing] = useState<string | null>(null);
  const [resizeStart, setResizeStart] = useState({ x: 0, y: 0, w: 0, h: 0, px: 0, py: 0 });
  const [showSnapMenu, setShowSnapMenu] = useState(false);

  const isActive = activeWindowId === win.id;

  // Window drag handler
  const handleMouseDownHeader = (e: React.MouseEvent) => {
    if (win.isMaximized) return;
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - win.position.x,
      y: e.clientY - win.position.y,
    });
    focusWindow(win.id);
  };

  // Resize handler
  const handleMouseDownResize = (direction: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (win.isMaximized) return;
    setIsResizing(direction);
    setResizeStart({
      x: e.clientX,
      y: e.clientY,
      w: win.size.width,
      h: win.size.height,
      px: win.position.x,
      py: win.position.y,
    });
    focusWindow(win.id);
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        const nextX = Math.max(0, Math.min(window.innerWidth - 100, e.clientX - dragOffset.x));
        const nextY = Math.max(0, Math.min(window.innerHeight - 80, e.clientY - dragOffset.y));
        updateWindowPosition(win.id, nextX, nextY);
      } else if (isResizing) {
        const dx = e.clientX - resizeStart.x;
        const dy = e.clientY - resizeStart.y;
        let newW = resizeStart.w;
        let newH = resizeStart.h;
        let newX = resizeStart.px;
        let newY = resizeStart.py;

        if (isResizing.includes('e')) newW = Math.max(340, resizeStart.w + dx);
        if (isResizing.includes('s')) newH = Math.max(220, resizeStart.h + dy);
        if (isResizing.includes('w')) {
          const possibleW = resizeStart.w - dx;
          if (possibleW > 340) {
            newW = possibleW;
            newX = resizeStart.px + dx;
          }
        }
        if (isResizing.includes('n')) {
          const possibleH = resizeStart.h - dy;
          if (possibleH > 220) {
            newH = possibleH;
            newY = resizeStart.py + dy;
          }
        }

        updateWindowSize(win.id, newW, newH);
        updateWindowPosition(win.id, newX, newY);
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      setIsResizing(null);
    };

    if (isDragging || isResizing) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, isResizing, dragOffset, resizeStart, win.id, updateWindowPosition, updateWindowSize]);

  if (win.isMinimized) return null;

  // Snap Layout Actions
  const handleSnap = (type: 'left' | 'right' | 'top-left' | 'top-right' | 'full') => {
    setShowSnapMenu(false);
    const screenW = typeof window !== 'undefined' ? window.innerWidth : 1200;
    const screenH = typeof window !== 'undefined' ? window.innerHeight - 48 : 700;

    if (type === 'left') {
      updateWindowPosition(win.id, 0, 0);
      updateWindowSize(win.id, Math.floor(screenW / 2), screenH);
    } else if (type === 'right') {
      updateWindowPosition(win.id, Math.floor(screenW / 2), 0);
      updateWindowSize(win.id, Math.floor(screenW / 2), screenH);
    } else if (type === 'top-left') {
      updateWindowPosition(win.id, 0, 0);
      updateWindowSize(win.id, Math.floor(screenW / 2), Math.floor(screenH / 2));
    } else if (type === 'top-right') {
      updateWindowPosition(win.id, Math.floor(screenW / 2), 0);
      updateWindowSize(win.id, Math.floor(screenW / 2), Math.floor(screenH / 2));
    } else {
      maximizeWindow(win.id);
    }
  };

  // Dynamic Window Backdrop Styling (Authentic Windows 11 Mica / Acrylic / Slate)
  const getWindowBackdropClass = () => {
    const backdrop = win.windowBackdrop || 'mica';
    switch (backdrop) {
      case 'acrylic':
        return 'bg-white/80 dark:bg-[#1a1a1a]/85 backdrop-blur-2xl';
      case 'slate':
        return 'bg-[#0f172a] text-slate-100';
      case 'ambient':
        return 'bg-gradient-to-b from-[#18181b]/95 to-[#09090b]/95 backdrop-blur-2xl text-white';
      case 'glow':
        return 'bg-gradient-to-b from-indigo-950/40 via-purple-950/30 to-zinc-950/80 backdrop-blur-2xl';
      case 'canvas':
        return 'bg-[#fcfcfc] dark:bg-[#1f1f1f]';
      case 'mica':
      default:
        return 'bg-[#f3f3f3]/95 dark:bg-[#202020]/95 backdrop-blur-xl';
    }
  };

  // Render Inner Application View
  const renderAppContent = () => {
    const customData = win.customData || win.data;

    switch (win.appId) {
      case 'explorer':
        return <FileExplorerApp initialPath={customData?.initialPath} />;
      case 'edge':
        return <EdgeBrowserApp />;
      case 'terminal':
        return <TerminalApp windowId={win.id} initialMode="powershell" />;
      case 'cmd':
        return <TerminalApp windowId={win.id} initialMode="cmd" />;
      case 'powershell':
        return <TerminalApp windowId={win.id} initialMode="powershell" />;
      case 'notepad':
        return (
          <NotepadApp
            filePath={customData?.filePath}
            fileName={customData?.fileName}
            content={customData?.content || customData?.fileContent}
          />
        );
      case 'calc':
      case 'calculator':
        return <CalculatorApp />;
      case 'paint':
        return <PaintApp />;
      case 'store':
        return <StoreApp />;
      case 'settings':
        return (
          <SettingsApp
            initialSection={
              customData?.initialSection ||
              customData?.section ||
              customData?.tab ||
              'personalization'
            }
          />
        );
      case 'control':
      case 'controlpanel':
        return (
          <ControlPanelApp
            initialPage={customData?.page || customData?.initialPage || customData?.name}
            initialCpl={customData?.cpl || customData?.initialCpl}
            isAdmin={customData?.isAdmin || customData?.admin}
          />
        );
      case 'taskmanager':
      case 'taskmgr':
        return <TaskManagerApp />;
      case 'photos':
        return <PhotosApp filePath={customData?.filePath} fileName={customData?.fileName} />;
      case 'copilot':
        return <CopilotApp />;
      case 'clock':
        return <ClockApp />;
      case 'mediaplayer':
        return <MediaPlayerApp />;
      case 'videoplayer':
      case 'video':
      case 'movies':
        return (
          <VideoPlayerApp
            initialVideoUrl={customData?.videoUrl || customData?.url || customData?.content}
            initialVideoName={customData?.videoName || customData?.fileName || customData?.title}
            filePath={customData?.filePath}
          />
        );
      case 'camera':
        return <CameraApp />;
      case 'weather':
        return <WeatherApp />;
      case 'snippingtool':
        return <SnippingToolApp />;
      case 'security':
      case 'defender':
        return <WindowsSecurityApp />;
      case 'voicerecorder':
      case 'soundrecorder':
        return <VoiceRecorderApp />;
      case 'maps':
        return <MapsApp />;
      case 'youtube':
        return <YouTubeApp />;
      case 'phonelink':
        return <PhoneLinkApp />;
      case 'xbox':
        return <XboxApp />;
      case 'winver':
        return <WinverDialog windowId={win.id} />;
      case 'dxdiag':
        return <DxDiagDialog windowId={win.id} />;
      case 'app-runner': {
        const filePath = customData?.filePath;
        const file = fileSystem.find((f) => f.path === filePath);
        const code = file?.content || customData?.htmlContent || customData?.code || '';
        return (
          <HtmlAppRunner
            code={code}
            appName={win.title}
            filePath={filePath}
          />
        );
      }
      default: {
        const file = fileSystem.find((f) => f.path === customData?.filePath || f.name === win.title);
        if (file && file.isHtmlApp) {
          return (
            <HtmlAppRunner
              code={file.content || ''}
              appName={file.appMetadata?.title || file.name}
              filePath={file.path}
            />
          );
        }
        return (
          <div className="flex flex-col items-center justify-center h-full p-8 text-center text-slate-400">
            <IconRenderer name={win.icon} size={48} className="text-sky-500 mb-3" />
            <h3 className="font-semibold text-slate-200">{win.title}</h3>
            <p className="text-xs text-slate-500 mt-1">Windows 11 Application Active</p>
          </div>
        );
      }
    }
  };

  const stylePosition: React.CSSProperties = win.isMaximized
    ? {
        top: 0,
        left: 0,
        width: '100vw',
        height: 'calc(100vh - 48px)',
        zIndex: win.zIndex,
      }
    : {
        top: `${win.position.y}px`,
        left: `${win.position.x}px`,
        width: `${win.size.width}px`,
        height: `${win.size.height}px`,
        zIndex: win.zIndex,
      };

  return (
    <motion.div
      data-window="true"
      initial={{ opacity: 0, scale: 0.92, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.88, y: 30 }}
      transition={{ type: 'spring', damping: 26, stiffness: 320, mass: 0.8 }}
      onMouseDown={(e) => e.stopPropagation()}
      onClick={() => focusWindow(win.id)}
      style={stylePosition}
      className={`fixed flex flex-col overflow-hidden transition-[box-shadow,border-radius] duration-200 ${
        win.isMaximized ? 'rounded-none' : 'rounded-xl border border-slate-300/80 dark:border-white/10'
      } ${
        isActive
          ? 'shadow-2xl ring-1 ring-black/10 dark:ring-white/15'
          : 'shadow-lg opacity-95'
      } ${getWindowBackdropClass()}`}
    >
      {/* Title Bar with authentic Windows 11 Mica material */}
      <div
        onMouseDown={handleMouseDownHeader}
        onDoubleClick={() => {
          if (win.appId !== 'winver') {
            maximizeWindow(win.id);
          }
        }}
        className={`h-9 px-3 flex items-center justify-between select-none cursor-default ${
          isActive
            ? 'bg-slate-100/80 dark:bg-[#1c1c1c]/90 text-slate-800 dark:text-slate-100'
            : 'bg-slate-200/70 dark:bg-[#222222]/85 text-slate-500 dark:text-zinc-400'
        } backdrop-blur-md border-b border-black/5 dark:border-white/5 transition-colors`}
      >
        {/* App Icon + Title */}
        <div className="flex items-center gap-2 truncate pointer-events-none">
          <IconRenderer name={win.icon} size={15} />
          <span className="text-xs font-semibold tracking-wide truncate">{displayTitle}</span>
        </div>

        {/* Window Controls */}
        <div className="flex items-center h-full -mr-3" onMouseDown={(e) => e.stopPropagation()}>
          {win.appId !== 'winver' && (
            <>
              {/* Nút 1: Thu nhỏ cửa sổ (− Gạch ngang) -> Ẩn cửa sổ vào thanh tác vụ (Taskbar) */}
              <button
                onClick={() => minimizeWindow(win.id)}
                className="w-11 sm:w-12 h-full flex items-center justify-center hover:bg-slate-300/80 dark:hover:bg-zinc-700/80 active:bg-slate-400/80 dark:active:bg-zinc-600/80 text-slate-700 dark:text-slate-200 transition-colors duration-100"
                title={`${t.minimize} (Win + Down)`}
                aria-label={t.minimize}
              >
                <Minus size={13} strokeWidth={1.5} />
              </button>

              {/* Nút 2: Phóng to / Khôi phục kích thước (□ Hình chữ nhật / ❐ 2 ô lồng) + Snap Layouts */}
              <div
                className="relative h-full"
                onMouseEnter={() => setShowSnapMenu(true)}
                onMouseLeave={() => setShowSnapMenu(false)}
              >
                <button
                  onClick={() => maximizeWindow(win.id)}
                  className="w-11 sm:w-12 h-full flex items-center justify-center hover:bg-slate-300/80 dark:hover:bg-zinc-700/80 active:bg-slate-400/80 dark:active:bg-zinc-600/80 text-slate-700 dark:text-slate-200 transition-colors duration-100"
                  title={win.isMaximized ? `${t.restoreDown} (Khôi phục)` : `${t.maximize} (Phóng to)`}
                  aria-label={win.isMaximized ? t.restoreDown : t.maximize}
                >
                  {win.isMaximized ? (
                    /* Biểu tượng 2 hình chữ nhật lồng nhau khi đã phóng to (Restore Down) */
                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" className="shrink-0 text-current">
                      <path d="M2.5 1.5H8.5V7.5" stroke="currentColor" strokeWidth="1.1" strokeLinecap="square" />
                      <rect x="1.5" y="2.5" width="6" height="6" stroke="currentColor" strokeWidth="1.1" />
                    </svg>
                  ) : (
                    /* Biểu tượng 1 hình chữ nhật khi chưa phóng to (Maximize) */
                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" className="shrink-0 text-current">
                      <rect x="0.75" y="0.75" width="8.5" height="8.5" rx="0.5" stroke="currentColor" strokeWidth="1.1" />
                    </svg>
                  )}
                </button>

                {/* Windows 11 Snap Layouts Flyout Menu khi rê chuột vào nút Phóng to */}
                {showSnapMenu && (
                  <div
                    className="absolute top-9 right-0 w-56 bg-white/95 dark:bg-[#202020]/95 backdrop-blur-2xl border border-slate-300 dark:border-zinc-700 rounded-xl shadow-2xl p-2.5 z-50 animate-in fade-in zoom-in-95 duration-150"
                    onMouseEnter={() => setShowSnapMenu(true)}
                    onMouseLeave={() => setShowSnapMenu(false)}
                  >
                    <div className="text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-2 uppercase tracking-wider flex items-center justify-between">
                      <span>{t.snapLayouts}</span>
                      <span className="text-[9px] font-normal text-slate-400 lowercase">Win + Z</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {/* Snap Cột Trái 50% */}
                      <div
                        onClick={() => handleSnap('left')}
                        className="h-12 rounded-lg border border-slate-300 dark:border-zinc-700 hover:bg-sky-500/20 hover:border-sky-500 cursor-pointer flex p-1 group transition-all"
                        title={t.snapLeft}
                      >
                        <div className="w-1/2 bg-sky-500/40 rounded-sm border-r border-sky-500/50 group-hover:bg-sky-500/70 transition-colors" />
                        <div className="w-1/2 bg-slate-200/40 dark:bg-white/5 rounded-sm ml-0.5" />
                      </div>

                      {/* Snap Cột Phải 50% */}
                      <div
                        onClick={() => handleSnap('right')}
                        className="h-12 rounded-lg border border-slate-300 dark:border-zinc-700 hover:bg-sky-500/20 hover:border-sky-500 cursor-pointer flex p-1 group transition-all"
                        title={t.snapRight}
                      >
                        <div className="w-1/2 bg-slate-200/40 dark:bg-white/5 rounded-sm mr-0.5" />
                        <div className="w-1/2 bg-sky-500/40 rounded-sm border-l border-sky-500/50 group-hover:bg-sky-500/70 transition-colors" />
                      </div>

                      {/* Snap Góc Trên Trái 25% */}
                      <div
                        onClick={() => handleSnap('top-left')}
                        className="h-12 rounded-lg border border-slate-300 dark:border-zinc-700 hover:bg-sky-500/20 hover:border-sky-500 cursor-pointer grid grid-cols-2 grid-rows-2 p-1 gap-1 group transition-all"
                        title={t.snapTopLeft}
                      >
                        <div className="bg-sky-500/40 rounded-sm group-hover:bg-sky-500/70 transition-colors" />
                        <div className="bg-slate-200/40 dark:bg-white/5 rounded-sm" />
                        <div className="bg-slate-200/40 dark:bg-white/5 rounded-sm" />
                        <div className="bg-slate-200/40 dark:bg-white/5 rounded-sm" />
                      </div>

                      {/* Snap Góc Trên Phải 25% */}
                      <div
                        onClick={() => handleSnap('top-right')}
                        className="h-12 rounded-lg border border-slate-300 dark:border-zinc-700 hover:bg-sky-500/20 hover:border-sky-500 cursor-pointer grid grid-cols-2 grid-rows-2 p-1 gap-1 group transition-all"
                        title={t.snapTopRight}
                      >
                        <div className="bg-slate-200/40 dark:bg-white/5 rounded-sm" />
                        <div className="bg-sky-500/40 rounded-sm group-hover:bg-sky-500/70 transition-colors" />
                        <div className="bg-slate-200/40 dark:bg-white/5 rounded-sm" />
                        <div className="bg-slate-200/40 dark:bg-white/5 rounded-sm" />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}

          {/* Nút 3: Đóng cửa sổ / Thoát ứng dụng (× Dấu X) -> Chuyển màu đỏ khi hover và đóng hoàn toàn */}
          <button
            onClick={() => closeWindow(win.id)}
            className="w-11 sm:w-12 h-full flex items-center justify-center hover:bg-[#e81123] hover:text-white active:bg-[#c4101f] active:text-white/90 text-slate-700 dark:text-slate-200 transition-colors duration-100"
            title={`${t.closeWindow} (Alt + F4)`}
            aria-label={t.closeWindow}
          >
            <X size={14} strokeWidth={1.5} />
          </button>
        </div>
      </div>

      {/* Window Body Application */}
      <div className="flex-1 overflow-hidden relative">
        {renderAppContent()}
      </div>

      {/* Resize Handles (Only if not maximized and not winver dialog) */}
      {!win.isMaximized && win.appId !== 'winver' && (
        <>
          <div
            onMouseDown={(e) => handleMouseDownResize('n', e)}
            className="absolute top-0 left-0 right-0 h-1.5 cursor-n-resize"
          />
          <div
            onMouseDown={(e) => handleMouseDownResize('s', e)}
            className="absolute bottom-0 left-0 right-0 h-1.5 cursor-s-resize"
          />
          <div
            onMouseDown={(e) => handleMouseDownResize('w', e)}
            className="absolute top-0 bottom-0 left-0 w-1.5 cursor-w-resize"
          />
          <div
            onMouseDown={(e) => handleMouseDownResize('e', e)}
            className="absolute top-0 bottom-0 right-0 w-1.5 cursor-e-resize"
          />
          <div
            onMouseDown={(e) => handleMouseDownResize('nw', e)}
            className="absolute top-0 left-0 w-3 h-3 cursor-nw-resize z-10"
          />
          <div
            onMouseDown={(e) => handleMouseDownResize('ne', e)}
            className="absolute top-0 right-0 w-3 h-3 cursor-ne-resize z-10"
          />
          <div
            onMouseDown={(e) => handleMouseDownResize('sw', e)}
            className="absolute bottom-0 left-0 w-3 h-3 cursor-sw-resize z-10"
          />
          <div
            onMouseDown={(e) => handleMouseDownResize('se', e)}
            className="absolute bottom-0 right-0 w-3 h-3 cursor-se-resize z-10"
          />
        </>
      )}
    </motion.div>
  );
};
