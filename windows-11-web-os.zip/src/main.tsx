import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Gracefully handle benign Vite HMR websocket connection errors in sandboxed environments
if (typeof window !== 'undefined') {
  window.addEventListener('unhandledrejection', (event) => {
    if (
      event.reason &&
      (typeof event.reason.message === 'string' || typeof event.reason === 'string')
    ) {
      const message = event.reason.message || String(event.reason);
      if (
        message.includes('WebSocket') ||
        message.includes('websocket') ||
        message.includes('failed to connect') ||
        message.includes('closed without being opened')
      ) {
        event.preventDefault();
      }
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

