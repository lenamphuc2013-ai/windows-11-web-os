import express, { Request, Response } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// In-memory apps storage on server
const serverApps: Record<string, { title: string; code: string; updatedAt: string }> = {
  'index.html': {
    title: 'Windows 11 Welcome Portal',
    code: `<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Windows 11 Web Portal</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: radial-gradient(circle at 50% 30%, #1e293b, #0f172a, #020617);
      color: #f8fafc;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 24px;
      text-align: center;
    }
    .card {
      background: rgba(30, 41, 59, 0.7);
      backdrop-filter: blur(16px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 24px;
      padding: 40px 32px;
      max-width: 580px;
      width: 100%;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
      animation: fadeIn 0.8s ease-out;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .icon {
      width: 64px;
      height: 64px;
      margin: 0 auto 16px;
      background: linear-gradient(135deg, #0284c7, #38bdf8);
      border-radius: 18px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 32px;
      box-shadow: 0 10px 25px -5px rgba(56, 189, 248, 0.4);
    }
    h1 { font-size: 26px; font-weight: 700; margin-bottom: 8px; color: #ffffff; }
    p { color: #94a3b8; font-size: 14px; line-height: 1.6; margin-bottom: 24px; }
    .btn-group { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
    .btn {
      padding: 12px 24px;
      border-radius: 12px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      text-decoration: none;
      transition: all 0.2s;
      border: none;
    }
    .btn-primary { background: #0284c7; color: white; }
    .btn-primary:hover { background: #0369a1; transform: translateY(-2px); }
    .btn-secondary { background: rgba(255, 255, 255, 0.1); color: #e2e8f0; border: 1px solid rgba(255, 255, 255, 0.1); }
    .btn-secondary:hover { background: rgba(255, 255, 255, 0.2); }
    .stats {
      display: flex;
      justify-content: space-around;
      margin-top: 32px;
      padding-top: 24px;
      border-top: 1px solid rgba(255, 255, 255, 0.1);
    }
    .stat-item h3 { font-size: 20px; color: #38bdf8; font-weight: 700; }
    .stat-item span { font-size: 12px; color: #64748b; }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">💻</div>
    <h1>Windows 11 Live HTML App</h1>
    <p>File <code>index.html</code> này đang được máy chủ Node.js & Express phục vụ trực tiếp. Bạn có thể chỉnh sửa mã nguồn hoặc mở trong tab mới.</p>
    <div class="btn-group">
      <button class="btn btn-primary" onclick="testInteractive()">⚡ Chạy Tác Vụ Mẫu</button>
      <button class="btn btn-secondary" onclick="alert('Đang chạy trực tiếp file index.html!')">ℹ️ Thông Tin</button>
    </div>
    <div class="stats">
      <div class="stat-item">
        <h3 id="click-count">0</h3>
        <span>Lượt Tương Tác</span>
      </div>
      <div class="stat-item">
        <h3>100%</h3>
        <span>HTML5 & JS</span>
      </div>
      <div class="stat-item">
        <h3>Online</h3>
        <span>Máy Chủ Express</span>
      </div>
    </div>
  </div>
  <script>
    let clicks = 0;
    function testInteractive() {
      clicks++;
      document.getElementById('click-count').innerText = clicks;
      console.log('User clicked test button in index.html, total:', clicks);
    }
  </script>
</body>
</html>`,
    updatedAt: new Date().toISOString(),
  },
};

// API: Health check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    os: 'Windows 11 Web Edition',
    serverTime: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

// API: Direct raw HTML runner (serves raw HTML so user can click and run directly)
app.get('/raw/:filename', (req: Request, res: Response) => {
  const filename = req.params.filename;
  const appData = serverApps[filename] || serverApps[`${filename}.html`];
  if (appData) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    return res.send(appData.code);
  }
  res.status(404).send(`<h1>404 Not Found</h1><p>HTML file ${filename} not found on server.</p>`);
});

// API: List server apps
app.get('/api/apps', (req: Request, res: Response) => {
  const list = Object.entries(serverApps).map(([filename, val]) => ({
    filename,
    title: val.title,
    updatedAt: val.updatedAt,
    size: Buffer.byteLength(val.code, 'utf8'),
  }));
  res.json({ success: true, apps: list });
});

// API: Save or update HTML App on server
app.post('/api/apps/save', (req: Request, res: Response) => {
  const { filename, title, code } = req.body;
  if (!filename || !code) {
    return res.status(400).json({ error: 'Missing filename or code' });
  }
  const cleanName = filename.endsWith('.html') ? filename : `${filename}.html`;
  serverApps[cleanName] = {
    title: title || cleanName,
    code,
    updatedAt: new Date().toISOString(),
  };
  res.json({ success: true, filename: cleanName, directUrl: `/raw/${cleanName}` });
});

// API: Copilot AI server-side proxy
app.post('/api/copilot/chat', async (req: Request, res: Response) => {
  const { prompt } = req.body;
  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.json({
      reply: `Máy chủ đã nhận yêu cầu "${prompt}". (Để kích hoạt trí tuệ nhân tạo Gemini nâng cao, vui lòng cấu hình GEMINI_API_KEY trong .env).`,
      generatedApp: null,
    });
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `You are Windows 11 Copilot Assistant. The user asks: "${prompt}".
If the user is asking to build an HTML game/app/widget or code snippet, provide a brief friendly explanation in Vietnamese, followed by a valid self-contained HTML5 code block (\`\`\`html ... \`\`\`).
Otherwise, give a helpful, concise answer about Windows 11 in Vietnamese.`,
    });

    const replyText = response.text || 'Không có phản hồi từ máy chủ AI.';

    // Extract HTML code block if present
    let generatedApp = null;
    const htmlMatch = replyText.match(/```html([\s\S]*?)```/);
    if (htmlMatch) {
      generatedApp = {
        title: 'Copilot Generated App',
        code: htmlMatch[1].trim(),
        category: 'productivity',
      };
    }

    res.json({
      reply: replyText.replace(/```html[\s\S]*?```/, '').trim() || 'Đã tạo xong ứng dụng HTML!',
      generatedApp,
    });
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    res.status(500).json({
      error: 'Failed to communicate with AI',
      details: error.message,
    });
  }
});

// Start Server with Vite Middleware in Development
async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR === 'true' ? false : undefined,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Windows 11 Server running on http://0.0.0.0:${PORT}`);
  });
}

start();
